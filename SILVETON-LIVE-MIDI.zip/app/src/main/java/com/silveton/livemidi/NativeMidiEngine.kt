package com.silveton.livemidi

class NativeMidiEngine {
    companion object {
        init { System.loadLibrary("livemidi") }
    }

    external fun nativeInit()
    external fun nativeHandleMidiIn(status: Int, data1: Int, data2: Int): ByteArray
    external fun nativeClearState()

    init {
        nativeInit()
    }
}
