#include "NativeMidiEngine.h"
// Implementation is intentionally inline in the header so handleMidiIn can be
// unit-tested directly without JNI or Android dependencies.
