#pragma once

#include <array>
#include <cstdint>
#include <unordered_set>

namespace silveton {

struct Midi3 {
    std::uint8_t status{0};
    std::uint8_t data1{0};
    std::uint8_t data2{0};
};

class NativeMidiEngine {
public:
    NativeMidiEngine() { clearState(); }

    /**
     * Tracks U1/U2/U3 note ownership.
     * 0x9n NN 00 is treated exactly as Note Off.
     * The original 3-byte packet is returned unchanged for forwarding.
     */
    Midi3 handleMidiIn(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) {
        status = static_cast<std::uint8_t>(status & 0xFFu);
        data1 = static_cast<std::uint8_t>(data1 & 0x7Fu);
        data2 = static_cast<std::uint8_t>(data2 & 0x7Fu);

        const int command = static_cast<int>(status & 0xF0u);
        const int channel = static_cast<int>(status & 0x0Fu);

        if (channel >= 0 && channel < 3) {
            const int note = static_cast<int>(data1);

            if (command == 0x90 && data2 != 0) {
                activeNotes_[static_cast<std::size_t>(channel)].insert(note);
                lastNote_[static_cast<std::size_t>(channel)] = note;
            } else if (command == 0x80 || (command == 0x90 && data2 == 0)) {
                auto& notes = activeNotes_[static_cast<std::size_t>(channel)];
                notes.erase(note);
                if (lastNote_[static_cast<std::size_t>(channel)] == note) {
                    lastNote_[static_cast<std::size_t>(channel)] = notes.empty() ? -1 : *notes.begin();
                }
            } else if (command == 0xB0 && (data1 == 120 || data1 == 123)) {
                clearChannel(channel);
            }
        }

        return Midi3{status, data1, data2};
    }

    void clearChannel(int upper) {
        if (upper < 0 || upper > 2) return;
        activeNotes_[static_cast<std::size_t>(upper)].clear();
        lastNote_[static_cast<std::size_t>(upper)] = -1;
    }

    void clearState() {
        for (int upper = 0; upper < 3; ++upper) clearChannel(upper);
    }

    bool isActive(int upper, int note) const {
        if (upper < 0 || upper > 2 || note < 0 || note > 127) return false;
        const auto& notes = activeNotes_[static_cast<std::size_t>(upper)];
        return notes.find(note) != notes.end();
    }

    int lastNote(int upper) const {
        if (upper < 0 || upper > 2) return -1;
        return lastNote_[static_cast<std::size_t>(upper)];
    }

private:
    std::array<std::unordered_set<int>, 3> activeNotes_{};
    std::array<int, 3> lastNote_{{-1, -1, -1}};
};

} // namespace silveton
