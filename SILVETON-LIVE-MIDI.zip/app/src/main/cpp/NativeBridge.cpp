#include <jni.h>
#include <memory>
#include "NativeMidiEngine.h"

namespace {
std::unique_ptr<silveton::NativeMidiEngine> gEngine;

silveton::NativeMidiEngine& engine() {
    if (!gEngine) gEngine = std::make_unique<silveton::NativeMidiEngine>();
    return *gEngine;
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeInit(JNIEnv*, jobject) {
    gEngine = std::make_unique<silveton::NativeMidiEngine>();
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeHandleMidiIn(
    JNIEnv* env, jobject, jint status, jint data1, jint data2) {

    const auto out = engine().handleMidiIn(
        static_cast<std::uint8_t>(status & 0xFF),
        static_cast<std::uint8_t>(data1 & 0x7F),
        static_cast<std::uint8_t>(data2 & 0x7F));

    const jbyte raw[3] = {
        static_cast<jbyte>(out.status),
        static_cast<jbyte>(out.data1),
        static_cast<jbyte>(out.data2)
    };
    jbyteArray result = env->NewByteArray(3);
    if (result != nullptr) env->SetByteArrayRegion(result, 0, 3, raw);
    return result;
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeClearState(JNIEnv*, jobject) {
    engine().clearState();
}
