# SILVETON LIVE MIDI

Android MIDI controller for KORG PA-series. Current PORTAMENTO + TERCA logic is a clean-room implementation based on static reverse engineering of the user-supplied MasterKey 5.01 FREE binary; no original MasterKey source code is present or copied.

## Safe start
Opening/reconnecting does **not** write Pitch Bend Range/RPN, CC5/CC65, transpose or octave. PORTA and TERCA start runtime-OFF each app session.

## PORTAMENTO
- `MasterKeyPortamento.kt`
- 14-bit Pitch Bend glide with 1 ms update cadence and elapsed-time completion.
- Same requested TIME for different intervals.
- Legato/last-note-priority state is per MIDI channel.
- Physical joystick/ribbon Pitch Bend is retained as the base component while the temporary glide offset is added.
- PB Range in Settings is **LOCAL REFERENCE ONLY** (1–12); it is never transmitted to the KORG.
- Tap the PORTAMENTO TIME digits to enter 1–5000 ms with the Android numeric keyboard.

## TERCA
- `TercaEngine.kt`
- Exact 48-byte interval table recovered from `MasterKey.exe` at VA `0x4C866A`.
- Exact 48 scan masks at VA `0x4C869C` and root/mode table at VA `0x4C875C`.
- Low mode raw `+8/+9` pitch-class values are intentionally rendered as `-4/-3` so no extra octave is introduced.
- TERCA output is UPPER 3 only and emits Note On/Off only.
- SCAN consumes three C4+ notes, blinks in the UI, and sends transient CC123 All Notes Off to UPPER1/2/3 while scanning so the scan chord does not hang/ring.

## Live zone
C4 / MIDI 60 and above: PORTAMENTO + TERCA.  B3 / MIDI 59 and below: bypassed for the left-hand/chord zone.
