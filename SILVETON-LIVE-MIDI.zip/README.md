# PA600 strict low-level fix

Core guarantees:
- U1/U2/U3 are zero-based 0/1/2 internally.
- Note On velocity 0 is treated as Note Off in Kotlin and C++.
- Every generated MIDI message is exactly 3 bytes.
- PA600 native portamento order is CC#5 -> CC#65 -> Note On.
- Terca is U1 main + U3 third. U2 remains untouched.
- Panic explicitly releases tracked notes, sends CC123 + CC120, clears activeNotes and lastNote.
- Pitch Bend is 14-bit, LSB first then MSB.
- Android ABI filter is arm64-v8a only.


Exact TERCA + native portamento byte flow for C4(60), major third, velocity 100, time 64:
- B0 05 40
- B0 41 7F
- B2 05 40
- B2 41 7F
- 90 3C 64
- 92 40 64
