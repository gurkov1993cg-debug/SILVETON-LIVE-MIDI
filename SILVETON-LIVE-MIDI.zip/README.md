# Silveton LIVE MIDI

Native Android live MIDI control application for KORG PA-series keyboards.

Mandatory compatibility range:

- PA600
- PA700
- PA900
- PA1000
- PA4X
- PA5X

The project uses Kotlin for the Android shell/transport and an independent C++17 MIDI/control core. No JUCE is used.

## Core build and tests

```bash
cmake -S core -B build-core -DSILVETON_LIVE_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-core -j
ctest --test-dir build-core --output-on-failure
```

The CI also runs AddressSanitizer + UndefinedBehaviorSanitizer tests.

## Android target

- minSdk 23 (Android 6.0; Android MIDI API baseline)
- target/compile SDK 35
- Kotlin + Android MIDI API
- C++17 via NDK/CMake
- arm64-v8a, armeabi-v7a and x86_64

## Compatibility rule

Model-specific behavior is never presented as hardware-verified merely because a generic MIDI message exists. The project separates:

- `GenericMidi`
- `Documented`
- `Verified`
- `Unsupported`

Portamento milliseconds are similarly separated from the raw 0..127 KORG Portamento Time control. Per-model measured calibration tables can be installed without changing the UI or MIDI engine.


## Live safety invariants

- Native core access is serialized across Android UI and MIDI callback threads.
- App-side glide tails are cancellable; stale scheduled bends are not left in the Android MIDI queue.
- PANIC/disconnect flush generated interval, pad and portamento state before All Sound Off/All Notes Off.
- Hardware portamento is forced off while the application-side TIMES engine owns the glide, avoiding double-glide behavior.
- Harmony/chromatic intervals reference-count overlapping generated pitches so one source NoteOff cannot cut a note still needed by another source.
- TERCA uses Juzisound-style three-note scanning: the scan chord selects tonic/mode/direction in all 12 tonalities, scan notes are consumed by the app, ON/OFF remains independent from scanning, and the generated terca is routed only to Upper 3. See `docs/TERCA.md`.
- PORTA, TERCA and RIBBON can run separately or together. App-side PORTA and Pitch Bend RIBBON are combined through a single 14-bit Pitch Bend mixer instead of overwriting each other.

## Hardware calibration

The Android settings screen includes a per-model Portamento Calibration editor. Measured points are entered as `CC=milliseconds`, stored independently for each PA model, and applied by the native engine. MIDI Identity Reply data is parsed and shown for connection diagnostics, but model-number mappings are not guessed.

### Effect isolation
PORTA, TERCA, RIBBON and PADS keep independent runtime state. Effect buttons do not reconfigure other effects. PORTA is permanently armed on UPPER 1/2/3, TERCA generates notes only on UPPER 3, and RIBBON keeps its own routing. The final Pitch Bend mixer only combines control values when two independent effects share a physical MIDI channel.

### PORTA custom milliseconds

The `CUSTOM · MS` keypad is an exact app-side timing control. Pressing `OK` automatically selects the internal `CUSTOM` portamento law and `TIMES`; the entered value (1–5000 ms) is the total glide duration for every interval. Preset buttons remain mode-dependent controls.



### Upper mute safety
App-side PORTA is control-only for the main melody: it derives its glide from incoming right-hand notes and sends Pitch Bend to all three Upper channels. There are no per-Upper PORTA target buttons. It never sends main Note On/Off messages, so a KORG Upper muted by the current Sound/Performance remains muted. TERCA remains an independent generated-note path on Upper 3.
### Keyboard-state safety
Launching/connecting the app is passive: no automatic CC5/CC65, RPN Pitch Bend Sensitivity, Program Change, or track Play/Mute writes are sent. PORTA and TERCA start OFF each app session.


### Connection indicator
The UI connection badge is driven by the real Android MIDI transport state. A usable open MIDI output to the keyboard is shown in green as CONNECTED. No usable connection is shown in red as DISCONNECTED. A failed send on a dead USB/MIDI port forces the transport back to disconnected state so the badge cannot remain falsely green.
