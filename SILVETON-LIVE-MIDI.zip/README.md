# Silveton LIVE MIDI

Native Android live MIDI control application for KORG PA-series keyboards.

Mandatory compatibility range:

- PA600
- PA700
- PA900
- PA1000
- PA4X
- PA5X

The project uses Kotlin for the Android shell/transport and an independent C++17 MIDI/control core. No JUCE is used.

## Core build and tests

```bash
cmake -S core -B build-core -DSILVETON_LIVE_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-core -j
ctest --test-dir build-core --output-on-failure
```

The CI also runs AddressSanitizer + UndefinedBehaviorSanitizer tests.

## Android target

- minSdk 23 (Android 6.0; Android MIDI API baseline)
- target/compile SDK 35
- Kotlin + Android MIDI API
- C++17 via NDK/CMake
- arm64-v8a, armeabi-v7a and x86_64

## Compatibility rule

Model-specific behavior is never presented as hardware-verified merely because a generic MIDI message exists. The project separates:

- `GenericMidi`
- `Documented`
- `Verified`
- `Unsupported`

Portamento milliseconds are similarly separated from the raw 0..127 KORG Portamento Time control. Per-model measured calibration tables can be installed without changing the UI or MIDI engine.


## Live safety invariants

- Native core access is serialized across Android UI and MIDI callback threads.
- App-side glide tails are cancellable; stale scheduled bends are not left in the Android MIDI queue.
- PANIC/disconnect flush generated interval, pad and portamento state before All Sound Off/All Notes Off.
- Hardware portamento is forced off while the application-side TIMES engine owns the glide, avoiding double-glide behavior.
- Harmony/chromatic intervals reference-count overlapping generated pitches so one source NoteOff cannot cut a note still needed by another source.

## Hardware calibration

The Android settings screen includes a per-model Portamento Calibration editor. Measured points are entered as `CC=milliseconds`, stored independently for each PA model, and applied by the native engine. MIDI Identity Reply data is parsed and shown for connection diagnostics, but model-number mappings are not guessed.
