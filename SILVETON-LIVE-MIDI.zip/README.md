# Silveton LIVE MIDI

Native Android live MIDI control application for KORG PA-series keyboards. Kotlin handles the Android UI/transport and a C++17 core remains for model/Ribbon/Pads/MIDI utilities. No JUCE is used.

Supported target profiles in the project: PA600, PA700, PA900, PA1000, PA4X and PA5X. Physical behavior is not called verified for a model until tested on that hardware.

## Current live architecture

- Separate pages: PADS, PORTA, TERCA, RIBBON, plus SETTINGS.
- Default routing: UPPER 1 = CH1, UPPER 2 = CH2, UPPER 3 = CH3.
- C4 / MIDI 60 and above is the PORTA + TERCA performance zone; B3 / 59 and below bypasses those effect paths.
- PORTA is KORG-native: CC5 Time + CC65 Switch only. The old app-side Pitch Bend Portamento stack has been physically removed from the source tree.
- TERCA is a dedicated note-only UPPER 3 engine. The old general harmony/interval engines have been physically removed.
- RIBBON remains an independent Pitch Bend/CC module.

## SAFE START

Opening the app or reconnecting MIDI does not automatically send CC5/CC65, Pitch Bend Range/RPN, transpose, octave, Program Change or track Play/Mute. PORTA and TERCA start runtime-OFF each app session.

A Universal MIDI Identity Request may be sent after connect; it does not alter the current sound/performance.

## PORTA

`KorgNativePortamento.kt` emits only CC5 and CC65 on explicitly selected UPPER channels. It never emits Pitch Bend, so it cannot replace the PA600 joystick/bend stream.

Manual Time accepts 1–5000: tap the number, enter digits with Android's numeric keyboard and press Done. The millisecond display is currently an app control scale mapped monotonically to CC5; it is not yet a measured guarantee of equal physical travel time for every interval.

See `docs/NATIVE-PORTAMENTO.md`.

## TERCA

`TercaEngine.kt` emits only generated Note On/Off on UPPER 3. The generated voice is the nearest third (+3/+4 or -3/-4 semitones), never an added octave. TERCA SCAN works from three pitch classes and uses transient CC123 while scanning so the scan chord does not hang.

See `docs/TERCA.md`.

## Core build/tests

```bash
cmake -S core -B build-core -DSILVETON_LIVE_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-core -j
ctest --test-dir build-core --output-on-failure
```

## Android target

- minSdk 23
- compile/target SDK 35
- Kotlin + Android MIDI API
- C++17 via NDK/CMake
- arm64-v8a, armeabi-v7a and x86_64
