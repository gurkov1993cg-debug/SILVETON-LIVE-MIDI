# SILVETON LIVE MIDI

Android MIDI controller for KORG PA-series.

PORTAMENTO and TERCA use SILVETON's own implementation and musical/MIDI logic.

## Safe start
Opening/reconnecting does **not** send PORTAMENTO or TERCA setup. Both start runtime-OFF each app session. Pitch Bend Sensitivity RPN is sent only after the user explicitly turns PORTAMENTO ON.

## PORTAMENTO
- `SmoothPortamento.kt`
- Own 14-bit Pitch Bend glide engine with a dedicated timer thread.
- Time-domain interpolation: 1-semitone and 12-semitone transitions finish in the same requested TIME.
- Smoothstep curve for soft start/end without changing total duration.
- Short note-release memory keeps normal non-overlapped melody playing usable.
- Physical joystick/ribbon Pitch Bend remains the base component while the temporary glide offset is added.
- When PORTAMENTO is explicitly enabled, RPN 0 aligns the selected KORG Upper channel(s) to the configured PB range (1–12 semitones).
- No CC5/CC65, transpose, octave, Program Change, or Sound selection is used by the SILVETON glide engine.

## TERCA
- `TercaEngine.kt`
- Own scale-aware diatonic-third logic; no recovered interval/mask tables.
- Generated harmony is always the nearest `+3/+4` semitones (UP) or `-3/-4` semitones (DOWN). No hidden octave displacement.
- TERCA output is UPPER 3 only and emits Note On/Off only.
- SCAN recognizes three-note musical signatures:
  - major triad -> MAJOR
  - minor triad -> HARMONIC MINOR
  - root + b2 + 3 -> HIJAZ
- Root in the highest scanned voice selects THIRD DOWN; otherwise THIRD UP.
- SCAN consumes only right-hand notes and does not play the scan chord.

## Live zone
C4 / MIDI 60 and above: PORTAMENTO + TERCA.
B3 / MIDI 59 and below: hard bypass for the left-hand/chord zone.
