# Silveton LIVE MIDI

Native Android live MIDI control application for KORG PA-series keyboards, with Kotlin Android transport/UI and an independent C++17 MIDI/control core. No JUCE is used.

Supported-target profiles in the project: PA600, PA700, PA900, PA1000, PA4X and PA5X. Model-specific behaviour is not called hardware-verified until it has been confirmed on the physical keyboard.

## Current live architecture

- Separate pages for PADS, PORTA, TERCA and RIBBON.
- Default routing: UPPER 1 = CH1, UPPER 2 = CH2, UPPER 3 = CH3.
- C4 / MIDI 60 and above is the PORTA + TERCA performance zone; B3 / 59 and below bypasses those effects.
- TERCA is a single generated third on UPPER 3 with no octave offset.
- RIBBON remains an independent Pitch Bend/CC module.

## SAFE START

Opening the app or reconnecting MIDI does not change the current KORG performance state. The controller does not automatically send Pitch Bend Range, CC65/CC5 portamento state, transpose, octave, Program Change or track Play/Mute changes. PORTA and TERCA start runtime-OFF in every app session.

A Universal MIDI Identity Request may be sent for connection identification; it does not change the keyboard's sound/performance state.

## SMART PORTAMENTO

The current Portamento engine is an independent implementation of the equal-time stepping principle observed in the user-supplied MasterKey 5.01 reference application:

- FIX uses a fixed **total time** in milliseconds.
- Interval distance changes the Pitch Bend span/step size, not the FIX duration.
- Manual `CUSTOM · MS` entry accepts 1–5000 ms. Tap the number, enter digits with Android's numeric keyboard, press Done.
- Last-note-priority held-note tracking gives legato behaviour and allows a glide back to the previously held note.
- In-flight glide tails are replaceable/cancellable per MIDI channel.
- The app never changes the KORG Pitch Bend Range automatically. The settings value is only a local reference and must match the keyboard's existing range.

See `docs/SMART-PORTAMENTO.md`.

## TERCA SCAN

TERCA SCAN uses a three-pitch-class control gesture. Supported cells are checked in all 12 tonalities and the same cell can be recognized across octave displacement/inversion. While scan is active the SCAN control flashes and transient CC123 All Notes Off is sent to the three UPPER channels to stop the scan chord from hanging. Scan does not change octave/transpose/program state.

## Core build and tests

```bash
cmake -S core -B build-core -DSILVETON_LIVE_BUILD_TESTS=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-core -j
ctest --test-dir build-core --output-on-failure
```

The core regression suite includes equal-time FIX checks for 1-semitone versus 12-semitone glides and TERCA scan inversion/octave-displacement checks.

## Android target

- minSdk 23
- compile/target SDK 35
- Kotlin + Android MIDI API
- C++17 via NDK/CMake
- arm64-v8a, armeabi-v7a and x86_64
