# CMake generated Testfile for 
# Source directory: /mnt/data/SilvetonLiveMIDI/core
# Build directory: /mnt/data/SilvetonLiveMIDI/build-core
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[core]=] "/mnt/data/SilvetonLiveMIDI/build-core/silveton_live_midi_core_tests")
set_tests_properties([=[core]=] PROPERTIES  _BACKTRACE_TRIPLES "/mnt/data/SilvetonLiveMIDI/core/CMakeLists.txt;47;add_test;/mnt/data/SilvetonLiveMIDI/core/CMakeLists.txt;0;")
