# TERCA

The live TERCA page intentionally has only two controls:

- **TERCA ON/OFF** — enables or disables the generated third.
- **SCAN** — arms three-note scan. The three held notes are control input and are not forwarded by the app while scanning.

A valid scan selects tonic, scale/mode and third direction. Scanning does **not** force TERCA on or off; the ON/OFF button remains authoritative.

TERCA output is hard-routed to **UPPER 3 only**. No generated TERCA note is sent to UPPER 1, UPPER 2, the input channel, or any legacy harmony voice. PORTA is always armed on UPPER 1/2/3; while TERCA is ON, UPPER 3 carries the generated TERCA note and PORTA shapes that note independently.

The six supported scan cells are transposed identically through all 12 tonalities:

- 0,4,7 — natural major, third up
- 0,2,4 — natural major, third down
- 0,3,7 — natural minor, third up
- 0,2,3 — natural minor, third down
- 0,1,3 — phrygian, third up
- 0,1,4 — Hijaz, third up

PORTA, TERCA and RIBBON are independent. App-side PORTA and Pitch Bend RIBBON share one MIDI Pitch Bend stream through a mixer so they can operate simultaneously instead of overwriting each other.

## Upper 3 mute integrity

TERCA is hard-routed to **UPPER 3** but is not allowed to change the KORG track state. The Android controller only transmits TERCA Note On/Off data on the configured U3 MIDI channel; Program Change, CC and Play/Mute messages are rejected from the TERCA output path.

On KORG PA instruments, enable **GLOBAL > MIDI > MIDI In Controls > Track Mute Active = ON**. With this keyboard setting, a Keyboard Set/Performance that has U3 muted remains unchanged and U3 stays silent. When the player manually unmutes U3, the already-enabled TERCA can sound immediately.
