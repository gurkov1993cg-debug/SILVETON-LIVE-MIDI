# TERCA

TERCA is now a dedicated note-only engine.

- Output is fixed to UPPER 3.
- It emits only Note On / Note Off for the generated third.
- It never emits CC, Pitch Bend, RPN, transpose, octave, Program Change, or Play/Mute commands.
- Generated notes are always the nearest third: +3/+4 semitones for THIRD UP or -3/-4 for THIRD DOWN. There is no +12/-12 octave offset.
- Input-note -> generated-note tracking guarantees that Note Off releases the exact generated note and overlapping notes use reference counting.

TERCA SCAN consumes a three-note pitch-class gesture. Octave placement and inversion do not change the pitch-class comparison. While scan is armed the SCAN indicator flashes and transient CC123 All Notes Off is sent to UPPER 1/2/3 so the scan chord does not hang. CC123 does not change Program, transpose, octave, volume, or Keyboard Set state.

C4 / MIDI 60 and above is the TERCA performance zone. B3 / MIDI 59 and below is reserved for the arranger/chord section.
