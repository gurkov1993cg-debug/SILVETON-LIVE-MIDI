# TERCA

The live TERCA page intentionally has only two controls:

- **TERCA ON/OFF** — enables or disables the generated third.
- **SCAN** — arms three-note scan. The three held notes are control input and are not forwarded by the app while scanning.

A valid scan selects tonic, scale/mode and third direction. Scanning does **not** force TERCA on or off; the ON/OFF button remains authoritative.

TERCA output is fixed to **UPPER 3**. While TERCA is ON, UPPER 3 is reserved for the generated harmony voice and cannot also be selected as a main portamento target.

The six supported scan cells are transposed identically through all 12 tonalities:

- 0,4,7 — natural major, third up
- 0,2,4 — natural major, third down
- 0,3,7 — natural minor, third up
- 0,2,3 — natural minor, third down
- 0,1,3 — phrygian, third up
- 0,1,4 — Hijaz, third up

PORTA, TERCA and RIBBON are independent. App-side PORTA and Pitch Bend RIBBON share one MIDI Pitch Bend stream through a mixer so they can operate simultaneously instead of overwriting each other.
