# TERCA

TERCA is a dedicated note-only UPPER 3 harmony engine.

- It emits only generated Note On / Note Off.
- It never emits CC, Pitch Bend, RPN, transpose, octave, Program Change, or Play/Mute commands.
- Harmony is scale-aware and always stays at the nearest musical third: +3/+4 semitones for THIRD UP or -3/-4 for THIRD DOWN.
- There is no +12/-12 octave offset in the harmony calculation.
- Input-note -> generated-note tracking guarantees that Note Off releases the exact generated note; overlapping notes use reference counting.

## SCAN
SCAN consumes three right-hand notes (C4/MIDI 60 or above):

- root + major 3rd + perfect 5th -> MAJOR
- root + minor 3rd + perfect 5th -> HARMONIC MINOR
- root + minor 2nd + major 3rd -> HIJAZ

The signature is recognized in any inversion. If the tonic is the highest of the three played notes, TERCA direction becomes DOWN; otherwise it is UP.

B3 / MIDI 59 and below is reserved for the arranger/chord section and is hard-bypassed before SCAN or harmony processing.
