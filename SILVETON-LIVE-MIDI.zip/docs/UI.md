# Silveton LIVE MIDI UI contract

The live UI has four functional pages plus Settings:

- PADS
- PORTA
- TERCA
- RIBBON
- SETTINGS

Every visible interactive control must have a real controller/MIDI action. Passive status such as `KORG NATIVE` is displayed as text, not as a disabled fake button.

## PORTA

- ON/OFF
- U1/U2/U3 target switches
- Time presets
- Manual Time numeric field: tap the digits, Android numeric keyboard opens, enter 1–5000, press Done

There are no legacy LIN/FIB/REAL/depth/TIMES controls in the clean native-Portamento version.

## TERCA

- TERCA ON/OFF
- SCAN 3 NOTES
- status/scan feedback

## Ribbon

Ribbon is independent from Portamento. In Pitch Bend mode it controls the keyboard bend stream without a Portamento mixer rewriting it.
