# Silveton LIVE MIDI UI contract

The approved live-controller visual direction is locked to `docs/reference/silveton-live-midi-porta.png`.

Implementation rules:

- Landscape-first Android live surface.
- Header: SILVETON LIVE MIDI, model selector, CONNECT, MON, PRESET and PANIC.
- Primary navigation: PADS, PORTA, INTERVAL, RIBBON, SETTINGS.
- Dark graphite/carbon surface with restrained accent families: amber=PADS/time, violet=PORTA page, cyan=INTERVAL, blue=RIBBON/modes, green=enabled live targets, red=PANIC.
- Controls are large enough for stage use and show state by fill/border, not by text alone.
- No decorative control is allowed. Every visible button, toggle, selector, pad and touch ribbon must have a real action path into the controller/native MIDI engine.
- PORTA is the reference layout: ON + U1/U2/U3 + TIMES + FIX/LIN/FIB/REAL, five time cards, depth +/- and an always-visible custom-ms keypad.
- The K button shown in the external visual reference is intentionally not implemented until its MIDI/behavior contract is known; this prevents a dead or invented control.
- UI must remain usable on smaller landscape tablets/phones by weighted layouts rather than a fixed pixel canvas.


## Ribbon

Ribbon is spring-centred: releasing the touch always returns both the visual thumb and MIDI output to the exact centre. The touch surface and thumb are deliberately oversized for live use.
