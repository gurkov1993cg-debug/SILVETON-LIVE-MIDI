# UI

No layout redesign is introduced by the SILVETON PORTAMENTO/TERCA rewrite.
PORTAMENTO TIME is an editable numeric field: tap the digits, type 1–5000 ms with the Android numeric keyboard, press Done.
The TERCA SCAN control blinks while armed.
All visible controls are wired to working state/actions.
