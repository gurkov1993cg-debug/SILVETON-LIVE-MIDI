# MasterKey 5.01 clean-room integration

Source basis: user-supplied MasterKey.exe disassembly. No original source code is present or copied.

CONFIRMED observations used:
- Portamento speed byte at VA 0x4F281A; UI increment caps at 250 (0xFA), code at 0x405851..0x405860.
- Glide calculation at 0x406247..0x40629B computes absolute delta and integer-divides by the speed value.
- TERCA scan at 0x406418..0x406444 normalizes note modulo 12, ORs a pitch-class bit into mask 0x4F2D98 and waits for 3 notes.
- 48 scan masks begin VA 0x4C869C; packed root/mode results begin VA 0x4C875C.
- TERCA interval table begins VA 0x4C866A and is indexed mode*12 + relative pitch class at 0x406009..0x40601A.

SILVETON design constraint:
- MasterKey rows containing +8/+9 are rendered as -4/-3 (same pitch class) so low TERCA never adds an octave.
- Android UI milliseconds are mapped to the number of 1ms glide ticks; no PA600 RPN, pitch-bend-range, transpose, octave, CC5 or CC65 is sent at connect/start.
