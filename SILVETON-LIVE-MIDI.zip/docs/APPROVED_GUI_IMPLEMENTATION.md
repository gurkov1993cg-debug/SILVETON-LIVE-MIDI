# Approved GUI implementation

Implemented from `docs/reference/approved-silveton-live-midi-gui.png`.

Active HOME surface now contains:
- SILVETON LIVE MIDI header and HOME / UPPERS / EFFECTS / MIDI / SETTINGS navigation.
- KORG model selector and real MIDI connection status.
- One-octave scale keyboard wired to the existing harmony key/scale engine.
- USER SCALE section with live scale-type and key selection. Controls requiring unconfirmed per-model tuning mappings remain disabled rather than faked.
- GLOBAL PORTAMENTO (ALL UPPERS) with real enable, curve/mode and millisecond time controls.
- TERCA with real SCAN TERCA and ON/OFF actions.
- RIBBON (GLOBAL) wired to the existing real ribbon MIDI engine.

Connection indication is driven by `LiveMidiController.State.connected` only:
- Connected -> green `MIDI Connected`
- Disconnected -> red `MIDI Disconnected`

The previous PADS / PORTA / TERCA / RIBBON navigation is no longer the active main surface.
