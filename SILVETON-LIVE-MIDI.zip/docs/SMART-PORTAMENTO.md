# SMART PORTAMENTO

This build uses an independently implemented equal-time Pitch Bend glide inspired by the behaviour observed in the user-supplied MasterKey 5.01 reference program. No MasterKey executable/code is included or copied.

## Safety / PA state

- App startup and MIDI reconnect do **not** send RPN Pitch Bend Range, CC65 Portamento Switch, CC5 Portamento Time, transpose, octave, Program Change, or track state.
- SMART PORTA starts OFF for every app session. Saved mode/time values are only recalled as local preferences.
- The `Pitch bend range reference` setting is a local mathematical reference only. The app does not write that range to the KORG.

## Equal-time FIX mode

- The entered `CUSTOM · MS` value is the total glide time.
- FIX computes the required start bend from the played interval and returns to center over exactly that duration.
- A larger interval therefore uses larger 14-bit Pitch Bend steps; it does not receive a longer FIX duration.
- The C++ regression test checks that a 1-semitone and a 12-semitone FIX glide end on the same timestamp.
- Glide generation is cancelled/replaced immediately when a newer transition takes ownership of the same MIDI channel.

Important physical constraint: the KORG's already-configured Pitch Bend range must be large enough for the requested interval. The app intentionally does not change it automatically.

## Legato behaviour

The monophonic bridge keeps a last-note-priority held-note stack. A glide occurs while moving between overlapping held notes. If the active note is fully released and no note is held, the next note starts without a glide.

## C4 performance firewall

- MIDI 60 / C4 and above: SMART PORTA + TERCA performance zone.
- MIDI 59 / B3 and below: bypassed by the live effects.

## TERCA interaction

- TERCA is a separate module and generates only one harmony voice on UPPER 3.
- TERCA uses `octaves = 0`; it never deliberately adds an octave to the generated third.
- When TERCA and SMART PORTA are both ON, generated UPPER 3 notes use their own U3 portamento bridge. U1/U2 remain on the main-note bridge.
- TERCA SCAN is a three-pitch-class gesture. The scanner ignores octave placement/inversion of the same three pitch classes for the supported scan cells.
- While SCAN is armed, the UI flashes and CC123 (All Notes Off) is sent transiently to U1/U2/U3 to stop the scan chord from hanging/sounding. It does not change volume, program, transpose, or octave.
