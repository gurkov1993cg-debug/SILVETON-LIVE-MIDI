# Silveton LIVE MIDI — current architecture

Main path:

`Android UI -> LiveMidiController -> Android MIDI transport -> KORG PA`

The native C++17 core remains for model profiles, Ribbon, Pads, panic, MIDI parsing/identity and latency utilities. Portamento and TERCA no longer use the old C++ Pitch-Bend/harmony engines.

## Portamento

`KorgNativePortamento.kt` is the only Portamento message generator. It can emit only:

- CC5 — Portamento Time
- CC65 — Portamento Switch

There is no app-side Pitch Bend glide, bridge-note scheduler, Pitch Bend mixer, RPN bend-range writer, transpose, or octave manipulation in the Portamento path.

## TERCA

`TercaEngine.kt` is the only generated-third engine. It emits note messages only on UPPER 3 and generates the nearest musical third (+3/+4 or -3/-4 semitones). There are no legacy hidden harmony voices or octave offsets.

## Safe start

Opening the app and MIDI reconnect do not write CC5/CC65, Pitch Bend Range, transpose, octave, Program Change, or UPPER Play/Mute state. PORTA and TERCA runtime state starts OFF.

A Universal MIDI Identity Request can be sent after connect; it does not alter the current sound/performance.

## Isolation

- PORTA owns only CC5/CC65 for its selected UPPER channels.
- TERCA owns generated Note On/Off on UPPER 3.
- RIBBON owns its own Pitch Bend/CC output and is not mixed with Portamento.
- PADS remain independent.
- C4 / MIDI 60 and above reaches the live PORTA/TERCA zone; B3 / 59 and below is bypassed by those effect paths.
- TERCA SCAN uses transient CC123 All Notes Off only while scanning to silence the scan chord.
