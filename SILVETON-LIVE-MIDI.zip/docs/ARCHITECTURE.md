# Architecture

PORTAMENTO and TERCA are independent SILVETON Kotlin state machines.

- PORTAMENTO: `SmoothPortamento.kt`; 14-bit Pitch Bend glide with absolute time-domain interpolation and short retrigger memory. RPN 0 is emitted only when PORTAMENTO is explicitly enabled so the KORG track PB sensitivity matches the configured range.
- TERCA: `TercaEngine.kt`; note-only UPPER3 smart-third harmony based on tonic + scale + direction. It never emits transpose/octave/RPN/Pitch Bend.
- RIBBON: existing native/core Ribbon engine; when it outputs Pitch Bend while PORTA is active, its value is routed through the PORTA physical-bend base component instead of fighting the glide.
- Startup/reconnect is neutral: no PORTA/TERCA state is pushed to the keyboard until the user enables a function.
- Performance split firewall is before both engines: B3/59 and below never enters TERCA scan, TERCA generation, or PORTAMENTO state.
