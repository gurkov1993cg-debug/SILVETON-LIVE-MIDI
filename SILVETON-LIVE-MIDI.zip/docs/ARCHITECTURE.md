# Architecture

PORTAMENTO and TERCA are independent Kotlin state machines.

- PORTAMENTO: `MasterKeyPortamento.kt`; 14-bit Pitch Bend glide. No RPN/CC5/CC65/transpose/octave writes.
- TERCA: `TercaEngine.kt`; note-only UPPER3 harmony using recovered MasterKey tables.
- RIBBON: existing native/core Ribbon engine; when it outputs Pitch Bend while PORTA is active, its value is routed through the PORTA base component instead of fighting the glide.
- Startup/reconnect is neutral: no persistent keyboard-state mutation.
