# Keyboard setup for Silveton LIVE MIDI

## Default channel plan

- Right-hand / performance input: CH1
- UPPER 1 output: CH1
- UPPER 2 output: CH2
- UPPER 3 output: CH3
- TERCA output: UPPER 3 only
- MIDI THRU: normally OFF

## Hard split

- B3 / MIDI 59 and below: arranger/chord zone; PORTA and TERCA do not process these notes.
- C4 / MIDI 60 and above: live PORTA + TERCA zone.

## Preserve the current KORG state

The app does not automatically change Pitch Bend Range, transpose, octave, Program, or UPPER Play/Mute. PORTA uses only CC5/CC65 after the player explicitly enables/changes it. TERCA sends generated Note On/Off only.

For KORG PA MIDI routing, configure the phone to receive one clean right-hand source channel and map app UPPER outputs to the intended UPPER tracks. Keep the relevant Note/CC MIDI filters open if those messages are to be used.

If you want a muted UPPER to remain muted even when external MIDI arrives, use the PA keyboard's MIDI input/Track Mute setting appropriate to the model. The app itself never sends UPPER Play/Mute commands.

## PORTA check

1. Connect the phone and confirm the keyboard sounds unchanged before pressing PORTA ON.
2. Press PORTA ON: selected UPPER channels receive CC5 followed by CC65 ON.
3. Change Time: while PORTA is ON, selected UPPER channels receive CC5 only.
4. Press PORTA OFF: selected UPPER channels receive CC65 OFF.
5. Move the PA600 joystick/bend control: Portamento does not generate Pitch Bend and therefore does not overwrite that stream.

The displayed milliseconds are not yet a measured PA600 wall-clock calibration. Different physical intervals may still require future hardware calibration if exact equal-time travel is required.

## TERCA check

1. TERCA ON generates only the nearest +3/+4 or -3/-4 third on UPPER 3.
2. No octave/transpose command is sent.
3. SCAN flashes while armed; the three scan notes are consumed by the scanner and transient CC123 is used to stop the scan chord from hanging.
