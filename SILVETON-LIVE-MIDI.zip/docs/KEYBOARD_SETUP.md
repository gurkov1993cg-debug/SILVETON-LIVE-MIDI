# KORG PA setup notes

The app does not change the keyboard's Pitch Bend Range.  In Settings, `PORTA Pitch Bend range reference` is a local mathematical value only and must match the currently selected Sound's own PB range for accurate semitone travel.

UPPER defaults: U1=CH1, U2=CH2, U3=CH3. TERCA output is U3.
C4 (60)+ is the live PORTA/TERCA zone; B3 (59)- is left-hand/chord bypass.
