# Keyboard setup for Silveton LIVE MIDI

This document describes the routing expected by the current app. The PA600 menu names below follow the KORG Pa600 user manual. Other PA models can use the same channel plan, but menu wording can differ.

## Recommended channel plan

- Performance source from keyboard to Android: MIDI channel 1
- App output to Upper 1: channel 1
- App output to Upper 2: channel 2
- App output to Upper 3: channel 3 (**reserved for TERCA while TERCA is ON**)
- Android setting `Performance input: OMNI`: OFF
- Android `MIDI THRU`: OFF for normal use
- Android Pitch Bend Range for PA600: 12 semitones

The keyboard should send only one performance source track to the app. This avoids the same physical key arriving three times when Upper 1/2/3 are all active. The app can then route the source to U1/U2/U3 itself.

## PA600

Open `GLOBAL`, press `MENU`, choose `MIDI`.

### MIDI Out Channel

Recommended:

- Ch01 = Upper 1
- Ch02 = Off
- Ch03 = Off
- Other unused channels = Off

This gives the app one clean keyboard-note stream on channel 1.

### MIDI In Channel

Recommended:

- Ch01 = Upper 1
- Ch02 = Upper 2
- Ch03 = Upper 3

These three channels must match the app's Upper 1/2/3 output-channel settings.

### Filters

On the `Filters` page leave the relevant MIDI In and MIDI Out filters set to `Off`. In particular, do not filter Notes, Pitch Bend, All CC, or System Exclusive. The app uses notes, CC5/CC65, Pitch Bend/RPN, and MIDI Identity SysEx.

### Local Control

There are two operating modes:

1. **Hardware portamento (`TIMES` OFF in the app)**
   - PA600 `Local Control On` = ON
   - The keyboard plays its own Upper tracks locally.
   - The app sends CC65 and CC5 to the selected U1/U2/U3 channels.
   - FIX/LIN/FIB/REAL and DEPTH are intentionally disabled in the app because the keyboard owns the glide curve in this mode.

2. **Exact app-side timing (`TIMES` ON in the app)**
   - PA600 `Local Control On` = OFF
   - The physical keyboard sends notes to Android; Android sends the sounding notes back to U1/U2/U3.
   - The app forces hardware portamento OFF and generates its own timed Pitch Bend trajectory.
   - For PA600 set each used Upper track's Pitch Bend sensitivity to **12 semitones**. This supports smooth app-side glides up to one octave.
   - Keep Android `MIDI THRU` OFF; the app-side bridge already routes the notes.

On PA600, Pitch Bend sensitivity is available in Style Play `Mixer/Tuning > Tuning` for each track. Set the used Upper 1/2/3 tracks to 12 when using `TIMES`.

## Android app settings

Open `SETTINGS` and use:

- Performance input channel = MIDI CH 1
- Performance input: OMNI = OFF
- Upper 1 output channel = MIDI CH 1
- Upper 2 output channel = MIDI CH 2
- Upper 3 output channel = MIDI CH 3
- MIDI THRU = OFF
- Pitch Bend Range = 12 for PA600
- Auto reconnect = ON

Connect the phone/tablet to the keyboard's USB Device port through a proper USB-OTG/host connection. Press `CONNECT`, select the KORG MIDI device, then choose the port pair that sends data **To KORG** and receives data **From KORG**.

## Quick functional check

- Press `MON`; playing a key should show an `IN` Note On/Note Off line.
- Press `PANIC`; stuck notes must stop.
- With `TIMES` OFF and PA600 Local Control ON, `ON` plus a 10/20/35/60/100 ms value should control hardware portamento through CC65/CC5.
- With `TIMES` ON and Local Control OFF, select U1, FIX and 20 ms. A one-semitone move and an octave move should both finish in the same 20 ms total time.
- TERCA: press SCAN, hold the three control notes, then use TERCA ON/OFF independently. Generated thirds always leave the app on Upper 3.
- PORTA, TERCA and RIBBON can run together. If Ribbon is set to Pitch Bend while TIMES portamento is active, the app combines the two Pitch Bend contributions instead of letting them overwrite each other.
