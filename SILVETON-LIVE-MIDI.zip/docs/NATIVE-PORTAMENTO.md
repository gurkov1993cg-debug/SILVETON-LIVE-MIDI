# KORG-native Portamento

The current live Portamento path is deliberately small and isolated.

- The app never generates Portamento with Pitch Bend.
- It never changes Pitch Bend Range, RPN, transpose, octave, Program Change, or track Play/Mute.
- The only Portamento messages emitted are CC5 (Portamento Time) and CC65 (Portamento Switch) on explicitly selected UPPER channels.
- Opening/reconnecting the app emits no Portamento state. Runtime PORTA starts OFF.
- CC5/CC65 are sent only after the player explicitly changes PORTA ON/OFF, target UPPER, or Time while PORTA is ON.
- RIBBON remains an independent Pitch Bend/CC module, so Portamento cannot overwrite the PA600 joystick/bend stream.

The displayed millisecond value is an app control scale mapped monotonically to CC5. It is not yet a hardware-calibrated guarantee that every interval takes exactly the same measured wall-clock time on a PA600. That requires physical timing measurements/calibration.
