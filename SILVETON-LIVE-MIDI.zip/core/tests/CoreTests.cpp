#include "silvetonlive/GlideScheduler.h"
#include "silvetonlive/HarmonyEngine.h"
#include "silvetonlive/LatencyTracker.h"
#include "silvetonlive/LiveMidiEngine.h"
#include "silvetonlive/MidiIdentity.h"
#include "silvetonlive/MidiParser.h"
#include "silvetonlive/MonophonicPortaProcessor.h"
#include "silvetonlive/PortamentoCalibration.h"
#include "silvetonlive/PadBank.h"
#include <cstdlib>
#include <stdexcept>
#include <string>
#include <cmath>
#include <iostream>
#include <random>
#include <array>

using namespace silvetonlive;

#define REQUIRE(expr) do { \
    if (!(expr)) throw std::runtime_error(std::string("REQUIRE failed: ") + #expr + \
                                          " at " + __FILE__ + ":" + std::to_string(__LINE__)); \
} while (false)

static void testProfiles() {
    const auto& p = ModelRegistry::all();
    REQUIRE(p.size() >= 6);
    REQUIRE(ModelRegistry::byId("pa600"));
    REQUIRE(ModelRegistry::byId("pa5x"));
    REQUIRE(!ModelRegistry::byId("not-a-model"));
}

static void testPanic() {
    auto* p = ModelRegistry::byId("pa600");
    auto packets = PanicEngine::build(*p, true);
    REQUIRE(packets.size() == 48);
    REQUIRE(packets.front().bytes[0] == 0xB0);
    REQUIRE(packets.front().bytes[1] == 120);
}

static void testIntervalLifecycle() {
    IntervalEngine e;
    e.setVoice(0, {true, 4, 0, -1});
    e.setVoice(1, {true, 7, -10, -1});
    auto on = e.processNoteOn(0, 60, 100);
    REQUIRE(on.size() == 2);
    REQUIRE(on[0].bytes[1] == 64);
    REQUIRE(on[1].bytes[1] == 67);
    auto off = e.processNoteOff(0, 60);
    REQUIRE(off.size() == 2);
    REQUIRE(e.processNoteOff(0, 60).empty());

    // Two different source notes can land on the same generated pitch. The first
    // source NoteOff must not cut the note still referenced by the second source.
    IntervalEngine overlap;
    overlap.setVoice(0, {true, 4, 0, -1}); // C -> E
    overlap.setVoice(1, {true, 0, 0, -1}); // E -> E
    auto cOn = overlap.processNoteOn(0, 60, 100);
    REQUIRE(cOn.size() == 2); // E and C(unison voice)
    auto eOn = overlap.processNoteOn(0, 64, 100);
    // E from the unison voice is already active from C's +4 voice, so only G# is new.
    REQUIRE(eOn.size() == 1);
    auto cOff = overlap.processNoteOff(0, 60);
    REQUIRE(cOff.size() == 1); // C off; shared E remains sounding.
    REQUIRE(cOff[0].bytes[1] == 60);
    auto eOff = overlap.processNoteOff(0, 64);
    REQUIRE(eOff.size() == 2); // shared E and G# can now turn off.
}

static void testHarmony() {
    HarmonyEngine h;
    h.setConfig({0, ScaleType::Major, true});
    REQUIRE(h.harmonizeNote(60, HarmonyDegree::Third) == 64); // C->E
    REQUIRE(h.harmonizeNote(62, HarmonyDegree::Third) == 65); // D->F
    REQUIRE(h.harmonizeNote(71, HarmonyDegree::Third) == 74); // B->D
    h.setVoice(0, {true, HarmonyDegree::Third, 0, 0, -1});
    auto on = h.processNoteOn(0, 60, 100);
    REQUIRE(on.size() == 1 && on[0].bytes[1] == 64);
    auto off = h.processNoteOff(0, 60);
    REQUIRE(off.size() == 1 && off[0].bytes[1] == 64);

    // Ref-count overlapping output pitches: C third -> E and E unison -> E.
    HarmonyEngine overlap;
    overlap.setConfig({0, ScaleType::Major, true});
    overlap.setVoice(0, {true, HarmonyDegree::Third, 0, 0, -1});
    overlap.setVoice(1, {true, HarmonyDegree::Unison, 0, 0, -1});
    auto a = overlap.processNoteOn(0, 60, 100);
    REQUIRE(a.size() == 2); // E + C
    auto b = overlap.processNoteOn(0, 64, 100);
    REQUIRE(b.size() == 1); // G only; E already held by first source.
    auto ao = overlap.processNoteOff(0, 60);
    REQUIRE(ao.size() == 1 && ao[0].bytes[1] == 60); // shared E remains.
    auto bo = overlap.processNoteOff(0, 64);
    REQUIRE(bo.size() == 2);
}

static void testRibbon() {
    RibbonEngine r;
    r.setConfig({RibbonOutput::PitchBend, 0, 16, true, 0.0, RibbonRelease::Center});
    auto center = r.center();
    REQUIRE(center.bytes[0] == 0xE0);
    REQUIRE(center.bytes[1] == 0x00);
    REQUIRE(center.bytes[2] == 0x40);
    auto max = r.process(1.0);
    REQUIRE(max.bytes[1] == 0x7F && max.bytes[2] == 0x7F);
}

static void testPorta() {
    PortamentoEngine p;
    PortamentoConfig c;
    c.enabled = true;
    c.mode = PortaMode::Fix;
    c.durationMs = 10.0;
    c.steps = 32;
    p.setConfig(c);
    auto curve1 = p.buildCurve(1);
    auto curve12 = p.buildCurve(12);
    REQUIRE(curve1.size() == curve12.size());
    REQUIRE(std::abs(curve1.front().position01) < 1e-12);
    REQUIRE(std::abs(curve1.back().position01 - 1.0) < 1e-12);
    REQUIRE(p.midiPortamentoTimeValue() >= 0 && p.midiPortamentoTimeValue() <= 127);

    // FIX DEPTH must be a real control: it shapes the path while preserving
    // the exact same fixed total duration and 0/1 endpoints.
    const double midLinear = curve1[curve1.size() / 2].position01;
    c.depth = 2.0;
    p.setConfig(c);
    const auto depthCurve = p.buildCurve(12);
    REQUIRE(depthCurve.size() == curve12.size());
    REQUIRE(std::abs(depthCurve.front().position01) < 1e-12);
    REQUIRE(std::abs(depthCurve.back().position01 - 1.0) < 1e-12);
    REQUIRE(depthCurve[depthCurve.size() / 2].position01 > midLinear);
    REQUIRE(std::abs(p.effectiveDurationMs(12) - 10.0) < 1e-9);
    c.depth = 1.0;
    p.setConfig(c);

    auto schedule = GlideScheduler::build(p, 60, 72, 1'000'000'000LL, {0, 12, true});
    REQUIRE(!schedule.empty());
    REQUIRE(schedule.front().timestampNanos == 1'000'000'000LL);
    REQUIRE(schedule.back().bytes == pitchBend14(0, 8192).bytes);
    REQUIRE(schedule.back().timestampNanos == 1'010'000'000LL);
    // 10 ms glides are rate-limited to a wire-safe event density instead of
    // flooding Android/DIN MIDI with the configured 33 curve points.
    REQUIRE(schedule.size() <= 11);
    for (std::size_t i = 1; i < schedule.size(); ++i)
        REQUIRE(schedule[i].timestampNanos >= schedule[i - 1].timestampNanos);

    c.mode = PortaMode::Lin;
    c.durationMs = 10.0;
    p.setConfig(c);
    REQUIRE(std::abs(p.effectiveDurationMs(12) - 120.0) < 1e-9);

    c.mode = PortaMode::Fix;
    p.setConfig(c);
    MonophonicPortaProcessor mono;
    mono.setConfig({0, 24, 100});
    auto first = mono.noteOn(p, 60, 100, 2'000'000'000LL);
    REQUIRE(first.size() == 2 && mono.activeNote() == 60);
    auto second = mono.noteOn(p, 72, 100, 2'100'000'000LL);
    REQUIRE(second.size() > 4 && mono.activeNote() == 72);
    REQUIRE(second.back().timestampNanos == 2'110'000'000LL);
    auto release = mono.noteOff(p, 72, 0, 2'200'000'000LL);
    REQUIRE(!release.empty() && mono.activeNote() == 60 && mono.heldCount() == 1);
    auto endFirst = mono.noteOff(p, 60, 0, 2'300'000'000LL);
    REQUIRE(endFirst.size() == 2 && mono.activeNote() == -1);

    // Last-note priority: C held, E pressed, E released -> glide/resume C.
    mono.noteOn(p, 60, 90, 3'000'000'000LL);
    mono.noteOn(p, 64, 100, 3'100'000'000LL);
    REQUIRE(mono.activeNote() == 64 && mono.heldCount() == 2);
    auto resume = mono.noteOff(p, 64, 0, 3'200'000'000LL);
    REQUIRE(!resume.empty() && mono.activeNote() == 60 && mono.heldCount() == 1);
    auto finalOff = mono.noteOff(p, 60, 0, 3'300'000'000LL);
    REQUIRE(finalOff.size() == 2 && mono.activeNote() == -1 && mono.heldCount() == 0);

    // A hard flush during a held-note stack must never resume an older note.
    mono.noteOn(p, 60, 90, 4'000'000'000LL);
    mono.noteOn(p, 67, 100, 4'100'000'000LL);
    auto hard = mono.flush(4'200'000'000LL);
    REQUIRE(hard.size() == 2);
    REQUIRE((hard[0].bytes[0] & 0xF0) == 0x80 && hard[0].bytes[1] == 67);
    REQUIRE((hard[1].bytes[0] & 0xF0) == 0xE0);
    REQUIRE(mono.activeNote() == -1 && mono.heldCount() == 0);
    for (const auto& m : hard) REQUIRE((m.bytes[0] & 0xF0) != 0x90);
}

static void testPad() {
    PadEngine p;
    p.setPad(0, {PadActionType::Note, 9, 36, 110, 0, true});
    auto on = p.press(0);
    auto off = p.release(0);
    REQUIRE(on.size() == 1 && off.size() == 1);
    REQUIRE(on[0].bytes[0] == 0x99);
    REQUIRE(off[0].bytes[0] == 0x89);
    REQUIRE(!p.latched(0));

    // Non-momentary pads are real toggles, not one-way latches.
    p.setPad(1, {PadActionType::ControlChange, 0, 80, 127, 0, false});
    auto toggleOn = p.press(1);
    REQUIRE(toggleOn.size() == 1 && toggleOn[0].bytes[1] == 80 && toggleOn[0].bytes[2] == 127);
    REQUIRE(p.latched(1));
    REQUIRE(p.release(1).empty());
    auto toggleOff = p.press(1);
    REQUIRE(toggleOff.size() == 1 && toggleOff[0].bytes[2] == 0);
    REQUIRE(!p.latched(1));

    p.setPad(2, {PadActionType::Note, 0, 48, 100, 0, false});
    p.press(2);
    auto flushed = p.flush(123);
    REQUIRE(flushed.size() == 1 && flushed[0].bytes[1] == 48 && flushed[0].timestampNanos == 123);
    REQUIRE(!p.latched(2));

    PadBankSet banks;
    banks.setActiveBank(1);
    banks.loadInto(p);
    REQUIRE(banks.bank(1).name == "U2");
}

static void testMidiParser() {
    MidiParser p;
    const std::vector<std::uint8_t> running{0x90, 60, 100, 64, 0, 0xF8, 67, 120};
    auto m = p.push(running, 123);
    REQUIRE(m.size() == 4);
    REQUIRE(m[0].kind == MidiMessageKind::NoteOn && m[0].bytes[1] == 60);
    REQUIRE(m[1].kind == MidiMessageKind::NoteOff && m[1].bytes[1] == 64);
    REQUIRE(m[2].kind == MidiMessageKind::SystemRealtime);
    REQUIRE(m[3].kind == MidiMessageKind::NoteOn && m[3].bytes[1] == 67);

    p.reset();
    auto a = p.push(std::vector<std::uint8_t>{0xF0, 0x7E, 0x7F});
    REQUIRE(a.empty());
    auto b = p.push(std::vector<std::uint8_t>{0x06, 0x01, 0xF7});
    REQUIRE(b.size() == 1 && b[0].kind == MidiMessageKind::SystemExclusive);
}

static void testIdentity() {
    auto rq = MidiIdentityCodec::request();
    REQUIRE((rq.bytes == std::vector<std::uint8_t>{0xF0,0x7E,0x7F,0x06,0x01,0xF7}));
    std::vector<std::uint8_t> reply{0xF0,0x7E,0x00,0x06,0x02,0x42, 0x01,0x02, 0x03,0x04, 0x31,0x32,0x33,0x34, 0xF7};
    auto id = MidiIdentityCodec::parseReply(reply);
    REQUIRE(id.valid);
    REQUIRE(id.manufacturerName == "KORG");
    REQUIRE(id.familyCode[0] == 0x01 && id.modelNumber[1] == 0x04);
}

static void testLatency() {
    LatencyTracker t;
    t.addSampleNanos(1'000'000);
    t.addSampleNanos(3'000'000);
    auto s = t.stats();
    REQUIRE(s.samples == 2);
    REQUIRE(std::abs(s.meanMs - 2.0) < 1e-9);
    REQUIRE(s.minMs == 1.0 && s.maxMs == 3.0);
    REQUIRE(s.jitterMs > 0.0);
}

static void testSafetyFlushAndMultiChannelBridge() {
    LiveMidiEngine e;
    e.harmony().setConfig({0, ScaleType::Major, true});
    e.harmony().setVoice(0, {true, HarmonyDegree::Third, 0, 0, -1});
    auto hon = e.harmony().processNoteOn(0, 60, 100, 10);
    REQUIRE(hon.size() == 1);
    auto flush = e.flushHarmony(20);
    REQUIRE(flush.size() == 1);
    REQUIRE((flush[0].bytes[0] & 0xF0) == 0x80);
    REQUIRE(flush[0].bytes[1] == 64);
    REQUIRE(e.flushHarmony(30).empty());

    PortamentoConfig cfg;
    cfg.enabled = true;
    cfg.mode = PortaMode::Fix;
    cfg.durationMs = 25.0;
    cfg.steps = 8;
    e.portamento().setConfig(cfg);

    auto ch0first = e.portaBridgeNoteOn(0, 60, 100, 1'000'000'000LL, 24);
    auto ch1first = e.portaBridgeNoteOn(1, 65, 100, 1'000'000'000LL, 24);
    REQUIRE(ch0first.size() == 2 && ch1first.size() == 2);
    REQUIRE((ch0first.back().bytes[0] & 0x0F) == 0);
    REQUIRE((ch1first.back().bytes[0] & 0x0F) == 1);

    auto ch0glide = e.portaBridgeNoteOn(0, 72, 100, 2'000'000'000LL, 24);
    auto ch1glide = e.portaBridgeNoteOn(1, 53, 100, 2'000'000'000LL, 24);
    REQUIRE(ch0glide.size() > 5 && ch1glide.size() > 5);
    REQUIRE(ch0glide.back().timestampNanos == 2'025'000'000LL);
    REQUIRE(ch1glide.back().timestampNanos == 2'025'000'000LL);

    // Add a held-note stack before reset; reset must not emit a resume NoteOn.
    e.portaBridgeNoteOn(0, 76, 100, 2'100'000'000LL, 24);
    auto reset = e.resetPortaBridge(3'000'000'000LL);
    REQUIRE(!reset.empty());
    for (const auto& m : reset) REQUIRE((m.bytes[0] & 0xF0) != 0x90);
    auto off0 = e.portaBridgeNoteOff(0, 72, 0, 3'100'000'000LL);
    auto off1 = e.portaBridgeNoteOff(1, 53, 0, 3'100'000'000LL);
    REQUIRE(off0.empty() && off1.empty());
}

static void testPortamentoCalibration() {
    PortamentoCalibration c;
    REQUIRE(!c.valid());
    REQUIRE(c.ccForMilliseconds(20.0) == -1);
    c.setPoints({{0, 5.0}, {32, 20.0}, {64, 80.0}, {96, 320.0}, {127, 1200.0}});
    REQUIRE(c.valid());
    REQUIRE(c.ccForMilliseconds(5.0) == 0);
    REQUIRE(c.ccForMilliseconds(20.0) == 32);
    REQUIRE(c.ccForMilliseconds(1200.0) == 127);
    REQUIRE(std::abs(c.millisecondsForCc(64) - 80.0) < 1e-9);
    const int mid = c.ccForMilliseconds(40.0);
    REQUIRE(mid > 32 && mid < 64);
    const double roundTrip = c.millisecondsForCc(mid);
    REQUIRE(roundTrip > 30.0 && roundTrip < 55.0);

    bool threw = false;
    try { c.setPoints({{0, 100.0}, {127, 10.0}}); } catch (const std::invalid_argument&) { threw = true; }
    REQUIRE(threw);

    LiveMidiEngine engine;
    PortamentoConfig pc;
    pc.enabled = true; pc.durationMs = 20.0;
    engine.portamento().setConfig(pc);
    engine.setPortamentoCalibration({{0, 5.0}, {64, 20.0}, {127, 100.0}});
    auto applied = engine.applyPortamentoTime(2);
    REQUIRE(applied.size() == 1);
    REQUIRE(applied[0].bytes[0] == 0xB2 && applied[0].bytes[1] == 5 && applied[0].bytes[2] == 64);
    engine.clearPortamentoCalibration();
    REQUIRE(!engine.portamentoCalibration().valid());

    // App-side timing needs the curve engine enabled while hardware portamento is OFF.
    engine.setPortamentoEngineEnabled(true);
    auto hwOff = engine.hardwarePortamentoSwitch(false, 3);
    REQUIRE(engine.portamento().config().enabled);
    REQUIRE(hwOff.size() == 1 && hwOff[0].bytes[0] == 0xB3 && hwOff[0].bytes[1] == 65 && hwOff[0].bytes[2] == 0);
}

static void testCoreBoundaries() {
    PortamentoEngine porta;
    for (PortaMode mode : {PortaMode::Fix, PortaMode::Lin, PortaMode::Fib, PortaMode::Real, PortaMode::Custom}) {
        PortamentoConfig cfg;
        cfg.enabled = true;
        cfg.mode = mode;
        cfg.durationMs = 37.0;
        cfg.depth = 1.7;
        cfg.steps = 24;
        porta.setConfig(cfg);
        for (int distance = 1; distance <= 48; ++distance) {
            const auto curve = porta.buildCurve(distance);
            REQUIRE(curve.size() >= 3);
            REQUIRE(std::abs(curve.front().position01) < 1e-12);
            REQUIRE(std::abs(curve.back().position01 - 1.0) < 1e-12);
            double lastT = -1.0, lastY = -1.0;
            for (const auto& pt : curve) {
                REQUIRE(pt.t01 >= lastT);
                REQUIRE(pt.position01 + 1e-12 >= lastY);
                REQUIRE(pt.t01 >= 0.0 && pt.t01 <= 1.0);
                REQUIRE(pt.position01 >= 0.0 && pt.position01 <= 1.0);
                lastT = pt.t01; lastY = pt.position01;
            }
            REQUIRE(porta.effectiveDurationMs(distance) >= 1.0);
            REQUIRE(porta.effectiveDurationMs(distance) <= 5000.0);
        }
    }

    HarmonyEngine harmony;
    const ScaleType scales[] = {ScaleType::Major, ScaleType::NaturalMinor, ScaleType::HarmonicMinor,
                                ScaleType::Dorian, ScaleType::Phrygian, ScaleType::Lydian, ScaleType::Mixolydian};
    for (auto scale : scales) {
        for (int tonic = 0; tonic < 12; ++tonic) {
            harmony.setConfig({tonic, scale, true});
            for (int note = 0; note < 128; ++note) {
                for (int degree = 0; degree <= 7; ++degree) {
                    const int out = harmony.harmonizeNote(note, static_cast<HarmonyDegree>(degree));
                    REQUIRE(out >= 0 && out <= 127);
                }
            }
        }
    }

    RibbonEngine ribbon;
    ribbon.setConfig({RibbonOutput::PitchBend, 15, 16, true, 0.0, RibbonRelease::Center});
    for (int i = 0; i <= 100; ++i) {
        const auto p = ribbon.process(i / 100.0);
        REQUIRE(p.bytes.size() == 3);
        REQUIRE((p.bytes[0] & 0x0F) == 15);
    }

    MidiParser parser;
    for (int note = 0; note < 128; ++note) {
        const std::vector<std::uint8_t> stream{0x90, static_cast<std::uint8_t>(note), 100,
                                               static_cast<std::uint8_t>(note), 0};
        auto parsed = parser.push(stream);
        REQUIRE(parsed.size() == 2);
        REQUIRE(parsed[0].kind == MidiMessageKind::NoteOn);
        REQUIRE(parsed[1].kind == MidiMessageKind::NoteOff);
    }
}


static void validatePacket(const MidiPacket& p) {
    REQUIRE(!p.bytes.empty());
    const auto status = p.bytes[0];
    REQUIRE(status >= 0x80);
    if (status < 0xF0) {
        const auto kind = status & 0xF0;
        const std::size_t expected = (kind == 0xC0 || kind == 0xD0) ? 2u : 3u;
        REQUIRE(p.bytes.size() == expected);
        for (std::size_t i = 1; i < p.bytes.size(); ++i) REQUIRE(p.bytes[i] <= 0x7F);
    } else if (status != 0xF0 && status != 0xF7) {
        for (std::size_t i = 1; i < p.bytes.size(); ++i) REQUIRE(p.bytes[i] <= 0x7F);
    }
}

static void testStressSequences() {
    std::mt19937 rng(0x51A7E70u);
    std::uniform_int_distribution<int> noteDist(0, 127);
    std::uniform_int_distribution<int> velocityDist(1, 127);
    std::uniform_int_distribution<int> channelDist(0, 15);
    std::uniform_int_distribution<int> boolDist(0, 1);

    // Stress the per-channel last-note-priority bridge with arbitrary retriggers,
    // releases and hard resets. A hard reset may emit NoteOff/PitchBend only.
    LiveMidiEngine porta;
    PortamentoConfig pc;
    pc.enabled = true;
    pc.mode = PortaMode::Fix;
    pc.durationMs = 12.0;
    pc.depth = 1.0;
    pc.steps = 48;
    porta.portamento().setConfig(pc);
    std::int64_t ts = 1'000'000'000LL;
    for (int i = 0; i < 20000; ++i) {
        const int ch = channelDist(rng);
        const int note = noteDist(rng);
        std::vector<MidiPacket> packets;
        if ((i % 257) == 0) {
            packets = porta.resetPortaBridge(ts);
            for (const auto& m : packets) REQUIRE((m.bytes[0] & 0xF0) != 0x90);
        } else if (boolDist(rng)) {
            packets = porta.portaBridgeNoteOn(ch, note, velocityDist(rng), ts, 24);
        } else {
            packets = porta.portaBridgeNoteOff(ch, note, 0, ts);
        }
        for (const auto& m : packets) validatePacket(m);
        ts += 1'000'000LL;
    }
    auto reset = porta.resetPortaBridge(ts);
    for (const auto& m : reset) {
        validatePacket(m);
        REQUIRE((m.bytes[0] & 0xF0) != 0x90);
    }
    REQUIRE(porta.resetPortaBridge(ts + 1).size() == 16); // one centered bend per channel

    // Harmony + chromatic interval engines under dense overlapping traffic.
    HarmonyEngine harmony;
    harmony.setConfig({7, ScaleType::HarmonicMinor, true});
    harmony.setVoice(0, {true, HarmonyDegree::Third, 0, 0, -1});
    harmony.setVoice(1, {true, HarmonyDegree::Fifth, 0, -5, 1});
    harmony.setVoice(2, {true, HarmonyDegree::Octave, -1, -10, 2});
    IntervalEngine intervals;
    intervals.setVoice(0, {true, 4, 0, -1});
    intervals.setVoice(1, {true, 7, -5, 1});
    intervals.setVoice(2, {true, 12, -10, 2});
    for (int i = 0; i < 10000; ++i) {
        const int ch = channelDist(rng);
        const int note = noteDist(rng);
        const int vel = velocityDist(rng);
        auto ho = harmony.processNoteOn(ch, note, vel, ts++);
        auto io = intervals.processNoteOn(ch, note, vel, ts++);
        for (const auto& m : ho) validatePacket(m);
        for (const auto& m : io) validatePacket(m);
        auto hf = harmony.processNoteOff(ch, note, 0, ts++);
        auto iff = intervals.processNoteOff(ch, note, 0, ts++);
        for (const auto& m : hf) validatePacket(m);
        for (const auto& m : iff) validatePacket(m);
    }
    for (const auto& m : harmony.flush(ts++)) validatePacket(m);
    for (const auto& m : intervals.flush(ts++)) validatePacket(m);
    REQUIRE(harmony.flush(ts++).empty());
    REQUIRE(intervals.flush(ts++).empty());

    // Pads: mix momentary and latched actions, then verify a flush clears every latch.
    PadEngine pads;
    for (int i = 0; i < PadEngine::kPadCount; ++i) {
        const bool momentary = (i % 2) == 0;
        const auto type = (i % 3 == 0) ? PadActionType::Note :
                          (i % 3 == 1) ? PadActionType::ControlChange : PadActionType::ProgramChange;
        pads.setPad(i, {type, i % 16, 24 + i, 100, 0, momentary});
    }
    std::uniform_int_distribution<int> padDist(0, PadEngine::kPadCount - 1);
    for (int i = 0; i < 10000; ++i) {
        const int pad = padDist(rng);
        auto on = pads.press(pad, ts++);
        for (const auto& m : on) validatePacket(m);
        if ((pad % 2) == 0) {
            auto off = pads.release(pad, ts++);
            for (const auto& m : off) validatePacket(m);
        }
    }
    for (const auto& m : pads.flush(ts++)) validatePacket(m);
    for (int i = 0; i < PadEngine::kPadCount; ++i) REQUIRE(!pads.latched(i));

    // Ribbon must remain legal MIDI even for out-of-range touch coordinates.
    RibbonEngine ribbon;
    ribbon.setConfig({RibbonOutput::PitchBend, 15, 16, true, 0.2, RibbonRelease::Center});
    std::uniform_real_distribution<double> posDist(-0.5, 1.5);
    for (int i = 0; i < 20000; ++i) validatePacket(ribbon.process(posDist(rng), ts++));
    validatePacket(ribbon.release(ts++));

    // Panic invariant across every supported model: every channel receives the
    // three documented safety CC messages and all payload bytes remain 7-bit.
    for (const auto& model : ModelRegistry::all()) {
        const auto p = PanicEngine::build(model, true);
        REQUIRE(p.size() == 48);
        for (const auto& m : p) validatePacket(m);
    }
}

int main() {
    testProfiles();
    testPanic();
    testIntervalLifecycle();
    testHarmony();
    testRibbon();
    testPorta();
    testPad();
    testMidiParser();
    testIdentity();
    testLatency();
    testSafetyFlushAndMultiChannelBridge();
    testPortamentoCalibration();
    testCoreBoundaries();
    testStressSequences();
    std::cout << "Silveton LIVE MIDI core tests: PASS\n";
    return 0;
}
