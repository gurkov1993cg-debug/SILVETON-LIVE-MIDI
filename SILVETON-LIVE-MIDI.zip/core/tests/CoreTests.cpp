#include "silvetonlive/LatencyTracker.h"
#include "silvetonlive/LiveMidiEngine.h"
#include "silvetonlive/MidiIdentity.h"
#include "silvetonlive/MidiParser.h"
#include "silvetonlive/PadBank.h"
#include "silvetonlive/PadEngine.h"
#include "silvetonlive/PanicEngine.h"
#include "silvetonlive/RibbonEngine.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace silvetonlive;

#define REQUIRE(expr) do { if (!(expr)) throw std::runtime_error(std::string("REQUIRE failed: ") + #expr + " at line " + std::to_string(__LINE__)); } while (false)

static void testProfiles() {
    REQUIRE(ModelRegistry::all().size() >= 6);
    REQUIRE(ModelRegistry::byId("pa600"));
    REQUIRE(ModelRegistry::byId("pa5x"));
    REQUIRE(!ModelRegistry::byId("not-a-model"));
}

static void testPanic() {
    const auto* p = ModelRegistry::byId("pa600");
    REQUIRE(p);
    const auto packets = PanicEngine::build(*p, true);
    REQUIRE(packets.size() == 48);
    REQUIRE(packets.front().bytes[0] == 0xB0);
    REQUIRE(packets.front().bytes[1] == 120);
}

static void testRibbon() {
    RibbonEngine r;
    r.setConfig({RibbonOutput::PitchBend, 0, 16, true, 0.0, RibbonRelease::Center});
    auto center = r.center();
    REQUIRE(center.bytes.size() == 3);
    REQUIRE(center.bytes[0] == 0xE0);
    REQUIRE(center.bytes[1] == 0x00 && center.bytes[2] == 0x40);
    auto max = r.process(1.0);
    REQUIRE(max.bytes[1] == 0x7F && max.bytes[2] == 0x7F);
    auto released = r.release();
    REQUIRE(released.bytes[1] == 0x00 && released.bytes[2] == 0x40);

    RibbonEngine cc;
    cc.setConfig({RibbonOutput::ControlChange, 2, 16, true, 0.0, RibbonRelease::Center});
    cc.process(0.9);
    auto ccReleased = cc.release();
    REQUIRE(ccReleased.bytes[0] == 0xB2);
    REQUIRE(ccReleased.bytes[1] == 16 && ccReleased.bytes[2] == 64);
}

static void testPads() {
    PadEngine p;
    p.setPad(0, {PadActionType::Note, 9, 36, 110, 0, true});
    auto on = p.press(0, 10);
    REQUIRE(on.size() == 1);
    REQUIRE(on[0].bytes[0] == 0x99 && on[0].bytes[1] == 36 && on[0].bytes[2] == 110);
    auto off = p.release(0, 20);
    REQUIRE(off.size() == 1);
    REQUIRE((off[0].bytes[0] & 0xF0) == 0x80);

    p.setPad(1, {PadActionType::ControlChange, 1, 64, 127, 0, false});
    auto a = p.press(1, 30);
    REQUIRE(a.size() == 1 && a[0].bytes[0] == 0xB1 && a[0].bytes[1] == 64);
    auto b = p.press(1, 40);
    REQUIRE(b.size() == 1 && b[0].bytes[2] == 0);
    REQUIRE(p.flush(50).empty());
}

static void testParser() {
    MidiParser parser;
    const std::vector<std::uint8_t> bytes{0x90,60,100, 64,110, 60,0};
    const auto out = parser.push(bytes, 123);
    REQUIRE(out.size() == 3);
    REQUIRE(out[0].kind == MidiMessageKind::NoteOn);
    REQUIRE(out[1].kind == MidiMessageKind::NoteOn);
    REQUIRE(out[2].kind == MidiMessageKind::NoteOff);
    REQUIRE(out[0].timestampNanos == 123);
}

static void testLatency() {
    LatencyTracker t;
    t.addSampleNanos(1'000'000);
    t.addSampleNanos(3'000'000);
    const auto s = t.stats();
    REQUIRE(s.samples == 2);
    REQUIRE(std::abs(s.meanMs - 2.0) < 1e-9);
    REQUIRE(std::abs(s.minMs - 1.0) < 1e-9);
    REQUIRE(std::abs(s.maxMs - 3.0) < 1e-9);
}

static void testLiveEngine() {
    LiveMidiEngine e;
    REQUIRE(e.model().id == "pa600");
    REQUIRE(e.selectModel("pa5x"));
    REQUIRE(e.model().id == "pa5x");
    REQUIRE(!e.selectModel("missing"));
    auto panic = e.panic(false, 3);
    REQUIRE(panic.size() == 3);
    REQUIRE((panic[0].bytes[0] & 0x0F) == 3);
}

int main() {
    try {
        testProfiles();
        testPanic();
        testRibbon();
        testPads();
        testParser();
        testLatency();
        testLiveEngine();
        std::cout << "All core tests passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
