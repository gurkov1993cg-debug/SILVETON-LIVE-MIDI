#pragma once
#include "MidiTypes.h"
#include <cstddef>
#include <cstdint>
#include <vector>

namespace silvetonlive {

enum class MidiMessageKind : std::uint8_t {
    Unknown = 0,
    NoteOff,
    NoteOn,
    PolyPressure,
    ControlChange,
    ProgramChange,
    ChannelPressure,
    PitchBend,
    SystemExclusive,
    SystemCommon,
    SystemRealtime
};

struct ParsedMidiMessage {
    MidiMessageKind kind{MidiMessageKind::Unknown};
    std::vector<std::uint8_t> bytes;
    std::int64_t timestampNanos{0};
    int channel{-1};
};

// Stateful MIDI 1.0 byte-stream parser with running-status and SysEx support.
// Realtime bytes are emitted immediately and do not disturb parser state.
class MidiParser {
public:
    std::vector<ParsedMidiMessage> push(const std::uint8_t* data, std::size_t size,
                                        std::int64_t timestampNanos = 0);
    std::vector<ParsedMidiMessage> push(const std::vector<std::uint8_t>& bytes,
                                        std::int64_t timestampNanos = 0) {
        return push(bytes.data(), bytes.size(), timestampNanos);
    }
    void reset();

private:
    std::uint8_t runningStatus_{0};
    std::uint8_t currentStatus_{0};
    int expectedData_{0};
    std::vector<std::uint8_t> current_;
    bool inSysEx_{false};
    std::vector<std::uint8_t> sysex_;

    static int dataBytesForStatus(std::uint8_t status);
    static ParsedMidiMessage classify(std::vector<std::uint8_t> bytes, std::int64_t ts);
};

} // namespace silvetonlive
