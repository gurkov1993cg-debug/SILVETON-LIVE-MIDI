#pragma once
#include "Capabilities.h"
#include <string>
#include <vector>

namespace silvetonlive {

struct ModelProfile {
    std::string id;
    std::string displayName;
    int defaultMidiChannel{0};
    ModelCapabilities capabilities;

    std::vector<std::uint8_t> identityPrefix;
    int allSoundOffCc{120};
    int resetControllersCc{121};
    int allNotesOffCc{123};
};

class ModelRegistry {
public:
    static const std::vector<ModelProfile>& all();
    static const ModelProfile* byId(const std::string& id);
};

} // namespace silvetonlive
