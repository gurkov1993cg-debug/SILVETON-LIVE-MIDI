#pragma once
#include <vector>

namespace silvetonlive {

struct PortamentoCalibrationPoint {
    int cc{0};
    double measuredMs{0.0};
};

// Piecewise calibration for a keyboard's real CC5 -> wall-clock glide time.
// Points are measured on hardware and kept separate per model. Empty means
// "uncalibrated" and the caller must use a generic mapping or app-side glide.
class PortamentoCalibration {
public:
    void setPoints(std::vector<PortamentoCalibrationPoint> points);
    const std::vector<PortamentoCalibrationPoint>& points() const noexcept { return points_; }
    bool valid() const noexcept { return points_.size() >= 2; }

    int ccForMilliseconds(double ms) const;
    double millisecondsForCc(int cc) const;

private:
    std::vector<PortamentoCalibrationPoint> points_{};
};

} // namespace silvetonlive
