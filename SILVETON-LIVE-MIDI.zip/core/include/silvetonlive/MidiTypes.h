#pragma once
#include <algorithm>
#include <cstdint>
#include <cmath>
#include <vector>

namespace silvetonlive {

struct MidiPacket {
    std::vector<std::uint8_t> bytes;
    std::int64_t timestampNanos{0};
};

inline std::uint8_t clamp7(int value) {
    return static_cast<std::uint8_t>(std::clamp(value, 0, 127));
}

inline int clampChannel(int channel) {
    return std::clamp(channel, 0, 15);
}

inline MidiPacket noteOn(int channel, int note, int velocity, std::int64_t ts = 0) {
    return {{static_cast<std::uint8_t>(0x90 | clampChannel(channel)), clamp7(note), clamp7(velocity)}, ts};
}

inline MidiPacket noteOff(int channel, int note, int velocity = 0, std::int64_t ts = 0) {
    return {{static_cast<std::uint8_t>(0x80 | clampChannel(channel)), clamp7(note), clamp7(velocity)}, ts};
}

inline MidiPacket controlChange(int channel, int cc, int value, std::int64_t ts = 0) {
    return {{static_cast<std::uint8_t>(0xB0 | clampChannel(channel)), clamp7(cc), clamp7(value)}, ts};
}

inline MidiPacket pitchBend14(int channel, int value14, std::int64_t ts = 0) {
    value14 = std::clamp(value14, 0, 16383);
    return {{static_cast<std::uint8_t>(0xE0 | clampChannel(channel)),
             static_cast<std::uint8_t>(value14 & 0x7F),
             static_cast<std::uint8_t>((value14 >> 7) & 0x7F)}, ts};
}

inline MidiPacket programChange(int channel, int program, std::int64_t ts = 0) {
    return {{static_cast<std::uint8_t>(0xC0 | clampChannel(channel)), clamp7(program)}, ts};
}

inline std::vector<MidiPacket> rpnPitchBendRange(int channel, int semitones, int cents = 0, std::int64_t ts = 0) {
    const int ch = clampChannel(channel);
    semitones = std::clamp(semitones, 0, 127);
    cents = std::clamp(cents, 0, 99);
    return {
        controlChange(ch, 101, 0, ts),
        controlChange(ch, 100, 0, ts),
        controlChange(ch, 6, semitones, ts),
        controlChange(ch, 38, static_cast<int>(std::lround(cents * 127.0 / 100.0)), ts),
        controlChange(ch, 101, 127, ts),
        controlChange(ch, 100, 127, ts)
    };
}

} // namespace silvetonlive
