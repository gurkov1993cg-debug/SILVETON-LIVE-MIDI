#pragma once
#include "PadEngine.h"
#include <array>
#include <string>

namespace silvetonlive {

struct NamedPadBank {
    std::string name;
    std::array<PadAction, PadEngine::kPadCount> pads{};
};

class PadBankSet {
public:
    static constexpr int kBankCount = 3;
    PadBankSet();
    void setActiveBank(int bank);
    int activeBank() const noexcept { return active_; }
    NamedPadBank& bank(int index);
    const NamedPadBank& bank(int index) const;
    void loadInto(PadEngine& engine) const;
    void captureFrom(const PadEngine& engine);
private:
    std::array<NamedPadBank, kBankCount> banks_{};
    int active_{0};
};

} // namespace silvetonlive
