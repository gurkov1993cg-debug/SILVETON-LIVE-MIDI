#pragma once
#include "MidiTypes.h"
#include <array>
#include <cstdint>
#include <unordered_map>
#include <vector>

namespace silvetonlive {

enum class ScaleType : std::uint8_t {
    Major = 0,
    NaturalMinor,
    HarmonicMinor,
    Dorian,
    Phrygian,
    Lydian,
    Mixolydian,
    Hijaz
};

enum class HarmonyDegree : std::int8_t {
    ThirdDown = -2,
    Unison = 0,
    Second = 1,
    Third = 2,
    Fourth = 3,
    Fifth = 4,
    Sixth = 5,
    Seventh = 6,
    Octave = 7
};

struct HarmonyVoice {
    bool enabled{false};
    HarmonyDegree degree{HarmonyDegree::Third};
    int octaves{0};
    int velocityOffset{0};
    int outputChannel{-1};
};

struct HarmonyConfig {
    int tonic{0}; // C=0..B=11
    ScaleType scale{ScaleType::Major};
    bool quantizeNonScaleNotes{true};
};

class HarmonyEngine {
public:
    static constexpr int kMaxVoices = 4;
    void setConfig(const HarmonyConfig& cfg);
    const HarmonyConfig& config() const noexcept { return config_; }
    void setVoice(int index, const HarmonyVoice& voice);
    const HarmonyVoice& voice(int index) const;

    int harmonizeNote(int note, HarmonyDegree degree, int octaves = 0) const;
    std::vector<MidiPacket> processNoteOn(int channel, int note, int velocity, std::int64_t ts = 0);
    std::vector<MidiPacket> processNoteOff(int channel, int note, int velocity = 0, std::int64_t ts = 0);
    // Emits one NoteOff for every generated output pitch still sounding, then clears tracking.
    std::vector<MidiPacket> flush(std::int64_t ts = 0, int velocity = 0);
    void clear();

private:
    HarmonyConfig config_{};
    std::array<HarmonyVoice, kMaxVoices> voices_{};
    // Input key -> generated output note ids. Repeated ids are intentional when
    // two harmony voices land on the same MIDI pitch.
    std::unordered_map<int, std::vector<int>> activeGenerated_;
    // Generated output note id -> number of active source/voice references.
    // This prevents one source NoteOff from cutting a note still required by another source.
    std::unordered_map<int, int> outputRefCount_;

    static const std::array<int, 7>& intervalsFor(ScaleType type);
    int scaleIndexAtOrBelow(int absoluteSemitoneFromTonic) const;
    void releaseInputKey(int key, int velocity, std::int64_t ts, std::vector<MidiPacket>& out);
};

} // namespace silvetonlive
