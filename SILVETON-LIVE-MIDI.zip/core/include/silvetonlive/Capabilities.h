#pragma once
#include <cstdint>
#include <string>

namespace silvetonlive {

enum class SupportStatus : std::uint8_t {
    Unknown = 0,
    GenericMidi = 1,
    Documented = 2,
    Verified = 3,
    Unsupported = 4
};

struct Capability {
    SupportStatus status{SupportStatus::Unknown};
    std::string note;
};

struct ModelCapabilities {
    Capability usbMidi;
    Capability portamentoSwitch;
    Capability portamentoTime;
    Capability pitchBend;
    Capability ribbon;
    Capability intervalHarmony;
    Capability pads;
};

} // namespace silvetonlive
