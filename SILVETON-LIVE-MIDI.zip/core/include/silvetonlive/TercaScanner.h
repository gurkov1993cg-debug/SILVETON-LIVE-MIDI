#pragma once

#include "HarmonyEngine.h"
#include <array>

namespace silvetonlive {

struct TercaScanResult {
    bool valid{false};
    int tonic{0};
    ScaleType scale{ScaleType::Major};
    HarmonyDegree degree{HarmonyDegree::Third};
};

// Three-note live scanner inspired by the Juzisound terca workflow:
// a scan chord selects the base note, mode and third direction.
// The scanner is deliberately deterministic and transposition-invariant.
class TercaScanner {
public:
    static TercaScanResult scan(const std::array<int, 3>& midiNotes);
};

} // namespace silvetonlive
