#pragma once
#include "LatencyTracker.h"
#include "MidiIdentity.h"
#include "MidiParser.h"
#include "ModelProfile.h"
#include "PadBank.h"
#include "PadEngine.h"
#include "PanicEngine.h"
#include "RibbonEngine.h"
#include <string>
#include <vector>

namespace silvetonlive {

/** Native core for features that genuinely benefit from C++.
 * Portamento and TERCA intentionally do NOT live here anymore:
 * - MasterKey-style Portamento is an isolated Kotlin real-time state machine.
 * - TERCA is a dedicated note-only Kotlin state machine.
 */
class LiveMidiEngine {
public:
    LiveMidiEngine();
    bool selectModel(const std::string& modelId);
    const ModelProfile& model() const noexcept { return *model_; }

    RibbonEngine& ribbon() noexcept { return ribbon_; }
    PadEngine& pads() noexcept { return pads_; }
    PadBankSet& padBanks() noexcept { return padBanks_; }
    MidiParser& parser() noexcept { return parser_; }
    LatencyTracker& latency() noexcept { return latency_; }

    std::vector<MidiPacket> panic(bool allChannels = true, int channel = 0);
    std::vector<MidiPacket> flushPads(std::int64_t ts = 0);
    MidiPacket identityRequest(std::uint8_t deviceId = 0x7F) const;

private:
    const ModelProfile* model_{nullptr};
    RibbonEngine ribbon_{};
    PadEngine pads_{};
    PadBankSet padBanks_{};
    MidiParser parser_{};
    LatencyTracker latency_{};
};

} // namespace silvetonlive
