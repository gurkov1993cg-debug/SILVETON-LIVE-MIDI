#pragma once
#include "HarmonyEngine.h"
#include "IntervalEngine.h"
#include "LatencyTracker.h"
#include "MidiIdentity.h"
#include "MidiParser.h"
#include "ModelProfile.h"
#include "MonophonicPortaProcessor.h"
#include "PadBank.h"
#include "PadEngine.h"
#include "PanicEngine.h"
#include "PortamentoEngine.h"
#include "PortamentoCalibration.h"
#include "RibbonEngine.h"
#include <array>
#include <string>
#include <vector>

namespace silvetonlive {

class LiveMidiEngine {
public:
    LiveMidiEngine();
    bool selectModel(const std::string& modelId);
    const ModelProfile& model() const noexcept { return *model_; }

    PortamentoEngine& portamento() noexcept { return portamento_; }
    IntervalEngine& intervals() noexcept { return intervals_; }
    HarmonyEngine& harmony() noexcept { return harmony_; }
    RibbonEngine& ribbon() noexcept { return ribbon_; }
    PadEngine& pads() noexcept { return pads_; }
    PadBankSet& padBanks() noexcept { return padBanks_; }
    MidiParser& parser() noexcept { return parser_; }
    LatencyTracker& latency() noexcept { return latency_; }

    // Engine state and keyboard hardware switch are intentionally separate: the
    // app-side pitch-bend bridge must keep the engine enabled while forcing the
    // keyboard's own portamento switch OFF to avoid double glides.
    void setPortamentoEngineEnabled(bool enabled);
    std::vector<MidiPacket> hardwarePortamentoSwitch(bool enabled, int channel = 0) const;
    std::vector<MidiPacket> setPortamentoEnabled(bool enabled, int channel = 0); // legacy combined operation
    std::vector<MidiPacket> applyPortamentoTime(int channel = 0);
    void setPortamentoCalibration(std::vector<PortamentoCalibrationPoint> points);
    void clearPortamentoCalibration();
    const PortamentoCalibration& portamentoCalibration() const noexcept { return portamentoCalibration_; }
    std::vector<MidiPacket> panic(bool allChannels = true, int channel = 0);
    std::vector<MidiPacket> flushHarmony(std::int64_t ts = 0);
    std::vector<MidiPacket> flushIntervals(std::int64_t ts = 0);
    std::vector<MidiPacket> flushPads(std::int64_t ts = 0);

    // Application-side monophonic portamento bridge, one independent state per MIDI channel.
    std::vector<MidiPacket> portaBridgeNoteOn(int outputChannel, int note, int velocity,
                                               std::int64_t ts, int bendRangeSemitones = 24);
    std::vector<MidiPacket> portaBridgeNoteOff(int outputChannel, int note, int velocity,
                                                std::int64_t ts);
    std::vector<MidiPacket> resetPortaBridge(std::int64_t ts = 0);

    MidiPacket identityRequest(std::uint8_t deviceId = 0x7F) const;

private:
    const ModelProfile* model_{nullptr};
    PortamentoEngine portamento_{};
    PortamentoCalibration portamentoCalibration_{};
    IntervalEngine intervals_{};
    HarmonyEngine harmony_{};
    RibbonEngine ribbon_{};
    PadEngine pads_{};
    PadBankSet padBanks_{};
    MidiParser parser_{};
    LatencyTracker latency_{};
    std::array<MonophonicPortaProcessor, 16> portaBridge_{};
};

} // namespace silvetonlive
