#pragma once
#include <cstdint>
#include <vector>

namespace silvetonlive {

enum class PortaMode : std::uint8_t {
    Fix = 0,
    Lin = 1,
    Fib = 2,
    Real = 3,
    Custom = 4
};

struct PortamentoConfig {
    bool enabled{false};
    PortaMode mode{PortaMode::Fix};
    double durationMs{10.0};
    double depth{1.0};
    int steps{48};
};

struct GlidePoint {
    double t01{0.0};          // normalized time [0, 1]
    double position01{0.0};   // normalized pitch path [0, 1]
};

class PortamentoEngine {
public:
    void setConfig(const PortamentoConfig& cfg);
    const PortamentoConfig& config() const noexcept { return cfg_; }

    // Generates a deterministic normalized glide. The UI labels FIX/LIN/FIB/REAL
    // are preserved, while exact DNKontrol curve equivalence remains a validation task.
    std::vector<GlidePoint> buildCurve(int semitoneDistance) const;
    double effectiveDurationMs(int semitoneDistance) const;

    // Maps milliseconds to standard MIDI CC5 (0..127) with a monotonic logarithmic map.
    // This is an app mapping, not a claim about a KORG-specific internal time table.
    int midiPortamentoTimeValue() const;

private:
    PortamentoConfig cfg_{};
};

} // namespace silvetonlive
