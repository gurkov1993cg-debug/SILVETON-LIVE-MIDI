#pragma once
#include "GlideScheduler.h"
#include "MidiTypes.h"
#include "PortamentoEngine.h"
#include <cstdint>
#include <vector>

namespace silvetonlive {

struct MonophonicPortaConfig {
    int channel{0};
    int bendRangeSemitones{24};
    int velocityFallback{100};
};

// Application-side monophonic note bridge with last-note priority.
// Held notes are tracked so releasing the newest note can glide back to the
// previously held note instead of producing a dead gap.
class MonophonicPortaProcessor {
public:
    void setConfig(const MonophonicPortaConfig& cfg);
    const MonophonicPortaConfig& config() const noexcept { return cfg_; }
    void reset();
    // Immediately terminates the currently sounding bridged note, recenters bend,
    // clears held-note priority state and never resumes an older held note.
    std::vector<MidiPacket> flush(std::int64_t ts = 0, int velocity = 0);
    std::vector<MidiPacket> noteOn(PortamentoEngine& engine, int note, int velocity, std::int64_t ts);
    std::vector<MidiPacket> noteOff(PortamentoEngine& engine, int note, int velocity, std::int64_t ts);
    int activeNote() const noexcept { return activeNote_; }
    std::size_t heldCount() const noexcept { return held_.size(); }

private:
    struct HeldNote { int note; int velocity; };
    MonophonicPortaConfig cfg_{};
    int activeNote_{-1};
    std::vector<HeldNote> held_{};

    std::vector<MidiPacket> transition(PortamentoEngine& engine, int fromNote, int toNote,
                                       int velocity, std::int64_t ts);
};

} // namespace silvetonlive
