#pragma once
#include <cstddef>
#include <cstdint>

namespace silvetonlive {

struct LatencyStats {
    std::size_t samples{0};
    double minMs{0.0};
    double maxMs{0.0};
    double meanMs{0.0};
    double jitterMs{0.0}; // standard deviation
};

class LatencyTracker {
public:
    void reset();
    void addSampleNanos(std::int64_t latencyNanos);
    LatencyStats stats() const;
private:
    std::size_t n_{0};
    double meanNs_{0.0};
    double m2Ns_{0.0};
    double minNs_{0.0};
    double maxNs_{0.0};
};

} // namespace silvetonlive
