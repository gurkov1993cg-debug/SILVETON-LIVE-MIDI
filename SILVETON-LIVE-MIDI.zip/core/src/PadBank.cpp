#include "silvetonlive/PadBank.h"
#include <stdexcept>

namespace silvetonlive {

PadBankSet::PadBankSet() {
    banks_[0].name = "U1";
    banks_[1].name = "U2";
    banks_[2].name = "U3";
    for (int b = 0; b < kBankCount; ++b) {
        for (int i = 0; i < PadEngine::kPadCount; ++i) {
            banks_[static_cast<std::size_t>(b)].pads[static_cast<std::size_t>(i)] =
                {PadActionType::Note, 9, 36 + i, 110, 0, true};
        }
    }
}

void PadBankSet::setActiveBank(int bank) {
    if (bank < 0 || bank >= kBankCount) throw std::out_of_range("pad bank");
    active_ = bank;
}

NamedPadBank& PadBankSet::bank(int index) {
    if (index < 0 || index >= kBankCount) throw std::out_of_range("pad bank");
    return banks_[static_cast<std::size_t>(index)];
}

const NamedPadBank& PadBankSet::bank(int index) const {
    if (index < 0 || index >= kBankCount) throw std::out_of_range("pad bank");
    return banks_[static_cast<std::size_t>(index)];
}

void PadBankSet::loadInto(PadEngine& engine) const {
    const auto& b = bank(active_);
    for (int i = 0; i < PadEngine::kPadCount; ++i) engine.setPad(i, b.pads[static_cast<std::size_t>(i)]);
}

void PadBankSet::captureFrom(const PadEngine& engine) {
    auto& b = bank(active_);
    for (int i = 0; i < PadEngine::kPadCount; ++i) b.pads[static_cast<std::size_t>(i)] = engine.pad(i);
}

} // namespace silvetonlive
