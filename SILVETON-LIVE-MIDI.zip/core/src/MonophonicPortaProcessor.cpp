#include "silvetonlive/MonophonicPortaProcessor.h"
#include <algorithm>
#include <cmath>

namespace silvetonlive {

void MonophonicPortaProcessor::setConfig(const MonophonicPortaConfig& cfg) {
    cfg_ = cfg;
    cfg_.channel = clampChannel(cfg_.channel);
    cfg_.bendRangeSemitones = std::clamp(cfg_.bendRangeSemitones, 1, 127);
    cfg_.velocityFallback = std::clamp(cfg_.velocityFallback, 1, 127);
}

void MonophonicPortaProcessor::reset() {
    activeNote_ = -1;
    held_.clear();
}

std::vector<MidiPacket> MonophonicPortaProcessor::flush(std::int64_t ts, int velocity) {
    std::vector<MidiPacket> out;
    if (activeNote_ >= 0) out.push_back(silvetonlive::noteOff(cfg_.channel, activeNote_, velocity, ts));
    out.push_back(pitchBend14(cfg_.channel, 8192, ts));
    reset();
    return out;
}

std::vector<MidiPacket> MonophonicPortaProcessor::transition(PortamentoEngine& engine,
                                                             int fromNote, int toNote,
                                                             int velocity, std::int64_t ts) {
    std::vector<MidiPacket> out;
    out.push_back(silvetonlive::noteOff(cfg_.channel, fromNote, 0, ts));

    const double offset = static_cast<double>(fromNote - toNote);
    const double normalized = std::clamp(offset / static_cast<double>(cfg_.bendRangeSemitones), -1.0, 1.0);
    const int bend = static_cast<int>(std::lround(8192.0 + normalized * (normalized >= 0 ? 8191.0 : 8192.0)));
    out.push_back(pitchBend14(cfg_.channel, bend, ts));
    out.push_back(silvetonlive::noteOn(cfg_.channel, toNote, velocity, ts));

    auto glide = GlideScheduler::build(engine, fromNote, toNote, ts,
                                       {cfg_.channel, cfg_.bendRangeSemitones, true});
    if (!glide.empty()) glide.erase(glide.begin()); // initial bend already emitted above
    out.insert(out.end(), glide.begin(), glide.end());
    return out;
}

std::vector<MidiPacket> MonophonicPortaProcessor::noteOn(PortamentoEngine& engine,
                                                         int note, int velocity, std::int64_t ts) {
    note = std::clamp(note, 0, 127);
    velocity = std::clamp(velocity, 1, 127);

    // Re-trigger moves the note to the top of the last-note-priority stack.
    held_.erase(std::remove_if(held_.begin(), held_.end(),
                               [note](const HeldNote& h) { return h.note == note; }), held_.end());
    held_.push_back({note, velocity});

    if (activeNote_ < 0 || !engine.config().enabled) {
        activeNote_ = note;
        return {pitchBend14(cfg_.channel, 8192, ts),
                silvetonlive::noteOn(cfg_.channel, note, velocity, ts)};
    }

    if (activeNote_ == note) {
        return {silvetonlive::noteOff(cfg_.channel, note, 0, ts),
                silvetonlive::noteOn(cfg_.channel, note, velocity, ts)};
    }

    const int previous = activeNote_;
    activeNote_ = note;
    return transition(engine, previous, note, velocity, ts);
}

std::vector<MidiPacket> MonophonicPortaProcessor::noteOff(PortamentoEngine& engine,
                                                          int note, int velocity, std::int64_t ts) {
    note = std::clamp(note, 0, 127);
    held_.erase(std::remove_if(held_.begin(), held_.end(),
                               [note](const HeldNote& h) { return h.note == note; }), held_.end());

    if (activeNote_ < 0 || note != activeNote_) return {};

    if (!held_.empty()) {
        const auto resume = held_.back();
        const int previous = activeNote_;
        activeNote_ = resume.note;
        if (!engine.config().enabled) {
            return {silvetonlive::noteOff(cfg_.channel, previous, velocity, ts),
                    pitchBend14(cfg_.channel, 8192, ts),
                    silvetonlive::noteOn(cfg_.channel, resume.note, resume.velocity, ts)};
        }
        return transition(engine, previous, resume.note, resume.velocity, ts);
    }

    std::vector<MidiPacket> out;
    out.push_back(silvetonlive::noteOff(cfg_.channel, activeNote_, velocity, ts));
    out.push_back(pitchBend14(cfg_.channel, 8192, ts));
    activeNote_ = -1;
    return out;
}

} // namespace silvetonlive
