#include "silvetonlive/PortamentoEngine.h"
#include <algorithm>
#include <cmath>

namespace silvetonlive {

void PortamentoEngine::setConfig(const PortamentoConfig& cfg) {
    cfg_ = cfg;
    cfg_.durationMs = std::clamp(cfg_.durationMs, 1.0, 5000.0);
    cfg_.depth = std::clamp(cfg_.depth, 0.05, 8.0);
    cfg_.steps = std::clamp(cfg_.steps, 2, 512);
}

static double fibEase(double t) {
    // Smooth monotonic curve with golden-ratio exponent. This is our own curve;
    // it is intentionally marked provisional until behavior is measured.
    constexpr double phi = 1.6180339887498948482;
    return std::pow(t, 1.0 / phi);
}

static double realEase(double t) {
    // Critically-damped-like normalized rise.
    constexpr double k = 5.0;
    const double y = 1.0 - std::exp(-k * t) * (1.0 + k * t);
    const double y1 = 1.0 - std::exp(-k) * (1.0 + k);
    return y / y1;
}

std::vector<GlidePoint> PortamentoEngine::buildCurve(int semitoneDistance) const {
    std::vector<GlidePoint> out;
    if (!cfg_.enabled) {
        out.push_back({0.0, 1.0});
        return out;
    }

    const int distance = std::max(1, std::abs(semitoneDistance));
    int steps = cfg_.steps;
    if (cfg_.mode == PortaMode::Lin) {
        steps = std::clamp(cfg_.steps + distance * 2, 2, 512);
    }

    out.reserve(static_cast<std::size_t>(steps + 1));
    for (int i = 0; i <= steps; ++i) {
        const double t = static_cast<double>(i) / static_cast<double>(steps);
        double y = t;
        switch (cfg_.mode) {
            case PortaMode::Fix:    y = t; break;
            case PortaMode::Lin:    y = t; break;
            case PortaMode::Fib:    y = fibEase(t); break;
            case PortaMode::Real:   y = realEase(t); break;
            case PortaMode::Custom: y = std::pow(t, 1.0 / cfg_.depth); break;
        }
        out.push_back({t, std::clamp(y, 0.0, 1.0)});
    }
    return out;
}

double PortamentoEngine::effectiveDurationMs(int semitoneDistance) const {
    const double d = static_cast<double>(std::max(1, std::abs(semitoneDistance)));
    switch (cfg_.mode) {
        case PortaMode::Fix:
        case PortaMode::Custom:
            return cfg_.durationMs;
        case PortaMode::Lin:
            // Constant-rate glide: configured duration is milliseconds per semitone.
            return std::min(5000.0, cfg_.durationMs * d);
        case PortaMode::Fib: {
            // Musically gentler distance growth using the golden-ratio exponent.
            constexpr double invPhi = 0.6180339887498948482;
            return std::min(5000.0, cfg_.durationMs * std::pow(d, invPhi));
        }
        case PortaMode::Real:
            // Distance-dependent, sub-linear response intended as a natural-feeling mode.
            return std::min(5000.0, cfg_.durationMs * std::sqrt(d));
    }
    return cfg_.durationMs;
}

int PortamentoEngine::midiPortamentoTimeValue() const {
    const double ms = std::clamp(cfg_.durationMs, 1.0, 5000.0);
    const double x = std::log(ms) / std::log(5000.0);
    return std::clamp(static_cast<int>(std::lround(x * 127.0)), 0, 127);
}

} // namespace silvetonlive
