#include "silvetonlive/TercaScanner.h"
#include <algorithm>
#include <array>

namespace silvetonlive {
namespace {

int pc(int note) {
    int v = note % 12;
    return v < 0 ? v + 12 : v;
}

} // namespace

TercaScanResult TercaScanner::scan(const std::array<int, 3>& midiNotes) {
    std::array<int, 3> notes = midiNotes;
    for (int& n : notes) n = std::clamp(n, 0, 127);
    std::sort(notes.begin(), notes.end());

    // Juzisound Keyboard Enhancer / early Total SOLO Sampler scan principle:
    // three simultaneously held notes are a control chord.  The lowest note is
    // the tonic and the two intervals above it select one of the six documented
    // terca types.  The same cells transpose to every tonic.
    //
    // Relative scan cells (C examples from the published table):
    //   0,4,7  = C-E-G   natural major, terca up
    //   0,2,4  = C-D-E   natural major, terca down
    //   0,3,7  = C-Eb-G  natural minor, terca up
    //   0,2,3  = C-D-Eb  natural minor, terca down
    //   0,1,3  = C-Db-Eb phrygian minor, terca up
    //   0,1,4  = C-Db-E  maqam Hijaz, terca up
    //
    // Match actual key spacing, not merely pitch-class sets: inversions must not
    // silently select another mode.
    const int i1 = notes[1] - notes[0];
    const int i2 = notes[2] - notes[0];
    const int tonic = pc(notes[0]);

    if (i1 == 4 && i2 == 7) return {true, tonic, ScaleType::Major,        HarmonyDegree::Third};
    if (i1 == 2 && i2 == 4) return {true, tonic, ScaleType::Major,        HarmonyDegree::ThirdDown};
    if (i1 == 3 && i2 == 7) return {true, tonic, ScaleType::NaturalMinor, HarmonyDegree::Third};
    if (i1 == 2 && i2 == 3) return {true, tonic, ScaleType::NaturalMinor, HarmonyDegree::ThirdDown};
    if (i1 == 1 && i2 == 3) return {true, tonic, ScaleType::Phrygian,     HarmonyDegree::Third};
    if (i1 == 1 && i2 == 4) return {true, tonic, ScaleType::Hijaz,        HarmonyDegree::Third};

    return {};
}

} // namespace silvetonlive
