#include "silvetonlive/TercaScanner.h"
#include <algorithm>
#include <array>

namespace silvetonlive {
namespace {

int pc(int note) {
    int v = note % 12;
    return v < 0 ? v + 12 : v;
}

std::array<int, 3> sortedPcs(const std::array<int, 3>& notes) {
    std::array<int, 3> out {pc(notes[0]), pc(notes[1]), pc(notes[2])};
    std::sort(out.begin(), out.end());
    return out;
}

std::array<int, 3> templatePcs(int tonic, int i1, int i2) {
    std::array<int, 3> out {pc(tonic), pc(tonic + i1), pc(tonic + i2)};
    std::sort(out.begin(), out.end());
    return out;
}

struct ScanCell {
    int i1;
    int i2;
    ScaleType scale;
    HarmonyDegree degree;
};

constexpr std::array<ScanCell, 6> kCells {{
    {4, 7, ScaleType::Major,        HarmonyDegree::Third},
    {2, 4, ScaleType::Major,        HarmonyDegree::ThirdDown},
    {3, 7, ScaleType::NaturalMinor, HarmonyDegree::Third},
    {2, 3, ScaleType::NaturalMinor, HarmonyDegree::ThirdDown},
    {1, 3, ScaleType::Phrygian,     HarmonyDegree::Third},
    {1, 4, ScaleType::Hijaz,        HarmonyDegree::Third}
}};

} // namespace

TercaScanResult TercaScanner::scan(const std::array<int, 3>& midiNotes) {
    std::array<int, 3> notes = midiNotes;
    for (int& n : notes) n = std::clamp(n, 0, 127);

    // Smart scan: treat the three keys as a control chord, not as a fixed voicing.
    // Octave placement and inversion therefore do not matter; only the three pitch
    // classes matter.  We try the known scan cells in all 12 tonalities.
    const auto input = sortedPcs(notes);
    if (input[0] == input[1] || input[1] == input[2]) return {};

    for (int tonic = 0; tonic < 12; ++tonic) {
        for (const auto& cell : kCells) {
            if (input == templatePcs(tonic, cell.i1, cell.i2)) {
                return {true, tonic, cell.scale, cell.degree};
            }
        }
    }
    return {};
}

} // namespace silvetonlive
