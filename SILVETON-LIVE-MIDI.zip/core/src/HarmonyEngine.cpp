#include "silvetonlive/HarmonyEngine.h"
#include <algorithm>
#include <stdexcept>

namespace silvetonlive {

static constexpr std::array<int, 7> kMajor{{0,2,4,5,7,9,11}};
static constexpr std::array<int, 7> kNaturalMinor{{0,2,3,5,7,8,10}};
static constexpr std::array<int, 7> kHarmonicMinor{{0,2,3,5,7,8,11}};
static constexpr std::array<int, 7> kDorian{{0,2,3,5,7,9,10}};
static constexpr std::array<int, 7> kPhrygian{{0,1,3,5,7,8,10}};
static constexpr std::array<int, 7> kLydian{{0,2,4,6,7,9,11}};
static constexpr std::array<int, 7> kMixolydian{{0,2,4,5,7,9,10}};

const std::array<int, 7>& HarmonyEngine::intervalsFor(ScaleType type) {
    switch (type) {
        case ScaleType::Major: return kMajor;
        case ScaleType::NaturalMinor: return kNaturalMinor;
        case ScaleType::HarmonicMinor: return kHarmonicMinor;
        case ScaleType::Dorian: return kDorian;
        case ScaleType::Phrygian: return kPhrygian;
        case ScaleType::Lydian: return kLydian;
        case ScaleType::Mixolydian: return kMixolydian;
    }
    return kMajor;
}

void HarmonyEngine::setConfig(const HarmonyConfig& cfg) {
    config_ = cfg;
    config_.tonic = ((config_.tonic % 12) + 12) % 12;
}

void HarmonyEngine::setVoice(int index, const HarmonyVoice& voice) {
    if (index < 0 || index >= kMaxVoices) throw std::out_of_range("harmony voice index");
    voices_[static_cast<std::size_t>(index)] = voice;
}

const HarmonyVoice& HarmonyEngine::voice(int index) const {
    if (index < 0 || index >= kMaxVoices) throw std::out_of_range("harmony voice index");
    return voices_[static_cast<std::size_t>(index)];
}

int HarmonyEngine::scaleIndexAtOrBelow(int rel) const {
    const auto& s = intervalsFor(config_.scale);
    int octave = rel / 12;
    int pc = rel % 12;
    if (pc < 0) { pc += 12; --octave; }
    int degree = 0;
    for (int i = 0; i < 7; ++i) if (s[static_cast<std::size_t>(i)] <= pc) degree = i;
    return octave * 7 + degree;
}

int HarmonyEngine::harmonizeNote(int note, HarmonyDegree degree, int octaves) const {
    const auto& s = intervalsFor(config_.scale);
    const int rel = note - config_.tonic;
    int octave = rel / 12;
    int pc = rel % 12;
    if (pc < 0) { pc += 12; --octave; }

    int sourceDegree = -1;
    for (int i = 0; i < 7; ++i) {
        if (s[static_cast<std::size_t>(i)] == pc) { sourceDegree = i; break; }
    }
    if (sourceDegree < 0) {
        if (!config_.quantizeNonScaleNotes) {
            static constexpr int semis[8] = {0,2,4,5,7,9,11,12};
            const int d = std::clamp(static_cast<int>(degree), 0, 7);
            return std::clamp(note + semis[d] + 12 * octaves, 0, 127);
        }
        const int idx = scaleIndexAtOrBelow(rel);
        sourceDegree = ((idx % 7) + 7) % 7;
        octave = idx / 7;
        if (idx < 0 && idx % 7) --octave;
    }

    int targetIndex = sourceDegree + static_cast<int>(degree);
    int targetOctave = octave;
    while (targetIndex >= 7) { targetIndex -= 7; ++targetOctave; }
    while (targetIndex < 0) { targetIndex += 7; --targetOctave; }
    const int target = config_.tonic + targetOctave * 12 + s[static_cast<std::size_t>(targetIndex)] + 12 * octaves;
    return std::clamp(target, 0, 127);
}

void HarmonyEngine::releaseInputKey(int key, int velocity, std::int64_t ts, std::vector<MidiPacket>& out) {
    const auto it = activeGenerated_.find(key);
    if (it == activeGenerated_.end()) return;

    for (const int packed : it->second) {
        const auto rcIt = outputRefCount_.find(packed);
        if (rcIt == outputRefCount_.end()) continue;
        if (--rcIt->second <= 0) {
            out.push_back(noteOff((packed >> 8) & 0x0F, packed & 0x7F, velocity, ts));
            outputRefCount_.erase(rcIt);
        }
    }
    activeGenerated_.erase(it);
}

std::vector<MidiPacket> HarmonyEngine::processNoteOn(int channel, int note, int velocity, std::int64_t ts) {
    std::vector<MidiPacket> out;
    const int key = (clampChannel(channel) << 8) | clamp7(note);

    // A repeated NoteOn for the same input key is a retrigger. Release its prior
    // generated references first so the tracker can never leak a sounding note.
    releaseInputKey(key, 0, ts, out);

    std::vector<int> generated;
    for (const auto& v : voices_) {
        if (!v.enabled) continue;
        const int n = harmonizeNote(note, v.degree, v.octaves);
        const int ch = v.outputChannel < 0 ? clampChannel(channel) : clampChannel(v.outputChannel);
        const int vel = std::clamp(velocity + v.velocityOffset, 1, 127);
        const int packed = (ch << 8) | n;
        int& refs = outputRefCount_[packed];
        if (refs == 0) out.push_back(noteOn(ch, n, vel, ts));
        ++refs;
        generated.push_back(packed);
    }
    if (!generated.empty()) activeGenerated_[key] = std::move(generated);
    return out;
}

std::vector<MidiPacket> HarmonyEngine::processNoteOff(int channel, int note, int velocity, std::int64_t ts) {
    std::vector<MidiPacket> out;
    const int key = (clampChannel(channel) << 8) | clamp7(note);
    releaseInputKey(key, velocity, ts, out);
    return out;
}

std::vector<MidiPacket> HarmonyEngine::flush(std::int64_t ts, int velocity) {
    std::vector<MidiPacket> out;
    out.reserve(outputRefCount_.size());
    for (const auto& entry : outputRefCount_) {
        const int packed = entry.first;
        out.push_back(noteOff((packed >> 8) & 0x0F, packed & 0x7F, velocity, ts));
    }
    activeGenerated_.clear();
    outputRefCount_.clear();
    return out;
}

void HarmonyEngine::clear() {
    activeGenerated_.clear();
    outputRefCount_.clear();
}

} // namespace silvetonlive
