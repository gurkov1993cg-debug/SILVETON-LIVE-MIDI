#include "silvetonlive/MidiIdentity.h"

namespace silvetonlive {

MidiPacket MidiIdentityCodec::request(std::uint8_t deviceId, std::int64_t ts) {
    return {{0xF0, 0x7E, static_cast<std::uint8_t>(deviceId & 0x7F), 0x06, 0x01, 0xF7}, ts};
}

MidiIdentity MidiIdentityCodec::parseReply(const std::vector<std::uint8_t>& s) {
    MidiIdentity id;
    // Universal Non-Realtime Identity Reply:
    // F0 7E <device> 06 02 <manufacturer:1-or-3> <family2> <model2> <version4> F7
    if (s.size() < 15 || s.front() != 0xF0 || s.back() != 0xF7 ||
        s[1] != 0x7E || s[3] != 0x06 || s[4] != 0x02) return id;

    std::size_t p = 5;
    if (s[p] == 0x00) {
        if (s.size() < 17) return id;
        id.manufacturerId = {s[p], s[p + 1], s[p + 2]};
        p += 3;
    } else {
        id.manufacturerId = {s[p++]};
    }
    if (p + 2 + 2 + 4 >= s.size()) return MidiIdentity{};
    id.familyCode = {s[p], s[p + 1]}; p += 2;
    id.modelNumber = {s[p], s[p + 1]}; p += 2;
    id.version = {s[p], s[p + 1], s[p + 2], s[p + 3]};
    id.valid = true;
    if (id.manufacturerId.size() == 1 && id.manufacturerId[0] == 0x42)
        id.manufacturerName = "KORG";
    return id;
}

} // namespace silvetonlive
