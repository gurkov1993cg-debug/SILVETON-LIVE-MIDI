#include "silvetonlive/LatencyTracker.h"
#include <algorithm>
#include <cmath>

namespace silvetonlive {

void LatencyTracker::reset() { n_ = 0; meanNs_ = m2Ns_ = minNs_ = maxNs_ = 0.0; }

void LatencyTracker::addSampleNanos(std::int64_t latencyNanos) {
    const double x = static_cast<double>(std::max<std::int64_t>(0, latencyNanos));
    if (n_ == 0) minNs_ = maxNs_ = x;
    else { minNs_ = std::min(minNs_, x); maxNs_ = std::max(maxNs_, x); }
    ++n_;
    const double d = x - meanNs_;
    meanNs_ += d / static_cast<double>(n_);
    const double d2 = x - meanNs_;
    m2Ns_ += d * d2;
}

LatencyStats LatencyTracker::stats() const {
    LatencyStats s;
    s.samples = n_;
    if (n_ == 0) return s;
    constexpr double nsToMs = 1.0 / 1'000'000.0;
    s.minMs = minNs_ * nsToMs;
    s.maxMs = maxNs_ * nsToMs;
    s.meanMs = meanNs_ * nsToMs;
    s.jitterMs = (n_ > 1 ? std::sqrt(m2Ns_ / static_cast<double>(n_ - 1)) : 0.0) * nsToMs;
    return s;
}

} // namespace silvetonlive
