#include "silvetonlive/ModelProfile.h"
#include <algorithm>

namespace silvetonlive {

static Capability generic(const char* note) { return {SupportStatus::GenericMidi, note}; }
static Capability documented(const char* note) { return {SupportStatus::Documented, note}; }
static Capability unknown(const char* note) { return {SupportStatus::Unknown, note}; }

static ModelProfile makePa(const char* id, const char* name, bool docsConfirmCc5Cc65, bool docsConfirmRibbonCc16) {
    ModelProfile p;
    p.id = id;
    p.displayName = name;
    p.defaultMidiChannel = 0;
    p.capabilities.usbMidi = unknown("Physical Android/keyboard transport validation still required");
    p.capabilities.portamentoSwitch = docsConfirmCc5Cc65
        ? documented("KORG documentation identifies CC65 as Portamento On/Off/Switch")
        : generic("Standard MIDI CC65 path; physical/model documentation validation required");
    p.capabilities.portamentoTime = docsConfirmCc5Cc65
        ? documented("KORG documentation identifies CC5 as Portamento Time")
        : generic("Standard MIDI CC5 path; physical/model documentation validation required");
    p.capabilities.pitchBend = generic("Standard 14-bit MIDI Pitch Bend path");
    p.capabilities.ribbon = docsConfirmRibbonCc16
        ? documented("KORG documentation identifies CC16 as Ribbon Controller")
        : generic("Application-side ribbon can emit Pitch Bend or configurable CC");
    p.capabilities.intervalHarmony = generic("Application-side MIDI note generation; independent of keyboard harmony engine");
    p.capabilities.pads = generic("Application-side programmable Note/CC/Program Change actions");
    return p;
}

const std::vector<ModelProfile>& ModelRegistry::all() {
    static const std::vector<ModelProfile> profiles = {
        makePa("pa600",  "KORG PA600",  true,  false),
        makePa("pa700",  "KORG PA700",  true,  true),
        makePa("pa900",  "KORG PA900",  true,  true),
        makePa("pa1000", "KORG PA1000", true,  true),
        makePa("pa4x",   "KORG PA4X",   true,  true),
        makePa("pa5x",   "KORG PA5X",   true,  true),
    };
    return profiles;
}

const ModelProfile* ModelRegistry::byId(const std::string& id) {
    const auto& profiles = all();
    const auto it = std::find_if(profiles.begin(), profiles.end(), [&](const auto& p){ return p.id == id; });
    return it == profiles.end() ? nullptr : &*it;
}

} // namespace silvetonlive
