#include "silvetonlive/LiveMidiEngine.h"
#include <stdexcept>
#include <utility>

namespace silvetonlive {

LiveMidiEngine::LiveMidiEngine() {
    model_ = ModelRegistry::byId("pa600");
    if (!model_) throw std::runtime_error("PA600 profile missing");
    portamentoCalibration_.setPoints(model_->portamentoCalibration);
    padBanks_.loadInto(pads_);
}

bool LiveMidiEngine::selectModel(const std::string& modelId) {
    const auto* p = ModelRegistry::byId(modelId);
    if (!p) return false;
    model_ = p;
    portamentoCalibration_.setPoints(model_->portamentoCalibration);
    return true;
}

void LiveMidiEngine::setPortamentoEngineEnabled(bool enabled) {
    auto cfg = portamento_.config();
    cfg.enabled = enabled;
    portamento_.setConfig(cfg);
}

std::vector<MidiPacket> LiveMidiEngine::hardwarePortamentoSwitch(bool enabled, int channel) const {
    return {controlChange(channel, model_->portamentoSwitchCc, enabled ? 127 : 0)};
}

std::vector<MidiPacket> LiveMidiEngine::setPortamentoEnabled(bool enabled, int channel) {
    setPortamentoEngineEnabled(enabled);
    return hardwarePortamentoSwitch(enabled, channel);
}

std::vector<MidiPacket> LiveMidiEngine::applyPortamentoTime(int channel) {
    int value = portamento_.midiPortamentoTimeValue();
    if (portamentoCalibration_.valid()) {
        const int calibrated = portamentoCalibration_.ccForMilliseconds(portamento_.config().durationMs);
        if (calibrated >= 0) value = calibrated;
    }
    return {controlChange(channel, model_->portamentoTimeCc, value)};
}

void LiveMidiEngine::setPortamentoCalibration(std::vector<PortamentoCalibrationPoint> points) {
    portamentoCalibration_.setPoints(std::move(points));
}

void LiveMidiEngine::clearPortamentoCalibration() {
    portamentoCalibration_.setPoints({});
}

std::vector<MidiPacket> LiveMidiEngine::panic(bool allChannels, int channel) {
    intervals_.clear();
    harmony_.clear();
    (void)pads_.flush(0); // clear latch state; PanicEngine below silences the actual MIDI target.
    for (auto& p : portaBridge_) p.reset();
    return PanicEngine::build(*model_, allChannels, channel);
}


std::vector<MidiPacket> LiveMidiEngine::flushHarmony(std::int64_t ts) {
    return harmony_.flush(ts);
}

std::vector<MidiPacket> LiveMidiEngine::flushIntervals(std::int64_t ts) {
    return intervals_.flush(ts);
}

std::vector<MidiPacket> LiveMidiEngine::flushPads(std::int64_t ts) {
    return pads_.flush(ts);
}

std::vector<MidiPacket> LiveMidiEngine::portaBridgeNoteOn(int outputChannel, int note, int velocity,
                                                           std::int64_t ts, int bendRangeSemitones) {
    const int ch = clampChannel(outputChannel);
    auto cfg = portaBridge_[static_cast<std::size_t>(ch)].config();
    cfg.channel = ch;
    cfg.bendRangeSemitones = bendRangeSemitones;
    portaBridge_[static_cast<std::size_t>(ch)].setConfig(cfg);
    return portaBridge_[static_cast<std::size_t>(ch)].noteOn(portamento_, note, velocity, ts);
}

std::vector<MidiPacket> LiveMidiEngine::portaBridgeNoteOff(int outputChannel, int note, int velocity,
                                                            std::int64_t ts) {
    const int ch = clampChannel(outputChannel);
    return portaBridge_[static_cast<std::size_t>(ch)].noteOff(portamento_, note, velocity, ts);
}

std::vector<MidiPacket> LiveMidiEngine::resetPortaBridge(std::int64_t ts) {
    std::vector<MidiPacket> out;
    for (auto& p : portaBridge_) {
        auto flushed = p.flush(ts, 0);
        out.insert(out.end(), flushed.begin(), flushed.end());
    }
    return out;
}

std::vector<MidiPacket> LiveMidiEngine::resetPortaBridgeChannel(int outputChannel, std::int64_t ts) {
    const int ch = clampChannel(outputChannel);
    return portaBridge_[static_cast<std::size_t>(ch)].flush(ts, 0);
}

MidiPacket LiveMidiEngine::identityRequest(std::uint8_t deviceId) const {
    return MidiIdentityCodec::request(deviceId);
}

} // namespace silvetonlive
