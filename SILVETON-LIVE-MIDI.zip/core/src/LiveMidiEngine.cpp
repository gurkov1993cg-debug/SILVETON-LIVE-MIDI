#include "silvetonlive/LiveMidiEngine.h"
#include <stdexcept>

namespace silvetonlive {

LiveMidiEngine::LiveMidiEngine() {
    model_ = ModelRegistry::byId("pa600");
    if (!model_) throw std::runtime_error("PA600 profile missing");
    padBanks_.loadInto(pads_);
}

bool LiveMidiEngine::selectModel(const std::string& modelId) {
    const auto* p = ModelRegistry::byId(modelId);
    if (!p) return false;
    model_ = p;
    return true;
}

std::vector<MidiPacket> LiveMidiEngine::panic(bool allChannels, int channel) {
    (void)pads_.flush(0);
    return PanicEngine::build(*model_, allChannels, channel);
}

std::vector<MidiPacket> LiveMidiEngine::flushPads(std::int64_t ts) {
    return pads_.flush(ts);
}

MidiPacket LiveMidiEngine::identityRequest(std::uint8_t deviceId) const {
    return MidiIdentityCodec::request(deviceId);
}

} // namespace silvetonlive
