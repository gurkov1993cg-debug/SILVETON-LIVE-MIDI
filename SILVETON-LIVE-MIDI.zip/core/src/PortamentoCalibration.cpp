#include "silvetonlive/PortamentoCalibration.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace silvetonlive {

void PortamentoCalibration::setPoints(std::vector<PortamentoCalibrationPoint> points) {
    points.erase(std::remove_if(points.begin(), points.end(), [](const auto& p) {
        return p.cc < 0 || p.cc > 127 || !std::isfinite(p.measuredMs) || p.measuredMs <= 0.0;
    }), points.end());
    std::sort(points.begin(), points.end(), [](const auto& a, const auto& b) { return a.cc < b.cc; });
    points.erase(std::unique(points.begin(), points.end(), [](const auto& a, const auto& b) {
        return a.cc == b.cc;
    }), points.end());

    // A usable table must be monotonic non-decreasing in measured time.
    for (std::size_t i = 1; i < points.size(); ++i) {
        if (points[i].measuredMs < points[i - 1].measuredMs) {
            throw std::invalid_argument("portamento calibration must be monotonic");
        }
    }
    points_ = std::move(points);
}

static double interp(double x, double x0, double x1, double y0, double y1) {
    if (x1 <= x0) return y0;
    const double t = std::clamp((x - x0) / (x1 - x0), 0.0, 1.0);
    return y0 + (y1 - y0) * t;
}

int PortamentoCalibration::ccForMilliseconds(double ms) const {
    if (!valid()) return -1;
    ms = std::max(ms, points_.front().measuredMs);
    if (ms >= points_.back().measuredMs) return points_.back().cc;

    for (std::size_t i = 1; i < points_.size(); ++i) {
        if (ms <= points_[i].measuredMs) {
            const auto& a = points_[i - 1];
            const auto& b = points_[i];
            // Time responses are commonly closer to exponential than linear,
            // so interpolate in log-time while preserving measured endpoints.
            const double lx = std::log(ms);
            const double l0 = std::log(a.measuredMs);
            const double l1 = std::log(b.measuredMs);
            const double mapped = interp(lx, l0, l1, static_cast<double>(a.cc),
                                         static_cast<double>(b.cc));
            return std::clamp(static_cast<int>(std::lround(mapped)), 0, 127);
        }
    }
    return points_.back().cc;
}

double PortamentoCalibration::millisecondsForCc(int cc) const {
    if (!valid()) return -1.0;
    cc = std::clamp(cc, points_.front().cc, points_.back().cc);
    if (cc <= points_.front().cc) return points_.front().measuredMs;
    if (cc >= points_.back().cc) return points_.back().measuredMs;

    for (std::size_t i = 1; i < points_.size(); ++i) {
        if (cc <= points_[i].cc) {
            const auto& a = points_[i - 1];
            const auto& b = points_[i];
            const double lms = interp(static_cast<double>(cc), static_cast<double>(a.cc),
                                      static_cast<double>(b.cc), std::log(a.measuredMs),
                                      std::log(b.measuredMs));
            return std::exp(lms);
        }
    }
    return points_.back().measuredMs;
}

} // namespace silvetonlive
