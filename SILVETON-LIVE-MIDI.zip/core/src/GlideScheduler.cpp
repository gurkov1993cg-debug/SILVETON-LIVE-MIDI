#include "silvetonlive/GlideScheduler.h"
#include <algorithm>
#include <cmath>

namespace silvetonlive {

std::vector<MidiPacket> GlideScheduler::build(const PortamentoEngine& engine,
                                              int startNote, int endNote,
                                              std::int64_t startTimeNanos,
                                              const GlideScheduleConfig& cfg) {
    std::vector<MidiPacket> out;
    const int delta = endNote - startNote;
    if (delta == 0 || !engine.config().enabled) {
        out.push_back(pitchBend14(cfg.channel, 8192, startTimeNanos));
        return out;
    }

    const int range = std::max(1, cfg.bendRangeSemitones);
    const double sourceOffsetSemitones = static_cast<double>(startNote - endNote);
    const double durationMs = engine.effectiveDurationMs(delta);
    const double durationNs = durationMs * 1'000'000.0;

    // SMART/FIX portamento follows the equal-total-time principle:
    //   pitch distance changes the size of each bend step, NOT the total time.
    // A 1-semitone and a 12-semitone jump therefore end on the same timestamp.
    // We target roughly one update per millisecond, capped for long glides.
    if (engine.config().mode == PortaMode::Fix || engine.config().mode == PortaMode::Custom) {
        const std::size_t points = static_cast<std::size_t>(
            std::clamp(static_cast<int>(std::floor(durationMs)) + 1, 2, 512));
        out.reserve(points + (cfg.resetAtEnd ? 1u : 0u));

        const double normalizedStart = std::clamp(
            sourceOffsetSemitones / static_cast<double>(range), -1.0, 1.0);
        const double bendSpan = normalizedStart * (normalizedStart >= 0.0 ? 8191.0 : 8192.0);
        const double depth = std::clamp(engine.config().depth, 0.05, 8.0);

        for (std::size_t i = 0; i < points; ++i) {
            const double t = points <= 1 ? 1.0 :
                static_cast<double>(i) / static_cast<double>(points - 1);
            const double shaped = std::pow(t, 1.0 / depth);
            const double remaining = 1.0 - shaped;
            const int bend = static_cast<int>(std::lround(8192.0 + bendSpan * remaining));
            const auto time = startTimeNanos + static_cast<std::int64_t>(std::llround(t * durationNs));
            out.push_back(pitchBend14(cfg.channel, std::clamp(bend, 0, 16383), time));
        }

        if (cfg.resetAtEnd && (out.empty() || out.back().bytes != pitchBend14(cfg.channel, 8192).bytes)) {
            out.push_back(pitchBend14(cfg.channel, 8192,
                startTimeNanos + static_cast<std::int64_t>(std::llround(durationNs))));
        }
        return out;
    }

    // Other modes keep their own musical time/shape laws.
    const auto curve = engine.buildCurve(delta);
    const std::size_t maxCurvePoints = static_cast<std::size_t>(
        std::clamp(static_cast<int>(std::floor(durationMs)) + 1, 2, 512));
    const std::size_t emitPoints = std::min(curve.size(), maxCurvePoints);
    out.reserve(emitPoints + (cfg.resetAtEnd ? 1u : 0u));

    for (std::size_t j = 0; j < emitPoints; ++j) {
        const std::size_t i = emitPoints <= 1 ? 0 :
            static_cast<std::size_t>(std::llround(
                static_cast<double>(j) * static_cast<double>(curve.size() - 1) /
                static_cast<double>(emitPoints - 1)));
        const auto& pt = curve[i];
        const double remaining = (1.0 - pt.position01) * sourceOffsetSemitones;
        const double normalized = std::clamp(remaining / static_cast<double>(range), -1.0, 1.0);
        const int bend = static_cast<int>(std::lround(
            8192.0 + normalized * (normalized >= 0 ? 8191.0 : 8192.0)));
        const auto t = startTimeNanos + static_cast<std::int64_t>(std::llround(pt.t01 * durationNs));
        out.push_back(pitchBend14(cfg.channel, bend, t));
    }

    if (cfg.resetAtEnd && (out.empty() || out.back().bytes != pitchBend14(cfg.channel, 8192).bytes)) {
        out.push_back(pitchBend14(cfg.channel, 8192,
            startTimeNanos + static_cast<std::int64_t>(std::llround(durationNs))));
    }
    return out;
}

} // namespace silvetonlive
