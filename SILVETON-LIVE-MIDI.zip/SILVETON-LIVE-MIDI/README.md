# SILVETON LIVE MIDI

Android USB-OTG MIDI performance app for Korg Pa600+.

Locked live screen:
- Global Portamento for Upper 1/2/3
- TERCA: SCAN TERCA + ON/OFF only
- Large Ribbon with working sensitivity
- MIDI mapping: Channel 1/2/3, defaults 1/2/3
- Auto USB MIDI connection
- Lower/Style channels pass through unchanged

The approved GUI reference is `docs/APPROVED_UI.png`.
