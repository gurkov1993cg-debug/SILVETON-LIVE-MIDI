# SILVETON LIVE MIDI

Android live MIDI processor/controller for Korg Pa600.

## Isolated modules

- `Portamento` — controls the **native Pa600 Portamento** only. It emits MIDI CC#65 (On/Off) and CC#5 (Time). It does not synthesize glide with Pitch Bend and does not rewrite Note On/Off.
- `ThirdModule` — independent fixed-tonality diatonic third generator/scanner.
- `Ribbon` — independent touch controller with manual semitone range and sensitivity.
- `PitchCoordinator` — combines only Ribbon + physical/manual Pitch Bend. Native Pa600 Portamento is not part of this pitch-bend path.

Default Upper mapping is MIDI 1 / 2 / 3. Non-Upper arranger traffic remains transparent.
## Performance behavior

- Portamento is performed by the Pa600 sound engine itself. The app sends CC#5 (Time) and CC#65 (On/Off) on Upper 1/2/3 and re-asserts the current values immediately before every Note On, so adjacent and wide intervals use the same current native-portamento state.
- Ribbon is an independent high-resolution performance engine. Finger motion is critically damped in the native C++ core and rendered as 14-bit pitch control on Upper 1/2/3. Sensitivity changes response shape only; RANGE controls the musical span (±1..±12 semitones).

