# SILVETON LIVE MIDI

Android USB-MIDI live controller for Korg PA.

Architecture:
- `Portamento` — isolated note/glide state only.
- `ThirdModule` — isolated fixed-tonality diatonic third + scan state only.
- `Ribbon` — isolated ribbon response only.
- `PitchCoordinator` — infrastructure that combines independent Portamento/manual/Ribbon pitch contributions so modules never overwrite each other.
- `MidiRouter` — routes events between independent modules.

Default Upper mapping: MIDI 1 / 2 / 3.
