# SILVETON LIVE MIDI

Android USB-MIDI performance controller for Korg Pa-series keyboards.

## Locked defaults
- Upper 1 = MIDI channel 1
- Upper 2 = MIDI channel 2
- Upper 3 = MIDI channel 3
- Portamento time = 180 ms
- Pitch-bend range = +/-12 semitones
- USB OTG is the primary live connection
- Korg Local Control must be OFF while routing keyboard notes through the app

## Current module
The Portamento module is implemented as an independent module with last-note priority per Upper channel. The first note starts immediately. Legato transitions glide from the previous sounding pitch to the new target in a fixed amount of time, independent of interval size (within the configured +/-12 semitone bend range).

All non-Upper MIDI channels pass through unchanged. Upper-channel pitch bend is combined with the Portamento bend so hardware pitch control does not fight the glide engine. The Android layer owns the single MIDI output path and includes an anti-loop guard.

Third and Ribbon remain separate modules by design and are not embedded into Portamento.
