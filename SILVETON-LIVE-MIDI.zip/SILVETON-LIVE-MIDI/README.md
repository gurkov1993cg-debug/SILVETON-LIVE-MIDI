# SILVETON LIVE MIDI

Android USB-MIDI processor/controller for Korg Pa600.

**Setup (Bulgarian): see `KORG_SETUP.md`. The app mode must match PA600 Local Control.**

## Keyboard Local modes (v0.3.0)

- `LOCAL ON` (default, recommended): PA600 Local Control ON. The PA600 plays its own
  keybed. The app never echoes any keyboard message back; it only sends what it
  generates (TERCA notes on U3, Portamento CC5/CC65, Ribbon Pitch Bend).
- `LOCAL OFF`: PA600 Local Control OFF. The app bridges U1/U2/U3 through the native
  router and returns the configured Lower channel unchanged. Nothing else is echoed:
  no System Realtime (Clock/Active Sensing), no SysEx, no style/chord/player channels.

Echo safety: only real USB MIDI devices are opened (KORG/PA names preferred), never
virtual or Bluetooth ports. A runaway-traffic breaker (>500 channel messages per
100 ms) releases all notes and mutes input for 2 s, showing `MIDI LOOP STOPPED`.

## Architecture

- `MidiController` — Android MIDI device/port lifecycle, channel mapping and final USB path.
- `Pa600MidiSender` — the single final `MidiInputPort.send()` transport, debug byte trace and physical-output note mirror.
- `NativeMidiEngine` / JNI — one native entry point; no parallel MIDI engine.
- `MidiRouter` — canonical U1/U2/U3 routing plus authoritative native active-note ledger.
- `Portamento` — Korg-native Portamento control only: CC#5 Time and CC#65 On/Off. No software Pitch-Bend glide.
- `ThirdModule` — fixed scanned tonality, explicit scan state machine and generated-note ownership. TERCA output is always U3.
- `Ribbon` — independent smoothed performance controller with ±1..±12 semitone range.
- `PitchCoordinator` — combines Ribbon with physical/manual Pitch Bend. Portamento is not part of this path.

Default canonical mapping: U1=MIDI Ch1, U2=MIDI Ch2, U3=MIDI Ch3. User channel mapping happens only at the final Android boundary, so native modules always use canonical channels 0/1/2.

## Note safety

`9n NN 00` is treated as Note Off. C++ and the final Kotlin sender both track active notes. CC120, CC123, Panic and disconnect clear internal note state. Panic releases known notes, sends CC123 + CC120 on U1/U2/U3 and centers Pitch Bend.

No timing/echo heuristic suppresses channel voice messages. The old `LoopGuard` was removed: echo safety now comes from never returning system/style traffic and from the Local mode. The UI has a PANIC button.

## Native Pa600 Portamento

Desired state is sent to U1/U2/U3 with exact channel status bytes. Enabling sends CC#5 before CC#65 for each Upper. The app does not inject CC5/CC65 before every note. State is synchronized at connection, when the user changes Portamento controls, and once for the affected Upper after Program Change.

Adjacent and wide note events are passed unchanged to Pa600; the Pa600 sound engine performs the actual glide.

## TERCA

SCAN states: `Idle`, `Scanning`, `WaitingForRelease`, `Locked`.

Six scan cells, recognised in all 12 tonalities, any octave/inversion (pitch classes from U1):
`0,4,7` major third up, `0,2,4` major third down, `0,3,7` minor third up, `0,2,3` minor
third down, `0,1,3` phrygian third up, `0,1,4` hijaz third up. The harmony is a diatonic
third (two scale steps) inside the fixed scale, above or below. Out-of-scale notes get
no harmony. Generated notes use U3 only with source/reference ownership. The UI shows the
recognised result (e.g. `D MINOR ↓`).

## Ribbon

Ribbon runs independently on U1/U2/U3. Range is manually selectable from ±1 to ±12 semitones; default ±2. Sensitivity changes response shape only, not final range. The native C++ trajectory is smoothed and rendered as 14-bit Pitch Bend.

Before Ribbon is actually moved, physical PA600 Pitch Bend is passed through byte-for-byte (Local OFF) or ignored (Local ON). About 250 ms after the Ribbon is released and centred, RPN 0 is restored to ±2 and the raw wheel position is re-asserted, so the wheel never stays at ±12. The native engine still remembers the physical wheel position, so switching into the ±12 Ribbon transport preserves the current ±2 musical wheel offset instead of jumping to center.

## Debug MIDI trace

Debug builds trace the final bytes accepted by `MidiInputPort.send()`, for example:

```
OUT B0 05 40 PORTA TIME U1
OUT B0 41 7F PORTA ON U1
OUT 90 3C 64 NOTE ON U1
OUT 92 40 64 TERCA U3
```

The trace path does not depend on generated `BuildConfig`. It is gated with Android `Log.isLoggable("MIDI_TRACE", Log.DEBUG)`, so production does not continuously format/log MIDI traffic.


## Local Control OFF transparent baseline

When all three performance modules are inactive, connecting the app does not send RPN, Portamento CCs, or Pitch Bend resets. Upper note/control/program/pitch traffic remains transparent through the Kotlin -> JNI -> C++ -> Android MIDI output path. Native PA600 Portamento is armed only when the Portamento control is enabled; Ribbon configures its wider pitch transport only when Ribbon is actually moved; TERCA remains isolated on U3 after a valid fixed-tonality scan.
