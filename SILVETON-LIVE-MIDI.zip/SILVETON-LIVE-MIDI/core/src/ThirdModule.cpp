#include "silveton/ThirdModule.h"
#include <algorithm>
#include <cstdlib>

namespace silveton {

void ThirdModule::startScan() {
    scanning_ = true;
    detectedInterval_ = 0;
    lastUpper1Note_ = -1;
    lastUpper3Note_ = -1;
    lastUpper1Us_ = 0;
    lastUpper3Us_ = 0;
    scanFirstNote_ = -1;
    scanFirstUs_ = 0;
}

void ThirdModule::acceptInterval(int interval) {
    if (interval == 0) return;
    while (interval > 12) interval -= 12;
    while (interval < -12) interval += 12;
    if (std::abs(interval) == 3 || std::abs(interval) == 4) {
        detectedInterval_ = interval;
        scanning_ = false;
    }
}

void ThirdModule::tryDetectPair() {
    if (!scanning_ || lastUpper1Note_ < 0 || lastUpper3Note_ < 0) return;
    if (std::llabs(lastUpper1Us_ - lastUpper3Us_) > 150000) return;
    acceptInterval(lastUpper3Note_ - lastUpper1Note_);
}

void ThirdModule::observeScan(const MidiMessage& message, std::int64_t nowUs) {
    if (!scanning_ || !message.isNoteOn()) return;

    if (message.channel() == 0) {
        lastUpper1Note_ = message.data1;
        lastUpper1Us_ = nowUs;

        // Fallback learn mode: two played notes a third apart on Upper 1.
        if (scanFirstNote_ < 0) {
            scanFirstNote_ = message.data1;
            scanFirstUs_ = nowUs;
        } else if (message.data1 != scanFirstNote_ && nowUs - scanFirstUs_ <= 1500000) {
            acceptInterval(int(message.data1) - scanFirstNote_);
        }
        tryDetectPair();
    } else if (message.channel() == 2) {
        lastUpper3Note_ = message.data1;
        lastUpper3Us_ = nowUs;
        tryDetectPair();
    }
}

std::vector<MidiMessage> ThirdModule::generateFromUpper1(const MidiMessage& message) const {
    if (!enabled_ || message.channel() != 0) return {};
    if (!message.isNoteOn() && !message.isNoteOff()) return {};

    int note = int(message.data1) + detectedInterval_;
    note = std::clamp(note, 0, 127);
    if (message.isNoteOn()) return {MidiMessage::noteOn(2, note, message.data2)};
    return {MidiMessage::noteOff(2, note, message.data2)};
}

bool ThirdModule::isRawUpper3Musical(const MidiMessage& message) const {
    if (message.channel() != 2) return false;
    if (message.isNoteOn() || message.isNoteOff() || message.isPitchBend()) return true;
    const int cmd = message.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

} // namespace silveton
