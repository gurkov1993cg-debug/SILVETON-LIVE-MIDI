#include "silveton/ThirdModule.h"
#include <algorithm>
#include <array>
#include <set>

namespace silveton {

namespace {
constexpr std::size_t kNoteCount = 128;
}

void ThirdModule::startScan() {
    scanState_ = ScanState::Scanning;
    scanHeldU1_.fill(false);
    for (auto& channel : scanMutedRefs_) channel.fill(0);
    for (auto& channel : cancelledReleaseRefs_) channel.fill(0);
}

void ThirdModule::cancelScan() {
    // Return sound immediately, but remember the already-muted scan key presses
    // so their later releases cannot leak into the normal MIDI stream.
    for (std::size_t ch = 0; ch < scanMutedRefs_.size(); ++ch) {
        for (std::size_t note = 0; note < kNoteCount; ++note) {
            cancelledReleaseRefs_[ch][note] = scanMutedRefs_[ch][note];
        }
        scanMutedRefs_[ch].fill(0);
    }
    scanHeldU1_.fill(false);
    scanState_ = tonalityValid_ ? ScanState::Locked : ScanState::Idle;
}

int ThirdModule::scanResultCode() const {
    if (scanState_ == ScanState::Scanning || !tonalityValid_) return 0;
    return 1 + rootPitchClass_ + (scaleMode_ == ScaleMode::Minor ? 12 : 0);
}

bool ThirdModule::detectHeldTriad() {
    std::set<int> pcs;
    for (int note = 0; note < 128; ++note) {
        if (scanHeldU1_[static_cast<std::size_t>(note)]) pcs.insert(note % 12);
    }
    if (pcs.size() != 3) return false;

    for (int root = 0; root < 12; ++root) {
        const std::set<int> major{root, (root + 4) % 12, (root + 7) % 12};
        if (pcs == major) {
            rootPitchClass_ = root;
            scaleMode_ = ScaleMode::Major;
            tonalityValid_ = true;
            enabled_ = true;
            scanState_ = ScanState::WaitingForRelease;
            ++scanRevision_;
            return true;
        }
        const std::set<int> minor{root, (root + 3) % 12, (root + 7) % 12};
        if (pcs == minor) {
            rootPitchClass_ = root;
            scaleMode_ = ScaleMode::Minor;
            tonalityValid_ = true;
            enabled_ = true;
            scanState_ = ScanState::WaitingForRelease;
            ++scanRevision_;
            return true;
        }
    }
    return false;
}

bool ThirdModule::anyScanMutedHeld() const {
    for (const auto& channel : scanMutedRefs_) {
        for (std::uint16_t refs : channel) {
            if (refs != 0) return true;
        }
    }
    return false;
}

void ThirdModule::observeScan(const MidiMessage& message) {
    if (!scanSilenceActive()) return;
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return;

    const std::size_t channelIndex = static_cast<std::size_t>(ch);
    const std::size_t noteIndex = static_cast<std::size_t>(message.data1 & 0x7F);

    if (message.isNoteOn()) {
        auto& refs = scanMutedRefs_[channelIndex][noteIndex];
        if (refs < UINT16_MAX) ++refs;
        if (ch == 0 && scanState_ == ScanState::Scanning) {
            scanHeldU1_[noteIndex] = true;
            detectHeldTriad();
        }
    } else if (message.isNoteOff()) {
        auto& refs = scanMutedRefs_[channelIndex][noteIndex];
        if (refs > 0) --refs;
        if (ch == 0) scanHeldU1_[noteIndex] = false;
    }

    if (scanState_ == ScanState::WaitingForRelease && !anyScanMutedHeld()) {
        scanState_ = ScanState::Locked;
        scanHeldU1_.fill(false);
    }
}

bool ThirdModule::shouldMuteScanMessage(const MidiMessage& message) const {
    if (!scanSilenceActive()) return false;
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return false;
    if (message.isNoteOn() || message.isNoteOff() || message.isPitchBend()) return true;
    const int cmd = message.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

bool ThirdModule::consumeCancelledScanRelease(const MidiMessage& message) {
    if (!message.isNoteOff()) return false;
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return false;
    auto& refs = cancelledReleaseRefs_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(message.data1 & 0x7F)];
    if (refs == 0) return false;
    --refs;
    return true;
}

bool ThirdModule::pitchClassInScale(int relativePc, int& degree) const {
    static constexpr std::array<int, 7> major{{0, 2, 4, 5, 7, 9, 11}};
    static constexpr std::array<int, 7> minor{{0, 2, 3, 5, 7, 8, 10}};
    const auto& scale = (scaleMode_ == ScaleMode::Major) ? major : minor;
    for (int i = 0; i < 7; ++i) {
        if (scale[static_cast<std::size_t>(i)] == relativePc) {
            degree = i;
            return true;
        }
    }
    return false;
}

int ThirdModule::diatonicThirdFor(int sourceNote) const {
    if (!tonalityValid_) return -1;
    const int pc = ((sourceNote % 12) + 12) % 12;
    const int relative = (pc - rootPitchClass_ + 12) % 12;
    int degree = -1;
    if (!pitchClassInScale(relative, degree)) return -1;

    static constexpr std::array<int, 7> major{{0, 2, 4, 5, 7, 9, 11}};
    static constexpr std::array<int, 7> minor{{0, 2, 3, 5, 7, 8, 10}};
    const auto& scale = (scaleMode_ == ScaleMode::Major) ? major : minor;

    const int targetDegree = degree + 2;
    const int octaveAdd = targetDegree >= 7 ? 12 : 0;
    const int targetRelative = scale[static_cast<std::size_t>(targetDegree % 7)] + octaveAdd;
    const int semitoneDelta = targetRelative - scale[static_cast<std::size_t>(degree)];
    const int result = sourceNote + semitoneDelta;
    if (result < 0 || result > 127) return -1;
    return result;
}

std::vector<MidiMessage> ThirdModule::processUpper1(const MidiMessage& message) {
    if (!enabled_ || !tonalityValid_ || message.channel() != 0) return {};
    if (!message.isNoteOn() && !message.isNoteOff()) return {};

    const std::size_t source = static_cast<std::size_t>(message.data1 & 0x7F);

    if (message.isNoteOn()) {
        const int harmony = diatonicThirdFor(static_cast<int>(message.data1));
        if (harmony < 0) return {};
        const std::size_t harmonyIndex = static_cast<std::size_t>(harmony);

        if (sourceRefs_[source] == 0) sourceHarmony_[source] = harmony;
        if (sourceRefs_[source] < UINT16_MAX) ++sourceRefs_[source];
        if (harmonyRefs_[harmonyIndex] < UINT16_MAX) ++harmonyRefs_[harmonyIndex];

        if (harmonyRefs_[harmonyIndex] == 1) {
            return {MidiMessage::noteOn(2, harmony, message.data2)};
        }
        return {};
    }

    if (sourceRefs_[source] == 0) return {};
    const int harmony = sourceHarmony_[source];
    --sourceRefs_[source];
    if (sourceRefs_[source] == 0) sourceHarmony_[source] = -1;
    if (harmony < 0 || harmony > 127) return {};

    auto& harmonyRefs = harmonyRefs_[static_cast<std::size_t>(harmony)];
    if (harmonyRefs > 0) --harmonyRefs;
    if (harmonyRefs == 0) return {MidiMessage::noteOffZero(2, harmony)};
    return {};
}

void ThirdModule::clearGeneratedState() {
    sourceRefs_.fill(0);
    sourceHarmony_.fill(-1);
    harmonyRefs_.fill(0);
}

bool ThirdModule::isRawUpper3Musical(const MidiMessage& message) const {
    if (!ownsRawUpper3() || message.channel() != 2) return false;
    if (message.isNoteOn() || message.isNoteOff()) return true;
    const int cmd = message.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

} // namespace silveton
