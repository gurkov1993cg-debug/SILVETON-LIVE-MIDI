#include "silveton/ThirdModule.h"
#include <algorithm>
#include <array>
#include <set>

namespace silveton {

void ThirdModule::startScan() {
    scanning_ = true;
    scanHeld_.fill(false);
}

void ThirdModule::cancelScan() {
    scanning_ = false;
    scanHeld_.fill(false);
}

void ThirdModule::toggleScan() {
    if (scanning_) cancelScan();
    else startScan();
}

int ThirdModule::scanResultCode() const {
    if (scanning_ || !tonalityValid_) return 0;
    // 1..12 major, 13..24 minor. C major is therefore never confused with "no result".
    return 1 + rootPitchClass_ + (scaleMode_ == ScaleMode::Minor ? 12 : 0);
}

bool ThirdModule::detectHeldTriad() {
    std::set<int> pcs;
    for (int note = 0; note < 128; ++note) {
        if (scanHeld_[static_cast<std::size_t>(note)]) pcs.insert(note % 12);
    }
    if (pcs.size() != 3) return false;

    for (int root = 0; root < 12; ++root) {
        const std::set<int> major{root, (root + 4) % 12, (root + 7) % 12};
        if (pcs == major) {
            rootPitchClass_ = root;
            scaleMode_ = ScaleMode::Major;
            tonalityValid_ = true;
            scanning_ = false;
            scanHeld_.fill(false);
            return true;
        }
        const std::set<int> minor{root, (root + 3) % 12, (root + 7) % 12};
        if (pcs == minor) {
            rootPitchClass_ = root;
            scaleMode_ = ScaleMode::Minor;
            tonalityValid_ = true;
            scanning_ = false;
            scanHeld_.fill(false);
            return true;
        }
    }
    return false;
}

void ThirdModule::observeScan(const MidiMessage& message) {
    if (!scanning_ || message.channel() != 0) return;
    if (message.isNoteOn()) {
        scanHeld_[static_cast<std::size_t>(message.data1)] = true;
        detectHeldTriad();
    } else if (message.isNoteOff()) {
        scanHeld_[static_cast<std::size_t>(message.data1)] = false;
        bool any = false;
        for (bool held : scanHeld_) any = any || held;
        if (!any) scanHeld_.fill(false);
    }
}

bool ThirdModule::pitchClassInScale(int relativePc, int& degree) const {
    static constexpr std::array<int, 7> major{{0, 2, 4, 5, 7, 9, 11}};
    static constexpr std::array<int, 7> minor{{0, 2, 3, 5, 7, 8, 10}};
    const auto& scale = (scaleMode_ == ScaleMode::Major) ? major : minor;
    for (int i = 0; i < 7; ++i) {
        if (scale[static_cast<std::size_t>(i)] == relativePc) {
            degree = i;
            return true;
        }
    }
    return false;
}

int ThirdModule::diatonicThirdFor(int sourceNote) const {
    if (!tonalityValid_) return -1;
    const int pc = ((sourceNote % 12) + 12) % 12;
    const int relative = (pc - rootPitchClass_ + 12) % 12;
    int degree = -1;
    if (!pitchClassInScale(relative, degree)) return -1; // Never create a note outside the fixed tonality.

    static constexpr std::array<int, 7> major{{0, 2, 4, 5, 7, 9, 11}};
    static constexpr std::array<int, 7> minor{{0, 2, 3, 5, 7, 8, 10}};
    const auto& scale = (scaleMode_ == ScaleMode::Major) ? major : minor;

    const int targetDegree = degree + 2;
    const int octaveAdd = targetDegree >= 7 ? 12 : 0;
    const int targetRelative = scale[static_cast<std::size_t>(targetDegree % 7)] + octaveAdd;
    const int semitoneDelta = targetRelative - scale[static_cast<std::size_t>(degree)];
    const int result = sourceNote + semitoneDelta;
    if (result < 0 || result > 127) return -1;
    return result;
}

std::vector<MidiMessage> ThirdModule::generateFromUpper1(const MidiMessage& message) const {
    if (!enabled_ || !tonalityValid_ || message.channel() != 0) return {};
    if (!message.isNoteOn() && !message.isNoteOff()) return {};

    const int note = diatonicThirdFor(int(message.data1));
    if (note < 0) return {};
    if (message.isNoteOn()) return {MidiMessage::noteOn(2, note, message.data2)};
    return {MidiMessage::noteOff(2, note, message.data2)};
}

bool ThirdModule::isRawUpper3Musical(const MidiMessage& message) const {
    if (!ownsRawUpper3() || message.channel() != 2) return false;
    if (message.isNoteOn() || message.isNoteOff()) return true;
    const int cmd = message.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

} // namespace silveton
