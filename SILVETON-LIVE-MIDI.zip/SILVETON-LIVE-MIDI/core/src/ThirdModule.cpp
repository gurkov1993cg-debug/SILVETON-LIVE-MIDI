#include "silveton/ThirdModule.h"
#include <algorithm>
#include <cstdlib>

namespace silveton {

void ThirdModule::startScan() {
    scanning_ = true;
    detectedInterval_ = 0;
    lastUpper1Note_ = -1;
    lastUpper3Note_ = -1;
    lastUpper1Us_ = 0;
    lastUpper3Us_ = 0;
}

void ThirdModule::tryDetect() {
    if (!scanning_ || lastUpper1Note_ < 0 || lastUpper3Note_ < 0) return;

    const auto deltaUs = std::llabs(lastUpper1Us_ - lastUpper3Us_);
    if (deltaUs > 120000) return;

    int interval = lastUpper3Note_ - lastUpper1Note_;
    while (interval > 12) interval -= 12;
    while (interval < -12) interval += 12;

    // A musical third is 3 or 4 semitones in either direction.
    if (std::abs(interval) == 3 || std::abs(interval) == 4) {
        detectedInterval_ = interval;
        scanning_ = false;
    }
}

void ThirdModule::observe(const MidiMessage& message, std::int64_t nowUs) {
    if (!scanning_ || !message.isNoteOn()) return;

    if (message.channel() == 0) {
        lastUpper1Note_ = message.data1;
        lastUpper1Us_ = nowUs;
        tryDetect();
    } else if (message.channel() == 2) {
        lastUpper3Note_ = message.data1;
        lastUpper3Us_ = nowUs;
        tryDetect();
    }
}

bool ThirdModule::shouldPass(const MidiMessage& message) const {
    if (message.channel() != 2) return true;
    if (enabled_) return true;

    // Keep non-musical transport/system routing untouched; only mute the actual Upper 3 voice.
    if (message.isNoteOn() || message.isNoteOff() || message.isPitchBend()) return false;

    const int cmd = message.command();
    if (cmd == 0xA0 || cmd == 0xD0) return false;
    return true;
}

} // namespace silveton
