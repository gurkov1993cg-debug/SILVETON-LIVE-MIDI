#include "silveton/ThirdModule.h"
#include <algorithm>
#include <array>
#include <set>

namespace silveton {

namespace {
constexpr std::size_t kNoteCount = 128;
}

void ThirdModule::startScan() {
    scanState_ = ScanState::Scanning;
    for (auto& channel : scanMutedRefs_) channel.fill(0);
    for (auto& channel : cancelledReleaseRefs_) channel.fill(0);
}

void ThirdModule::cancelScan() {
    // Return sound immediately, but remember the already-muted scan key presses
    // so their later releases cannot leak into the normal MIDI stream.
    for (std::size_t ch = 0; ch < scanMutedRefs_.size(); ++ch) {
        for (std::size_t note = 0; note < kNoteCount; ++note) {
            cancelledReleaseRefs_[ch][note] = scanMutedRefs_[ch][note];
        }
        scanMutedRefs_[ch].fill(0);
    }
    scanState_ = tonalityValid_ ? ScanState::Locked : ScanState::Idle;
}

namespace {
struct CellShape {
    ThirdModule::ScanCell cell;
    std::array<int, 3> pcs;
    ThirdModule::ScaleMode scale;
    int direction;
};

constexpr std::array<CellShape, ThirdModule::kScanCellCount> kCells{{
    {ThirdModule::ScanCell::MajorUp,    {{0, 4, 7}}, ThirdModule::ScaleMode::Major,    +1},
    {ThirdModule::ScanCell::MajorDown,  {{0, 2, 4}}, ThirdModule::ScaleMode::Major,    -1},
    {ThirdModule::ScanCell::MinorUp,    {{0, 3, 7}}, ThirdModule::ScaleMode::Minor,    +1},
    {ThirdModule::ScanCell::MinorDown,  {{0, 2, 3}}, ThirdModule::ScaleMode::Minor,    -1},
    {ThirdModule::ScanCell::PhrygianUp, {{0, 1, 3}}, ThirdModule::ScaleMode::Phrygian, +1},
    {ThirdModule::ScanCell::HijazUp,    {{0, 1, 4}}, ThirdModule::ScaleMode::Hijaz,    +1},
}};

using Scale = std::array<int, 7>;
constexpr Scale kMajor{{0, 2, 4, 5, 7, 9, 11}};
constexpr Scale kMinor{{0, 2, 3, 5, 7, 8, 10}};
constexpr Scale kPhrygian{{0, 1, 3, 5, 7, 8, 10}};
constexpr Scale kHijaz{{0, 1, 4, 5, 7, 8, 10}};

const Scale& scaleFor(ThirdModule::ScaleMode mode) {
    switch (mode) {
        case ThirdModule::ScaleMode::Minor: return kMinor;
        case ThirdModule::ScaleMode::Phrygian: return kPhrygian;
        case ThirdModule::ScaleMode::Hijaz: return kHijaz;
        case ThirdModule::ScaleMode::Major: break;
    }
    return kMajor;
}
} // namespace

int ThirdModule::scanResultCode() const {
    if (scanState_ == ScanState::Scanning || !tonalityValid_) return 0;
    return 1 + rootPitchClass_ + 12 * static_cast<int>(scanCell_);
}

bool ThirdModule::detectHeldTriad() {
    std::set<int> pcs;
    for (int note = 0; note < 128; ++note) {
        // A scan key counts when it is held on any Upper (the PA600 sends the
        // same key on every active Upper; any of them may be muted).
        const std::size_t n = static_cast<std::size_t>(note);
        if (scanMutedRefs_[0][n] != 0 || scanMutedRefs_[1][n] != 0 || scanMutedRefs_[2][n] != 0) {
            pcs.insert(note % 12);
        }
    }
    if (pcs.size() != 3) return false;

    for (const auto& shape : kCells) {
        for (int root = 0; root < 12; ++root) {
            const std::set<int> candidate{(root + shape.pcs[0]) % 12,
                                          (root + shape.pcs[1]) % 12,
                                          (root + shape.pcs[2]) % 12};
            if (pcs != candidate) continue;
            rootPitchClass_ = root;
            scaleMode_ = shape.scale;
            scanCell_ = shape.cell;
            direction_ = shape.direction;
            tonalityValid_ = true;
            enabled_ = true;
            scanState_ = ScanState::WaitingForRelease;
            ++scanRevision_;
            return true;
        }
    }
    return false;
}

bool ThirdModule::anyScanMutedHeld() const {
    for (const auto& channel : scanMutedRefs_) {
        for (std::uint16_t refs : channel) {
            if (refs != 0) return true;
        }
    }
    return false;
}

void ThirdModule::observeScan(const MidiMessage& message) {
    if (!scanSilenceActive()) return;
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return;

    const std::size_t channelIndex = static_cast<std::size_t>(ch);
    const std::size_t noteIndex = static_cast<std::size_t>(message.data1 & 0x7F);

    if (message.isNoteOn()) {
        auto& refs = scanMutedRefs_[channelIndex][noteIndex];
        if (refs < UINT16_MAX) ++refs;
        if (scanState_ == ScanState::Scanning) detectHeldTriad();
    } else if (message.isNoteOff()) {
        auto& refs = scanMutedRefs_[channelIndex][noteIndex];
        if (refs > 0) --refs;
    }

    if (scanState_ == ScanState::WaitingForRelease && !anyScanMutedHeld()) {
        scanState_ = ScanState::Locked;
        }
}

bool ThirdModule::shouldMuteScanMessage(const MidiMessage& message) const {
    if (!scanSilenceActive()) return false;
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return false;
    // Only the scan KEYS are consumed. Pitch Bend (the wheel) must never be
    // swallowed: a wheel returning to centre during SCAN would otherwise leave
    // the Upper permanently bent.
    if (message.isNoteOn() || message.isNoteOff()) return true;
    const int cmd = message.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

bool ThirdModule::consumeCancelledScanRelease(const MidiMessage& message) {
    if (!message.isNoteOff()) return false;
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return false;
    auto& refs = cancelledReleaseRefs_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(message.data1 & 0x7F)];
    if (refs == 0) return false;
    --refs;
    return true;
}

bool ThirdModule::pitchClassInScale(int relativePc, int& degree) const {
    const auto& scale = scaleFor(scaleMode_);
    for (int i = 0; i < 7; ++i) {
        if (scale[static_cast<std::size_t>(i)] == relativePc) {
            degree = i;
            return true;
        }
    }
    return false;
}

int ThirdModule::diatonicThirdFor(int sourceNote) const {
    if (!tonalityValid_) return -1;
    const int pc = ((sourceNote % 12) + 12) % 12;
    const int relative = (pc - rootPitchClass_ + 12) % 12;
    int degree = -1;
    if (!pitchClassInScale(relative, degree)) {
        // Every key gets a third. For a note outside the scale (e.g. E or B in
        // D phrygian) use the minor third that lands in the scale, else the
        // major third that lands in the scale, else a plain minor third.
        const int minorTarget = relative + 3 * direction_;
        const int majorTarget = relative + 4 * direction_;
        int unused = -1;
        int delta = 3 * direction_;
        if (pitchClassInScale(((minorTarget % 12) + 12) % 12, unused)) {
            delta = 3 * direction_;
        } else if (pitchClassInScale(((majorTarget % 12) + 12) % 12, unused)) {
            delta = 4 * direction_;
        }
        const int chromaticResult = sourceNote + delta;
        if (chromaticResult < 0 || chromaticResult > 127) return -1;
        return chromaticResult;
    }

    const auto& scale = scaleFor(scaleMode_);
    // A diatonic third is two scale steps away, above or below.
    const int step = degree + 2 * direction_;
    const int octave = (step >= 7) ? 12 : (step < 0 ? -12 : 0);
    const int targetDegree = ((step % 7) + 7) % 7;
    const int targetRelative = scale[static_cast<std::size_t>(targetDegree)] + octave;
    const int semitoneDelta = targetRelative - scale[static_cast<std::size_t>(degree)];
    const int result = sourceNote + semitoneDelta;
    if (result < 0 || result > 127) return -1;
    return result;
}

std::vector<MidiMessage> ThirdModule::processSource(const MidiMessage& message, int sourceChannel) {
    if (!enabled_ || !tonalityValid_ || message.channel() != sourceChannel) return {};
    if (!message.isNoteOn() && !message.isNoteOff()) return {};

    const std::size_t source = static_cast<std::size_t>(message.data1 & 0x7F);

    if (message.isNoteOn()) {
        const int harmony = diatonicThirdFor(static_cast<int>(message.data1));
        if (harmony < 0) return {};
        const std::size_t harmonyIndex = static_cast<std::size_t>(harmony);

        if (sourceRefs_[source] == 0) sourceHarmony_[source] = harmony;
        if (sourceRefs_[source] < UINT16_MAX) ++sourceRefs_[source];
        if (harmonyRefs_[harmonyIndex] < UINT16_MAX) ++harmonyRefs_[harmonyIndex];

        if (harmonyRefs_[harmonyIndex] == 1) {
            return {MidiMessage::noteOn(2, harmony, message.data2)};
        }
        return {};
    }

    if (sourceRefs_[source] == 0) return {};
    const int harmony = sourceHarmony_[source];
    --sourceRefs_[source];
    if (sourceRefs_[source] == 0) sourceHarmony_[source] = -1;
    if (harmony < 0 || harmony > 127) return {};

    auto& harmonyRefs = harmonyRefs_[static_cast<std::size_t>(harmony)];
    if (harmonyRefs > 0) --harmonyRefs;
    if (harmonyRefs == 0) return {MidiMessage::noteOffZero(2, harmony)};
    return {};
}

bool ThirdModule::anySourceHeld() const {
    for (std::uint16_t refs : sourceRefs_) {
        if (refs != 0) return true;
    }
    return false;
}

void ThirdModule::clearGeneratedState() {
    sourceRefs_.fill(0);
    sourceHarmony_.fill(-1);
    harmonyRefs_.fill(0);
}

bool ThirdModule::isRawUpper3Musical(const MidiMessage& message) const {
    if (!ownsRawUpper3() || message.channel() != 2) return false;
    if (message.isNoteOn() || message.isNoteOff()) return true;
    const int cmd = message.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

} // namespace silveton
