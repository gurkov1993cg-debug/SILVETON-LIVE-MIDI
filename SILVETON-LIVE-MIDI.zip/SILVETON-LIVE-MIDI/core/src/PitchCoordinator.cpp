#include "silveton/PitchCoordinator.h"
#include <algorithm>
#include <cmath>

namespace silveton {

void PitchCoordinator::setBendRangeSemitones(int value) {
    bendRangeSemitones_ = std::clamp(value, 1, 24);
    manualRangeSemitones_ = std::clamp(manualRangeSemitones_, 1, bendRangeSemitones_);
}

void PitchCoordinator::setManualRangeSemitones(int value) {
    manualRangeSemitones_ = std::clamp(value, 1, bendRangeSemitones_);
}

int PitchCoordinator::compose14(const State& state) const {
    const double manualNorm = (double(state.manualBend14) - 8192.0) / 8192.0;
    const double manualSemitones = manualNorm * double(manualRangeSemitones_);
    const double total = std::clamp(state.ribbonSemitones + manualSemitones,
                                    -double(bendRangeSemitones_), double(bendRangeSemitones_));
    const double normalized = total / double(bendRangeSemitones_);
    return std::clamp(int(std::lround(8192.0 + normalized * 8192.0)), 0, 16383);
}

std::vector<MidiMessage> PitchCoordinator::emitIfChanged(int ch) {
    if (ch < 0 || ch >= 16) return {};
    auto& state = states_[static_cast<std::size_t>(ch)];
    const int bend = compose14(state);
    if (bend == state.lastOutputBend14) return {};
    state.lastOutputBend14 = bend;
    return {MidiMessage::pitchBend(ch, bend)};
}

std::vector<MidiMessage> PitchCoordinator::setRibbonSemitones(int ch, double semitones) {
    if (ch < 0 || ch >= 16) return {};
    states_[static_cast<std::size_t>(ch)].ribbonSemitones = std::clamp(semitones,
                                             -double(bendRangeSemitones_),
                                              double(bendRangeSemitones_));
    return emitIfChanged(ch);
}

std::vector<MidiMessage> PitchCoordinator::setManualBend14(int ch, int bend14) {
    if (ch < 0 || ch >= 16) return {};
    states_[static_cast<std::size_t>(ch)].manualBend14 = std::clamp(bend14, 0, 16383);
    return emitIfChanged(ch);
}

std::vector<MidiMessage> PitchCoordinator::forceEmitChannel(int ch) {
    if (ch < 0 || ch >= 16) return {};
    states_[static_cast<std::size_t>(ch)].lastOutputBend14 = -1;
    return emitIfChanged(ch);
}

std::vector<MidiMessage> PitchCoordinator::resetChannel(int ch) {
    if (ch < 0 || ch >= 16) return {};
    states_[static_cast<std::size_t>(ch)] = State{};
    states_[static_cast<std::size_t>(ch)].lastOutputBend14 = 8192;
    return {MidiMessage::pitchBend(ch, 8192)};
}

std::vector<MidiMessage> PitchCoordinator::resetAll() {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 16; ++ch) {
        auto one = resetChannel(ch);
        out.insert(out.end(), one.begin(), one.end());
    }
    return out;
}

} // namespace silveton
