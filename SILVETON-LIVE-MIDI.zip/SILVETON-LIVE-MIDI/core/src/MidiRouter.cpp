#include "silveton/MidiRouter.h"

namespace silveton {

void MidiRouter::append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const {
    dst.insert(dst.end(), src.begin(), src.end());
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t) {
    const int ch = message.channel();
    if (ch < 0 || !KorgProfile::isUpperChannel(ch)) return {message};

    // Pa600 performs Portamento internally. We never synthesize the note glide.
    // To make the native engine reliable across both adjacent and wide intervals,
    // the active TIME/SW state is re-asserted immediately before every Note On.

    // Scan gate owns musical input while learning the TERCA tonality.
    const bool scanGateWasActive = third_.scanning() || third_.scanSilenceActive();
    if (scanGateWasActive) {
        const bool muteThisMessage = third_.shouldMuteScanMessage(message);
        third_.observeScan(message);
        if (muteThisMessage) return {};
    }

    // Physical/manual bend remains independent from native Pa600 Portamento.
    if (message.isPitchBend()) {
        return pitch_.setManualBend14(ch, message.pitchBend14());
    }

    // Korg All Sound Off / All Notes Off also resets our independent pitch lane.
    if (message.command() == 0xB0 && (message.data1 == 120 || message.data1 == 123)) {
        std::vector<MidiMessage> out;
        append(out, pitch_.resetChannel(ch));
        out.push_back(message);
        return out;
    }

    // Upper 3 is owned by generated TERCA only while TERCA is active.
    if (third_.isRawUpper3Musical(message)) return {};

    std::vector<MidiMessage> out;
    if (message.isNoteOn()) append(out, portamento_.syncForChannel(ch));
    out.push_back(message);

    if (message.channel() == 0) {
        const auto harmony = third_.generateFromUpper1(message);
        if (!harmony.empty() && harmony.front().isNoteOn()) {
            append(out, portamento_.syncForChannel(2));
        }
        append(out, harmony);
    }
    return out;
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    const auto update = ribbon_.advance(nowUs);
    if (!update.valid) return out;

    // High-end Ribbon is a completely separate performance lane from native
    // Pa600 Portamento. It is rendered at 14-bit resolution on all three Uppers.
    append(out, pitch_.setRibbonSemitones(0, update.semitones));
    append(out, pitch_.setRibbonSemitones(1, update.semitones));
    append(out, pitch_.setRibbonSemitones(2, update.semitones));
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoEnabled(bool enabled) {
    return portamento_.setEnabled(enabled);
}

std::vector<MidiMessage> MidiRouter::setPortamentoTime(int value) {
    return portamento_.setTime(value);
}

std::vector<MidiMessage> MidiRouter::syncPortamento() const {
    return portamento_.sync();
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    if (!enabled && (third_.scanning() || third_.scanSilenceActive())) third_.cancelScan();
    if (third_.enabled() == enabled) return {};
    std::vector<MidiMessage> out;
    // Stop any generated U3 note at the ownership boundary using CC123.
    out.push_back(MidiMessage::controlChange(2, 123, 0));
    third_.setEnabled(enabled);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdScanning(bool scanning) {
    if (scanning == third_.scanning()) return {};
    if (!scanning) {
        third_.cancelScan();
        return {};
    }

    std::vector<MidiMessage> out;
    // Silence existing Upper notes before SCAN. Each effect keeps its own state.
    for (int ch = 0; ch < 3; ++ch) out.push_back(MidiMessage::controlChange(ch, 123, 0));
    third_.startScan();
    return out;
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t nowUs) {
    ribbon_.setTarget(normalizedPosition, nowUs);
    // The 1 ms MIDI poller renders the smoothed 14-bit trajectory. Returning
    // no immediate bend here prevents finger-event jitter from leaking through.
    return {};
}

std::vector<MidiMessage> MidiRouter::panic() {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) {
        out.push_back(MidiMessage::controlChange(ch, 123, 0));
        append(out, pitch_.resetChannel(ch));
    }
    third_.cancelScan();
    ribbon_.reset();
    return out;
}

} // namespace silveton
