#include "silveton/MidiRouter.h"
#include <algorithm>
#include <cstddef>

namespace silveton {

MidiRouter::MidiRouter() {
    third_.clearGeneratedState();
}

void MidiRouter::append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const {
    dst.insert(dst.end(), src.begin(), src.end());
}

void MidiRouter::clearActiveChannel(int ch) {
    if (ch < 0 || ch > 2) return;
    activeRefs_[static_cast<std::size_t>(ch)].fill(0);
    lastNotes_[static_cast<std::size_t>(ch)] = -1;
}

void MidiRouter::trackOutgoing(const MidiMessage& message) {
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return;
    const std::size_t channel = static_cast<std::size_t>(ch);

    if (message.isNoteOn()) {
        const std::size_t note = static_cast<std::size_t>(message.data1 & 0x7F);
        auto& refs = activeRefs_[channel][note];
        if (refs < UINT16_MAX) ++refs;
        lastNotes_[channel] = static_cast<int>(message.data1);
        return;
    }

    if (message.isNoteOff()) {
        const std::size_t note = static_cast<std::size_t>(message.data1 & 0x7F);
        auto& refs = activeRefs_[channel][note];
        if (refs > 0) --refs;
        if (lastNotes_[channel] == static_cast<int>(message.data1) && refs == 0) {
            int replacement = -1;
            for (int candidate = 127; candidate >= 0; --candidate) {
                if (activeRefs_[channel][static_cast<std::size_t>(candidate)] != 0) {
                    replacement = candidate;
                    break;
                }
            }
            lastNotes_[channel] = replacement;
        }
        return;
    }

    if (message.isControlChange() && (message.data1 == 120 || message.data1 == 123)) {
        clearActiveChannel(ch);
    }
}

void MidiRouter::trackOutgoing(const std::vector<MidiMessage>& messages) {
    for (const auto& message : messages) trackOutgoing(message);
}

std::vector<MidiMessage> MidiRouter::releaseActiveChannel(int ch, bool addAllNotesOff) {
    std::vector<MidiMessage> out;
    if (ch < 0 || ch > 2) return out;
    const std::size_t channel = static_cast<std::size_t>(ch);

    for (int note = 0; note < 128; ++note) {
        const std::uint16_t refs = activeRefs_[channel][static_cast<std::size_t>(note)];
        for (std::uint16_t n = 0; n < refs; ++n) {
            out.push_back(MidiMessage::noteOffZero(ch, note));
        }
    }
    if (addAllNotesOff) out.push_back(MidiMessage::controlChange(ch, 123, 0));
    clearActiveChannel(ch);
    return out;
}

std::vector<MidiMessage> MidiRouter::releaseAllActive(bool addAllNotesOff) {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) append(out, releaseActiveChannel(ch, addAllNotesOff));
    return out;
}

int MidiRouter::activeNoteRefs(int ch, int note) const {
    if (ch < 0 || ch > 2 || note < 0 || note > 127) return 0;
    return static_cast<int>(activeRefs_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(note)]);
}

int MidiRouter::lastNote(int ch) const {
    if (ch < 0 || ch > 2) return -1;
    return lastNotes_[static_cast<std::size_t>(ch)];
}

void MidiRouter::syncU3Ownership(std::vector<MidiMessage>& out) {
    const bool owned = third_.ownsRawUpper3();
    if (owned == u3Owned_) return;
    u3Owned_ = owned;
    // U3 switches between the raw line and the TERCA line: never glide across.
    portamento_.resetChannel(2);
    auto msgs = pitch_.setGlideSemitones(2, 0.0);
    if (pitchTransportEnabled_) append(out, msgs);
}

void MidiRouter::startGlide(std::vector<MidiMessage>& out, int ch, int note, std::int64_t nowUs) {
    if (!portamento_.config().enabled || !pitchTransportEnabled_) return;
    const double range = static_cast<double>(pitch_.bendRangeSemitones());
    if (portamento_.noteOn(ch, note, nowUs, range)) {
        append(out, pitch_.setGlideSemitones(ch, portamento_.offsetSemitones(ch)));
    }
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t nowUs) {
    const int ch = message.channel();
    if (ch < 0 || !KorgProfile::isUpperChannel(ch)) {
        // Local ON: the keyboard already sounds these itself; echo = doubling.
        if (keyboardLocal_) return {};
        return {message};
    }

    // Releases from a manually-cancelled scan are consumed individually. New
    // notes are immediately allowed again, so cancel really is immediate.
    if (third_.consumeCancelledScanRelease(message)) return {};

    const bool scanGateWasActive = third_.scanSilenceActive();
    if (scanGateWasActive) {
        const bool muteThisMessage = third_.shouldMuteScanMessage(message);
        third_.observeScan(message);
        if (muteThisMessage) {
            std::vector<MidiMessage> gateOut;
            syncU3Ownership(gateOut);   // a scan may have just locked TERCA
            trackOutgoing(gateOut);
            return gateOut;
        }
    }

    // Until Ribbon is actually used, physical Pitch Bend is a true byte-for-byte
    // pass-through.  Only after the Android layer explicitly enables the
    // +/-12 Ribbon transport do we compose physical bend with Ribbon.
    if (message.isPitchBend()) {
        if (!pitchTransportEnabled_) {
            // Keep the exact raw PA600 bend bytes transparent, but remember
            // the physical control position. If Ribbon is enabled later, the
            // coordinator can change to the +/-12 transport without a pitch
            // jump or falsely assuming the wheel is centered.
            pitch_.rememberManualBend14(ch, message.pitchBend14());
            if (keyboardLocal_) return {};
            return {message};
        }
        // Ribbon active: emit wheel + Ribbon as one composed value. In Local ON
        // this re-asserts the combined value right after the keyboard's own
        // local wheel message, so the two never fight.
        auto out = pitch_.setManualBend14(ch, message.pitchBend14());
        trackOutgoing(out);
        return out;
    }

    // CC120/123 is authoritative cleanup. If U1 is killed while TERCA is
    // active, generated U3 notes are killed too because they belong to U1.
    if (message.isControlChange() && (message.data1 == 120 || message.data1 == 123)) {
        std::vector<MidiMessage> out;
        if ((ch == 0 || ch == 1) && third_.enabled()) {
            append(out, releaseActiveChannel(2, false));
            third_.clearGeneratedState();
        } else if (ch == 2) {
            third_.clearGeneratedState();
        }
        portamento_.resetChannel(ch);
        if (ch == 0) {
            portamento_.resetChannel(1);
            portamento_.resetChannel(2);
        }
        if (!keyboardLocal_) out.push_back(message);
        else clearActiveChannel(ch);
        // In transparent Local-OFF bridge mode CC120/123 must not inject an
        // unrelated Pitch Bend. Only reset the composed pitch lane when the
        // Ribbon transport is actually active.
        if (pitchTransportEnabled_) append(out, pitch_.resetChannel(ch));
        trackOutgoing(out);
        return out;
    }

    // With a locked/enabled TERCA, raw U3 musical events are intentionally
    // suppressed; U3 is owned by generated harmony. When TERCA is OFF, U3 is
    // completely normal again.
    if (third_.isRawUpper3Musical(message)) return {};

    std::vector<MidiMessage> out;

    // TIME portamento, per Upper:
    //  Local OFF: every Upper glides from ITS OWN incoming notes (the PA600
    //    sends the key separately on U1/U2/U3), so a muted/untransmitted Upper
    //    never breaks another one. U3 uses the TERCA line while TERCA owns it.
    //  Local ON: only U1 is transmitted to the app, so U1 drives U1/U2(/U3).
    // The glide Pitch Bend is placed BEFORE the note so in Local OFF the note
    // already starts at the glide's start pitch.
    if (message.isNoteOn()) {
        if (keyboardLocal_) {
            if (ch == 0) {
                startGlide(out, 0, message.data1, nowUs);
                startGlide(out, 1, message.data1, nowUs);
                if (!third_.ownsRawUpper3()) startGlide(out, 2, message.data1, nowUs);
            }
        } else if (ch != 2 || !third_.ownsRawUpper3()) {
            startGlide(out, ch, message.data1, nowUs);
        }
    }

    if (!keyboardLocal_) out.push_back(message);

    if (ch == 0 || ch == 1) {
        const auto harmony = third_.processSource(message);
        // U3 glides along its own line of thirds (C->D melody = E->F terca).
        if (third_.ownsRawUpper3()) {
            for (const auto& h : harmony) {
                if (h.isNoteOn()) startGlide(out, 2, h.data1, nowUs);
            }
        }
        append(out, harmony);
        trackOutgoing(out);

        // Safety net: once the last key producing a third is released, U3
        // must be silent. Releasing everything still known on U3 plus CC123
        // guarantees no TERCA note can hang even if the PA600 missed a Note Off.
        if (message.isNoteOff() && third_.ownsRawUpper3() && !third_.anySourceHeld()) {
            auto sweep = releaseActiveChannel(2, true);
            third_.clearGeneratedState();
            append(out, sweep);
        }
        return out;
    }

    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    if (!pitchTransportEnabled_) return out;

    // Update glide offsets first (state only), then emit once per channel.
    const auto glideChanged = portamento_.advance(nowUs);
    const auto update = ribbon_.advance(nowUs);
    for (int ch = 0; ch < 3; ++ch) {
        const bool g = glideChanged[static_cast<std::size_t>(ch)];
        if (!g && !update.valid) continue;
        if (g) pitch_.storeGlideSemitones(ch, portamento_.offsetSemitones(ch));
        if (update.valid) pitch_.storeRibbonSemitones(ch, update.semitones);
        append(out, pitch_.emitChannel(ch));
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoEnabled(bool enabled) {
    auto out = portamento_.setEnabled(enabled);
    if (!enabled) {
        // Drop any glide offset that was still running.
        for (int ch = 0; ch < 3; ++ch) {
            auto msgs = pitch_.setGlideSemitones(ch, 0.0);
            if (pitchTransportEnabled_) append(out, msgs);
        }
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoTimeMs(int ms) {
    portamento_.setTimeMs(ms);
    return {};
}

std::vector<MidiMessage> MidiRouter::syncPortamento() const {
    return portamento_.sync();
}

std::vector<MidiMessage> MidiRouter::syncPortamentoChannel(int ch) const {
    return portamento_.syncForChannel(ch);
}

std::vector<MidiMessage> MidiRouter::syncPitchChannel(int ch) {
    if (!pitchTransportEnabled_) return {};
    return pitch_.forceEmitChannel(ch);
}

std::vector<MidiMessage> MidiRouter::setPitchTransportEnabled(bool enabled) {
    if (pitchTransportEnabled_ == enabled) return {};
    pitchTransportEnabled_ = enabled;
    ribbon_.reset();

    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) {
        // Preserve the remembered physical PA600 wheel position. Only the
        // Ribbon contribution is reset when switching transport modes.
        pitch_.clearRibbonContribution(ch);
        if (enabled) {
            append(out, pitch_.forceEmitChannel(ch));
        } else {
            // Back to the normal +/-2 transport (the Android layer restores
            // RPN 0 = 2 first): re-assert the raw physical wheel position.
            out.push_back(MidiMessage::pitchBend(ch, pitch_.manualBend14(ch)));
        }
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    if (!enabled && third_.scanSilenceActive()) third_.cancelScan();
    if (third_.enabled() == enabled) return {};

    std::vector<MidiMessage> out;
    // U3 ownership changes are always made at a clean note boundary.
    if (third_.tonalityValid()) append(out, releaseActiveChannel(2, true));
    third_.clearGeneratedState();
    third_.setEnabled(enabled);
    syncU3Ownership(out);
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdScanning(bool scanning) {
    if (scanning) {
        if (third_.scanning()) return {};
        // Local ON: never CC123 the keyboard's own U1/U2 notes; only the
        // app-generated notes (tracked here) are released.
        std::vector<MidiMessage> out = releaseAllActive(!keyboardLocal_);
        third_.clearGeneratedState();
        third_.startScan();
        trackOutgoing(out);
        return out;
    }

    if (!third_.scanSilenceActive()) return {};
    third_.cancelScan();
    return {};
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t nowUs) {
    ribbon_.setTarget(normalizedPosition, nowUs);
    return {};
}

std::vector<MidiMessage> MidiRouter::panic() {
    std::vector<MidiMessage> out = releaseAllActive(false);
    for (int ch = 0; ch < 3; ++ch) {
        out.push_back(MidiMessage::controlChange(ch, 123, 0));
        out.push_back(MidiMessage::controlChange(ch, 120, 0));
        append(out, pitch_.resetChannel(ch));
    }

    third_.cancelScan();
    third_.clearGeneratedState();
    ribbon_.reset();
    portamento_.reset();
    pitch_.clearAll();
    pitchTransportEnabled_ = false;
    for (int ch = 0; ch < 3; ++ch) clearActiveChannel(ch);
    trackOutgoing(out);
    return out;
}

} // namespace silveton
