#include "silveton/MidiRouter.h"

namespace silveton {

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t nowUs) {
    const int ch = message.channel();
    if (ch >= 0 && KorgProfile::isUpperChannel(ch)) {
        return portamento_.process(message, nowUs);
    }
    return {message};
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    auto all = portamento_.poll(nowUs);
    std::vector<MidiMessage> upperOnly;
    upperOnly.reserve(all.size());
    for (const auto& m : all) {
        if (KorgProfile::isUpperChannel(m.channel())) upperOnly.push_back(m);
    }
    return upperOnly;
}

std::vector<MidiMessage> MidiRouter::panic() {
    auto all = portamento_.panic();
    std::vector<MidiMessage> upperOnly;
    upperOnly.reserve(all.size());
    for (const auto& m : all) {
        if (KorgProfile::isUpperChannel(m.channel())) upperOnly.push_back(m);
    }
    return upperOnly;
}

} // namespace silveton
