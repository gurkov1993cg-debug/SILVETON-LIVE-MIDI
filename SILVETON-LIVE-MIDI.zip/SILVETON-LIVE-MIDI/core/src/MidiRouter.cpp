#include "silveton/MidiRouter.h"
#include <algorithm>
#include <cstddef>

namespace silveton {

MidiRouter::MidiRouter() {
    third_.clearGeneratedState();
}

void MidiRouter::append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const {
    dst.insert(dst.end(), src.begin(), src.end());
}

void MidiRouter::clearActiveChannel(int ch) {
    if (ch < 0 || ch > 2) return;
    activeRefs_[static_cast<std::size_t>(ch)].fill(0);
    lastNotes_[static_cast<std::size_t>(ch)] = -1;
}

void MidiRouter::trackOutgoing(const MidiMessage& message) {
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return;
    const std::size_t channel = static_cast<std::size_t>(ch);

    if (message.isNoteOn()) {
        const std::size_t note = static_cast<std::size_t>(message.data1 & 0x7F);
        auto& refs = activeRefs_[channel][note];
        if (refs < UINT16_MAX) ++refs;
        lastNotes_[channel] = static_cast<int>(message.data1);
        return;
    }

    if (message.isNoteOff()) {
        const std::size_t note = static_cast<std::size_t>(message.data1 & 0x7F);
        auto& refs = activeRefs_[channel][note];
        if (refs > 0) --refs;
        if (lastNotes_[channel] == static_cast<int>(message.data1) && refs == 0) {
            int replacement = -1;
            for (int candidate = 127; candidate >= 0; --candidate) {
                if (activeRefs_[channel][static_cast<std::size_t>(candidate)] != 0) {
                    replacement = candidate;
                    break;
                }
            }
            lastNotes_[channel] = replacement;
        }
        return;
    }

    if (message.isControlChange() && (message.data1 == 120 || message.data1 == 123)) {
        clearActiveChannel(ch);
    }
}

void MidiRouter::trackOutgoing(const std::vector<MidiMessage>& messages) {
    for (const auto& message : messages) trackOutgoing(message);
}

std::vector<MidiMessage> MidiRouter::releaseActiveChannel(int ch, bool addAllNotesOff) {
    std::vector<MidiMessage> out;
    if (ch < 0 || ch > 2) return out;
    const std::size_t channel = static_cast<std::size_t>(ch);

    for (int note = 0; note < 128; ++note) {
        const std::uint16_t refs = activeRefs_[channel][static_cast<std::size_t>(note)];
        for (std::uint16_t n = 0; n < refs; ++n) {
            out.push_back(MidiMessage::noteOffZero(ch, note));
        }
    }
    if (addAllNotesOff) out.push_back(MidiMessage::controlChange(ch, 123, 0));
    clearActiveChannel(ch);
    return out;
}

std::vector<MidiMessage> MidiRouter::releaseAllActive(bool addAllNotesOff) {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) append(out, releaseActiveChannel(ch, addAllNotesOff));
    return out;
}

int MidiRouter::activeNoteRefs(int ch, int note) const {
    if (ch < 0 || ch > 2 || note < 0 || note > 127) return 0;
    return static_cast<int>(activeRefs_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(note)]);
}

int MidiRouter::lastNote(int ch) const {
    if (ch < 0 || ch > 2) return -1;
    return lastNotes_[static_cast<std::size_t>(ch)];
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t) {
    const int ch = message.channel();
    if (ch < 0 || !KorgProfile::isUpperChannel(ch)) return {message};

    // Releases from a manually-cancelled scan are consumed individually. New
    // notes are immediately allowed again, so cancel really is immediate.
    if (third_.consumeCancelledScanRelease(message)) return {};

    const bool scanGateWasActive = third_.scanSilenceActive();
    if (scanGateWasActive) {
        const bool muteThisMessage = third_.shouldMuteScanMessage(message);
        third_.observeScan(message);
        if (muteThisMessage) return {};
    }

    // Physical pitch wheel is preserved and composed only with Ribbon.
    if (message.isPitchBend()) {
        auto out = pitch_.setManualBend14(ch, message.pitchBend14());
        trackOutgoing(out);
        return out;
    }

    // CC120/123 is authoritative cleanup. If U1 is killed while TERCA is
    // active, generated U3 notes are killed too because they belong to U1.
    if (message.isControlChange() && (message.data1 == 120 || message.data1 == 123)) {
        std::vector<MidiMessage> out;
        if (ch == 0 && third_.enabled()) {
            append(out, releaseActiveChannel(2, false));
            third_.clearGeneratedState();
        } else if (ch == 2) {
            third_.clearGeneratedState();
        }
        out.push_back(message);
        append(out, pitch_.resetChannel(ch));
        trackOutgoing(out);
        return out;
    }

    // With a locked/enabled TERCA, raw U3 musical events are intentionally
    // suppressed; U3 is owned by generated harmony. When TERCA is OFF, U3 is
    // completely normal again.
    if (third_.isRawUpper3Musical(message)) return {};

    std::vector<MidiMessage> out;
    out.push_back(message);

    if (ch == 0) append(out, third_.processUpper1(message));

    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    const auto update = ribbon_.advance(nowUs);
    if (!update.valid) return out;

    append(out, pitch_.setRibbonSemitones(0, update.semitones));
    append(out, pitch_.setRibbonSemitones(1, update.semitones));
    append(out, pitch_.setRibbonSemitones(2, update.semitones));
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoEnabled(bool enabled) {
    return portamento_.setEnabled(enabled);
}

std::vector<MidiMessage> MidiRouter::setPortamentoTime(int value) {
    return portamento_.setTime(value);
}

std::vector<MidiMessage> MidiRouter::syncPortamento() const {
    return portamento_.sync();
}

std::vector<MidiMessage> MidiRouter::syncPortamentoChannel(int ch) const {
    return portamento_.syncForChannel(ch);
}

std::vector<MidiMessage> MidiRouter::syncPitchChannel(int ch) {
    return pitch_.forceEmitChannel(ch);
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    if (!enabled && third_.scanSilenceActive()) third_.cancelScan();
    if (third_.enabled() == enabled) return {};

    std::vector<MidiMessage> out;
    // U3 ownership changes are always made at a clean note boundary.
    if (third_.tonalityValid()) append(out, releaseActiveChannel(2, true));
    third_.clearGeneratedState();
    third_.setEnabled(enabled);
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdScanning(bool scanning) {
    if (scanning) {
        if (third_.scanning()) return {};
        std::vector<MidiMessage> out = releaseAllActive(true);
        third_.clearGeneratedState();
        third_.startScan();
        trackOutgoing(out);
        return out;
    }

    if (!third_.scanSilenceActive()) return {};
    third_.cancelScan();
    return {};
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t nowUs) {
    ribbon_.setTarget(normalizedPosition, nowUs);
    return {};
}

std::vector<MidiMessage> MidiRouter::panic() {
    std::vector<MidiMessage> out = releaseAllActive(false);
    for (int ch = 0; ch < 3; ++ch) {
        out.push_back(MidiMessage::controlChange(ch, 123, 0));
        out.push_back(MidiMessage::controlChange(ch, 120, 0));
        append(out, pitch_.resetChannel(ch));
    }

    third_.cancelScan();
    third_.clearGeneratedState();
    ribbon_.reset();
    for (int ch = 0; ch < 3; ++ch) clearActiveChannel(ch);
    trackOutgoing(out);
    return out;
}

} // namespace silveton
