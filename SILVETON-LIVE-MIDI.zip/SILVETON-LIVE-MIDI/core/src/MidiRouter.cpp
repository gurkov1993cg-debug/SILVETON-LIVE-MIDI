#include "silveton/MidiRouter.h"
#include <algorithm>
#include <cmath>
#include <cstddef>

namespace silveton {

MidiRouter::MidiRouter() {
    third_.clearGeneratedState();
}

void MidiRouter::setKeyboardLocal(bool keyboardLocal) {
    keyboardLocal_ = keyboardLocal;
    for (int ch = 0; ch < 3; ++ch) clearMono(ch);
    localRange_ = kLocalBaseRange;
    // Local OFF: fixed +/-12 transport (the app owns the wheel and composes it).
    // Local ON : adaptive, starting at the keyboard's normal +/-2.
    pitch_.setBendRangeSemitones(keyboardLocal ? kLocalBaseRange : kWideRange);
}

void MidiRouter::appendRpnRange(std::vector<MidiMessage>& out, int ch, int semitones) {
    out.push_back(MidiMessage::controlChange(ch, 101, 0));
    out.push_back(MidiMessage::controlChange(ch, 100, 0));
    out.push_back(MidiMessage::controlChange(ch, 6, semitones));
    out.push_back(MidiMessage::controlChange(ch, 38, 0));
    out.push_back(MidiMessage::controlChange(ch, 101, 127));
    out.push_back(MidiMessage::controlChange(ch, 100, 127));
}

void MidiRouter::applyLocalRange(std::vector<MidiMessage>& out, int semitones) {
    if (!keyboardLocal_ || semitones == localRange_) return;
    localRange_ = semitones;
    pitch_.setBendRangeSemitones(semitones);
    for (int ch = 0; ch < 3; ++ch) {
        appendRpnRange(out, ch, semitones);
        // Same musical pitch expressed in the new scale.
        append(out, pitch_.forceEmitChannel(ch));
    }
}

int MidiRouter::localRangeNeeded() const {
    for (int ch = 0; ch < 3; ++ch) {
        if (portamento_.gliding(ch) && localRange_ > kLocalBaseRange) return kWideRange;
    }
    const bool ribbonActive = ribbonUsesPitchBend() &&
        (ribbon_.targetSemitoneOffset() != 0.0 || ribbon_.currentSemitoneOffset() != 0.0);
    if (ribbonActive && ribbon_.rangeSemitones() > kLocalBaseRange) return kWideRange;
    return kLocalBaseRange;
}

void MidiRouter::append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const {
    dst.insert(dst.end(), src.begin(), src.end());
}

void MidiRouter::clearActiveChannel(int ch) {
    if (ch < 0 || ch > 2) return;
    activeRefs_[static_cast<std::size_t>(ch)].fill(0);
    lastNotes_[static_cast<std::size_t>(ch)] = -1;
}

void MidiRouter::trackOutgoing(const MidiMessage& message) {
    const int ch = message.channel();
    if (ch < 0 || ch > 2) return;
    const std::size_t channel = static_cast<std::size_t>(ch);

    if (message.isNoteOn()) {
        const std::size_t note = static_cast<std::size_t>(message.data1 & 0x7F);
        auto& refs = activeRefs_[channel][note];
        if (refs < UINT16_MAX) ++refs;
        lastNotes_[channel] = static_cast<int>(message.data1);
        return;
    }

    if (message.isNoteOff()) {
        const std::size_t note = static_cast<std::size_t>(message.data1 & 0x7F);
        auto& refs = activeRefs_[channel][note];
        if (refs > 0) --refs;
        if (lastNotes_[channel] == static_cast<int>(message.data1) && refs == 0) {
            int replacement = -1;
            for (int candidate = 127; candidate >= 0; --candidate) {
                if (activeRefs_[channel][static_cast<std::size_t>(candidate)] != 0) {
                    replacement = candidate;
                    break;
                }
            }
            lastNotes_[channel] = replacement;
        }
        return;
    }

    if (message.isControlChange() && (message.data1 == 120 || message.data1 == 123)) {
        clearActiveChannel(ch);
    }
}

void MidiRouter::trackOutgoing(const std::vector<MidiMessage>& messages) {
    for (const auto& message : messages) trackOutgoing(message);
}

std::vector<MidiMessage> MidiRouter::releaseActiveChannel(int ch, bool addAllNotesOff) {
    std::vector<MidiMessage> out;
    if (ch < 0 || ch > 2) return out;
    const std::size_t channel = static_cast<std::size_t>(ch);

    for (int note = 0; note < 128; ++note) {
        const std::uint16_t refs = activeRefs_[channel][static_cast<std::size_t>(note)];
        for (std::uint16_t n = 0; n < refs; ++n) {
            out.push_back(MidiMessage::noteOffZero(ch, note));
        }
    }
    if (addAllNotesOff) out.push_back(MidiMessage::controlChange(ch, 123, 0));
    clearActiveChannel(ch);
    return out;
}

std::vector<MidiMessage> MidiRouter::releaseAllActive(bool addAllNotesOff) {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) append(out, releaseActiveChannel(ch, addAllNotesOff));
    return out;
}

int MidiRouter::activeNoteRefs(int ch, int note) const {
    if (ch < 0 || ch > 2 || note < 0 || note > 127) return 0;
    return static_cast<int>(activeRefs_[static_cast<std::size_t>(ch)][static_cast<std::size_t>(note)]);
}

int MidiRouter::lastNote(int ch) const {
    if (ch < 0 || ch > 2) return -1;
    return lastNotes_[static_cast<std::size_t>(ch)];
}

void MidiRouter::syncU3Ownership(std::vector<MidiMessage>& out) {
    const bool owned = third_.ownsRawUpper3();
    if (owned == u3Owned_) return;
    u3Owned_ = owned;
    // U3 switches between the raw line and the TERCA line: never glide across.
    portamento_.resetChannel(2);
    auto msgs = pitch_.setGlideSemitones(2, 0.0);
    if (pitchTransportEnabled_) append(out, msgs);
}

void MidiRouter::jumpGlide(std::vector<MidiMessage>& out, int ch, int note) {
    if (!portamento_.config().enabled) return;
    if (portamento_.jumpTo(ch, note) && pitchTransportEnabled_) {
        append(out, pitch_.setGlideSemitones(ch, 0.0));
    }
}

void MidiRouter::startGlide(std::vector<MidiMessage>& out, int ch, int note, std::int64_t nowUs) {
    if (!portamento_.config().enabled || !pitchTransportEnabled_) return;
    if (keyboardLocal_ && localRange_ < kWideRange) {
        const int last = portamento_.lastNote(ch);
        if (last >= 0) {
            const double sounding = static_cast<double>(last) + portamento_.offsetSemitones(ch);
            if (std::abs(sounding - static_cast<double>(note)) > static_cast<double>(localRange_)) {
                applyLocalRange(out, kWideRange);
                lastRangeNeedUs_ = nowUs;
            }
        }
    }
    const double range = static_cast<double>(pitch_.bendRangeSemitones());
    if (portamento_.noteOn(ch, note, nowUs, range)) {
        append(out, pitch_.setGlideSemitones(ch, portamento_.offsetSemitones(ch)));
    }
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t nowUs) {
    const int ch = message.channel();
    if (ch < 0 || !KorgProfile::isUpperChannel(ch)) {
        // Local ON: the keyboard already sounds these itself; echo = doubling.
        if (keyboardLocal_) return {};
        return {message};
    }

    // Releases from a manually-cancelled scan are consumed individually. New
    // notes are immediately allowed again, so cancel really is immediate.
    if (third_.consumeCancelledScanRelease(message)) return {};

    const bool scanGateWasActive = third_.scanSilenceActive();
    if (scanGateWasActive) {
        const bool muteThisMessage = third_.shouldMuteScanMessage(message);
        third_.observeScan(message);
        if (muteThisMessage) {
            std::vector<MidiMessage> gateOut;
            syncU3Ownership(gateOut);   // a scan may have just locked TERCA
            trackOutgoing(gateOut);
            return gateOut;
        }
    }

    // Until Ribbon is actually used, physical Pitch Bend is a true byte-for-byte
    // pass-through.  Only after the Android layer explicitly enables the
    // +/-12 Ribbon transport do we compose physical bend with Ribbon.
    if (message.isPitchBend()) {
        if (!pitchTransportEnabled_) {
            // Keep the exact raw PA600 bend bytes transparent, but remember
            // the physical control position. If Ribbon is enabled later, the
            // coordinator can change to the +/-12 transport without a pitch
            // jump or falsely assuming the wheel is centered.
            pitch_.rememberManualBend14(ch, message.pitchBend14());
            if (keyboardLocal_) return {};
            return {message};
        }
        // Ribbon active: emit wheel + Ribbon as one composed value. In Local ON
        // this re-asserts the combined value right after the keyboard's own
        // local wheel message, so the two never fight.
        auto out = pitch_.setManualBend14(ch, message.pitchBend14());
        trackOutgoing(out);
        return out;
    }

    // CC120/123 is authoritative cleanup. If the TERCA source Upper is killed,
    // the generated U3 notes are killed too because they belong to it.
    if (message.isControlChange() && (message.data1 == 120 || message.data1 == 123)) {
        std::vector<MidiMessage> out;
        if (ch == tercaSource() && ch != 2 && third_.enabled()) {
            append(out, releaseActiveChannel(2, false));
            third_.clearGeneratedState();
        } else if (ch == 2) {
            third_.clearGeneratedState();
        }
        portamento_.resetChannel(ch);
        clearMono(ch);
        if (keyboardLocal_ && ch == 0) {
            portamento_.resetChannel(1);
            portamento_.resetChannel(2);
        }
        if (!keyboardLocal_) out.push_back(message);
        else clearActiveChannel(ch);
        // In transparent Local-OFF bridge mode CC120/123 must not inject an
        // unrelated Pitch Bend. Only reset the composed pitch lane when the
        // Ribbon transport is actually active.
        if (pitchTransportEnabled_) append(out, pitch_.resetChannel(ch));
        trackOutgoing(out);
        return out;
    }

    // With a locked/enabled TERCA, raw U3 musical events are intentionally
    // suppressed; U3 is owned by generated harmony. When TERCA is OFF, U3 is
    // completely normal again.
    // MONO legato: notes on U1/U2/U3 are turned into a strictly monophonic
    // line per Upper (last-note priority, return to a still-held key) BEFORE
    // TERCA / portamento / bridging see them.
    // Automatic MONO: forced on while TIME portamento is ON (a Pitch Bend glide
    // bends every sounding note of the channel, so notes must never overlap),
    // and on the TERCA source while TERCA owns U3 (one clean line of thirds).
    // With both OFF every Upper stays exactly as the PA600 Sound plays it.
    const bool monoHere = monoEnabled_ || portamento_.config().enabled ||
                          (ch == tercaSource() && third_.ownsRawUpper3());
    auto& activeFlag = monoActive_[static_cast<std::size_t>(ch)];
    if (monoHere != activeFlag) {
        clearMono(ch);          // never carry a stale key memory across a switch
        activeFlag = monoHere;
    }
    if (monoHere && (message.isNoteOn() || message.isNoteOff())) {
        std::vector<MidiMessage> out;
        for (const auto& ev : monoTransform(ch, message)) {
            append(out, processNote(ev.message, nowUs, ev.isReturn));
        }
        return out;
    }
    return processNote(message, nowUs, false);
}

std::vector<MidiRouter::MonoEvent> MidiRouter::monoTransform(int ch, const MidiMessage& message) {
    std::vector<MonoEvent> events;
    auto& mono = mono_[static_cast<std::size_t>(ch)];
    const int note = message.data1;
    auto findHeld = [&](int n) {
        for (std::size_t i = 0; i < mono.held.size(); ++i) if (mono.held[i].first == n) return static_cast<int>(i);
        return -1;
    };

    if (message.isNoteOn()) {
        const int existing = findHeld(note);
        if (existing >= 0) mono.held.erase(mono.held.begin() + existing);
        mono.held.emplace_back(note, message.data2);
        if (mono.sounding == note) return events;           // same key again: keep it
        const int previous = mono.sounding;
        mono.sounding = note;
        // Legato order: new note first, then release the previous one.
        events.push_back({message, false});
        if (previous >= 0) events.push_back({MidiMessage::noteOffZero(ch, previous), false});
        return events;
    }

    // Note Off
    const int index = findHeld(note);
    if (index < 0) {
        // Not ours (pressed before MONO was switched on): pass it through so
        // nothing can ever hang.
        events.push_back({message, false});
        return events;
    }
    mono.held.erase(mono.held.begin() + index);
    if (mono.sounding != note) return events;                // a silent held key
    if (!mono.held.empty()) {
        const auto back = mono.held.back();
        mono.sounding = back.first;
        events.push_back({MidiMessage::noteOn(ch, back.first, back.second), true});
        events.push_back({message, false});
    } else {
        mono.sounding = -1;
        events.push_back({message, false});
    }
    return events;
}

void MidiRouter::clearMono(int ch) {
    if (ch < 0 || ch > 2) return;
    mono_[static_cast<std::size_t>(ch)] = MonoState{};
}

void MidiRouter::setMonoEnabled(bool enabled) {
    monoEnabled_ = enabled;
    for (int ch = 0; ch < 3; ++ch) clearMono(ch);
}

std::vector<MidiMessage> MidiRouter::processNote(const MidiMessage& message, std::int64_t nowUs, bool isReturn) {
    const int ch = message.channel();
    // Local ON: raw U3 is never the source, just ignore it while TERCA owns U3.
    // Local OFF: raw U3 keys ARE the source; they are consumed below and only
    // their thirds reach U3.
    if (third_.isRawUpper3Musical(message) && tercaSource() != 2) return {};

    std::vector<MidiMessage> out;

    // TIME portamento, per Upper:
    //  Local OFF: every Upper glides from ITS OWN incoming notes (the PA600
    //    sends the key separately on U1/U2/U3), so a muted/untransmitted Upper
    //    never breaks another one. U3 uses the TERCA line while TERCA owns it.
    //  Local ON: only U1 is transmitted to the app, so U1 drives U1/U2(/U3).
    // The glide Pitch Bend is placed BEFORE the note so in Local OFF the note
    // already starts at the glide's start pitch.
    if (message.isNoteOn()) {
        if (keyboardLocal_) {
            if (ch == 0 && isReturn) {
                // The keyboard plays U1/U2 itself; the older key never stopped
                // there, so its pitch must simply be centred, not glided.
                jumpGlide(out, 0, message.data1);
                jumpGlide(out, 1, message.data1);
                if (!third_.ownsRawUpper3()) jumpGlide(out, 2, message.data1);
            } else if (ch == 0) {
                startGlide(out, 0, message.data1, nowUs);
                startGlide(out, 1, message.data1, nowUs);
                if (!third_.ownsRawUpper3()) startGlide(out, 2, message.data1, nowUs);
            }
        } else if (ch != 2 || !third_.ownsRawUpper3()) {
            startGlide(out, ch, message.data1, nowUs);
        }
    }

    const bool consumedAsSource = (ch == 2) && third_.isRawUpper3Musical(message);
    if (!keyboardLocal_ && !consumedAsSource) out.push_back(message);

    if (ch == tercaSource()) {
        const auto harmony = third_.processSource(message, tercaSource());
        // U3 glides along its own line of thirds (C->D melody = E->F terca).
        if (third_.ownsRawUpper3()) {
            for (const auto& h : harmony) {
                if (h.isNoteOn()) startGlide(out, 2, h.data1, nowUs);
            }
        }
        append(out, harmony);
        trackOutgoing(out);

        // Safety net: once the last key producing a third is released, U3
        // must be silent. Releasing everything still known on U3 plus CC123
        // guarantees no TERCA note can hang even if the PA600 missed a Note Off.
        if (message.isNoteOff() && third_.ownsRawUpper3() && !third_.anySourceHeld()) {
            auto sweep = releaseActiveChannel(2, true);
            third_.clearGeneratedState();
            append(out, sweep);
        }
        return out;
    }

    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    std::vector<MidiMessage> out;

    // RIBBON on the TUNING output lives completely outside the Pitch Bend lane
    // (the wheel and the blend's bend range are never touched).
    if (!ribbonUsesPitchBend()) {
        const auto tu = ribbon_.advance(nowUs);
        if (tu.valid) emitRibbonTuning(out, tu.semitones, nowUs, false);
        else if (tuningDirty_ && !ribbon_.active()) emitRibbonTuning(out, 0.0, nowUs, true);
        if (!pitchTransportEnabled_) return out;
    } else if (!pitchTransportEnabled_) {
        return out;
    }

    if (keyboardLocal_) {
        const bool ribbonWide = ribbonUsesPitchBend() && ribbon_.rangeSemitones() > kLocalBaseRange &&
            (ribbon_.targetSemitoneOffset() != 0.0 || ribbon_.currentSemitoneOffset() != 0.0);
        if (ribbonWide && localRange_ < kWideRange) applyLocalRange(out, kWideRange);
    }

    // Update glide offsets first (state only), then emit once per channel.
    const auto glideChanged = portamento_.advance(nowUs);
    const auto update = ribbonUsesPitchBend() ? ribbon_.advance(nowUs) : Ribbon::Update{};
    for (int ch = 0; ch < 3; ++ch) {
        const bool g = glideChanged[static_cast<std::size_t>(ch)];
        if (!g && !update.valid) continue;
        if (g) pitch_.storeGlideSemitones(ch, portamento_.offsetSemitones(ch));
        if (update.valid) pitch_.storeRibbonSemitones(ch, update.semitones);
        append(out, pitch_.emitChannel(ch));
    }

    // Local ON: back to the keyboard's normal +/-2 once nothing needs more.
    if (keyboardLocal_ && localRange_ > kLocalBaseRange) {
        if (localRangeNeeded() > kLocalBaseRange) {
            lastRangeNeedUs_ = nowUs;
        } else if (nowUs - lastRangeNeedUs_ >= kRangeReleaseUs) {
            applyLocalRange(out, kLocalBaseRange);
        }
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoEnabled(bool enabled) {
    auto out = portamento_.setEnabled(enabled);
    if (!enabled) {
        // Drop any glide offset that was still running.
        for (int ch = 0; ch < 3; ++ch) {
            auto msgs = pitch_.setGlideSemitones(ch, 0.0);
            if (pitchTransportEnabled_) append(out, msgs);
        }
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoTimeMs(int ms) {
    portamento_.setTimeMs(ms);
    return {};
}

std::vector<MidiMessage> MidiRouter::syncPortamento() const {
    return portamento_.sync();
}

std::vector<MidiMessage> MidiRouter::syncPortamentoChannel(int ch) const {
    return portamento_.syncForChannel(ch);
}

std::vector<MidiMessage> MidiRouter::syncPitchChannel(int ch) {
    if (!pitchTransportEnabled_) return {};
    std::vector<MidiMessage> out;
    // Local ON: a new Sound may have reset the bend range; re-assert ours.
    if (keyboardLocal_ && ch >= 0 && ch <= 2) appendRpnRange(out, ch, localRange_);
    append(out, pitch_.forceEmitChannel(ch));
    return out;
}

std::vector<MidiMessage> MidiRouter::setPitchTransportEnabled(bool enabled) {
    if (pitchTransportEnabled_ == enabled) return {};
    pitchTransportEnabled_ = enabled;
    ribbon_.reset();
    // A glide cannot survive a transport change: drop its offset completely so
    // no stale glide lane is composed into a later Pitch Bend.
    for (int ch = 0; ch < 3; ++ch) {
        const int last = portamento_.lastNote(ch);
        portamento_.resetChannel(ch);
        if (last >= 0) portamento_.jumpTo(ch, last);
        pitch_.storeGlideSemitones(ch, 0.0);
    }

    std::vector<MidiMessage> out;
    if (keyboardLocal_) {
        // Local ON always starts/ends at the keyboard's normal +/-2 range; the
        // core owns the RPN in this mode.
        localRange_ = kLocalBaseRange;
        pitch_.setBendRangeSemitones(kLocalBaseRange);
        for (int ch = 0; ch < 3; ++ch) appendRpnRange(out, ch, kLocalBaseRange);
    }
    for (int ch = 0; ch < 3; ++ch) {
        // Preserve the remembered physical PA600 wheel position. Only the
        // Ribbon contribution is reset when switching transport modes.
        pitch_.clearRibbonContribution(ch);
        if (enabled) {
            append(out, pitch_.forceEmitChannel(ch));
        } else {
            // Back to the normal +/-2 transport (the Android layer restores
            // RPN 0 = 2 first): re-assert the raw physical wheel position.
            out.push_back(MidiMessage::pitchBend(ch, pitch_.manualBend14(ch)));
        }
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    if (!enabled && third_.scanSilenceActive()) third_.cancelScan();
    if (third_.enabled() == enabled) return {};

    std::vector<MidiMessage> out;
    // U3 ownership changes are always made at a clean note boundary.
    if (third_.tonalityValid()) append(out, releaseActiveChannel(2, true));
    third_.clearGeneratedState();
    third_.setEnabled(enabled);
    syncU3Ownership(out);
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdScanning(bool scanning) {
    if (scanning) {
        if (third_.scanning()) return {};
        // Local ON: never CC123 the keyboard's own U1/U2 notes; only the
        // app-generated notes (tracked here) are released.
        std::vector<MidiMessage> out = releaseAllActive(!keyboardLocal_);
        // SCAN swallows the releases of keys held right now, so MONO must not
        // remember them (it would later "return" to a key that is already up).
        for (int ch = 0; ch < 3; ++ch) clearMono(ch);
        third_.clearGeneratedState();
        third_.startScan();
        trackOutgoing(out);
        return out;
    }

    if (!third_.scanSilenceActive()) return {};
    third_.cancelScan();
    return {};
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t nowUs) {
    ribbon_.setTarget(normalizedPosition, nowUs);
    return {};
}

std::vector<MidiMessage> MidiRouter::ribbonTouch(int action, double position, std::int64_t nowUs) {
    if (action == 0) ribbon_.touchDown(position, nowUs);
    else if (action == 1) ribbon_.touchMove(position, nowUs);
    else ribbon_.touchUp(nowUs);
    return {};
}

std::vector<MidiMessage> MidiRouter::setRibbonSettings(const Ribbon::Settings& settings) {
    std::vector<MidiMessage> out;
    const auto previous = ribbon_.settings().output;
    ribbon_.setSettings(settings);
    if (previous != ribbon_.settings().output) {
        // Switching destination: clear whatever the ribbon had applied before.
        if (previous == Ribbon::Output::Tuning) resetRibbonTuning(out);
        for (int ch = 0; ch < 3; ++ch) {
            auto msgs = pitch_.setRibbonSemitones(ch, 0.0);
            if (pitchTransportEnabled_) append(out, msgs);
        }
        ribbon_.reset();
    }
    trackOutgoing(out);
    return out;
}

void MidiRouter::emitRibbonTuning(std::vector<MidiMessage>& out, double semitones, std::int64_t nowUs, bool force) {
    // Coarse = whole semitones, Fine = remainder (-1..+1 semitone = +-100 cents).
    const double clamped = std::clamp(semitones, -24.0, 24.0);
    // Hysteresis: keep the current coarse step while the fine part can still
    // express the pitch (+-1 semitone), so coarse writes are rare and a
    // ribbon within +-1 semitone moves on Fine Tuning only (perfectly smooth).
    int coarse = (tuningCoarse_ >= -24 && tuningCoarse_ <= 24) ? tuningCoarse_ : 0;
    if (std::abs(clamped) <= 1.0) {
        coarse = 0;                               // Fine alone covers +-1: centre is always clean
    } else if (coarse == 0 || std::abs(clamped - static_cast<double>(coarse)) > 1.0) {
        coarse = static_cast<int>(std::lround(clamped));
    }
    const double rest = std::clamp(clamped - static_cast<double>(coarse), -1.0, 1.0);
    const int fine14 = std::clamp(static_cast<int>(std::lround(8192.0 + rest * 8191.0)), 0, 16383);
    const bool changed = coarse != tuningCoarse_ || fine14 != tuningFine14_;
    if (!changed && !force) return;
    // At most 250 updates/s: plenty for pitch, light on USB MIDI.
    if (!force && nowUs - tuningLastUs_ < 4000 && coarse == tuningCoarse_) return;
    tuningLastUs_ = nowUs;

    for (int ch = 0; ch < 3; ++ch) {
        if (coarse != tuningCoarse_ || force) {
            out.push_back(MidiMessage::controlChange(ch, 101, 0));
            out.push_back(MidiMessage::controlChange(ch, 100, 2));
            out.push_back(MidiMessage::controlChange(ch, 6, 64 + coarse));
            out.push_back(MidiMessage::controlChange(ch, 38, 0));
        }
        if (fine14 != tuningFine14_ || force || coarse != tuningCoarse_) {
            out.push_back(MidiMessage::controlChange(ch, 101, 0));
            out.push_back(MidiMessage::controlChange(ch, 100, 1));
            out.push_back(MidiMessage::controlChange(ch, 6, (fine14 >> 7) & 0x7F));
            out.push_back(MidiMessage::controlChange(ch, 38, fine14 & 0x7F));
        }
    }
    tuningCoarse_ = coarse;
    tuningFine14_ = fine14;
    tuningSelected_ = 1;
    const bool atZero = coarse == 0 && fine14 == 8192;
    tuningDirty_ = !atZero;
    if (atZero) {
        // Back at 0: close the RPN so no later Data Entry can change tuning.
        for (int ch = 0; ch < 3; ++ch) {
            out.push_back(MidiMessage::controlChange(ch, 101, 127));
            out.push_back(MidiMessage::controlChange(ch, 100, 127));
        }
        tuningSelected_ = 0;
    }
}

void MidiRouter::resetRibbonTuning(std::vector<MidiMessage>& out) {
    if (!tuningDirty_ && tuningCoarse_ == 0 && tuningFine14_ == 8192) return;
    tuningCoarse_ = 99;   // force both parts
    tuningFine14_ = -1;
    emitRibbonTuning(out, 0.0, 0, true);
}

std::vector<MidiMessage> MidiRouter::ribbonReset() {
    std::vector<MidiMessage> out;
    resetRibbonTuning(out);
    ribbon_.reset();
    for (int ch = 0; ch < 3; ++ch) {
        auto msgs = pitch_.setRibbonSemitones(ch, 0.0);
        if (pitchTransportEnabled_) append(out, msgs);
    }
    trackOutgoing(out);
    return out;
}

std::vector<MidiMessage> MidiRouter::panic() {
    std::vector<MidiMessage> out = releaseAllActive(false);
    for (int ch = 0; ch < 3; ++ch) {
        out.push_back(MidiMessage::controlChange(ch, 123, 0));
        out.push_back(MidiMessage::controlChange(ch, 120, 0));
        append(out, pitch_.resetChannel(ch));
    }

    third_.cancelScan();
    third_.clearGeneratedState();
    resetRibbonTuning(out);
    ribbon_.reset();
    portamento_.reset();
    for (int ch = 0; ch < 3; ++ch) clearMono(ch);
    pitch_.clearAll();
    if (keyboardLocal_) {
        localRange_ = kLocalBaseRange;
        pitch_.setBendRangeSemitones(kLocalBaseRange);
    }
    pitchTransportEnabled_ = false;
    for (int ch = 0; ch < 3; ++ch) clearActiveChannel(ch);
    trackOutgoing(out);
    return out;
}

} // namespace silveton
