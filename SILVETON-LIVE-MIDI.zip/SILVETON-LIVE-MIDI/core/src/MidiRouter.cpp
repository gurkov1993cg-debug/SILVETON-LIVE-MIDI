#include "silveton/MidiRouter.h"
#include <algorithm>

namespace silveton {

bool MidiRouter::isMusicalUpperMessage(const MidiMessage& m) {
    if (m.channel() < 0) return false;
    if (m.isNoteOn() || m.isNoteOff() || m.isPitchBend()) return true;
    const int cmd = m.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

void MidiRouter::append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const {
    dst.insert(dst.end(), src.begin(), src.end());
}

double MidiRouter::bend14ToPortamentoSemitones(int bend14) const {
    const auto& cfg = portamento_.config();
    const double n = (double(std::clamp(bend14, 0, 16383)) - 8192.0) / 8192.0;
    return n * double(cfg.bendRangeSemitones);
}

void MidiRouter::consumePortamentoOutput(std::vector<MidiMessage>& dst,
                                         const std::vector<MidiMessage>& src) {
    for (const auto& m : src) {
        if (m.isPitchBend() && KorgProfile::isUpperChannel(m.channel())) {
            append(dst, pitch_.setPortamentoSemitones(m.channel(),
                                                       bend14ToPortamentoSemitones(m.pitchBend14())));
        } else {
            dst.push_back(m);
        }
    }
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t nowUs) {
    const int ch = message.channel();
    if (ch < 0 || !KorgProfile::isUpperChannel(ch)) return {message};

    const bool scanWasActive = third_.scanning();
    if (scanWasActive) {
        third_.observeScan(message);
        // SCAN is acoustically silent. The successful third note is swallowed too.
        if (isMusicalUpperMessage(message)) return {};
    }

    // Manual/physical pitch bend is an independent contribution.
    if (message.isPitchBend()) {
        return pitch_.setManualBend14(ch, message.pitchBend14());
    }

    // Upper 3 is owned by TERCA only while TERCA is ON.
    // When TERCA is OFF, Upper 3 is fully independent and Portamento works on it normally.
    if (third_.isRawUpper3Musical(message)) return {};

    std::vector<MidiMessage> out;
    consumePortamentoOutput(out, portamento_.process(message, nowUs));

    // TERCA has no access to Portamento state. Router simply sends its generated note
    // through the normal Upper 3 Portamento input path.
    if (message.channel() == 0) {
        for (const auto& harmony : third_.generateFromUpper1(message)) {
            consumePortamentoOutput(out, portamento_.process(harmony, nowUs));
        }
    }
    return out;
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    if (third_.scanning()) return out;
    consumePortamentoOutput(out, portamento_.poll(nowUs));
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoEnabled(bool enabled) {
    auto cfg = portamento_.config();
    if (cfg.enabled == enabled) return {};

    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) {
        consumePortamentoOutput(out, portamento_.panicChannel(ch));
    }
    cfg.enabled = enabled;
    portamento_.setConfig(cfg);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    if (third_.enabled() == enabled) return {};
    std::vector<MidiMessage> out;
    // Only TERCA-owned Upper 3 note state is cleared. No other effect state is touched.
    consumePortamentoOutput(out, portamento_.panicChannel(2));
    third_.setEnabled(enabled);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdScanning(bool scanning) {
    if (scanning == third_.scanning()) return {};
    if (!scanning) {
        third_.cancelScan();
        return {};
    }

    std::vector<MidiMessage> out;
    // Silence any notes already sounding, while preserving every module's configuration.
    for (int ch = 0; ch < 3; ++ch) {
        consumePortamentoOutput(out, portamento_.panicChannel(ch));
    }
    third_.startScan();
    return out;
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t) {
    std::vector<MidiMessage> out;
    const double semitones = ribbon_.semitoneOffset(normalizedPosition);

    // Independent Ribbon: Upper 2 + Upper 3 always, regardless of TERCA or Portamento state.
    append(out, pitch_.setRibbonSemitones(1, semitones));
    append(out, pitch_.setRibbonSemitones(2, semitones));
    return out;
}

std::vector<MidiMessage> MidiRouter::panic() {
    std::vector<MidiMessage> out;
    // Keep only note cleanup from Portamento; final pitch reset comes from PitchCoordinator.
    const auto p = portamento_.panic();
    for (const auto& m : p) {
        if (!m.isPitchBend() && KorgProfile::isUpperChannel(m.channel())) out.push_back(m);
    }
    for (int ch = 0; ch < 3; ++ch) append(out, pitch_.resetChannel(ch));
    third_.cancelScan();
    return out;
}

} // namespace silveton
