#include "silveton/MidiRouter.h"
#include <algorithm>

namespace silveton {

void MidiRouter::setPortamentoConfig(const Portamento::Config& config) {
    portamento_.setConfig(config);
    thirdPortamento_.setConfig(config);
}

bool MidiRouter::isMusicalUpperMessage(const MidiMessage& m) {
    if (m.channel() < 0) return false;
    if (m.isNoteOn() || m.isNoteOff() || m.isPitchBend()) return true;
    const int cmd = m.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

void MidiRouter::append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const {
    dst.insert(dst.end(), src.begin(), src.end());
}

double MidiRouter::bend14ToPortamentoSemitones(int bend14) const {
    const auto& cfg = portamento_.config();
    const double n = (double(std::clamp(bend14, 0, 16383)) - 8192.0) / 8192.0;
    return n * double(cfg.bendRangeSemitones);
}

void MidiRouter::consumePortamentoOutput(std::vector<MidiMessage>& dst,
                                         const std::vector<MidiMessage>& src) {
    for (const auto& m : src) {
        if (m.isPitchBend() && KorgProfile::isUpperChannel(m.channel())) {
            append(dst, pitch_.setPortamentoSemitones(m.channel(),
                                                       bend14ToPortamentoSemitones(m.pitchBend14())));
        } else {
            dst.push_back(m);
        }
    }
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t nowUs) {
    const int ch = message.channel();
    if (ch < 0 || !KorgProfile::isUpperChannel(ch)) return {message};

    // Low-level safety boundary: a Korg All Sound Off / All Notes Off must
    // clear every internal lane that can drive this physical channel.
    // Otherwise the keyboard can be silent while an effect still believes
    // a note is sounding, causing the next phrase to stick.
    if (message.command() == 0xB0 && (message.data1 == 120 || message.data1 == 123)) {
        std::vector<MidiMessage> out;
        consumePortamentoOutput(out, portamento_.panicChannel(ch));
        if (ch == 2) consumePortamentoOutput(out, thirdPortamento_.panicChannel(2));
        append(out, pitch_.resetChannel(ch));
        out.push_back(message);
        return out;
    }

    const bool scanGateWasActive = third_.scanning() || third_.scanSilenceActive();
    if (scanGateWasActive) {
        const bool muteThisMessage = third_.shouldMuteScanMessage(message);
        third_.observeScan(message);
        // SCAN and its release latch are acoustically silent.  Compute the
        // decision before observeScan(), so the final releasing Note Off is
        // swallowed as well.
        if (muteThisMessage) {
            // Keep PitchCoordinator in sync with the physical wheel even while
            // the scan gate is muting output.  Without this, the coordinator's
            // manualBend14 grows stale if the wheel moves during the latch
            // period, causing a detuned first note after the latch clears.
            if (message.isPitchBend()) {
                pitch_.setManualBend14(ch, message.pitchBend14());
            }
            return {};
        }
    }

    // Manual/physical pitch bend is an independent contribution.
    if (message.isPitchBend()) {
        return pitch_.setManualBend14(ch, message.pitchBend14());
    }

    // Upper 3 is owned by TERCA only while TERCA is ON.
    // When TERCA is OFF, Upper 3 is fully independent and Portamento works on it normally.
    if (third_.isRawUpper3Musical(message)) return {};

    std::vector<MidiMessage> out;
    consumePortamentoOutput(out, portamento_.process(message, nowUs));

    // TERCA has no access to Portamento state. Router simply sends its generated note
    // through the normal Upper 3 Portamento input path.
    if (message.channel() == 0) {
        for (const auto& harmony : third_.generateFromUpper1(message)) {
            consumePortamentoOutput(out, thirdPortamento_.process(harmony, nowUs));
        }
    }
    return out;
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    if (third_.scanning()) return out;
    consumePortamentoOutput(out, portamento_.poll(nowUs));
    if (third_.enabled()) consumePortamentoOutput(out, thirdPortamento_.poll(nowUs));
    return out;
}

std::vector<MidiMessage> MidiRouter::setPortamentoEnabled(bool enabled) {
    auto cfg = portamento_.config();
    if (cfg.enabled == enabled) return {};

    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) {
        consumePortamentoOutput(out, portamento_.panicChannel(ch));
    }
    consumePortamentoOutput(out, thirdPortamento_.panicChannel(2));
    cfg.enabled = enabled;
    setPortamentoConfig(cfg);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    // OFF is authoritative: it also exits SCAN so the UI cannot keep blinking
    // while the effect is explicitly disabled.
    if (!enabled && (third_.scanning() || third_.scanSilenceActive())) third_.cancelScan();
    if (third_.enabled() == enabled) return {};
    std::vector<MidiMessage> out;
    // Raw Upper 3 and TERCA Upper 3 have separate glide state. Clear both at
    // the ownership boundary so neither can leave a note in the other lane.
    consumePortamentoOutput(out, portamento_.panicChannel(2));
    consumePortamentoOutput(out, thirdPortamento_.panicChannel(2));
    third_.setEnabled(enabled);
    return out;
}

std::vector<MidiMessage> MidiRouter::setThirdScanning(bool scanning) {
    if (scanning == third_.scanning()) return {};
    if (!scanning) {
        third_.cancelScan();
        return {};
    }

    std::vector<MidiMessage> out;
    // Silence any notes already sounding, while preserving every module's configuration.
    for (int ch = 0; ch < 3; ++ch) {
        consumePortamentoOutput(out, portamento_.panicChannel(ch));
    }
    consumePortamentoOutput(out, thirdPortamento_.panicChannel(2));
    third_.startScan();
    return out;
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t) {
    std::vector<MidiMessage> out;
    const double semitones = ribbon_.semitoneOffset(normalizedPosition);

    // Independent Ribbon: all three logical Upper tracks.
    // Channel mapping to the physical Korg MIDI channels is handled by Android.
    append(out, pitch_.setRibbonSemitones(0, semitones));
    append(out, pitch_.setRibbonSemitones(1, semitones));
    append(out, pitch_.setRibbonSemitones(2, semitones));
    return out;
}

std::vector<MidiMessage> MidiRouter::panic() {
    std::vector<MidiMessage> out;
    // Keep only note cleanup from Portamento; final pitch reset comes from PitchCoordinator.
    const auto p = portamento_.panic();
    for (const auto& m : p) {
        if (!m.isPitchBend() && KorgProfile::isUpperChannel(m.channel())) out.push_back(m);
    }
    const auto tp = thirdPortamento_.panic();
    for (const auto& m : tp) {
        if (!m.isPitchBend() && KorgProfile::isUpperChannel(m.channel())) out.push_back(m);
    }
    for (int ch = 0; ch < 3; ++ch) append(out, pitch_.resetChannel(ch));
    third_.cancelScan();
    return out;
}

} // namespace silveton
