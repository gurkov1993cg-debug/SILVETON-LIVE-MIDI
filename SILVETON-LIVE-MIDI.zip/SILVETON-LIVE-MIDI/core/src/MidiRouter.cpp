#include "silveton/MidiRouter.h"

namespace silveton {

bool MidiRouter::isMusicalUpperMessage(const MidiMessage& m) {
    if (m.channel() < 0) return false;
    if (m.isNoteOn() || m.isNoteOff() || m.isPitchBend()) return true;
    const int cmd = m.command();
    return cmd == 0xA0 || cmd == 0xD0;
}

void MidiRouter::append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const {
    dst.insert(dst.end(), src.begin(), src.end());
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t nowUs) {
    const int ch = message.channel();
    if (ch < 0 || !KorgProfile::isUpperChannel(ch)) return {message};

    const bool scanWasActive = third_.scanning();
    if (scanWasActive) {
        third_.observeScan(message, nowUs);
        // SCAN mode is intentionally silent on all Upper channels.
        if (isMusicalUpperMessage(message)) return {};
    }

    // Physical Upper 3 belongs to TERCA. Never let its raw note stream double the generated harmony.
    if (third_.isRawUpper3Musical(message)) return {};

    std::vector<MidiMessage> out;

    // Normal Upper 1 / Upper 2 path through global Portamento.
    append(out, portamento_.process(message, nowUs));

    // TERCA is generated from Upper 1 and then receives its own independent Portamento on Upper 3.
    if (message.channel() == 0) {
        for (const auto& h : third_.generateFromUpper1(message)) {
            append(out, portamento_.process(h, nowUs));
        }
    }

    return out;
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    if (third_.scanning()) return {};
    return portamento_.poll(nowUs);
}

std::vector<MidiMessage> MidiRouter::setPortamentoEnabled(bool enabled) {
    auto cfg = portamento_.config();
    if (cfg.enabled == enabled) return {};
    std::vector<MidiMessage> cleanup;
    for (int ch = 0; ch < 3; ++ch) append(cleanup, portamento_.panicChannel(ch));
    cfg.enabled = enabled;
    portamento_.setConfig(cfg);
    return cleanup;
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    if (third_.enabled() == enabled) return {};
    auto cleanup = portamento_.panicChannel(2);
    third_.setEnabled(enabled);
    return cleanup;
}

std::vector<MidiMessage> MidiRouter::startThirdScan() {
    std::vector<MidiMessage> cleanup;
    for (int ch = 0; ch < 3; ++ch) append(cleanup, portamento_.panicChannel(ch));
    third_.startScan();
    return cleanup;
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    const double semitones = ribbon_.semitoneOffset(normalizedPosition);

    // Locked requirement: Ribbon is separate from Portamento/manual Pitch Bend and targets only Upper 2 + Upper 3.
    append(out, portamento_.setRibbonOffsetSemitones(1, semitones, nowUs));
    if (third_.enabled()) {
        append(out, portamento_.setRibbonOffsetSemitones(2, semitones, nowUs));
    } else {
        // Keep Upper 3 centered while TERCA is OFF.
        append(out, portamento_.setRibbonOffsetSemitones(2, 0.0, nowUs));
    }
    return out;
}

std::vector<MidiMessage> MidiRouter::panic() {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) append(out, portamento_.panicChannel(ch));
    return out;
}

} // namespace silveton
