#include "silveton/MidiRouter.h"

namespace silveton {

std::vector<MidiMessage> MidiRouter::filterThird(const std::vector<MidiMessage>& messages) const {
    std::vector<MidiMessage> out;
    out.reserve(messages.size());
    for (const auto& m : messages) {
        if (third_.shouldPass(m)) out.push_back(m);
    }
    return out;
}

std::vector<MidiMessage> MidiRouter::process(const MidiMessage& message, std::int64_t nowUs) {
    const int ch = message.channel();
    if (ch >= 0 && KorgProfile::isUpperChannel(ch)) {
        third_.observe(message, nowUs);
        return filterThird(portamento_.process(message, nowUs));
    }
    return {message};
}

std::vector<MidiMessage> MidiRouter::poll(std::int64_t nowUs) {
    auto all = portamento_.poll(nowUs);
    std::vector<MidiMessage> upperOnly;
    upperOnly.reserve(all.size());
    for (const auto& m : all) {
        if (KorgProfile::isUpperChannel(m.channel()) && third_.shouldPass(m)) {
            upperOnly.push_back(m);
        }
    }
    return upperOnly;
}

std::vector<MidiMessage> MidiRouter::setThirdEnabled(bool enabled) {
    if (third_.enabled() == enabled) return {};

    // Always reset the real Upper 3 state on a gate transition. This prevents
    // a held/stale note from becoming the starting point of a later glide.
    auto out = portamento_.panicChannel(2);
    third_.setEnabled(enabled);
    return out;
}

std::vector<MidiMessage> MidiRouter::ribbonMove(double normalizedPosition, std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    for (const auto& bend : ribbon_.makePitchBends(normalizedPosition)) {
        auto processed = portamento_.process(bend, nowUs);
        for (const auto& m : processed) {
            if (third_.shouldPass(m)) out.push_back(m);
        }
    }
    return out;
}

std::vector<MidiMessage> MidiRouter::panic() {
    auto all = portamento_.panic();
    std::vector<MidiMessage> upperOnly;
    upperOnly.reserve(all.size());
    for (const auto& m : all) {
        if (KorgProfile::isUpperChannel(m.channel())) upperOnly.push_back(m);
    }
    return upperOnly;
}

} // namespace silveton
