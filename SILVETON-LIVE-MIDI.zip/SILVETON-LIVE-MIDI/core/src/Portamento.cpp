#include "silveton/Portamento.h"
#include <algorithm>
#include <cmath>

namespace silveton {

void Portamento::setConfig(const Config& config) {
    config_ = config;
    config_.glideMs = std::clamp(config_.glideMs, 1, 5000);
    config_.bendRangeSemitones = std::clamp(config_.bendRangeSemitones, 1, 24);
    config_.updateIntervalUs = std::clamp(config_.updateIntervalUs, 500, 20000);
}

double Portamento::currentBaseBendSemitones(const ChannelState& state, std::int64_t nowUs) const {
    if (!state.glideActive || nowUs >= state.glideEndUs) return 0.0;
    if (nowUs <= state.glideStartUs) return state.glideStartBendSemitones;
    const auto span = double(state.glideEndUs - state.glideStartUs);
    const auto pos = double(nowUs - state.glideStartUs) / span;
    const auto t = std::clamp(pos, 0.0, 1.0);
    // Smoothstep keeps both ends gentle while preserving exact fixed duration.
    const double smooth = t * t * (3.0 - 2.0 * t);
    return state.glideStartBendSemitones * (1.0 - smooth);
}

int Portamento::baseAndManualToBend14(double baseSemitones, int manualBend14) const {
    const double manualNorm = (double(manualBend14) - 8192.0) / 8192.0;
    const double manualSemitones = manualNorm * double(config_.bendRangeSemitones);
    const double totalSemitones = std::clamp(baseSemitones + manualSemitones,
                                             -double(config_.bendRangeSemitones),
                                              double(config_.bendRangeSemitones));
    const double normalized = totalSemitones / double(config_.bendRangeSemitones);
    const int value = int(std::lround(8192.0 + normalized * 8192.0));
    return std::clamp(value, 0, 16383);
}

int Portamento::newestHeldNote(const ChannelState& state) const {
    std::uint64_t bestOrder = 0;
    int bestNote = -1;
    for (int note = 0; note < 128; ++note) {
        const auto& h = state.held[note];
        if (h.note >= 0 && h.order >= bestOrder) {
            bestOrder = h.order;
            bestNote = note;
        }
    }
    return bestNote;
}

int Portamento::velocityFor(const ChannelState& state, int note) const {
    if (note < 0 || note > 127) return 100;
    return state.held[note].note >= 0 ? state.held[note].velocity : 100;
}

void Portamento::markHeld(ChannelState& state, int note, int velocity) {
    auto& h = state.held[note];
    h.note = note;
    h.velocity = std::clamp(velocity, 1, 127);
    h.order = ++state.orderCounter;
}

void Portamento::unmarkHeld(ChannelState& state, int note) {
    if (note < 0 || note > 127) return;
    state.held[note] = HeldNote{};
}

void Portamento::emitBendIfChanged(std::vector<MidiMessage>& out, int ch,
                                   ChannelState& state, double baseSemitones) {
    const int bend = baseAndManualToBend14(baseSemitones, state.manualBend14);
    if (bend != state.lastOutputBend14) {
        out.push_back(MidiMessage::pitchBend(ch, bend));
        state.lastOutputBend14 = bend;
    }
}

void Portamento::switchSoundingNote(std::vector<MidiMessage>& out, int ch, ChannelState& state,
                                    int newNote, int velocity, std::int64_t nowUs, bool glide) {
    const int oldNote = state.soundingNote;
    const double oldBase = currentBaseBendSemitones(state, nowUs);

    if (oldNote >= 0) {
        out.push_back(MidiMessage::noteOff(ch, oldNote, 0));
    }

    if (newNote < 0) {
        state.soundingNote = -1;
        state.soundingVelocity = 0;
        state.baseBendSemitones = 0.0;
        state.glideStartBendSemitones = 0.0;
        state.glideActive = false;
        emitBendIfChanged(out, ch, state, 0.0);
        return;
    }

    double startBase = 0.0;
    if (glide && oldNote >= 0 && config_.enabled) {
        // Preserve the actually sounding pitch at the instant of re-anchoring.
        const double oldPitch = double(oldNote) + oldBase;
        startBase = oldPitch - double(newNote);
        startBase = std::clamp(startBase,
                               -double(config_.bendRangeSemitones),
                                double(config_.bendRangeSemitones));
    }

    state.soundingNote = newNote;
    state.soundingVelocity = velocity;
    state.baseBendSemitones = startBase;
    state.glideStartBendSemitones = startBase;
    state.glideStartUs = nowUs;
    state.glideEndUs = nowUs + std::int64_t(config_.glideMs) * 1000;
    state.glideActive = config_.enabled && glide && std::abs(startBase) > 1e-9;
    state.lastPollUs = nowUs;

    // Bend must arrive before Note On so the new note starts at the previous pitch.
    emitBendIfChanged(out, ch, state, startBase);
    out.push_back(MidiMessage::noteOn(ch, newNote, velocity));
}

std::vector<MidiMessage> Portamento::process(const MidiMessage& message, std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    const int ch = message.channel();
    if (ch < 0 || ch >= 16) {
        out.push_back(message);
        return out;
    }

    auto& state = states_[ch];

    if (message.isPitchBend()) {
        state.manualBend14 = message.pitchBend14();
        const double base = currentBaseBendSemitones(state, nowUs);
        emitBendIfChanged(out, ch, state, base);
        return out;
    }

    if (message.isNoteOn()) {
        const int note = message.data1;
        markHeld(state, note, message.data2);

        if (!config_.enabled) {
            out.push_back(message);
            state.soundingNote = note;
            state.soundingVelocity = message.data2;
            return out;
        }

        if (state.soundingNote < 0) {
            switchSoundingNote(out, ch, state, note, message.data2, nowUs, false);
        } else if (note != state.soundingNote) {
            switchSoundingNote(out, ch, state, note, message.data2, nowUs, true);
        }
        return out;
    }

    if (message.isNoteOff()) {
        const int note = message.data1;
        unmarkHeld(state, note);

        if (!config_.enabled) {
            out.push_back(message);
            if (state.soundingNote == note) state.soundingNote = -1;
            return out;
        }

        if (state.soundingNote != note) {
            // A previously-held note may already have been turned off when last-note priority switched.
            return out;
        }

        const int fallback = newestHeldNote(state);
        if (fallback >= 0) {
            switchSoundingNote(out, ch, state, fallback, velocityFor(state, fallback), nowUs, true);
        } else {
            switchSoundingNote(out, ch, state, -1, 0, nowUs, false);
        }
        return out;
    }

    out.push_back(message);
    return out;
}

std::vector<MidiMessage> Portamento::poll(std::int64_t nowUs) {
    std::vector<MidiMessage> out;
    if (!config_.enabled) return out;

    for (int ch = 0; ch < 16; ++ch) {
        auto& state = states_[ch];
        if (!state.glideActive) continue;
        if (state.lastPollUs >= 0 && nowUs - state.lastPollUs < config_.updateIntervalUs && nowUs < state.glideEndUs) {
            continue;
        }

        state.lastPollUs = nowUs;
        const double base = currentBaseBendSemitones(state, nowUs);
        state.baseBendSemitones = base;
        emitBendIfChanged(out, ch, state, base);

        if (nowUs >= state.glideEndUs) {
            state.baseBendSemitones = 0.0;
            state.glideStartBendSemitones = 0.0;
            state.glideActive = false;
        }
    }
    return out;
}

std::vector<MidiMessage> Portamento::panic() {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 16; ++ch) {
        auto& state = states_[ch];
        if (state.soundingNote >= 0) {
            out.push_back(MidiMessage::noteOff(ch, state.soundingNote, 0));
        }
        for (int note = 0; note < 128; ++note) state.held[note] = HeldNote{};
        state = ChannelState{};
        out.push_back(MidiMessage::pitchBend(ch, 8192));
    }
    return out;
}

} // namespace silveton
