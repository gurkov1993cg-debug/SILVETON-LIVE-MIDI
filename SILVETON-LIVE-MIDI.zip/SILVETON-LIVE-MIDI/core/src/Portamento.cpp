#include "silveton/Portamento.h"
#include <algorithm>
#include <cmath>

namespace silveton {

void Portamento::setConfig(const Config& config) {
    config_ = config;
    config_.timeMs = std::clamp(config_.timeMs, kMinTimeMs, kMaxTimeMs);
    if (!config_.enabled) reset();
}

std::vector<MidiMessage> Portamento::setEnabled(bool enabled) {
    config_.enabled = enabled;
    if (!enabled) {
        reset();
        return {};
    }
    return sync();
}

void Portamento::setTimeMs(int ms) {
    config_.timeMs = std::clamp(ms, kMinTimeMs, kMaxTimeMs);
}

std::vector<MidiMessage> Portamento::sync() const {
    std::vector<MidiMessage> out;
    if (!config_.enabled) return out;
    for (int ch = 0; ch < 3; ++ch) out.push_back(MidiMessage::controlChange(ch, 65, 0));
    return out;
}

std::vector<MidiMessage> Portamento::syncForChannel(int ch) const {
    if (!config_.enabled || ch < 0 || ch > 2) return {};
    return {MidiMessage::controlChange(ch, 65, 0)};
}

double Portamento::offsetAt(const Glide& g, std::int64_t nowUs) const {
    if (!g.active || g.durationUs <= 0) return 0.0;
    const std::int64_t elapsed = nowUs - g.startUs;
    if (elapsed <= 0) return g.startOffset;
    if (elapsed >= g.durationUs) return 0.0;
    const double t = static_cast<double>(elapsed) / static_cast<double>(g.durationUs);
    return g.startOffset * (1.0 - t); // linear in semitones: constant total time
}

bool Portamento::noteOn(int ch, int note, std::int64_t nowUs, double maxSemitones) {
    if (ch < 0 || ch > 2) return false;
    auto& g = glides_[static_cast<std::size_t>(ch)];
    const double before = g.offset;

    if (!config_.enabled || g.lastNote < 0 || config_.timeMs <= 0) {
        g.lastNote = note;
        g.active = false;
        g.startOffset = 0.0;
        g.offset = 0.0;
        return before != g.offset;
    }

    // Start from the pitch that is sounding right now (also mid-glide).
    const double sounding = static_cast<double>(g.lastNote) + offsetAt(g, nowUs);
    const double start = std::clamp(sounding - static_cast<double>(note), -maxSemitones, maxSemitones);
    g.lastNote = note;
    g.startOffset = start;
    g.offset = start;
    g.startUs = nowUs;
    g.durationUs = static_cast<std::int64_t>(config_.timeMs) * 1000;
    g.active = std::abs(start) > 1.0e-9;
    return before != g.offset;
}

bool Portamento::jumpTo(int ch, int note) {
    if (ch < 0 || ch > 2) return false;
    auto& g = glides_[static_cast<std::size_t>(ch)];
    const double before = g.offset;
    g.lastNote = note;
    g.active = false;
    g.startOffset = 0.0;
    g.offset = 0.0;
    return before != g.offset;
}

std::array<bool, 3> Portamento::advance(std::int64_t nowUs) {
    std::array<bool, 3> changed{{false, false, false}};
    for (std::size_t ch = 0; ch < glides_.size(); ++ch) {
        auto& g = glides_[ch];
        if (!g.active) continue;
        const double next = offsetAt(g, nowUs);
        if (next == 0.0) g.active = false;
        if (next != g.offset) {
            g.offset = next;
            changed[ch] = true;
        }
    }
    return changed;
}

double Portamento::offsetSemitones(int ch) const {
    if (ch < 0 || ch > 2) return 0.0;
    return glides_[static_cast<std::size_t>(ch)].offset;
}

bool Portamento::gliding(int ch) const {
    if (ch < 0 || ch > 2) return false;
    return glides_[static_cast<std::size_t>(ch)].active;
}

int Portamento::lastNote(int ch) const {
    if (ch < 0 || ch > 2) return -1;
    return glides_[static_cast<std::size_t>(ch)].lastNote;
}

void Portamento::reset() {
    for (auto& g : glides_) g = Glide{};
}

void Portamento::resetChannel(int ch) {
    if (ch < 0 || ch > 2) return;
    glides_[static_cast<std::size_t>(ch)] = Glide{};
}

} // namespace silveton
