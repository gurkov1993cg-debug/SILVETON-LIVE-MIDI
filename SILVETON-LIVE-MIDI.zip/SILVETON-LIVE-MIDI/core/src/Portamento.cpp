#include "silveton/Portamento.h"
#include <algorithm>

namespace silveton {

void Portamento::setConfig(const Config& config) {
    config_ = config;
    config_.time = std::clamp(config_.time, 0, 127);
}

void Portamento::appendForAllUpper(std::vector<MidiMessage>& out, int controller, int value) {
    for (int ch = 0; ch < 3; ++ch) out.push_back(MidiMessage::controlChange(ch, controller, value));
}

std::vector<MidiMessage> Portamento::setEnabled(bool enabled) {
    config_.enabled = enabled;
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) {
        // When enabling, TIME is deliberately before ON on each exact channel.
        if (enabled) out.push_back(MidiMessage::controlChange(ch, 5, config_.time));
        out.push_back(MidiMessage::controlChange(ch, 65, enabled ? 127 : 0));
    }
    return out;
}

std::vector<MidiMessage> Portamento::setTime(int value) {
    config_.time = std::clamp(value, 0, 127);
    // Editing TIME while Portamento is OFF must not alter the PA600.
    // The value is cached and emitted before CC65 when the user enables it.
    if (!config_.enabled) return {};
    std::vector<MidiMessage> out;
    appendForAllUpper(out, 5, config_.time);
    return out;
}

std::vector<MidiMessage> Portamento::sync() const {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 3; ++ch) {
        out.push_back(MidiMessage::controlChange(ch, 5, config_.time));
        out.push_back(MidiMessage::controlChange(ch, 65, config_.enabled ? 127 : 0));
    }
    return out;
}

std::vector<MidiMessage> Portamento::syncForChannel(int ch) const {
    if (ch < 0 || ch > 2) return {};
    return {
        MidiMessage::controlChange(ch, 5, config_.time),
        MidiMessage::controlChange(ch, 65, config_.enabled ? 127 : 0)
    };
}

} // namespace silveton
