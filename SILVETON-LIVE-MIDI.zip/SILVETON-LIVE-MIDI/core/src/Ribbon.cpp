#include "silveton/Ribbon.h"
#include <cmath>

namespace silveton {

namespace {
constexpr double kCenterDeadZone = 0.02;     // absolute mode only
constexpr double kMaxDtSeconds = 0.010;      // robust after scheduler stalls
constexpr std::int64_t kMinUpdateUs = 2000;  // <= 500 Hz
constexpr double kSnapSemitones = 0.0005;
constexpr double kSnapVelocity = 0.003;
constexpr std::int64_t kTapMaxUs = 250000;   // HOLD: short tap resets
constexpr double kTapMaxTravel = 0.03;
} // namespace

void Ribbon::setSettings(const Settings& settings) {
    s_ = settings;
    s_.rangeSemitones = std::clamp(s_.rangeSemitones, 1, 24);
    s_.sensitivity = std::clamp(s_.sensitivity, 0.25, 2.0);
    s_.smoothMs = std::clamp(s_.smoothMs, 0, 200);
    s_.returnMs = std::clamp(s_.returnMs, 0, 2000);
    s_.roundRateMs = std::clamp(s_.roundRateMs, 1, 2000);
    if (!s_.rounding) roundOffset_ = 0.0;
}

double Ribbon::shape(double x) const {
    const double a = std::min(std::abs(x), 1.0);
    const double gamma = 1.0 / std::sqrt(s_.sensitivity); // 2.0 .. ~0.707
    return std::copysign(std::pow(a, gamma), x);
}

double Ribbon::absoluteTarget(double position) const {
    const double pos = std::clamp(position, -1.0, 1.0);
    const double a = std::abs(pos);
    if (a <= kCenterDeadZone) return 0.0;
    const double n = (a - kCenterDeadZone) / (1.0 - kCenterDeadZone);
    return shape(std::copysign(n, pos)) * static_cast<double>(s_.rangeSemitones);
}

void Ribbon::touchDown(double raw, std::int64_t nowUs) {
    const double pos = positionOf(std::clamp(raw, -1.0, 1.0));
    touching_ = true;
    downPos_ = pos;
    maxTravel_ = 0.0;
    downUs_ = nowUs;
    if (lastUs_ == 0) lastUs_ = nowUs;
    const double range = static_cast<double>(s_.rangeSemitones);
    if (s_.mode == Mode::Relative) {
        anchorPos_ = pos;
        // Continue from a held pitch (HOLD); otherwise start from 0.
        anchorValue_ = (s_.release == Release::Hold) ? std::clamp(target_, -range, range) : 0.0;
        target_ = anchorValue_;
    } else {
        target_ = absoluteTarget(pos);
        if (s_.rounding && s_.roundInitial) {
            // Land exactly on a semitone.
            roundOffset_ = std::round(target_) - target_;
            average_ = target_;
        }
    }
}

void Ribbon::touchMove(double raw, std::int64_t nowUs) {
    if (!touching_) {
        touchDown(raw, nowUs);
        return;
    }
    const double pos = positionOf(std::clamp(raw, -1.0, 1.0));
    maxTravel_ = std::max(maxTravel_, std::abs(pos - downPos_));
    const double range = static_cast<double>(s_.rangeSemitones);
    if (s_.mode == Mode::Relative) {
        // Half the strip width away from the touch point = full range.
        const double delta = std::clamp(pos - anchorPos_, -1.0, 1.0);
        target_ = std::clamp(anchorValue_ + shape(delta) * range, -range, range);
    } else {
        target_ = absoluteTarget(pos);
    }
}

void Ribbon::touchUp(std::int64_t nowUs) {
    if (!touching_) return;
    touching_ = false;
    if (s_.release == Release::Return) {
        target_ = 0.0;
        return;
    }
    // HOLD: keep the pitch; a short tap without movement clears it.
    const bool tap = (nowUs - downUs_) <= kTapMaxUs && maxTravel_ <= kTapMaxTravel;
    if (tap) target_ = 0.0;
    else target_ = s_.rounding ? output_ : target_;
}

void Ribbon::setTarget(double normalizedPosition, std::int64_t nowUs) {
    if (normalizedPosition == 0.0) {
        if (touching_) touchUp(nowUs);
        else target_ = (s_.release == Release::Return) ? 0.0 : target_;
        return;
    }
    if (!touching_) {
        // Legacy callers feed absolute positions.
        const Mode saved = s_.mode;
        s_.mode = Mode::Absolute;
        touchDown(normalizedPosition, nowUs);
        s_.mode = saved;
        if (saved == Mode::Absolute) return;
        // In relative mode a legacy caller still expects position -> pitch.
        target_ = absoluteTarget(positionOf(normalizedPosition));
        anchorPos_ = 0.0;
        anchorValue_ = 0.0;
        return;
    }
    if (s_.mode == Mode::Relative && anchorPos_ == 0.0 && anchorValue_ == 0.0) {
        target_ = absoluteTarget(positionOf(std::clamp(normalizedPosition, -1.0, 1.0)));
        return;
    }
    touchMove(normalizedPosition, nowUs);
}

Ribbon::Update Ribbon::advance(std::int64_t nowUs) {
    if (lastUs_ == 0) {
        lastUs_ = nowUs;
        return {};
    }
    const std::int64_t deltaUs = nowUs - lastUs_;
    if (deltaUs < kMinUpdateUs) return {};
    lastUs_ = nowUs;
    const double dt = std::min(static_cast<double>(deltaUs) * 1.0e-6, kMaxDtSeconds);

    // Critically damped follow (no overshoot). Touching uses the smooth time,
    // springing back uses the return time.
    const bool returning = !touching_ && target_ == 0.0;
    const double smoothSec = std::max(0.0005, (returning ? s_.returnMs : s_.smoothMs) * 1.0e-3 / 3.0);
    if ((returning ? s_.returnMs : s_.smoothMs) == 0) {
        value_ = target_;
        velocity_ = 0.0;
    } else {
        const double omega = 2.0 / smoothSec;
        const double x = omega * dt;
        const double expTerm = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x);
        const double change = value_ - target_;
        const double temp = (velocity_ + omega * change) * dt;
        velocity_ = (velocity_ - omega * temp) * expTerm;
        value_ = target_ + (change + temp) * expTerm;
    }
    const double range = static_cast<double>(s_.rangeSemitones);
    value_ = std::clamp(value_, -range, range);
    if (std::abs(target_ - value_) < kSnapSemitones && std::abs(velocity_) < kSnapVelocity) {
        value_ = target_;
        velocity_ = 0.0;
    }

    // Rounding: steer the averaged position onto the semitone grid; the
    // correction is slow so vibrato and slides stay expressive.
    if (s_.rounding && (touching_ || target_ != 0.0)) {
        const double rate = s_.roundRateMs * 1.0e-3;
        const double avgK = 1.0 - std::exp(-dt / std::max(0.02, rate));
        average_ += (value_ - average_) * avgK;
        const double desired = std::round(average_) - average_;
        const double k = 1.0 - std::exp(-dt / rate);
        roundOffset_ += (desired - roundOffset_) * k;
    } else {
        // Fade the correction out together with the return to centre.
        roundOffset_ = (value_ == 0.0) ? 0.0 : roundOffset_ * 0.9;
        average_ = value_;
    }

    const double out = std::clamp(value_ + roundOffset_, -range, range);
    const double snapped = (std::abs(out) < kSnapSemitones && target_ == 0.0 && !touching_) ? 0.0 : out;
    output_ = snapped;
    return {true, output_};
}

void Ribbon::reset() {
    touching_ = false;
    anchorPos_ = anchorValue_ = downPos_ = maxTravel_ = 0.0;
    downUs_ = 0;
    target_ = value_ = velocity_ = average_ = roundOffset_ = output_ = 0.0;
    lastUs_ = 0;
}

} // namespace silveton
