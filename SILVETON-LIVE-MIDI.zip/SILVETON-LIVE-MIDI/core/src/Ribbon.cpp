#include "silveton/Ribbon.h"
#include <algorithm>
#include <cmath>

namespace silveton {

namespace {
constexpr double kCenterDeadZone = 0.008;       // prevents center chatter
constexpr double kTouchSmoothSeconds = 0.012;  // responsive but polished
constexpr double kReturnSmoothSeconds = 0.020; // softer release to center
constexpr double kMaxDtSeconds = 0.010;         // robust after scheduler stalls
constexpr std::int64_t kMinUpdateUs = 2000;      // <=500 Hz; smooth without MIDI flooding
constexpr double kSnapSemitones = 0.00035;
constexpr double kSnapVelocity = 0.003;
}

double Ribbon::shapedPosition(double normalizedPosition) const {
    const double pos = std::clamp(normalizedPosition, -1.0, 1.0);
    const double a = std::abs(pos);
    if (a <= kCenterDeadZone) return 0.0;

    // Remove the center dead-zone, then use a bounded response curve.
    // Sensitivity changes the feel around center without changing end range.
    const double n = (a - kCenterDeadZone) / (1.0 - kCenterDeadZone);
    const double gamma = 1.0 / std::sqrt(sensitivity_); // 2.0 .. ~0.707
    const double shaped = std::pow(std::clamp(n, 0.0, 1.0), gamma);
    return std::copysign(shaped, pos);
}

double Ribbon::targetSemitoneOffset() const {
    return shapedPosition(targetPosition_) * static_cast<double>(rangeSemitones_);
}

void Ribbon::setTarget(double normalizedPosition, std::int64_t nowUs) {
    targetPosition_ = std::clamp(normalizedPosition, -1.0, 1.0);
    if (lastUpdateUs_ == 0) lastUpdateUs_ = nowUs;
}

Ribbon::Update Ribbon::advance(std::int64_t nowUs) {
    if (lastUpdateUs_ == 0) {
        lastUpdateUs_ = nowUs;
        return {};
    }

    const std::int64_t deltaUs = nowUs - lastUpdateUs_;
    if (deltaUs < kMinUpdateUs) return {};
    lastUpdateUs_ = nowUs;

    const double dt = std::min(static_cast<double>(deltaUs) * 1.0e-6, kMaxDtSeconds);
    const double target = targetSemitoneOffset();
    const double smoothTime = (std::abs(target) < kSnapSemitones)
        ? kReturnSmoothSeconds : kTouchSmoothSeconds;

    // Stable critically-damped SmoothDamp integration. It has no overshoot,
    // gives a soft "instrument" glide and stays timestep-independent enough
    // for Android's non-hard-realtime MIDI scheduler.
    const double omega = 2.0 / smoothTime;
    const double x = omega * dt;
    const double expTerm = 1.0 / (1.0 + x + 0.48 * x * x + 0.235 * x * x * x);
    const double change = currentSemitones_ - target;
    const double temp = (velocitySemitonesPerSecond_ + omega * change) * dt;
    velocitySemitonesPerSecond_ =
        (velocitySemitonesPerSecond_ - omega * temp) * expTerm;
    currentSemitones_ = target + (change + temp) * expTerm;

    // Never exceed the configured musical range, even after a scheduler stall.
    const double maxRange = static_cast<double>(rangeSemitones_);
    currentSemitones_ = std::clamp(currentSemitones_, -maxRange, maxRange);

    if (std::abs(target - currentSemitones_) < kSnapSemitones &&
        std::abs(velocitySemitonesPerSecond_) < kSnapVelocity) {
        currentSemitones_ = target;
        velocitySemitonesPerSecond_ = 0.0;
    }

    return {true, currentSemitones_};
}

void Ribbon::reset() {
    targetPosition_ = 0.0;
    currentSemitones_ = 0.0;
    velocitySemitonesPerSecond_ = 0.0;
    lastUpdateUs_ = 0;
}

} // namespace silveton
