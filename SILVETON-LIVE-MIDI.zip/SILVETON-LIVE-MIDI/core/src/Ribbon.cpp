#include "silveton/Ribbon.h"
#include <algorithm>
#include <cmath>

namespace silveton {

void Ribbon::setSensitivity(double sensitivity) {
    sensitivity_ = std::clamp(sensitivity, 0.25, 2.0);
}

std::vector<MidiMessage> Ribbon::makePitchBends(double normalizedPosition) const {
    const double scaled = std::clamp(normalizedPosition * sensitivity_, -1.0, 1.0);
    int bend = int(std::lround(8192.0 + scaled * 8191.0));
    bend = std::clamp(bend, 0, 16383);

    std::vector<MidiMessage> out;
    out.reserve(3);
    out.push_back(MidiMessage::pitchBend(0, bend));
    out.push_back(MidiMessage::pitchBend(1, bend));
    out.push_back(MidiMessage::pitchBend(2, bend));
    return out;
}

} // namespace silveton
