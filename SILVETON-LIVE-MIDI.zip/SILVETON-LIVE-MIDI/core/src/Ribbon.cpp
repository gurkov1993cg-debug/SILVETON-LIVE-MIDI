#include "silveton/Ribbon.h"
#include <algorithm>

namespace silveton {

double Ribbon::semitoneOffset(double normalizedPosition) const {
    const double pos = std::clamp(normalizedPosition, -1.0, 1.0);
    return pos * (2.0 * sensitivity_);
}

} // namespace silveton
