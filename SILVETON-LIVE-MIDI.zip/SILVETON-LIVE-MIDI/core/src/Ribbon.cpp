#include "silveton/Ribbon.h"
#include <algorithm>
#include <cmath>

namespace silveton {

double Ribbon::semitoneOffset(double normalizedPosition) const {
    const double pos = std::clamp(normalizedPosition, -1.0, 1.0);
    if (pos == 0.0) return 0.0;

    // Sensitivity is a response curve, not a pitch-range multiplier.
    // >1.0 reacts faster around the center; <1.0 reacts more gently.
    const double exponent = 1.0 / sensitivity_;
    const double shaped = std::pow(std::abs(pos), exponent);
    return std::copysign(shaped * double(rangeSemitones_), pos);
}

} // namespace silveton
