#pragma once
#include <array>

namespace silveton {

struct KorgProfile {
    // User-locked defaults. MIDI channels are zero-based internally.
    static constexpr std::array<int, 3> upperChannels{{0, 1, 2}}; // Upper 1/2/3 -> MIDI 1/2/3
    static constexpr int pitchBendRangeSemitones = 12;

    static constexpr bool isUpperChannel(int zeroBasedChannel) {
        return zeroBasedChannel == upperChannels[0] ||
               zeroBasedChannel == upperChannels[1] ||
               zeroBasedChannel == upperChannels[2];
    }
};

} // namespace silveton
