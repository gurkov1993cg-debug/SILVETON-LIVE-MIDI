#pragma once
#include "silveton/MidiTypes.h"
#include <vector>

namespace silveton {

class Ribbon {
public:
    void setSensitivity(double sensitivity);
    double sensitivity() const { return sensitivity_; }

    std::vector<MidiMessage> makePitchBends(double normalizedPosition) const;

private:
    double sensitivity_{1.0};
};

} // namespace silveton
