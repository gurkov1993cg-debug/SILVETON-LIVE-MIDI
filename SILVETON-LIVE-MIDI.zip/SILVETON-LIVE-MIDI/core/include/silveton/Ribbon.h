#pragma once
#include <algorithm>

namespace silveton {

class Ribbon {
public:
    void setSensitivity(double sensitivity) { sensitivity_ = std::clamp(sensitivity, 0.25, 2.0); }
    double sensitivity() const { return sensitivity_; }

    // Ribbon is an independent pitch source for Upper 2 + Upper 3 only.
    // At sensitivity 1.0 the full travel is +/-2 semitones.
    double semitoneOffset(double normalizedPosition) const;

private:
    double sensitivity_{1.0};
};

} // namespace silveton
