#pragma once
#include <algorithm>
#include <cstdint>

namespace silveton {

// High-resolution performance ribbon engine.
// The finger position is a target. The native engine turns that target into a
// continuous, critically-damped trajectory which is later rendered as 14-bit
// MIDI Pitch Bend by PitchCoordinator. This keeps the app-defined semitone
// range exact while avoiding the raw/steppy "joystick" feel.
class Ribbon {
public:
    struct Update {
        bool valid{false};
        double semitones{0.0};
    };

    void setSensitivity(double sensitivity) { sensitivity_ = std::clamp(sensitivity, 0.25, 2.0); }
    double sensitivity() const { return sensitivity_; }

    void setRangeSemitones(int semitones) { rangeSemitones_ = std::clamp(semitones, 1, 12); }
    int rangeSemitones() const { return rangeSemitones_; }

    // Set a new finger target in [-1, +1]. No MIDI is emitted here; advance()
    // produces the smoothed high-resolution trajectory on the realtime poller.
    void setTarget(double normalizedPosition, std::int64_t nowUs);
    Update advance(std::int64_t nowUs);
    void reset();

    // Public for deterministic tests and UI calibration.
    double targetSemitoneOffset() const;
    double currentSemitoneOffset() const { return currentSemitones_; }

private:
    double shapedPosition(double normalizedPosition) const;

    double sensitivity_{1.0};
    int rangeSemitones_{2};
    double targetPosition_{0.0};
    double currentSemitones_{0.0};
    double velocitySemitonesPerSecond_{0.0};
    std::int64_t lastUpdateUs_{0};
};

} // namespace silveton
