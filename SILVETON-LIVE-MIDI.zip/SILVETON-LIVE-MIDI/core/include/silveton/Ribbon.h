#pragma once
#include <algorithm>
#include <cstdint>

namespace silveton {

// RIBBON — independent performance-ribbon module.
//
// Modelled on professional ribbon controllers:
//  * Mode ABSOLUTE: the finger position on the strip IS the pitch offset
//    (centre = 0), with a centre dead zone.            (Doepfer R2M "absolute")
//  * Mode RELATIVE: the touch point is zero; sliding away from it bends, so the
//    pitch never jumps when the finger lands.        (R2M "relative"/Trautonium)
//  * Release RETURN: springs back to 0 with its own return time.
//    Release HOLD: the pitch stays after lifting (Korg "Lock"); a short tap
//    without movement returns it to 0.
//  * Rounding (Haken Continuum style): the pitch drifts to the nearest
//    semitone at ROUND RATE, computed from the averaged finger position so
//    vibrato around a note is preserved; ROUND INITIAL snaps on first touch.
//  * Curve (sensitivity), direction invert, movement smoothing.
// The module only produces a smoothed semitone value; where it goes (Pitch
// Bend lane or RPN tuning) is decided by the router.
class Ribbon {
public:
    enum class Mode : int { Absolute = 0, Relative = 1 };
    enum class Release : int { Return = 0, Hold = 1 };
    enum class Output : int { PitchBend = 0, Tuning = 1 };

    struct Settings {
        Mode mode{Mode::Relative};
        Release release{Release::Return};
        Output output{Output::PitchBend};
        int rangeSemitones{2};      // 1..24
        double sensitivity{1.0};    // 0.25..2.0 response curve (end range unchanged)
        bool invert{false};
        int smoothMs{36};           // finger-follow settle time, 0..200
        int returnMs{60};           // spring-back settle time, 0..2000
        bool rounding{false};
        int roundRateMs{150};       // 1..2000 time constant of drift to the semitone
        bool roundInitial{false};
    };

    struct Update {
        bool valid{false};
        double semitones{0.0};
    };

    const Settings& settings() const { return s_; }
    void setSettings(const Settings& settings);

    // Legacy/simple controls (kept for compatibility).
    void setSensitivity(double sensitivity) { s_.sensitivity = std::clamp(sensitivity, 0.25, 2.0); }
    double sensitivity() const { return s_.sensitivity; }
    void setRangeSemitones(int semitones) { s_.rangeSemitones = std::clamp(semitones, 1, 24); }
    int rangeSemitones() const { return s_.rangeSemitones; }

    // Touch interface. position: -1 (left end) .. +1 (right end) of the strip.
    void touchDown(double position, std::int64_t nowUs);
    void touchMove(double position, std::int64_t nowUs);
    void touchUp(std::int64_t nowUs);
    bool touching() const { return touching_; }

    // Legacy absolute-style target: a value of exactly 0 is treated as release.
    void setTarget(double normalizedPosition, std::int64_t nowUs);

    Update advance(std::int64_t nowUs);
    void reset();

    double targetSemitoneOffset() const { return target_; }
    double currentSemitoneOffset() const { return output_; }
    bool active() const { return target_ != 0.0 || output_ != 0.0 || touching_; }

private:
    double shape(double x) const;                 // curve for a -1..1 value
    double absoluteTarget(double position) const;
    double positionOf(double raw) const { return s_.invert ? -raw : raw; }

    Settings s_{};
    bool touching_{false};
    double anchorPos_{0.0};
    double anchorValue_{0.0};
    double downPos_{0.0};
    double maxTravel_{0.0};
    std::int64_t downUs_{0};

    double target_{0.0};       // requested semitones (before smoothing)
    double value_{0.0};        // smoothed semitones
    double velocity_{0.0};
    double average_{0.0};      // slow average for rounding
    double roundOffset_{0.0};
    double output_{0.0};
    std::int64_t lastUs_{0};
};

} // namespace silveton
