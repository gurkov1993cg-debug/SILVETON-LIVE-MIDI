#pragma once
#include <algorithm>

namespace silveton {

class Ribbon {
public:
    void setSensitivity(double sensitivity) { sensitivity_ = std::clamp(sensitivity, 0.25, 2.0); }
    double sensitivity() const { return sensitivity_; }

    // Manual full-travel range, independent from sensitivity.
    // The center is 0; the left/right edges are -range/+range semitones.
    void setRangeSemitones(int semitones) { rangeSemitones_ = std::clamp(semitones, 1, 12); }
    int rangeSemitones() const { return rangeSemitones_; }

    // Sensitivity shapes finger response only; it never changes the end-point range.
    double semitoneOffset(double normalizedPosition) const;

private:
    double sensitivity_{1.0};
    int rangeSemitones_{2};
};

} // namespace silveton
