#pragma once
#include "silveton/MidiRouter.h"
#include <cstdint>
#include <vector>

namespace silveton {

// Single native entry point used by JNI.  It owns the one authoritative
// MidiRouter/state graph; there is no parallel MIDI engine.
class NativeMidiEngine {
public:
    NativeMidiEngine() {
        Portamento::Config cfg;
        cfg.enabled = false;
        cfg.timeMs = 120;
        router_.setPortamentoConfig(cfg);
        router_.ribbon().setSensitivity(1.0);
        router_.ribbon().setRangeSemitones(2);
        router_.third().setEnabled(false);
    }

    std::vector<MidiMessage> handleMidiIn(std::uint8_t status,
                                          std::uint8_t data1,
                                          std::uint8_t data2,
                                          std::uint8_t size,
                                          std::int64_t nowUs) {
        // MidiMessage::isNoteOff() treats 0x9n NN 00 as Note Off.  Keep the
        // original status byte so transparent routing remains byte-correct.
        MidiMessage message{status,
                            static_cast<std::uint8_t>(data1 & 0x7F),
                            static_cast<std::uint8_t>(data2 & 0x7F),
                            size};
        return router_.process(message, nowUs);
    }

    MidiRouter& router() { return router_; }
    const MidiRouter& router() const { return router_; }

private:
    MidiRouter router_{};
};

} // namespace silveton
