#pragma once
#include "silveton/KorgProfile.h"
#include "silveton/PitchCoordinator.h"
#include "silveton/Portamento.h"
#include "silveton/Ribbon.h"
#include "silveton/ThirdModule.h"
#include <array>
#include <cstdint>
#include <utility>
#include <vector>

namespace silveton {

class MidiRouter {
public:
    MidiRouter();

    Portamento& portamento() { return portamento_; }
    const Portamento& portamento() const { return portamento_; }
    void setPortamentoConfig(const Portamento::Config& config) { portamento_.setConfig(config); }

    ThirdModule& third() { return third_; }
    const ThirdModule& third() const { return third_; }

    Ribbon& ribbon() { return ribbon_; }
    const Ribbon& ribbon() const { return ribbon_; }

    // Keyboard Local Control mode.
    //  keyboardLocal == false (PA600 Local Control OFF): the app is the bridge.
    //    Upper notes/controls are returned to the PA600 so it can sound them.
    //  keyboardLocal == true  (PA600 Local Control ON): the PA600 already plays
    //    its own keybed. The app NEVER echoes keyboard traffic back (that would
    //    double every note). It only emits what it generates: TERCA notes on
    //    U3, Portamento CCs and Ribbon Pitch Bend.
    void setKeyboardLocal(bool keyboardLocal);
    bool keyboardLocal() const { return keyboardLocal_; }
    // Upper whose keys drive TERCA: U3 itself in Local OFF, U1 in Local ON.
    int tercaSource() const { return keyboardLocal_ ? 0 : 2; }

    std::vector<MidiMessage> process(const MidiMessage& message, std::int64_t nowUs);

    // MONO legato for U1/U2/U3 (and therefore the TERCA line): a new key ends
    // the previous one; releasing it returns to the most recent held key.
    void setMonoEnabled(bool enabled);
    bool monoEnabled() const { return monoEnabled_; }
    std::vector<MidiMessage> poll(std::int64_t nowUs);
    std::vector<MidiMessage> panic();

    std::vector<MidiMessage> setPortamentoEnabled(bool enabled);
    std::vector<MidiMessage> setPortamentoTimeMs(int ms);
    std::vector<MidiMessage> syncPortamento() const;
    std::vector<MidiMessage> syncPortamentoChannel(int ch) const;
    std::vector<MidiMessage> syncPitchChannel(int ch);
    std::vector<MidiMessage> setPitchTransportEnabled(bool enabled);
    bool pitchTransportEnabled() const { return pitchTransportEnabled_; }

    std::vector<MidiMessage> setThirdEnabled(bool enabled);
    std::vector<MidiMessage> setThirdScanning(bool scanning);
    int thirdScanResult() const { return third_.scanResultCode(); }
    bool thirdScanning() const { return third_.scanning(); }

    std::vector<MidiMessage> ribbonMove(double normalizedPosition, std::int64_t nowUs);

    int activeNoteRefs(int ch, int note) const;
    int lastNote(int ch) const;

private:
    void append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const;
    void trackOutgoing(const MidiMessage& message);
    void trackOutgoing(const std::vector<MidiMessage>& messages);
    std::vector<MidiMessage> releaseActiveChannel(int ch, bool addAllNotesOff);
    std::vector<MidiMessage> releaseAllActive(bool addAllNotesOff);
    void clearActiveChannel(int ch);
    void startGlide(std::vector<MidiMessage>& out, int ch, int note, std::int64_t nowUs);
    void jumpGlide(std::vector<MidiMessage>& out, int ch, int note);
    struct MonoEvent { MidiMessage message; bool isReturn; };
    std::vector<MonoEvent> monoTransform(int ch, const MidiMessage& message);
    std::vector<MidiMessage> processNote(const MidiMessage& message, std::int64_t nowUs, bool isReturn);
    void clearMono(int ch);
    struct MonoState {
        std::vector<std::pair<int, int>> held; // (note, velocity) in press order
        int sounding{-1};
    };
    void syncU3Ownership(std::vector<MidiMessage>& out);
    // Local ON adaptive Pitch Bend range: the keyboard's own wheel shares the
    // Pitch Bend lane, so the range stays at +/-2 (wheel feels normal) and is
    // raised to +/-12 only while a wide glide or a >2 Ribbon needs it.
    void applyLocalRange(std::vector<MidiMessage>& out, int semitones);
    static void appendRpnRange(std::vector<MidiMessage>& out, int ch, int semitones);
    int localRangeNeeded() const;

    Portamento portamento_{};
    ThirdModule third_{};
    Ribbon ribbon_{};
    PitchCoordinator pitch_{};
    bool pitchTransportEnabled_{false};
    bool keyboardLocal_{false};
    bool u3Owned_{false};
    bool monoEnabled_{false};
    std::array<MonoState, 3> mono_{};
    int localRange_{2};
    std::int64_t lastRangeNeedUs_{0};
public:
    static constexpr int kLocalBaseRange = 2;
    static constexpr int kWideRange = 12;
    static constexpr std::int64_t kRangeReleaseUs = 150000;
    int localRange() const { return localRange_; }
private:

    std::array<std::array<std::uint16_t, 128>, 3> activeRefs_{};
    std::array<int, 3> lastNotes_{{-1, -1, -1}};
};

} // namespace silveton
