#pragma once
#include "silveton/KorgProfile.h"
#include "silveton/Portamento.h"
#include "silveton/Ribbon.h"
#include "silveton/ThirdModule.h"
#include <cstdint>
#include <vector>

namespace silveton {

class MidiRouter {
public:
    Portamento& portamento() { return portamento_; }
    const Portamento& portamento() const { return portamento_; }

    ThirdModule& third() { return third_; }
    const ThirdModule& third() const { return third_; }

    Ribbon& ribbon() { return ribbon_; }
    const Ribbon& ribbon() const { return ribbon_; }

    std::vector<MidiMessage> process(const MidiMessage& message, std::int64_t nowUs);
    std::vector<MidiMessage> poll(std::int64_t nowUs);
    std::vector<MidiMessage> panic();

    std::vector<MidiMessage> setPortamentoEnabled(bool enabled);
    std::vector<MidiMessage> setThirdEnabled(bool enabled);
    std::vector<MidiMessage> startThirdScan();
    int thirdScanResult() const { return third_.detectedInterval(); }
    bool thirdScanning() const { return third_.scanning(); }

    std::vector<MidiMessage> ribbonMove(double normalizedPosition, std::int64_t nowUs);

private:
    static bool isMusicalUpperMessage(const MidiMessage& m);
    void append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const;

    Portamento portamento_{};
    ThirdModule third_{};
    Ribbon ribbon_{};
};

} // namespace silveton
