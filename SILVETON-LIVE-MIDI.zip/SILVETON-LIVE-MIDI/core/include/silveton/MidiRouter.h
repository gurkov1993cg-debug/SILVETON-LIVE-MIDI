#pragma once
#include "silveton/KorgProfile.h"
#include "silveton/Portamento.h"
#include <cstdint>
#include <vector>

namespace silveton {

class MidiRouter {
public:
    Portamento& portamento() { return portamento_; }
    const Portamento& portamento() const { return portamento_; }

    std::vector<MidiMessage> process(const MidiMessage& message, std::int64_t nowUs);
    std::vector<MidiMessage> poll(std::int64_t nowUs);
    std::vector<MidiMessage> panic();

private:
    Portamento portamento_{};
};

} // namespace silveton
