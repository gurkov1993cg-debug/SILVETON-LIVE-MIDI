#pragma once
#include "silveton/KorgProfile.h"
#include "silveton/PitchCoordinator.h"
#include "silveton/Portamento.h"
#include "silveton/Ribbon.h"
#include "silveton/ThirdModule.h"
#include <array>
#include <cstdint>
#include <vector>

namespace silveton {

class MidiRouter {
public:
    MidiRouter();

    Portamento& portamento() { return portamento_; }
    const Portamento& portamento() const { return portamento_; }
    void setPortamentoConfig(const Portamento::Config& config) { portamento_.setConfig(config); }

    ThirdModule& third() { return third_; }
    const ThirdModule& third() const { return third_; }

    Ribbon& ribbon() { return ribbon_; }
    const Ribbon& ribbon() const { return ribbon_; }

    // Keyboard Local Control mode.
    //  keyboardLocal == false (PA600 Local Control OFF): the app is the bridge.
    //    Upper notes/controls are returned to the PA600 so it can sound them.
    //  keyboardLocal == true  (PA600 Local Control ON): the PA600 already plays
    //    its own keybed. The app NEVER echoes keyboard traffic back (that would
    //    double every note). It only emits what it generates: TERCA notes on
    //    U3, Portamento CCs and Ribbon Pitch Bend.
    void setKeyboardLocal(bool keyboardLocal) { keyboardLocal_ = keyboardLocal; }
    bool keyboardLocal() const { return keyboardLocal_; }

    std::vector<MidiMessage> process(const MidiMessage& message, std::int64_t nowUs);
    std::vector<MidiMessage> poll(std::int64_t nowUs);
    std::vector<MidiMessage> panic();

    std::vector<MidiMessage> setPortamentoEnabled(bool enabled);
    std::vector<MidiMessage> setPortamentoTime(int value);
    std::vector<MidiMessage> syncPortamento() const;
    std::vector<MidiMessage> syncPortamentoChannel(int ch) const;
    std::vector<MidiMessage> syncPitchChannel(int ch);
    std::vector<MidiMessage> setPitchTransportEnabled(bool enabled);
    bool pitchTransportEnabled() const { return pitchTransportEnabled_; }

    std::vector<MidiMessage> setThirdEnabled(bool enabled);
    std::vector<MidiMessage> setThirdScanning(bool scanning);
    int thirdScanResult() const { return third_.scanResultCode(); }
    bool thirdScanning() const { return third_.scanning(); }

    std::vector<MidiMessage> ribbonMove(double normalizedPosition, std::int64_t nowUs);

    int activeNoteRefs(int ch, int note) const;
    int lastNote(int ch) const;

private:
    void append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const;
    void trackOutgoing(const MidiMessage& message);
    void trackOutgoing(const std::vector<MidiMessage>& messages);
    std::vector<MidiMessage> releaseActiveChannel(int ch, bool addAllNotesOff);
    std::vector<MidiMessage> releaseAllActive(bool addAllNotesOff);
    void clearActiveChannel(int ch);

    Portamento portamento_{};
    ThirdModule third_{};
    Ribbon ribbon_{};
    PitchCoordinator pitch_{};
    bool pitchTransportEnabled_{false};
    bool keyboardLocal_{false};

    std::array<std::array<std::uint16_t, 128>, 3> activeRefs_{};
    std::array<int, 3> lastNotes_{{-1, -1, -1}};
};

} // namespace silveton
