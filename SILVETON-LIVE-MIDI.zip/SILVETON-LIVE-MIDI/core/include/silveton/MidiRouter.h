#pragma once
#include "silveton/KorgProfile.h"
#include "silveton/PitchCoordinator.h"
#include "silveton/Portamento.h"
#include "silveton/Ribbon.h"
#include "silveton/ThirdModule.h"
#include <cstdint>
#include <vector>

namespace silveton {

class MidiRouter {
public:
    Portamento& portamento() { return portamento_; }
    const Portamento& portamento() const { return portamento_; }
    void setPortamentoConfig(const Portamento::Config& config) { portamento_.setConfig(config); }

    ThirdModule& third() { return third_; }
    const ThirdModule& third() const { return third_; }

    Ribbon& ribbon() { return ribbon_; }
    const Ribbon& ribbon() const { return ribbon_; }

    std::vector<MidiMessage> process(const MidiMessage& message, std::int64_t nowUs);
    std::vector<MidiMessage> poll(std::int64_t nowUs);
    std::vector<MidiMessage> panic();

    // Native Pa600 portamento control. No generated pitch glide is involved.
    std::vector<MidiMessage> setPortamentoEnabled(bool enabled);
    std::vector<MidiMessage> setPortamentoTime(int value);
    std::vector<MidiMessage> syncPortamento() const;

    std::vector<MidiMessage> setThirdEnabled(bool enabled);
    std::vector<MidiMessage> setThirdScanning(bool scanning);
    int thirdScanResult() const { return third_.scanResultCode(); }
    bool thirdScanning() const { return third_.scanning(); }

    std::vector<MidiMessage> ribbonMove(double normalizedPosition, std::int64_t nowUs);

private:
    void append(std::vector<MidiMessage>& dst, const std::vector<MidiMessage>& src) const;

    Portamento portamento_{};
    ThirdModule third_{};
    Ribbon ribbon_{};
    PitchCoordinator pitch_{};
};

} // namespace silveton
