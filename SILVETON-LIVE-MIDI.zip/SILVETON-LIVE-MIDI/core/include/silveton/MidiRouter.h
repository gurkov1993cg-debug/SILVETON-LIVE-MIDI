#pragma once
#include "silveton/KorgProfile.h"
#include "silveton/Portamento.h"
#include "silveton/Ribbon.h"
#include "silveton/ThirdModule.h"
#include <cstdint>
#include <vector>

namespace silveton {

class MidiRouter {
public:
    Portamento& portamento() { return portamento_; }
    const Portamento& portamento() const { return portamento_; }

    ThirdModule& third() { return third_; }
    const ThirdModule& third() const { return third_; }

    Ribbon& ribbon() { return ribbon_; }
    const Ribbon& ribbon() const { return ribbon_; }

    std::vector<MidiMessage> process(const MidiMessage& message, std::int64_t nowUs);
    std::vector<MidiMessage> poll(std::int64_t nowUs);
    std::vector<MidiMessage> panic();

    std::vector<MidiMessage> setThirdEnabled(bool enabled);
    void startThirdScan() { third_.startScan(); }
    int thirdScanResult() const { return third_.detectedInterval(); }

    std::vector<MidiMessage> ribbonMove(double normalizedPosition, std::int64_t nowUs);

private:
    std::vector<MidiMessage> filterThird(const std::vector<MidiMessage>& messages) const;

    Portamento portamento_{};
    ThirdModule third_{};
    Ribbon ribbon_{};
};

} // namespace silveton
