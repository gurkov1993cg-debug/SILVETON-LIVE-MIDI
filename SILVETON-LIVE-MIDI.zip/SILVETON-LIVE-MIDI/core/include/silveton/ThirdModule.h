#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <cstdint>
#include <vector>

namespace silveton {

class ThirdModule {
public:
    enum class ScaleMode : int { Major = 0, Minor = 1, Phrygian = 2, Hijaz = 3 };

    // The six SCAN cells from the TERCA specification. Each cell is a
    // three-note pitch-class shape relative to the tonic and is recognised
    // identically in all 12 tonalities, in any octave and any inversion.
    //   0,4,7 major third up      0,2,4 major third down
    //   0,3,7 minor third up      0,2,3 minor third down
    //   0,1,3 phrygian third up   0,1,4 hijaz third up
    enum class ScanCell : int {
        MajorUp = 0, MajorDown = 1, MinorUp = 2, MinorDown = 3, PhrygianUp = 4, HijazUp = 5
    };
    static constexpr int kScanCellCount = 6;
    enum class ScanState : int { Idle = 0, Scanning = 1, WaitingForRelease = 2, Locked = 3 };

    void setEnabled(bool enabled) { enabled_ = enabled; }
    bool enabled() const { return enabled_; }

    void startScan();
    void cancelScan();
    bool scanning() const { return scanState_ == ScanState::Scanning; }
    bool scanSilenceActive() const {
        return scanState_ == ScanState::Scanning || scanState_ == ScanState::WaitingForRelease;
    }
    ScanState scanState() const { return scanState_; }
    bool shouldMuteScanMessage(const MidiMessage& message) const;
    bool consumeCancelledScanRelease(const MidiMessage& message);

    bool tonalityValid() const { return tonalityValid_; }
    int rootPitchClass() const { return rootPitchClass_; }
    ScaleMode scaleMode() const { return scaleMode_; }
    ScanCell scanCell() const { return scanCell_; }
    // +1 = generated third above the played note, -1 = below.
    int direction() const { return direction_; }
    // 0 = no valid tonality / scanning. Otherwise 1 + root + 12 * ScanCell.
    int scanResultCode() const;
    std::uint32_t scanRevision() const { return scanRevision_; }

    // SCAN detects tonality from canonical Upper 1, while all Upper musical
    // scan packets are tracked so their releases cannot leak after the gate.
    void observeScan(const MidiMessage& message);

    // Fixed-tonality third: notes of the source Upper -> generated notes on U3.
    // Local OFF: source = U3 itself (its raw keys become its thirds, U1/U2 are
    // completely independent). Local ON: source = U1 (the only one sent).
    std::vector<MidiMessage> processSource(const MidiMessage& message, int sourceChannel);
    void clearGeneratedState();
    bool anySourceHeld() const;

    bool ownsRawUpper3() const { return enabled_ && tonalityValid_; }
    bool isRawUpper3Musical(const MidiMessage& message) const;

private:
    bool detectHeldTriad();
    int diatonicThirdFor(int sourceNote) const;
    bool pitchClassInScale(int relativePc, int& degree) const;
    bool anyScanMutedHeld() const;

    bool enabled_{false};
    bool tonalityValid_{false};
    int rootPitchClass_{0};
    ScaleMode scaleMode_{ScaleMode::Major};
    ScanCell scanCell_{ScanCell::MajorUp};
    int direction_{1};
    ScanState scanState_{ScanState::Idle};

    std::array<std::array<std::uint16_t, 128>, 3> scanMutedRefs_{};
    std::array<std::array<std::uint16_t, 128>, 3> cancelledReleaseRefs_{};
    std::uint32_t scanRevision_{0};

    std::array<std::uint16_t, 128> sourceRefs_{};
    std::array<int, 128> sourceHarmony_{};
    std::array<std::uint16_t, 128> harmonyRefs_{};
};

} // namespace silveton
