#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <cstdint>
#include <vector>

namespace silveton {

class ThirdModule {
public:
    void setEnabled(bool enabled) { enabled_ = enabled; }
    bool enabled() const { return enabled_; }

    void startScan();
    bool scanning() const { return scanning_; }
    int detectedInterval() const { return detectedInterval_; }

    // Observe canonical Upper streams while scanning.
    void observeScan(const MidiMessage& message, std::int64_t nowUs);

    // Real TERCA generator: Upper 1 input -> generated Upper 3 note.
    std::vector<MidiMessage> generateFromUpper1(const MidiMessage& message) const;

    // Physical/raw Upper 3 is owned by TERCA and must not pass through.
    bool isRawUpper3Musical(const MidiMessage& message) const;

private:
    bool enabled_{false};
    bool scanning_{false};
    int detectedInterval_{4}; // sensible default: major third up

    int lastUpper1Note_{-1};
    int lastUpper3Note_{-1};
    std::int64_t lastUpper1Us_{0};
    std::int64_t lastUpper3Us_{0};

    int scanFirstNote_{-1};
    std::int64_t scanFirstUs_{0};

    void acceptInterval(int interval);
    void tryDetectPair();
};

} // namespace silveton
