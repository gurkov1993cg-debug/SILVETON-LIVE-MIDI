#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <cstdint>
#include <vector>

namespace silveton {

class ThirdModule {
public:
    enum class ScaleMode : int { Major = 0, Minor = 1 };
    enum class ScanState : int { Idle = 0, Scanning = 1, WaitingForRelease = 2, Locked = 3 };

    void setEnabled(bool enabled) { enabled_ = enabled; }
    bool enabled() const { return enabled_; }

    void startScan();
    void cancelScan();
    bool scanning() const { return scanState_ == ScanState::Scanning; }
    bool scanSilenceActive() const {
        return scanState_ == ScanState::Scanning || scanState_ == ScanState::WaitingForRelease;
    }
    ScanState scanState() const { return scanState_; }
    bool shouldMuteScanMessage(const MidiMessage& message) const;
    bool consumeCancelledScanRelease(const MidiMessage& message);

    bool tonalityValid() const { return tonalityValid_; }
    int rootPitchClass() const { return rootPitchClass_; }
    ScaleMode scaleMode() const { return scaleMode_; }
    int scanResultCode() const;
    std::uint32_t scanRevision() const { return scanRevision_; }

    // SCAN detects tonality from canonical Upper 1, while all Upper musical
    // scan packets are tracked so their releases cannot leak after the gate.
    void observeScan(const MidiMessage& message);

    // Fixed-tonality diatonic third: Upper 1 input -> Upper 3 output.
    // Generated-note ownership/reference counting is internal to this module.
    std::vector<MidiMessage> processUpper1(const MidiMessage& message);
    void clearGeneratedState();

    bool ownsRawUpper3() const { return enabled_ && tonalityValid_; }
    bool isRawUpper3Musical(const MidiMessage& message) const;

private:
    bool detectHeldTriad();
    int diatonicThirdFor(int sourceNote) const;
    bool pitchClassInScale(int relativePc, int& degree) const;
    bool anyScanMutedHeld() const;

    bool enabled_{false};
    bool tonalityValid_{false};
    int rootPitchClass_{0};
    ScaleMode scaleMode_{ScaleMode::Major};
    ScanState scanState_{ScanState::Idle};

    std::array<bool, 128> scanHeldU1_{};
    std::array<std::array<std::uint16_t, 128>, 3> scanMutedRefs_{};
    std::array<std::array<std::uint16_t, 128>, 3> cancelledReleaseRefs_{};
    std::uint32_t scanRevision_{0};

    std::array<std::uint16_t, 128> sourceRefs_{};
    std::array<int, 128> sourceHarmony_{};
    std::array<std::uint16_t, 128> harmonyRefs_{};
};

} // namespace silveton
