#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <cstdint>
#include <vector>

namespace silveton {

class ThirdModule {
public:
    enum class ScaleMode : int { Major = 0, Minor = 1 };

    void setEnabled(bool enabled) { enabled_ = enabled; }
    bool enabled() const { return enabled_; }

    void startScan();
    void cancelScan();
    void toggleScan();
    bool scanning() const { return scanning_; }

    bool tonalityValid() const { return tonalityValid_; }
    int rootPitchClass() const { return rootPitchClass_; }
    ScaleMode scaleMode() const { return scaleMode_; }
    int scanResultCode() const;

    // SCAN listens only to canonical Upper 1. It never adapts the tonality after scan.
    void observeScan(const MidiMessage& message);

    // Fixed-tonality diatonic third: Upper 1 input -> Upper 3 output.
    std::vector<MidiMessage> generateFromUpper1(const MidiMessage& message) const;

    bool ownsRawUpper3() const { return enabled_ && tonalityValid_; }
    bool isRawUpper3Musical(const MidiMessage& message) const;

private:
    bool detectHeldTriad();
    int diatonicThirdFor(int sourceNote) const;
    bool pitchClassInScale(int relativePc, int& degree) const;

    bool enabled_{false};
    bool scanning_{false};
    bool tonalityValid_{false};
    int rootPitchClass_{0};
    ScaleMode scaleMode_{ScaleMode::Major};

    std::array<bool, 128> scanHeld_{};
};

} // namespace silveton
