#pragma once
#include "silveton/MidiTypes.h"
#include <cstdint>

namespace silveton {

class ThirdModule {
public:
    void setEnabled(bool enabled) { enabled_ = enabled; }
    bool enabled() const { return enabled_; }

    void startScan();
    bool scanning() const { return scanning_; }
    int detectedInterval() const { return detectedInterval_; }

    // Observe real canonical Upper streams. Upper 1 = ch 0, Upper 3 = ch 2.
    void observe(const MidiMessage& message, std::int64_t nowUs);

    // TERCA is the real Upper 3 stream. When disabled, its musical note stream is muted.
    bool shouldPass(const MidiMessage& message) const;

private:
    bool enabled_{false};
    bool scanning_{false};
    int detectedInterval_{0};

    int lastUpper1Note_{-1};
    int lastUpper3Note_{-1};
    std::int64_t lastUpper1Us_{0};
    std::int64_t lastUpper3Us_{0};

    void tryDetect();
};

} // namespace silveton
