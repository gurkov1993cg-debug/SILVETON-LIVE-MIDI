#pragma once
#include <cstdint>

namespace silveton {

struct MidiMessage {
    std::uint8_t status{0};
    std::uint8_t data1{0};
    std::uint8_t data2{0};
    std::uint8_t size{0};

    int channel() const { return status < 0xF0 ? (status & 0x0F) : -1; }
    int command() const { return status < 0xF0 ? (status & 0xF0) : status; }
    bool isNoteOn() const { return command() == 0x90 && data2 != 0; }
    bool isNoteOff() const { return command() == 0x80 || (command() == 0x90 && data2 == 0); }
    bool isPitchBend() const { return command() == 0xE0; }
    int pitchBend14() const { return int(data1) | (int(data2) << 7); }

    static MidiMessage noteOn(int ch, int note, int velocity) {
        return {std::uint8_t(0x90 | (ch & 0x0F)), std::uint8_t(note & 0x7F), std::uint8_t(velocity & 0x7F), 3};
    }
    static MidiMessage noteOff(int ch, int note, int velocity = 0) {
        return {std::uint8_t(0x80 | (ch & 0x0F)), std::uint8_t(note & 0x7F), std::uint8_t(velocity & 0x7F), 3};
    }
    static MidiMessage controlChange(int ch, int controller, int value) {
        if (controller < 0) controller = 0;
        if (controller > 127) controller = 127;
        if (value < 0) value = 0;
        if (value > 127) value = 127;
        return {std::uint8_t(0xB0 | (ch & 0x0F)), std::uint8_t(controller), std::uint8_t(value), 3};
    }

    static MidiMessage pitchBend(int ch, int value14) {
        if (value14 < 0) value14 = 0;
        if (value14 > 16383) value14 = 16383;
        return {std::uint8_t(0xE0 | (ch & 0x0F)), std::uint8_t(value14 & 0x7F), std::uint8_t((value14 >> 7) & 0x7F), 3};
    }
};

} // namespace silveton
