#pragma once
#include "silveton/MidiTypes.h"
#include <vector>

namespace silveton {

// Native Korg Pa600 portamento controller.
// This module does not synthesize glide with Pitch Bend. It only emits the
// standard MIDI CCs recognized by Pa600: CC#65 Portamento On/Off and
// CC#5 Portamento Time. The Pa600 sound engine performs the glide itself.
class Portamento {
public:
    struct Config {
        bool enabled{false};
        int time{64}; // MIDI CC#5, 0..127. Korg does not specify milliseconds.
    };

    void setConfig(const Config& config);
    const Config& config() const { return config_; }

    std::vector<MidiMessage> setEnabled(bool enabled);
    std::vector<MidiMessage> setTime(int value);
    std::vector<MidiMessage> sync() const;
    std::vector<MidiMessage> syncForChannel(int ch) const;

private:
    static void appendForAllUpper(std::vector<MidiMessage>& out, int controller, int value);
    Config config_{};
};

} // namespace silveton
