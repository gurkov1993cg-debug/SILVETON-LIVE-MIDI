#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <cstdint>
#include <vector>

namespace silveton {

class Portamento {
public:
    enum class CurveMode : int {
        Fix = 0,
        Linear = 1,
        Fib = 2,
        Real = 3
    };

    struct Config {
        bool enabled{true};
        int glideMs{180};
        int bendRangeSemitones{12};
        int updateIntervalUs{1000};
        CurveMode curve{CurveMode::Fib};
    };

    void setConfig(const Config& config);
    const Config& config() const { return config_; }

    std::vector<MidiMessage> process(const MidiMessage& message, std::int64_t nowUs);
    std::vector<MidiMessage> poll(std::int64_t nowUs);
    std::vector<MidiMessage> panic();
    std::vector<MidiMessage> panicChannel(int ch);

private:
    struct HeldNote {
        int note{-1};
        int velocity{0};
        int count{0};
        std::uint64_t order{0};
    };

    struct ChannelState {
        std::array<HeldNote, 128> held{};
        std::array<bool, 128> outputActive{};
        std::uint64_t orderCounter{0};
        int soundingNote{-1};
        int soundingVelocity{0};

        double baseBendSemitones{0.0};
        double glideStartBendSemitones{0.0};
        std::int64_t glideStartUs{0};
        std::int64_t glideEndUs{0};
        bool glideActive{false};
        std::int64_t lastPollUs{-1};

        int lastOutputBend14{-1};
    };

    double curvePosition(double t) const;
    double currentBaseBendSemitones(const ChannelState& state, std::int64_t nowUs) const;
    int baseToBend14(double baseSemitones) const;
    int newestHeldNote(const ChannelState& state) const;
    int velocityFor(const ChannelState& state, int note) const;
    void markHeld(ChannelState& state, int note, int velocity);
    bool releaseHeld(ChannelState& state, int note);
    int heldCount(const ChannelState& state, int note) const;
    void emitBendIfChanged(std::vector<MidiMessage>& out, int ch, ChannelState& state, double baseSemitones);
    void emitNoteOn(std::vector<MidiMessage>& out, int ch, ChannelState& state, int note, int velocity);
    void emitNoteOff(std::vector<MidiMessage>& out, int ch, ChannelState& state, int note, int velocity = 0);
    void switchSoundingNote(std::vector<MidiMessage>& out, int ch, ChannelState& state,
                           int newNote, int velocity, std::int64_t nowUs, bool glide);

    Config config_{};
    std::array<ChannelState, 16> states_{};
};

} // namespace silveton
