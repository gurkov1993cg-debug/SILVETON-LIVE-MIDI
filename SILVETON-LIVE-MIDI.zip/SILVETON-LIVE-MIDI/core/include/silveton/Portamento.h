#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <cstdint>
#include <vector>

namespace silveton {

// TIME portamento.
//
// Korg's own portamento (CC#5) is rate based: a wide interval glides longer
// than a narrow one. This module instead glides every interval in exactly the
// same total time (timeMs), linearly in semitones, by driving a per-channel
// pitch offset that PitchCoordinator renders as 14-bit Pitch Bend.
//
// While it is enabled the PA600's own portamento is forced OFF (CC#65 = 0) so
// the two can never glide on top of each other.
class Portamento {
public:
    struct Config {
        bool enabled{false};
        int timeMs{120}; // total glide time, independent of the interval
    };

    static constexpr int kMinTimeMs = 0;
    static constexpr int kMaxTimeMs = 5000;

    void setConfig(const Config& config);
    const Config& config() const { return config_; }

    // Returns CC#65 = 0 on U1/U2/U3 when enabling; nothing when disabling.
    std::vector<MidiMessage> setEnabled(bool enabled);
    void setTimeMs(int ms);

    // Re-assert "Korg portamento OFF" (after connect / Program Change).
    std::vector<MidiMessage> sync() const;
    std::vector<MidiMessage> syncForChannel(int ch) const;

    // A new note starts on channel ch. Returns true when the pitch offset of
    // that channel changed (the caller then emits the composed Pitch Bend).
    // maxSemitones is the Pitch Bend transport range (a glide cannot start
    // further away than the bend range can express).
    bool noteOn(int ch, int note, std::int64_t nowUs, double maxSemitones);

    // Advances running glides. Returns true for every channel whose offset changed.
    std::array<bool, 3> advance(std::int64_t nowUs);

    double offsetSemitones(int ch) const;
    bool gliding(int ch) const;
    int lastNote(int ch) const;
    void reset();
    void resetChannel(int ch);

private:
    struct Glide {
        int lastNote{-1};
        double startOffset{0.0};
        double offset{0.0};
        std::int64_t startUs{0};
        std::int64_t durationUs{0};
        bool active{false};
    };
    double offsetAt(const Glide& g, std::int64_t nowUs) const;

    Config config_{};
    std::array<Glide, 3> glides_{};
};

} // namespace silveton
