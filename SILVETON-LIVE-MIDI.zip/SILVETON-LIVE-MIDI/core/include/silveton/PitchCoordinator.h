#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <vector>

namespace silveton {

// Combines the independent pitch controls that use MIDI Pitch Bend into one
// value per channel: physical wheel + Ribbon + TIME-portamento glide offset.
class PitchCoordinator {
public:
    void setBendRangeSemitones(int value);
    void setManualRangeSemitones(int value);

    std::vector<MidiMessage> setRibbonSemitones(int ch, double semitones);
    std::vector<MidiMessage> setGlideSemitones(int ch, double semitones);
    // State-only setters + a single emit, for updating several lanes at once.
    void storeRibbonSemitones(int ch, double semitones);
    void storeGlideSemitones(int ch, double semitones);
    std::vector<MidiMessage> emitChannel(int ch) { return emitIfChanged(ch); }
    int bendRangeSemitones() const { return bendRangeSemitones_; }
    std::vector<MidiMessage> setManualBend14(int ch, int bend14);
    void rememberManualBend14(int ch, int bend14);
    int manualBend14(int ch) const;
    void clearRibbonContribution(int ch);
    std::vector<MidiMessage> forceEmitChannel(int ch);

    std::vector<MidiMessage> resetChannel(int ch);
    std::vector<MidiMessage> resetAll();
    void clearAll();

private:
    struct State {
        double ribbonSemitones{0.0};
        double glideSemitones{0.0};
        int manualBend14{8192};
        int lastOutputBend14{-1};
    };

    int compose14(const State& state) const;
    std::vector<MidiMessage> emitIfChanged(int ch);

    int bendRangeSemitones_{12};
    int manualRangeSemitones_{2};
    std::array<State, 16> states_{};
};

} // namespace silveton
