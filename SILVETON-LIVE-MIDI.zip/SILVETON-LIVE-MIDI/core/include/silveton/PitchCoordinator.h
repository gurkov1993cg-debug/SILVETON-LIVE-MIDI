#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <vector>

namespace silveton {

// Combines only the independent pitch controls that actually use MIDI Pitch
// Bend: physical/manual wheel + Ribbon. Native Pa600 Portamento is deliberately
// absent from this class and therefore cannot conflict with either control.
class PitchCoordinator {
public:
    void setBendRangeSemitones(int value);
    void setManualRangeSemitones(int value);

    std::vector<MidiMessage> setRibbonSemitones(int ch, double semitones);
    std::vector<MidiMessage> setManualBend14(int ch, int bend14);

    std::vector<MidiMessage> resetChannel(int ch);
    std::vector<MidiMessage> resetAll();

private:
    struct State {
        double ribbonSemitones{0.0};
        int manualBend14{8192};
        int lastOutputBend14{-1};
    };

    int compose14(const State& state) const;
    std::vector<MidiMessage> emitIfChanged(int ch);

    int bendRangeSemitones_{12};
    int manualRangeSemitones_{2};
    std::array<State, 16> states_{};
};

} // namespace silveton
