// Randomised conflict test: PA600-like traffic on U1/U2/U3 (random muted /
// untransmitted Uppers), wheel on every Upper, Ribbon, SCAN, TERCA, TIME
// portamento and transport toggles in random order, both Local modes.
// After everything is released: no note may hang on any channel and every
// Upper's pitch must be back at centre.
#include "silveton/MidiRouter.h"
#include "silveton/Ribbon.h"
#include <array>
#include <cstdio>
#include <random>
#include <vector>

using namespace silveton;

namespace {
struct Sink {
    std::array<std::array<int, 128>, 16> on{};
    std::array<int, 16> bend{};
    std::array<int, 16> range{};
    std::array<int, 16> rpnStage{};
    std::array<int, 16> rpnLsb{};
    std::array<int, 16> coarse{};
    std::array<int, 16> fineMsb{};
    Sink() { bend.fill(-1); range.fill(-1); rpnStage.fill(0); rpnLsb.fill(-1); coarse.fill(64); fineMsb.fill(64); }
    void feed(const std::vector<MidiMessage>& v) {
        for (const auto& m : v) {
            const int ch = m.channel();
            if (ch < 0) continue;
            const auto c = static_cast<std::size_t>(ch);
            const auto n = static_cast<std::size_t>(m.data1);
            if (m.isNoteOn()) ++on[c][n];
            else if (m.isNoteOff()) { if (on[c][n] > 0) --on[c][n]; }
            else if (m.isControlChange() && (m.data1 == 123 || m.data1 == 120)) on[c].fill(0);
            else if (m.isPitchBend()) bend[c] = m.pitchBend14();
            if (m.isControlChange()) {
                // Track RPN 0,0 (Pitch Bend Sensitivity) Data Entry.
                if (m.data1 == 101) rpnStage[c] = (m.data2 == 0) ? 1 : 0;
                else if (m.data1 == 100) { rpnLsb[c] = (rpnStage[c] == 1) ? m.data2 : -1; rpnStage[c] = (rpnStage[c] == 1 && m.data2 == 0) ? 2 : 0; }
                else if (m.data1 == 6 && rpnStage[c] == 2) range[c] = m.data2;
                if (m.data1 == 6 && rpnLsb[c] == 1) fineMsb[c] = m.data2;
                if (m.data1 == 6 && rpnLsb[c] == 2) coarse[c] = m.data2;
            }
        }
    }
};
} // namespace

int main() {
    std::mt19937 rng(20260926u);
    auto rnd = [&](unsigned n) { return static_cast<int>(rng() % n); };
    int failures = 0;
    for (int it = 0; it < 6000; ++it) {
        MidiRouter r;
        const bool local = rnd(4) == 0;
        r.setKeyboardLocal(local);
        std::array<bool, 3> tx{{rnd(3) != 0, rnd(3) != 0, rnd(3) != 0}};
        if (!tx[0] && !tx[1]) tx[1] = true;
        if (local) tx = {{true, false, false}};
        Portamento::Config pc;
        pc.enabled = rnd(2) == 1;
        pc.timeMs = 1 + rnd(300);
        r.setPortamentoConfig(pc);
        r.setMonoEnabled(rnd(2) == 1);

        Sink s;
        std::int64_t t = 0;
        std::array<bool, 128> held{};
        auto key = [&](int n, bool down) {
            for (int ch = 0; ch < 3; ++ch) {
                if (!tx[static_cast<std::size_t>(ch)]) continue;
                s.feed(r.process(down ? MidiMessage::noteOn(ch, n, 90)
                                      : (rnd(2) ? MidiMessage::noteOffZero(ch, n) : MidiMessage::noteOff(ch, n, 40)), t));
            }
        };
        auto wheel = [&](int v) {
            if (local) for (int ch = 0; ch < 3; ++ch) s.bend[static_cast<std::size_t>(ch)] = v; // keyboard applies it itself
            for (int ch = 0; ch < 3; ++ch)
                if (tx[static_cast<std::size_t>(ch)]) s.feed(r.process(MidiMessage::pitchBend(ch, v), t));
        };
        const int steps = 30 + rnd(120);
        for (int k = 0; k < steps; ++k) {
            t += 500 + rnd(30000);
            const int a = rnd(100);
            if (a < 35) { const int n = 48 + rnd(40); if (!held[static_cast<std::size_t>(n)]) { held[static_cast<std::size_t>(n)] = true; key(n, true); } }
            else if (a < 65) {
                std::vector<int> hs;
                for (int n = 0; n < 128; ++n) if (held[static_cast<std::size_t>(n)]) hs.push_back(n);
                if (!hs.empty()) { const int n = hs[static_cast<std::size_t>(rnd(static_cast<unsigned>(hs.size())))]; held[static_cast<std::size_t>(n)] = false; key(n, false); }
            }
            else if (a < 70) s.feed(r.setThirdEnabled(rnd(2) == 1));
            else if (a < 74) s.feed(r.setThirdScanning(rnd(2) == 1));
            else if (a < 77) s.feed(r.setPortamentoEnabled(rnd(2) == 1));
            else if (a < 80) s.feed(r.setPitchTransportEnabled(rnd(2) == 1));
            else if (a < 86) wheel(rnd(16384));
            else if (a < 90) s.feed(r.ribbonMove((rnd(2001) - 1000) / 1000.0, t));
            else if (a < 92) r.setMonoEnabled(rnd(2) == 1);
            else if (a < 94) {
                Ribbon::Settings rs;
                rs.mode = rnd(2) ? Ribbon::Mode::Absolute : Ribbon::Mode::Relative;
                rs.release = rnd(2) ? Ribbon::Release::Hold : Ribbon::Release::Return;
                rs.output = rnd(2) ? Ribbon::Output::Tuning : Ribbon::Output::PitchBend;
                rs.rangeSemitones = 1 + rnd(24);
                rs.rounding = rnd(2) == 1;
                rs.roundInitial = rnd(2) == 1;
                rs.smoothMs = rnd(100);
                rs.returnMs = rnd(300);
                s.feed(r.setRibbonSettings(rs));
            }
            else if (a < 97) s.feed(r.ribbonTouch(rnd(3), (rnd(2001) - 1000) / 1000.0, t));
            else s.feed(r.poll(t));
        }
        for (int n = 0; n < 128; ++n) if (held[static_cast<std::size_t>(n)]) { t += 1000; key(n, false); }
        wheel(8192);
        s.feed(r.ribbonTouch(2, 0.0, t));
        // A HOLD ribbon keeps its pitch by design; a quick tap returns it.
        s.feed(r.ribbonTouch(0, 0.0, t));
        s.feed(r.ribbonTouch(2, 0.0, t + 1000));
        s.feed(r.ribbonMove(0.0, t));
        for (int i = 0; i < 400; ++i) { t += 2000; s.feed(r.poll(t)); }
        t += 6000000;
        s.feed(r.poll(t));

        for (std::size_t ch = 0; ch < 3; ++ch) {
            bool bad = false;
            for (std::size_t n = 0; n < 128; ++n) if (s.on[ch][n] != 0) bad = true;
            if (s.bend[ch] != -1 && s.bend[ch] != 8192) bad = true;
            // Local ON must always end back on the keyboard's normal +/-2 range.
            if (local && s.range[ch] != -1 && s.range[ch] != 2) bad = true;
            // Ribbon TUNING must always come back to 0 (coarse 64, fine centre).
            if (s.coarse[ch] != 64 || s.fineMsb[ch] != 64) bad = true;
            if (bad) {
                if (failures < 5) std::printf("fuzz iteration %d: channel %zu left hanging\n", it, ch);
                ++failures;
                break;
            }
        }
    }
    std::printf("SILVETON fuzz conflict test: %d failures\n", failures);
    return failures == 0 ? 0 : 1;
}
