#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include <cassert>
#include <iostream>

using namespace silveton;

static bool hasNote(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) return true;
    }
    return false;
}

static int lastBendFor(const std::vector<MidiMessage>& v, int ch) {
    int value = -1;
    for (const auto& m : v) if (m.channel() == ch && m.isPitchBend()) value = m.pitchBend14();
    return value;
}

static bool hasCc(const std::vector<MidiMessage>& v, int ch, int cc, int value) {
    for (const auto& m : v) {
        if (m.channel() == ch && m.command() == 0xB0 && int(m.data1) == cc && int(m.data2) == value) return true;
    }
    return false;
}

static void noteCycle(MidiRouter& router, int note, int expectedHarmony, std::int64_t t) {
    auto on = router.process(MidiMessage::noteOn(0, note, 100), t);
    assert(hasNote(on, 0, note, true));
    if (expectedHarmony >= 0) assert(hasNote(on, 2, expectedHarmony, true));
    else {
        for (const auto& m : on) assert(!(m.channel() == 2 && m.isNoteOn()));
    }
    auto off = router.process(MidiMessage::noteOff(0, note, 0), t + 1000);
    assert(hasNote(off, 0, note, false));
    if (expectedHarmony >= 0) assert(hasNote(off, 2, expectedHarmony, false));
}

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0);
    static_assert(KorgProfile::upperChannels[1] == 1);
    static_assert(KorgProfile::upperChannels[2] == 2);

    MidiRouter router;
    Portamento::Config pcfg;
    pcfg.enabled = true;
    pcfg.time = 64;
    router.setPortamentoConfig(pcfg);

    // Non-Upper stays transparent.
    auto pass = router.process(MidiMessage::noteOn(3, 48, 100), 0);
    assert(pass.size() == 1 && pass[0].status == 0x93);

    // Native Pa600 Portamento: CC#5 = Time, CC#65 = On/Off, all three Uppers.
    auto pTime = router.setPortamentoTime(91);
    for (int ch = 0; ch < 3; ++ch) assert(hasCc(pTime, ch, 5, 91));

    auto pOff = router.setPortamentoEnabled(false);
    for (int ch = 0; ch < 3; ++ch) assert(hasCc(pOff, ch, 65, 0));

    auto pOn = router.setPortamentoEnabled(true);
    for (int ch = 0; ch < 3; ++ch) {
        assert(hasCc(pOn, ch, 5, 91));
        assert(hasCc(pOn, ch, 65, 127));
    }

    // Synchronization restores the current native Pa600 state exactly.
    auto pSync = router.syncPortamento();
    for (int ch = 0; ch < 3; ++ch) {
        assert(hasCc(pSync, ch, 5, 91));
        assert(hasCc(pSync, ch, 65, 127));
    }

    // Critical regression: Portamento never synthesizes glide with Pitch Bend.
    // The native TIME/SW state is asserted before every Note On so Pa600 sees
    // the same portamento command for both adjacent and wide intervals.
    auto n1 = router.process(MidiMessage::noteOn(0, 60, 100), 1000);
    auto n2 = router.process(MidiMessage::noteOn(0, 61, 100), 2000); // C -> C#
    auto n3 = router.process(MidiMessage::noteOn(0, 72, 100), 3000); // C# -> octave C
    for (const auto* ev : {&n1, &n2, &n3}) {
        assert(hasCc(*ev, 0, 5, 91));
        assert(hasCc(*ev, 0, 65, 127));
        assert(lastBendFor(*ev, 0) == -1);
    }
    assert(hasNote(n1, 0, 60, true));
    assert(hasNote(n2, 0, 61, true));
    assert(hasNote(n3, 0, 72, true));

    // TERCA SCAN can be explicitly started and cancelled.
    const auto rev0 = router.third().scanRevision();
    router.setThirdScanning(true);
    assert(router.thirdScanning());
    assert(router.process(MidiMessage::noteOn(0, 60, 100), 10000).empty());
    router.setThirdScanning(false);
    assert(!router.thirdScanning());
    assert(router.third().scanRevision() == rev0);

    // C-E-G scans C major, stays silent through release latch, then locks tonality.
    router.setThirdScanning(true);
    assert(router.process(MidiMessage::noteOn(0, 60, 100), 11000).empty());
    assert(router.process(MidiMessage::noteOn(0, 64, 100), 11100).empty());
    assert(router.process(MidiMessage::noteOn(0, 67, 100), 11200).empty());
    assert(!router.thirdScanning());
    assert(router.third().enabled());
    assert(router.third().tonalityValid());
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);
    assert(router.third().scanRevision() == rev0 + 1);
    assert(router.process(MidiMessage::noteOff(0, 60, 0), 11300).empty());
    assert(router.process(MidiMessage::noteOff(0, 64, 0), 11400).empty());
    assert(router.process(MidiMessage::noteOff(0, 67, 0), 11500).empty());
    assert(!router.third().scanSilenceActive());

    // Locked C-major TERCA. Native Pa600 Portamento can act on generated U3 too
    // because U3 receives the same CC#5/CC#65 state.
    noteCycle(router, 60, 64, 20000); // C -> E
    noteCycle(router, 62, 65, 22000); // D -> F
    noteCycle(router, 64, 67, 24000); // E -> G
    noteCycle(router, 65, 69, 26000); // F -> A
    noteCycle(router, 67, 71, 28000); // G -> B
    noteCycle(router, 69, 72, 30000); // A -> C
    noteCycle(router, 71, 74, 32000); // B -> D
    noteCycle(router, 61, -1, 34000); // C# outside scale: no generated third

    // Raw Upper 3 is suppressed only while TERCA owns it.
    auto rawOwned = router.process(MidiMessage::noteOn(2, 70, 100), 35000);
    assert(rawOwned.empty());
    router.setThirdEnabled(false);
    auto rawFree = router.process(MidiMessage::noteOn(2, 70, 100), 36000);
    assert(hasNote(rawFree, 2, 70, true));

    // High-end Ribbon is independent from native Portamento and affects U1/U2/U3.
    // Finger events set a target; the 1 ms poller generates the smooth 14-bit path.
    router.ribbon().setRangeSemitones(2);
    router.ribbon().setSensitivity(1.0);
    auto rbTarget = router.ribbonMove(1.0, 40000);
    assert(rbTarget.empty());

    int firstPositive = -1;
    int previous = 8192;
    for (std::int64_t t = 41000; t <= 90000; t += 1000) {
        auto step = router.poll(t);
        const int bend = lastBendFor(step, 0);
        if (bend >= 0) {
            if (firstPositive < 0) firstPositive = bend;
            assert(bend >= previous); // critically damped: no reverse step / overshoot
            previous = bend;
            assert(lastBendFor(step, 1) == bend);
            assert(lastBendFor(step, 2) == bend);
        }
    }
    assert(firstPositive > 8192);
    assert(previous > 9000);

    // Changing native Portamento cannot alter Ribbon output/state.
    const double ribbonBefore = router.ribbon().currentSemitoneOffset();
    router.setPortamentoTime(12);
    router.setPortamentoEnabled(false);
    router.poll(91000);
    assert(router.ribbon().currentSemitoneOffset() >= ribbonBefore);

    // Release is also smoothed, but must converge exactly to MIDI center.
    router.ribbonMove(0.0, 92000);
    int lastCenterBend = -1;
    for (std::int64_t t = 93000; t <= 250000; t += 1000) {
        auto step = router.poll(t);
        const int bend = lastBendFor(step, 0);
        if (bend >= 0) lastCenterBend = bend;
    }
    assert(lastCenterBend == 8192);

    // Physical/manual pitch bend is still composed only with Ribbon, never with Portamento.
    auto manual = router.process(MidiMessage::pitchBend(0, 12288), 43000);
    assert(lastBendFor(manual, 0) > 8192);

    // Panic is bounded to Upper channels and does not mutate Portamento settings.
    const auto portaBefore = router.portamento().config();
    auto panic = router.panic();
    assert(!panic.empty());
    for (const auto& m : panic) assert(KorgProfile::isUpperChannel(m.channel()));
    const auto portaAfter = router.portamento().config();
    assert(portaBefore.enabled == portaAfter.enabled);
    assert(portaBefore.time == portaAfter.time);

    std::cout << "SILVETON LIVE MIDI native-Pa600 portamento tests passed\n";
    return 0;
}
