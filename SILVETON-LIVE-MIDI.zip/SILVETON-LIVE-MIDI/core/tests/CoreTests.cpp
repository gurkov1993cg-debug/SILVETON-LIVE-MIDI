#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include "silveton/NativeMidiEngine.h"
#include "silveton/Ribbon.h"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>

using namespace silveton;

static bool hasNote(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) return true;
    }
    return false;
}

static int countNotes(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    int n = 0;
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) ++n;
    }
    return n;
}

static bool hasCc(const std::vector<MidiMessage>& v, int ch, int cc, int value) {
    for (const auto& m : v) {
        if (m.channel() == ch && m.command() == 0xB0 && int(m.data1) == cc && int(m.data2) == value) return true;
    }
    return false;
}

static int lastBendFor(const std::vector<MidiMessage>& v, int ch) {
    int value = -1;
    for (const auto& m : v) if (m.channel() == ch && m.isPitchBend()) value = m.pitchBend14();
    return value;
}

static void scanCMajor(MidiRouter& router, std::int64_t t) {
    auto start = router.setThirdScanning(true);
    (void)start;
    assert(router.thirdScanning());
    assert(router.process(MidiMessage::noteOn(0, 60, 100), t + 0).empty());
    assert(router.process(MidiMessage::noteOn(0, 64, 100), t + 100).empty());
    assert(router.process(MidiMessage::noteOn(0, 67, 100), t + 200).empty());
    assert(!router.thirdScanning());
    assert(router.third().scanState() == ThirdModule::ScanState::WaitingForRelease);
    assert(router.process(MidiMessage::noteOffZero(0, 60), t + 300).empty());
    assert(router.process(MidiMessage::noteOffZero(0, 64), t + 400).empty());
    assert(router.process(MidiMessage::noteOffZero(0, 67), t + 500).empty());
    assert(router.third().scanState() == ThirdModule::ScanState::Locked);
    assert(router.third().enabled());
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);
}

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0);
    static_assert(KorgProfile::upperChannels[1] == 1);
    static_assert(KorgProfile::upperChannels[2] == 2);

    // Exact low-level MIDI encoding.
    const auto u1 = MidiMessage::noteOn(0, 60, 100);
    const auto u2 = MidiMessage::noteOn(1, 60, 100);
    const auto u3 = MidiMessage::noteOn(2, 60, 100);
    assert(u1.status == 0x90 && u2.status == 0x91 && u3.status == 0x92);
    const auto off0 = MidiMessage::noteOffZero(0, 60);
    assert(off0.status == 0x90 && off0.data1 == 0x3C && off0.data2 == 0x00 && off0.isNoteOff());
    const MidiMessage velocityZero{0x90, 0x3C, 0x00, 3};
    assert(velocityZero.isNoteOff());

    const auto bend0 = MidiMessage::pitchBend(0, 8192);
    const auto bend1 = MidiMessage::pitchBend(1, 8192);
    const auto bend2 = MidiMessage::pitchBend(2, 8192);
    assert(bend0.status == 0xE0 && bend0.data1 == 0x00 && bend0.data2 == 0x40);
    assert(bend1.status == 0xE1 && bend1.data1 == 0x00 && bend1.data2 == 0x40);
    assert(bend2.status == 0xE2 && bend2.data1 == 0x00 && bend2.data2 == 0x40);
    const auto bendMax = MidiMessage::pitchBend(0, 16383);
    assert(bendMax.data1 == 0x7F && bendMax.data2 == 0x7F);

    // Local-Control-OFF baseline: with all modules inactive the three Upper
    // channels are a semantic byte-for-byte bridge. No CC5/CC65/RPN/Pitch
    // injection is allowed merely because the app is connected.
    NativeMidiEngine bridgeEngine;
    assert(!bridgeEngine.router().portamento().config().enabled);
    const std::vector<MidiMessage> bridgeInput = {
        MidiMessage{0x90, 0x3C, 0x64, 3},
        MidiMessage{0x91, 0x3E, 0x55, 3},
        MidiMessage{0x92, 0x40, 0x48, 3},
        MidiMessage{0xB0, 0x01, 0x33, 3},
        MidiMessage{0xC1, 0x12, 0x00, 2},
        MidiMessage{0xE2, 0x7F, 0x3F, 3},
        MidiMessage{0x90, 0x3C, 0x00, 3},
        MidiMessage{0x91, 0x3E, 0x00, 3},
        MidiMessage{0x92, 0x40, 0x00, 3}
    };
    std::int64_t bridgeTime = 100;
    for (const auto& in : bridgeInput) {
        const auto out = bridgeEngine.handleMidiIn(in.status, in.data1, in.data2, in.size, bridgeTime++);
        assert(out.size() == 1);
        assert(out[0].status == in.status);
        assert(out[0].data1 == in.data1);
        assert(out[0].data2 == in.data2);
        assert(out[0].size == in.size);
    }
    // State-cleaning channel-mode messages remain transparent when Ribbon's
    // pitch transport is inactive: no surprise E0/E1/E2 center is appended.
    bridgeEngine.handleMidiIn(0x90, 60, 100, 3, bridgeTime++);
    const auto cc123Bridge = bridgeEngine.handleMidiIn(0xB0, 123, 0, 3, bridgeTime++);
    assert(cc123Bridge.size() == 1);
    assert(cc123Bridge[0].status == 0xB0 && cc123Bridge[0].data1 == 123 && cc123Bridge[0].data2 == 0);
    assert(bridgeEngine.router().activeNoteRefs(0, 60) == 0);
    // TIME portamento: changing the time is state-only. Enabling it forces the
    // PA600's own (rate-based) portamento OFF on U1/U2/U3 with CC65 = 0.
    const auto quietTime = bridgeEngine.router().setPortamentoTimeMs(100);
    assert(quietTime.empty());
    const auto bridgePortaOn = bridgeEngine.router().setPortamentoEnabled(true);
    assert(bridgePortaOn.size() == 3);
    for (int ch = 0; ch < 3; ++ch) {
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].status == std::uint8_t(0xB0 | ch));
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].data1 == 65);
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].data2 == 0);
    }
    assert(bridgeEngine.router().setPortamentoEnabled(false).empty());
    {
        MidiRouter r;
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        assert(r.syncPortamentoChannel(2).size() == 1 && hasCc(r.syncPortamentoChannel(2), 2, 65, 0));
        // Without the Pitch Bend transport no glide is generated; the app never
        // sends CC5 per note. PORTAMENTO ON = automatic MONO: 72 ends 60.
        auto n1 = r.process(MidiMessage::noteOn(0, 60, 100), 0);
        auto n2 = r.process(MidiMessage::noteOn(0, 72, 100), 1000);
        assert(n1.size() == 1 && n2.size() == 2 && lastBendFor(n2, 0) == -1);
        assert(hasNote(n2, 0, 72, true) && hasNote(n2, 0, 60, false));
        for (const auto& m : n2) assert(!(m.isControlChange() && m.data1 == 5));
    }

    // ---- Equal-time glide, Local OFF bridge -------------------------------
    // The PA600 sends every key on U1, U2 and U3; each Upper glides on its own.
    {
        MidiRouter r;
        r.setPitchTransportEnabled(true);          // +/-12 transport
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        auto key = [&](int note, bool on, std::int64_t t) {
            std::vector<MidiMessage> all;
            for (int ch = 0; ch < 3; ++ch) {
                auto o = r.process(on ? MidiMessage::noteOn(ch, note, 100) : MidiMessage::noteOffZero(ch, note), t);
                // Per channel: the glide Pitch Bend precedes that channel's note.
                if (on && o.size() == 2) assert(o[0].isPitchBend() && o[1].isNoteOn());
                all.insert(all.end(), o.begin(), o.end());
            }
            return all;
        };
        auto first = key(60, true, 0);
        assert(first.size() == 3 && lastBendFor(first, 0) == -1);
        key(60, false, 10000);

        const std::int64_t t0 = 1000000;
        auto up2 = key(62, true, t0);
        for (int ch = 0; ch < 3; ++ch) assert(lastBendFor(up2, ch) == 6827);
        auto half = r.poll(t0 + 50000);
        for (int ch = 0; ch < 3; ++ch) assert(lastBendFor(half, ch) == 7509);
        auto done = r.poll(t0 + 100000);
        for (int ch = 0; ch < 3; ++ch) assert(lastBendFor(done, ch) == 8192);
        assert(r.poll(t0 + 150000).empty());
        key(62, false, t0 + 200000);

        const std::int64_t t1 = 2000000;
        auto up12 = key(74, true, t1);
        assert(lastBendFor(up12, 0) == 0);
        assert(lastBendFor(r.poll(t1 + 50000), 0) == 4096);
        assert(lastBendFor(r.poll(t1 + 99000), 0) != 8192);
        assert(lastBendFor(r.poll(t1 + 100000), 0) == 8192);
        key(74, false, t1 + 200000);

        const std::int64_t t2 = 3000000;
        auto down24 = key(50, true, t2);
        assert(lastBendFor(down24, 0) == 16383);
        assert(lastBendFor(r.poll(t2 + 100000), 0) == 8192);
        key(50, false, t2 + 200000);

        const std::int64_t t3 = 4000000;
        key(62, true, t3);
        r.poll(t3 + 50000);
        auto re = key(58, true, t3 + 50000);
        assert(lastBendFor(re, 0) == 6827);

        auto off = r.setPortamentoEnabled(false);
        assert(lastBendFor(off, 0) == 8192);
    }

    // ---- Local OFF: TERCA takes its notes from U3 itself ------------------
    {
        MidiRouter r;
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        assert(r.tercaSource() == 2);
        // SCAN works from any Upper (here only U2 is transmitted).
        r.setThirdScanning(true);
        for (int n : {60, 64, 67}) r.process(MidiMessage::noteOn(1, n, 90), 1);
        for (int n : {60, 64, 67}) r.process(MidiMessage::noteOffZero(1, n), 2);
        assert(r.third().tonalityValid() && r.third().scanCell() == ThirdModule::ScanCell::MajorUp);

        // U1/U2 keys never create a third and are passed unchanged.
        auto k1u = r.process(MidiMessage::noteOn(0, 60, 100), 1000);
        auto k2u = r.process(MidiMessage::noteOn(1, 60, 100), 1001);
        assert(k1u.size() == 1 && hasNote(k1u, 0, 60, true));
        assert(k2u.size() == 1 && hasNote(k2u, 1, 60, true));
        // The U3 key is consumed and becomes its third: C -> E on U3 only.
        auto k3u = r.process(MidiMessage::noteOn(2, 60, 100), 1002);
        assert(k3u.size() == 1 && k3u[0].status == 0x92 && k3u[0].data1 == 64 && k3u[0].data2 == 100);
        r.process(MidiMessage::noteOffZero(0, 60), 2000);
        r.process(MidiMessage::noteOffZero(1, 60), 2001);
        auto u3off = r.process(MidiMessage::noteOffZero(2, 60), 2002);
        assert(hasNote(u3off, 2, 64, false) && !hasNote(u3off, 2, 60, false));

        // U3 glides along its own thirds: D on U3 -> F, from E = -1 semitone.
        auto d = r.process(MidiMessage::noteOn(2, 62, 100), 1000000);
        assert(hasNote(d, 2, 65, true) && lastBendFor(d, 2) == 7509);
        r.process(MidiMessage::noteOffZero(2, 62), 1100000);

        // U3 muted on the PA600 and not transmitted: U1/U2 alone -> no third.
        auto onlyU1 = r.process(MidiMessage::noteOn(0, 64, 100), 2000000);
        for (const auto& m : onlyU1) assert(m.channel() != 2);
        r.process(MidiMessage::noteOffZero(0, 64), 2100000);

        // CC123 on U1 no longer touches U3; CC123 on U3 cleans U3.
        r.process(MidiMessage::noteOn(2, 60, 100), 3000000);
        auto k1 = r.process(MidiMessage::controlChange(0, 123, 0), 3000100);
        for (const auto& m : k1) assert(m.channel() == 0);
        auto k3 = r.process(MidiMessage::controlChange(2, 123, 0), 3000200);
        assert(hasCc(k3, 2, 123, 0));
        assert(r.activeNoteRefs(2, 64) == 0);
    }

    // ---- TERCA toggle never makes U3 glide across raw <-> terca lines ------
    {
        MidiRouter r;
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        r.process(MidiMessage::noteOn(2, 72, 100), 0);          // raw U3 line at 72
        r.process(MidiMessage::noteOffZero(2, 72), 1000);
        scanCMajor(r, 2000);                                    // TERCA now owns U3
        auto c = r.process(MidiMessage::noteOn(2, 60, 100), 100000);
        assert(hasNote(c, 2, 64, true));
        assert(lastBendFor(c, 2) == -1);                        // first terca note: no glide from 72
    }

    // ---- Glide in Local ON with TERCA: U3 follows its own line of thirds ---
    {
        MidiRouter r;
        r.setKeyboardLocal(true);
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 200;
        r.setPortamentoConfig(pc);
        scanCMajor(r, 10);
        auto c = r.process(MidiMessage::noteOn(0, 60, 100), 100000);   // first note, E on U3
        assert(hasNote(c, 2, 64, true) && lastBendFor(c, 0) == -1);
        r.process(MidiMessage::noteOffZero(0, 60), 150000);
        auto d = r.process(MidiMessage::noteOn(0, 62, 100), 200000);   // D: U1/U2 -2, U3 E->F = -1
        assert(!hasNote(d, 0, 62, true));                               // Local ON: no echo
        // Local ON keeps the keyboard's +/-2 range for a 2-semitone glide:
        // -2 st = PB 0, U3 -1 st = PB 4096, and no RPN is sent.
        assert(lastBendFor(d, 0) == 0 && lastBendFor(d, 1) == 0);
        assert(lastBendFor(d, 2) == 4096 && hasNote(d, 2, 65, true));
        for (const auto& m : d) assert(!(m.isControlChange() && m.data1 == 101));
        // The U3 glide Pitch Bend precedes the generated U3 note.
        std::size_t bendIdx = 99, noteIdx = 99;
        for (std::size_t i = 0; i < d.size(); ++i) {
            if (d[i].channel() == 2 && d[i].isPitchBend()) bendIdx = i;
            if (d[i].channel() == 2 && d[i].isNoteOn()) noteIdx = i;
        }
        assert(bendIdx < noteIdx);
        auto mid = r.poll(300000);                                      // halfway
        assert(lastBendFor(mid, 0) == 4096);                            // -1 st at +/-2
        assert(lastBendFor(mid, 2) == 6144);                            // -0.5 st
        auto end = r.poll(400000);
        assert(lastBendFor(end, 0) == 8192 && lastBendFor(end, 2) == 8192);
    }

    // ---- Local ON adaptive range: +/-2 normally, +/-12 only while needed ---
    {
        auto rpnValue = [](const std::vector<MidiMessage>& v, int ch) {
            int value = -1;
            for (std::size_t i = 0; i + 2 < v.size(); ++i) {
                if (v[i].channel() == ch && v[i].isControlChange() && v[i].data1 == 101 && v[i].data2 == 0 &&
                    v[i + 1].data1 == 100 && v[i + 1].data2 == 0 && v[i + 2].data1 == 6) value = v[i + 2].data2;
            }
            return value;
        };
        MidiRouter r;
        r.setKeyboardLocal(true);
        auto en = r.setPitchTransportEnabled(true);
        for (int ch = 0; ch < 3; ++ch) assert(rpnValue(en, ch) == 2);
        assert(r.localRange() == 2);

        // The keyboard wheel keeps its native +/-2 meaning: full up = 16383.
        auto w = r.process(MidiMessage::pitchBend(0, 16383), 10);
        assert(lastBendFor(w, 0) == 16383);
        r.process(MidiMessage::pitchBend(0, 8192), 20);

        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        r.process(MidiMessage::noteOn(0, 60, 100), 1000);
        r.process(MidiMessage::noteOffZero(0, 60), 2000);
        // A 7-semitone glide needs more than +/-2: RPN 12 first, then -7 st.
        auto wide = r.process(MidiMessage::noteOn(0, 67, 100), 1000000);
        assert(rpnValue(wide, 0) == 12 && rpnValue(wide, 1) == 12 && rpnValue(wide, 2) == 12);
        assert(lastBendFor(wide, 0) == 3413);                          // 8192 - 7/12*8192
        assert(r.localRange() == 12);
        std::size_t rpnIdx = 0, bendIdx = 0;
        for (std::size_t i = 0; i < wide.size(); ++i) {
            if (wide[i].channel() == 0 && wide[i].isControlChange() && wide[i].data1 == 6) rpnIdx = i;
            if (wide[i].channel() == 0 && wide[i].isPitchBend()) bendIdx = i;
        }
        assert(rpnIdx < bendIdx);
        // Glide ends at 100 ms; range stays wide briefly, then returns to +/-2.
        assert(lastBendFor(r.poll(1100000), 0) == 8192);
        assert(r.localRange() == 12);
        auto back = r.poll(1300000);
        assert(r.localRange() == 2 && rpnValue(back, 0) == 2 && lastBendFor(back, 0) == 8192);

        // Ribbon with RANGE <= 2 stays on +/-2 (no RPN switching at all).
        r.ribbon().setRangeSemitones(2);
        r.ribbonMove(1.0, 2000000);
        std::vector<MidiMessage> rib;
        for (std::int64_t tt = 2002000; tt < 2300000; tt += 2000) { auto o = r.poll(tt); rib.insert(rib.end(), o.begin(), o.end()); }
        assert(rpnValue(rib, 0) == -1 && lastBendFor(rib, 0) == 16383);
        r.ribbonMove(0.0, 2300000);
        for (std::int64_t tt = 2302000; tt < 2700000; tt += 2000) r.poll(tt);

        // Ribbon with RANGE 7 widens to +/-12 while used and returns afterwards.
        r.ribbon().setRangeSemitones(7);
        r.ribbonMove(1.0, 3000000);
        std::vector<MidiMessage> rib7;
        for (std::int64_t tt = 3002000; tt < 3300000; tt += 2000) { auto o = r.poll(tt); rib7.insert(rib7.end(), o.begin(), o.end()); }
        assert(rpnValue(rib7, 0) == 12 && lastBendFor(rib7, 0) == 12971);   // +7 of 12
        r.ribbonMove(0.0, 3300000);
        std::vector<MidiMessage> rel;
        for (std::int64_t tt = 3302000; tt < 3900000; tt += 2000) { auto o = r.poll(tt); rel.insert(rel.end(), o.begin(), o.end()); }
        assert(r.localRange() == 2 && rpnValue(rel, 0) == 2 && lastBendFor(rel, 0) == 8192);

        // Program Change re-asserts the current range for that Upper.
        auto sync = r.syncPitchChannel(1);
        assert(rpnValue(sync, 1) == 2);
    }

    // activeNotes/lastNote reference counting: 9n NN 00 is a real Note Off.
    MidiRouter notes;
    notes.process(MidiMessage::noteOn(0, 60, 100), 0);
    notes.process(MidiMessage::noteOn(0, 60, 110), 1);
    assert(notes.activeNoteRefs(0, 60) == 2);
    assert(notes.lastNote(0) == 60);
    notes.process(MidiMessage{0x90, 60, 0, 3}, 2);
    assert(notes.activeNoteRefs(0, 60) == 1);
    notes.process(MidiMessage::noteOff(0, 60, 0), 3);
    assert(notes.activeNoteRefs(0, 60) == 0);
    assert(notes.lastNote(0) == -1);

    // Non-Upper stays transparent.
    auto pass = notes.process(MidiMessage::noteOn(3, 48, 100), 4);
    assert(pass.size() == 1 && pass[0].status == 0x93);

    // SCAN cancel: scan Note On and its later release never leak.
    MidiRouter scanCancel;
    scanCancel.setThirdScanning(true);
    assert(scanCancel.process(MidiMessage::noteOn(0, 60, 100), 10000).empty());
    scanCancel.setThirdScanning(false);
    assert(!scanCancel.thirdScanning());
    assert(scanCancel.process(MidiMessage::noteOffZero(0, 60), 10100).empty());
    auto normalAfterCancel = scanCancel.process(MidiMessage::noteOn(0, 62, 100), 10200);
    assert(hasNote(normalAfterCancel, 0, 62, true));

    // Fixed C-major tonality; TERCA is strictly U3, never U2.
    MidiRouter harmony;
    scanCMajor(harmony, 20000);
    // Local OFF: the U3 key is the source; it is consumed and replaced by its third.
    auto cOn = harmony.process(MidiMessage::noteOn(2, 60, 100), 21000);
    assert(!hasNote(cOn, 2, 60, true));
    assert(hasNote(cOn, 2, 64, true));
    assert(!hasNote(cOn, 1, 64, true));
    const MidiMessage* tercOn = nullptr;
    for (const auto& m : cOn) if (m.channel() == 2 && m.isNoteOn()) tercOn = &m;
    assert(tercOn != nullptr && tercOn->status == 0x92 && tercOn->data1 == 0x40 && tercOn->data2 == 0x64);

    auto cOff = harmony.process(MidiMessage{0x92, 60, 0, 3}, 21100);
    assert(!hasNote(cOff, 2, 60, false));
    bool exactTercaOff = false;
    for (const auto& m : cOff) {
        if (m.status == 0x92 && m.data1 == 0x40 && m.data2 == 0x00) exactTercaOff = true;
    }
    assert(exactTercaOff);

    // C-major mapping and out-of-scale policy.
    const int src[7] = {60, 62, 64, 65, 67, 69, 71};
    const int dst[7] = {64, 65, 67, 69, 71, 72, 74};
    for (int i = 0; i < 7; ++i) {
        auto on = harmony.process(MidiMessage::noteOn(2, src[i], 90), 22000 + i * 100);
        assert(hasNote(on, 2, dst[i], true));
        auto off = harmony.process(MidiMessage::noteOffZero(2, src[i]), 22100 + i * 100);
        assert(hasNote(off, 2, dst[i], false));
    }
    // Out-of-scale note in C major: C# gets the in-scale minor third E.
    auto outside = harmony.process(MidiMessage::noteOn(2, 61, 100), 23000);
    assert(hasNote(outside, 2, 64, true));
    harmony.process(MidiMessage::noteOffZero(2, 61), 23100);

    // The wheel is never swallowed by SCAN (centre during SCAN must arrive).
    {
        MidiRouter w;
        w.process(MidiMessage::pitchBend(0, 16000), 1);
        w.setThirdScanning(true);
        auto centre = w.process(MidiMessage::pitchBend(0, 8192), 2);
        assert(lastBendFor(centre, 0) == 8192);
        w.setThirdScanning(false);
    }

    // Safety sweep: releasing the last U1 source sends CC123 on U3.
    {
        MidiRouter sw;
        sw.setKeyboardLocal(true);
        scanCMajor(sw, 1);
        sw.process(MidiMessage::noteOn(0, 60, 100), 100);
        // TERCA ON = automatic MONO line: the new third starts, the old one ends.
        auto legato = sw.process(MidiMessage::noteOn(0, 64, 100), 200);
        assert(hasNote(legato, 2, 67, true) && hasNote(legato, 2, 64, false));
        auto partial = sw.process(MidiMessage::noteOffZero(0, 60), 300);   // silent held key
        assert(partial.empty());
        auto last = sw.process(MidiMessage::noteOffZero(0, 64), 400);
        assert(hasNote(last, 2, 67, false) && hasCc(last, 2, 123, 0));
        assert(sw.activeNoteRefs(2, 67) == 0);
        for (const auto& m : last) assert(m.channel() == 2);   // never touches U1/U2
    }

    // The user's case: D phrygian (scan D Eb F). E -> G and B -> D.
    {
        MidiRouter dp;
        dp.setKeyboardLocal(true);
        dp.setThirdScanning(true);
        dp.process(MidiMessage::noteOn(0, 62, 90), 1);
        dp.process(MidiMessage::noteOn(0, 63, 90), 2);
        dp.process(MidiMessage::noteOn(0, 65, 90), 3);
        dp.process(MidiMessage::noteOffZero(0, 62), 4);
        dp.process(MidiMessage::noteOffZero(0, 63), 5);
        dp.process(MidiMessage::noteOffZero(0, 65), 6);
        assert(dp.third().scanCell() == ThirdModule::ScanCell::PhrygianUp && dp.third().rootPitchClass() == 2);
        auto e = dp.process(MidiMessage::noteOn(0, 64, 100), 10);
        assert(e.size() == 1 && e[0].status == 0x92 && e[0].data1 == 67);
        dp.process(MidiMessage::noteOffZero(0, 64), 11);
        auto b = dp.process(MidiMessage::noteOn(0, 71, 100), 12);
        assert(b.size() == 1 && b[0].status == 0x92 && b[0].data1 == 74);
        dp.process(MidiMessage::noteOffZero(0, 71), 13);
    }

    // Generated TERCA ownership: duplicate source note cannot be killed early.
    auto dup1 = harmony.process(MidiMessage::noteOn(2, 60, 100), 24000);
    auto dup2 = harmony.process(MidiMessage::noteOn(2, 60, 100), 24100);
    assert(countNotes(dup1, 2, 64, true) == 1);
    assert(countNotes(dup2, 2, 64, true) == 0);
    // TERCA ON = automatic MONO line: a repeated key is one key, so the first
    // release ends the third and the stray second release produces nothing.
    auto dupOff1 = harmony.process(MidiMessage::noteOffZero(2, 60), 24200);
    assert(countNotes(dupOff1, 2, 64, false) == 1);
    auto dupOff2 = harmony.process(MidiMessage::noteOffZero(2, 60), 24300);
    for (const auto& m : dupOff2) assert(!m.isNoteOn());
    assert(harmony.activeNoteRefs(2, 64) == 0);

    // While TERCA owns U3 a raw U3 key becomes its third (A# -> D in C major);
    // with TERCA OFF, U3 is a completely normal Upper again.
    auto ownedU3 = harmony.process(MidiMessage::noteOn(2, 70, 100), 25000);
    assert(!hasNote(ownedU3, 2, 70, true) && hasNote(ownedU3, 2, 74, true));
    harmony.process(MidiMessage::noteOffZero(2, 70), 25050);
    harmony.setThirdEnabled(false);
    auto freeU3 = harmony.process(MidiMessage::noteOn(2, 70, 100), 25100);
    assert(freeU3.size() == 1 && hasNote(freeU3, 2, 70, true));
    harmony.process(MidiMessage::noteOffZero(2, 70), 25200);

    // CC123 on U3 terminates generated U3 state.
    harmony.setThirdEnabled(true);
    auto gen = harmony.process(MidiMessage::noteOn(2, 62, 100), 26000);
    assert(hasNote(gen, 2, 65, true));
    auto allOffU3 = harmony.process(MidiMessage::controlChange(2, 123, 0), 26100);
    assert(hasCc(allOffU3, 2, 123, 0));
    assert(harmony.activeNoteRefs(2, 65) == 0);
    auto afterKill = harmony.process(MidiMessage::noteOffZero(2, 62), 26200);
    for (const auto& m : afterKill) assert(!m.isNoteOn());

    // With pitch transport disabled (the Local-OFF baseline), physical Pitch
    // Bend is byte-for-byte transparent and Ribbon produces no background
    // output. This is the bridge state before Ribbon is actually touched.
    MidiRouter transparentBridge;
    const MidiMessage rawPitch{0xE0, 0x7F, 0x7F, 3};
    const auto rawPitchOut = transparentBridge.process(rawPitch, 29000);
    assert(rawPitchOut.size() == 1);
    assert(rawPitchOut[0].status == 0xE0 && rawPitchOut[0].data1 == 0x7F && rawPitchOut[0].data2 == 0x7F);
    transparentBridge.ribbonMove(1.0, 29100);
    assert(transparentBridge.poll(35000).empty());

    // A physical wheel position seen while the bridge is transparent must be
    // remembered. Switching to the +/-12 Ribbon transport must preserve the
    // same musical +/-2 wheel offset instead of jumping to center/full scale.
    MidiRouter heldWheelRouter;
    const auto heldRaw = heldWheelRouter.process(MidiMessage::pitchBend(0, 16383), 29500);
    assert(lastBendFor(heldRaw, 0) == 16383);
    const auto heldEnable = heldWheelRouter.setPitchTransportEnabled(true);
    assert(lastBendFor(heldEnable, 0) == 9557);

    // Ribbon remains an independent smooth 14-bit lane on all Uppers once the
    // Android layer has intentionally enabled the +/-12 pitch transport.
    MidiRouter ribbonRouter;
    auto enablePitchTransport = ribbonRouter.setPitchTransportEnabled(true);
    assert(lastBendFor(enablePitchTransport, 0) == 8192);
    assert(lastBendFor(enablePitchTransport, 1) == 8192);
    assert(lastBendFor(enablePitchTransport, 2) == 8192);
    ribbonRouter.ribbon().setRangeSemitones(3);
    ribbonRouter.ribbon().setSensitivity(1.0);
    ribbonRouter.ribbonMove(1.0, 30000);
    int last = 8192;
    for (std::int64_t t = 32000; t <= 250000; t += 2000) {
        const auto step = ribbonRouter.poll(t);
        const int b0 = lastBendFor(step, 0);
        if (b0 >= 0) {
            assert(b0 >= last);
            last = b0;
            assert(lastBendFor(step, 1) == b0);
            assert(lastBendFor(step, 2) == b0);
        }
    }
    assert(last > 8192);
    ribbonRouter.ribbonMove(0.0, 252000);
    int center = -1;
    for (std::int64_t t = 254000; t <= 600000; t += 2000) {
        const auto step = ribbonRouter.poll(t);
        const int b0 = lastBendFor(step, 0);
        if (b0 >= 0) center = b0;
    }
    assert(center == 8192);

    // Physical bend is composed with Ribbon and portamento never touches it.
    const auto manual = ribbonRouter.process(MidiMessage::pitchBend(0, 16383), 610000);
    const int manualBend = lastBendFor(manual, 0);
    assert(manualBend > 8192);
    const auto forcedPitch = ribbonRouter.syncPitchChannel(0);
    assert(lastBendFor(forcedPitch, 0) == manualBend);

    // Panic: exact known note releases + CC123 + CC120 + centered pitch, state clear.
    MidiRouter panicRouter;
    panicRouter.process(MidiMessage::noteOn(0, 60, 100), 0);
    panicRouter.process(MidiMessage::noteOn(1, 64, 100), 1);
    auto panic = panicRouter.panic();
    assert(hasNote(panic, 0, 60, false));
    assert(hasNote(panic, 1, 64, false));
    for (int ch = 0; ch < 3; ++ch) {
        assert(hasCc(panic, ch, 123, 0));
        assert(hasCc(panic, ch, 120, 0));
        assert(lastBendFor(panic, ch) == 8192);
        assert(panicRouter.lastNote(ch) == -1);
    }
    assert(panicRouter.activeNoteRefs(0, 60) == 0);
    assert(panicRouter.activeNoteRefs(1, 64) == 0);

    // JNI-facing native class uses the same authoritative router and treats
    // 90 NN 00 as Note Off.
    NativeMidiEngine native;
    assert(!native.router().monoEnabled());
    native.handleMidiIn(0x90, 60, 100, 3, 0);
    assert(native.router().activeNoteRefs(0, 60) == 1);
    native.handleMidiIn(0x90, 60, 0, 3, 1);
    assert(native.router().activeNoteRefs(0, 60) == 0);
    assert(native.router().lastNote(0) == -1);


    // ---------------------------------------------------------------------
    // TERCA: all six SCAN cells, all 12 tonalities, explicit expected notes.
    // Expected tables are written out by hand for tonic C and transposed.
    // ---------------------------------------------------------------------
    struct CellCase {
        ThirdModule::ScanCell cell;
        int scanPcs[3];
        int dir;
        int src[7];
        int dst[7];
    };
    const CellCase cellCases[6] = {
        {ThirdModule::ScanCell::MajorUp,    {0, 4, 7}, +1,
         {60, 62, 64, 65, 67, 69, 71}, {64, 65, 67, 69, 71, 72, 74}},
        {ThirdModule::ScanCell::MajorDown,  {0, 2, 4}, -1,
         {60, 62, 64, 65, 67, 69, 71}, {57, 59, 60, 62, 64, 65, 67}},
        {ThirdModule::ScanCell::MinorUp,    {0, 3, 7}, +1,
         {60, 62, 63, 65, 67, 68, 70}, {63, 65, 67, 68, 70, 72, 74}},
        {ThirdModule::ScanCell::MinorDown,  {0, 2, 3}, -1,
         {60, 62, 63, 65, 67, 68, 70}, {56, 58, 60, 62, 63, 65, 67}},
        {ThirdModule::ScanCell::PhrygianUp, {0, 1, 3}, +1,
         {60, 61, 63, 65, 67, 68, 70}, {63, 65, 67, 68, 70, 72, 73}},
        {ThirdModule::ScanCell::HijazUp,    {0, 1, 4}, +1,
         {60, 61, 64, 65, 67, 68, 70}, {64, 65, 67, 68, 70, 72, 73}},
    };
    for (const auto& cc : cellCases) {
        for (int root = 0; root < 12; ++root) {
            for (int local = 0; local < 2; ++local) {
                MidiRouter r;
                r.setKeyboardLocal(local == 1);
                r.setThirdScanning(true);
                // Scan in a different octave and in inversion (top note first,
                // highest note dropped an octave) to prove pitch-class matching.
                const int n0 = 72 + ((root + cc.scanPcs[2]) % 12);
                const int n1 = 48 + ((root + cc.scanPcs[0]) % 12);
                const int n2 = 60 + ((root + cc.scanPcs[1]) % 12);
                r.process(MidiMessage::noteOn(0, n0, 90), 1);
                r.process(MidiMessage::noteOn(0, n1, 90), 2);
                r.process(MidiMessage::noteOn(0, n2, 90), 3);
                r.process(MidiMessage::noteOffZero(0, n0), 4);
                r.process(MidiMessage::noteOffZero(0, n1), 5);
                r.process(MidiMessage::noteOffZero(0, n2), 6);
                assert(r.third().scanState() == ThirdModule::ScanState::Locked);
                assert(r.third().tonalityValid());
                assert(r.third().scanCell() == cc.cell);
                assert(r.third().rootPitchClass() == root);
                assert(r.third().direction() == cc.dir);
                assert(r.thirdScanResult() == 1 + root + 12 * static_cast<int>(cc.cell));
                const int srcCh = r.tercaSource();          // U3 in Local OFF, U1 in Local ON
                assert(srcCh == (local == 1 ? 0 : 2));
                for (int i = 0; i < 7; ++i) {
                    const int s = cc.src[i] + root;
                    const int d = cc.dst[i] + root;
                    auto on = r.process(MidiMessage::noteOn(srcCh, s, 100), 100 + i);
                    assert(hasNote(on, 2, d, true));
                    assert(countNotes(on, 2, d, true) == 1);
                    // The source key itself is never sent: only its third.
                    assert(on.size() == 1);
                    auto off = r.process(MidiMessage::noteOffZero(srcCh, s), 200 + i);
                    assert(hasNote(off, 2, d, false));
                }
                // Every out-of-scale note also gets a third: the minor third if
                // it lands in the scale, else the major third, else minor.
                for (int pc = 0; pc < 12; ++pc) {
                    bool inScale = false;
                    for (int i = 0; i < 7; ++i) if ((cc.src[i] - 60) == pc) inScale = true;
                    if (inScale) continue;
                    auto scaleHas = [&](int rel) {
                        const int m = ((rel % 12) + 12) % 12;
                        for (int i = 0; i < 7; ++i) if ((cc.src[i] - 60) == m) return true;
                        return false;
                    };
                    int delta = 3 * cc.dir;
                    if (!scaleHas(pc + 3 * cc.dir) && scaleHas(pc + 4 * cc.dir)) delta = 4 * cc.dir;
                    const int s = 60 + ((root + pc) % 12);
                    auto chrom = r.process(MidiMessage::noteOn(srcCh, s, 100), 300 + pc);
                    assert(hasNote(chrom, 2, s + delta, true));
                    auto chromOff = r.process(MidiMessage::noteOffZero(srcCh, s), 400 + pc);
                    assert(hasNote(chromOff, 2, s + delta, false));
                }
            }
        }
    }
    // Non-triad / unknown shapes never lock.
    {
        MidiRouter r;
        r.setThirdScanning(true);
        r.process(MidiMessage::noteOn(0, 60, 90), 1);
        r.process(MidiMessage::noteOn(0, 66, 90), 2);
        r.process(MidiMessage::noteOn(0, 70, 90), 3);
        assert(r.thirdScanning());
        assert(!r.third().tonalityValid());
    }

    // ---------------------------------------------------------------------
    // Local Control ON: nothing from the keyboard is ever echoed back.
    // ---------------------------------------------------------------------
    {
        MidiRouter r;
        r.setKeyboardLocal(true);
        assert(r.process(MidiMessage::noteOn(0, 60, 100), 1).empty());
        assert(r.process(MidiMessage::noteOn(1, 60, 100), 2).empty());
        assert(r.process(MidiMessage::noteOn(2, 60, 100), 3).empty());
        assert(r.process(MidiMessage::noteOn(3, 48, 100), 4).empty());      // Lower
        assert(r.process(MidiMessage::noteOn(9, 36, 100), 5).empty());      // style drum
        assert(r.process(MidiMessage::controlChange(0, 64, 127), 6).empty()); // damper
        assert(r.process(MidiMessage::pitchBend(0, 12000), 7).empty());
        assert(r.process(MidiMessage{0xC0, 5, 0, 2}, 8).empty());
        assert(r.process(MidiMessage::controlChange(0, 123, 0), 9).empty());
        assert(r.process(MidiMessage::noteOffZero(0, 60), 10).empty());
        // Enabling TIME portamento still forces Korg portamento OFF (CC65 = 0).
        auto pOn = r.setPortamentoEnabled(true);
        assert(pOn.size() == 3 && hasCc(pOn, 0, 65, 0) && hasCc(pOn, 2, 65, 0));
        // Starting SCAN must not send CC123 to the keyboard's own U1/U2.
        auto scanStart = r.setThirdScanning(true);
        for (const auto& m : scanStart) assert(!(m.isControlChange() && m.data1 == 123));
        r.process(MidiMessage::noteOn(0, 62, 90), 20);
        r.process(MidiMessage::noteOn(0, 65, 90), 21);
        r.process(MidiMessage::noteOn(0, 69, 90), 22);   // D minor, third up
        r.process(MidiMessage::noteOffZero(0, 62), 23);
        r.process(MidiMessage::noteOffZero(0, 65), 24);
        r.process(MidiMessage::noteOffZero(0, 69), 25);
        assert(r.third().scanCell() == ThirdModule::ScanCell::MinorUp && r.third().rootPitchClass() == 2);
        auto on = r.process(MidiMessage::noteOn(0, 74, 100), 30);   // D5 -> F5
        assert(on.size() == 1 && on[0].status == 0x92 && on[0].data1 == 77 && on[0].data2 == 100);
        // CC123 on U1 releases only the generated U3 note, without echoing CC123.
        auto kill = r.process(MidiMessage::controlChange(0, 123, 0), 31);
        assert(hasNote(kill, 2, 77, false));
        assert(!hasCc(kill, 0, 123, 0));
        assert(r.activeNoteRefs(2, 77) == 0);
        // With the transport active, a wheel move re-asserts wheel+Ribbon as one
        // value on the keyboard's own +/-2 scale (full up stays full up).
        r.setPitchTransportEnabled(true);
        auto wheel = r.process(MidiMessage::pitchBend(0, 16383), 40);
        assert(lastBendFor(wheel, 0) == 16383);
        // Leaving the Ribbon transport re-asserts the raw wheel value (+/-2 scale).
        auto leave = r.setPitchTransportEnabled(false);
        assert(lastBendFor(leave, 0) == 16383);
        assert(lastBendFor(leave, 1) == 8192 && lastBendFor(leave, 2) == 8192);
        assert(r.poll(1000000).empty());
    }


    // ---------------------------------------------------------------------
    // MONO legato
    // ---------------------------------------------------------------------
    {
        // Local OFF, plain Upper: legato order = new note on, then old note off.
        MidiRouter r;
        r.setMonoEnabled(true);
        auto a = r.process(MidiMessage::noteOn(0, 60, 100), 1);
        assert(a.size() == 1 && hasNote(a, 0, 60, true));
        auto b = r.process(MidiMessage::noteOn(0, 62, 90), 2);
        assert(b.size() == 2 && b[0].isNoteOn() && b[0].data1 == 62 && b[1].isNoteOff() && b[1].data1 == 60);
        // Release the newest while 60 is still held: back to 60 (velocity 100).
        auto c = r.process(MidiMessage::noteOffZero(0, 62), 3);
        assert(c.size() == 2 && c[0].isNoteOn() && c[0].data1 == 60 && c[0].data2 == 100);
        assert(c[1].isNoteOff() && c[1].data1 == 62);
        // Releasing a silent held key produces nothing.
        r.process(MidiMessage::noteOn(0, 64, 100), 4);                 // 64 sounds, 60 held
        auto silent = r.process(MidiMessage::noteOffZero(0, 60), 5);
        assert(silent.empty());
        auto lastOff = r.process(MidiMessage::noteOffZero(0, 64), 6);
        assert(lastOff.size() == 1 && lastOff[0].isNoteOff() && lastOff[0].data1 == 64);
        for (int n = 0; n < 128; ++n) assert(r.activeNoteRefs(0, n) == 0);

        // A Note Off for a key pressed before MONO was enabled passes through.
        MidiRouter late;
        late.process(MidiMessage::noteOn(0, 70, 100), 1);
        late.setMonoEnabled(true);
        auto lateOff = late.process(MidiMessage::noteOffZero(0, 70), 2);
        assert(lateOff.size() == 1 && lateOff[0].isNoteOff() && lateOff[0].data1 == 70);
        assert(late.activeNoteRefs(0, 70) == 0);
    }
    {
        // Local OFF TERCA from U3 in MONO: only one third at a time, never mixed.
        MidiRouter r;
        r.setMonoEnabled(true);
        scanCMajor(r, 1);
        auto c = r.process(MidiMessage::noteOn(2, 60, 100), 1000);
        assert(hasNote(c, 2, 64, true));
        auto d = r.process(MidiMessage::noteOn(2, 62, 100), 2000);      // legato D
        assert(hasNote(d, 2, 65, true) && hasNote(d, 2, 64, false));
        assert(r.activeNoteRefs(2, 64) == 0 && r.activeNoteRefs(2, 65) == 1);
        auto back = r.process(MidiMessage::noteOffZero(2, 62), 3000);  // back to C
        assert(hasNote(back, 2, 64, true) && hasNote(back, 2, 65, false));
        auto end = r.process(MidiMessage::noteOffZero(2, 60), 4000);
        assert(hasNote(end, 2, 64, false));
        for (int n = 0; n < 128; ++n) assert(r.activeNoteRefs(2, n) == 0);
    }
    {
        // Local OFF MONO + TIME portamento: legato glides, return glides back.
        MidiRouter r;
        r.setMonoEnabled(true);
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        r.process(MidiMessage::noteOn(0, 60, 100), 0);
        auto up = r.process(MidiMessage::noteOn(0, 62, 100), 1000000);
        assert(up[0].isPitchBend() && lastBendFor(up, 0) == 6827);      // PB, on 62, off 60
        assert(up[1].isNoteOn() && up[1].data1 == 62 && up[2].isNoteOff() && up[2].data1 == 60);
        r.poll(1200000);
        auto ret = r.process(MidiMessage::noteOffZero(0, 62), 2000000); // back to 60: glide down
        assert(lastBendFor(ret, 0) == 9557 && hasNote(ret, 0, 60, true) && hasNote(ret, 0, 62, false));
    }
    {
        // Local ON MONO: U3 terca line is mono; U1/U2 are centred (not glided) on return.
        MidiRouter r;
        r.setKeyboardLocal(true);
        r.setMonoEnabled(true);
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        scanCMajor(r, 1);
        r.process(MidiMessage::noteOn(0, 60, 100), 1000);
        auto d = r.process(MidiMessage::noteOn(0, 62, 100), 1000000);
        assert(hasNote(d, 2, 65, true) && hasNote(d, 2, 64, false) && !hasNote(d, 0, 62, true));
        auto ret = r.process(MidiMessage::noteOffZero(0, 62), 1020000);  // mid-glide return
        assert(lastBendFor(ret, 0) == 8192 && lastBendFor(ret, 1) == 8192);
        assert(hasNote(ret, 2, 64, true) && hasNote(ret, 2, 65, false));
        assert(lastBendFor(ret, 2) != -1 && lastBendFor(ret, 2) != 8192); // U3 glides F -> E
        auto end = r.process(MidiMessage::noteOffZero(0, 60), 1030000);
        assert(hasNote(end, 2, 64, false));
    }

    // ---- Automatic MONO: on with PORTAMENTO, off (poly chords) without it ---
    {
        MidiRouter r;                                     // app MONO flag off
        auto c1 = r.process(MidiMessage::noteOn(0, 60, 100), 1);
        auto c2 = r.process(MidiMessage::noteOn(0, 64, 100), 2);
        assert(c2.size() == 1 && hasNote(c2, 0, 64, true));       // poly: chord kept
        r.process(MidiMessage::noteOffZero(0, 60), 3);
        r.process(MidiMessage::noteOffZero(0, 64), 4);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        r.process(MidiMessage::noteOn(0, 60, 100), 10);
        auto leg = r.process(MidiMessage::noteOn(0, 62, 100), 20);
        assert(hasNote(leg, 0, 62, true) && hasNote(leg, 0, 60, false)); // mono: 60 ends
        r.process(MidiMessage::noteOffZero(0, 62), 30);
        r.process(MidiMessage::noteOffZero(0, 60), 40);
        for (int n = 0; n < 128; ++n) assert(r.activeNoteRefs(0, n) == 0);
        (void)c1;
    }


    // ---------------------------------------------------------------------
    // RIBBON module
    // ---------------------------------------------------------------------
    {
        auto settle = [](Ribbon& rb, std::int64_t& t, int ms) {
            for (int i = 0; i < ms / 2; ++i) { t += 2000; rb.advance(t); }
            return rb.currentSemitoneOffset();
        };
        // RELATIVE: landing anywhere never jumps; sliding half a strip = full range.
        {
            Ribbon rb;
            Ribbon::Settings s;
            s.mode = Ribbon::Mode::Relative;
            s.rangeSemitones = 2;
            rb.setSettings(s);
            std::int64_t t = 1000;
            rb.advance(t);
            rb.touchDown(0.7, t);
            assert(rb.targetSemitoneOffset() == 0.0);
            assert(std::abs(settle(rb, t, 100)) < 1e-9);
            rb.touchMove(-0.3, t);                          // 1.0 to the left = -range
            assert(std::abs(rb.targetSemitoneOffset() + 2.0) < 1e-9);
            assert(std::abs(settle(rb, t, 300) + 2.0) < 1e-3);
            rb.touchUp(t);                                  // RETURN
            assert(std::abs(settle(rb, t, 400)) < 1e-9);
        }
        // ABSOLUTE: position is pitch; centre dead zone.
        {
            Ribbon rb;
            Ribbon::Settings s;
            s.mode = Ribbon::Mode::Absolute;
            s.rangeSemitones = 12;
            rb.setSettings(s);
            std::int64_t t = 1000;
            rb.touchDown(1.0, t);
            assert(std::abs(rb.targetSemitoneOffset() - 12.0) < 1e-9);
            rb.touchMove(0.01, t);
            assert(rb.targetSemitoneOffset() == 0.0);
            rb.touchMove(-1.0, t);
            assert(std::abs(rb.targetSemitoneOffset() + 12.0) < 1e-9);
        }
        // Invert flips direction; range up to 24.
        {
            Ribbon rb;
            Ribbon::Settings s;
            s.mode = Ribbon::Mode::Absolute;
            s.rangeSemitones = 24;
            s.invert = true;
            rb.setSettings(s);
            rb.touchDown(1.0, 1000);
            assert(std::abs(rb.targetSemitoneOffset() + 24.0) < 1e-9);
        }
        // HOLD: pitch stays after lifting; relative continues from it; a tap clears.
        {
            Ribbon rb;
            Ribbon::Settings s;
            s.mode = Ribbon::Mode::Relative;
            s.release = Ribbon::Release::Hold;
            s.rangeSemitones = 4;
            rb.setSettings(s);
            std::int64_t t = 1000;
            rb.advance(t);
            rb.touchDown(0.0, t);
            rb.touchMove(0.5, t + 100000);
            settle(rb, t, 300);
            const double held = rb.currentSemitoneOffset();
            assert(held > 1.0);
            t += 400000;
            rb.touchUp(t);
            assert(std::abs(settle(rb, t, 300) - held) < 1e-6);   // stays
            rb.touchDown(-0.8, t);                                  // continue from held
            assert(std::abs(rb.targetSemitoneOffset() - held) < 1e-6);
            rb.touchUp(t + 50000);                                  // short tap -> clear
            t += 50000;
            assert(std::abs(settle(rb, t, 400)) < 1e-9);
        }
        // Rounding: a steady off-grid position is pulled onto the semitone,
        // vibrato around it is kept (average lands on the note, depth stays).
        {
            Ribbon rb;
            Ribbon::Settings s;
            s.mode = Ribbon::Mode::Absolute;
            s.rangeSemitones = 12;
            s.sensitivity = 1.0;
            s.rounding = true;
            s.roundRateMs = 100;
            rb.setSettings(s);
            std::int64_t t = 1000;
            rb.advance(t);
            // Position for ~3.3 semitones: invert the curve (gamma 1 at sens 1).
            const double pos = 0.02 + (3.3 / 12.0) * 0.98;
            rb.touchDown(pos, t);
            assert(std::abs(settle(rb, t, 1500) - 3.0) < 0.02);
            // Vibrato +-0.3 semitone at 6 Hz around 3.3 -> output centre ~3.0.
            double sum = 0.0, mn = 99.0, mx = -99.0;
            int n = 0;
            for (int i = 0; i < 1500; ++i) {
                t += 2000;
                const double vib = 3.3 + 0.3 * std::sin(2.0 * 3.14159265358979 * 6.0 * (i * 0.002));
                rb.touchMove(0.02 + (vib / 12.0) * 0.98, t);
                auto u = rb.advance(t);
                if (i > 750 && u.valid) { sum += u.semitones; ++n; mn = std::min(mn, u.semitones); mx = std::max(mx, u.semitones); }
            }
            assert(n > 0 && std::abs(sum / n - 3.0) < 0.06);
            assert(mx - mn > 0.4);                                  // vibrato depth kept
        }
        // Round Initial: lands exactly on a semitone at first touch.
        {
            Ribbon rb;
            Ribbon::Settings s;
            s.mode = Ribbon::Mode::Absolute;
            s.rangeSemitones = 12;
            s.rounding = true;
            s.roundInitial = true;
            s.smoothMs = 0;
            rb.setSettings(s);
            std::int64_t t = 1000;
            rb.advance(t);
            rb.touchDown(0.02 + (5.4 / 12.0) * 0.98, t);
            t += 2000;
            auto u = rb.advance(t);
            assert(u.valid && std::abs(u.semitones - 5.0) < 0.05);
        }
    }
    // ---- Router: TUNING output never touches Pitch Bend or RPN 0 ----------
    {
        MidiRouter r;
        Ribbon::Settings s;
        s.mode = Ribbon::Mode::Absolute;
        s.output = Ribbon::Output::Tuning;
        s.rangeSemitones = 3;
        s.smoothMs = 0;
        s.returnMs = 0;
        r.setRibbonSettings(s);
        // Wheel is always passed exactly as the PA600 sent it.
        auto w = r.process(MidiMessage::pitchBend(0, 12000), 1);
        assert(w.size() == 1 && w[0].pitchBend14() == 12000);
        std::vector<MidiMessage> all;
        r.ribbonTouch(0, 0.02 + (2.5 / 3.0) * 0.98, 1000);         // +2.5 semitones
        for (std::int64_t t = 3000; t < 50000; t += 2000) { auto o = r.poll(t); all.insert(all.end(), o.begin(), o.end()); }
        int coarse = -1, fineMsb = -1, sel = -1;
        for (std::size_t i = 0; i < all.size(); ++i) {
            const auto& m = all[i];
            assert(!m.isPitchBend());
            assert(m.isControlChange());
            if (m.channel() != 0) continue;
            if (m.data1 == 100) sel = m.data2;
            if (m.data1 == 101) assert(m.data2 == 0 || m.data2 == 127);
            if (m.data1 == 100) assert(m.data2 == 1 || m.data2 == 2 || m.data2 == 127);   // never RPN 0
            if (m.data1 == 6 && sel == 2) coarse = m.data2 - 64;
            if (m.data1 == 6 && sel == 1) fineMsb = m.data2;
        }
        // 2.5 = coarse 3 with fine -0.5 (hysteresis rounds the coarse step).
        assert(coarse == 3 && fineMsb == ((8192 - 4096) >> 7));
        for (int ch = 0; ch < 3; ++ch) {
            bool seen = false;
            for (const auto& m : all) if (m.channel() == ch && m.isControlChange() && m.data1 == 6) seen = true;
            assert(seen);
        }
        // Release: back to coarse 0 / fine centre, then RPN null.
        r.ribbonTouch(2, 0.0, 60000);
        std::vector<MidiMessage> rel;
        for (std::int64_t t = 62000; t < 200000; t += 2000) { auto o = r.poll(t); rel.insert(rel.end(), o.begin(), o.end()); }
        assert(!rel.empty() && rel.back().data1 == 100 && rel.back().data2 == 127);
        int relCoarse = -99, relFine = -1; sel = -1;
        for (const auto& m : rel) {
            if (m.channel() != 0 || !m.isControlChange()) continue;
            if (m.data1 == 100) sel = m.data2;
            if (m.data1 == 6 && sel == 2) relCoarse = m.data2 - 64;
            if (m.data1 == 6 && sel == 1) relFine = m.data2;
        }
        assert(relCoarse == 0 && relFine == 64);
        // PANIC also clears tuning.
        r.ribbonTouch(0, 0.9, 300000);
        for (std::int64_t t = 302000; t < 320000; t += 2000) r.poll(t);
        auto pr = r.ribbonReset();
        assert(!pr.empty() && pr.back().data2 == 127);
    }
    // ---- Ribbon within +-1 semitone on TUNING never writes Coarse ---------
    {
        MidiRouter r;
        Ribbon::Settings s;
        s.mode = Ribbon::Mode::Relative;
        s.output = Ribbon::Output::Tuning;
        s.rangeSemitones = 1;
        r.setRibbonSettings(s);
        std::vector<MidiMessage> all;
        r.ribbonTouch(0, 0.0, 1000);
        for (int i = 0; i < 400; ++i) {
            const double p = std::sin(i * 0.05);
            r.ribbonTouch(1, p, 1000 + i * 2000);
            auto o = r.poll(1000 + i * 2000);
            all.insert(all.end(), o.begin(), o.end());
        }
        for (const auto& m : all) assert(!(m.isControlChange() && m.data1 == 100 && m.data2 == 2));
    }

    std::cout << "SILVETON LIVE MIDI full low-level regression tests passed\n";
    return 0;
}
