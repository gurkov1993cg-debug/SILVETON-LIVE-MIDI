#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include "silveton/NativeMidiEngine.h"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

using namespace silveton;

static bool hasNote(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) return true;
    }
    return false;
}

static int countNotes(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    int n = 0;
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) ++n;
    }
    return n;
}

static bool hasCc(const std::vector<MidiMessage>& v, int ch, int cc, int value) {
    for (const auto& m : v) {
        if (m.channel() == ch && m.command() == 0xB0 && int(m.data1) == cc && int(m.data2) == value) return true;
    }
    return false;
}

static int lastBendFor(const std::vector<MidiMessage>& v, int ch) {
    int value = -1;
    for (const auto& m : v) if (m.channel() == ch && m.isPitchBend()) value = m.pitchBend14();
    return value;
}

static void scanCMajor(MidiRouter& router, std::int64_t t) {
    auto start = router.setThirdScanning(true);
    (void)start;
    assert(router.thirdScanning());
    assert(router.process(MidiMessage::noteOn(0, 60, 100), t + 0).empty());
    assert(router.process(MidiMessage::noteOn(0, 64, 100), t + 100).empty());
    assert(router.process(MidiMessage::noteOn(0, 67, 100), t + 200).empty());
    assert(!router.thirdScanning());
    assert(router.third().scanState() == ThirdModule::ScanState::WaitingForRelease);
    assert(router.process(MidiMessage::noteOffZero(0, 60), t + 300).empty());
    assert(router.process(MidiMessage::noteOffZero(0, 64), t + 400).empty());
    assert(router.process(MidiMessage::noteOffZero(0, 67), t + 500).empty());
    assert(router.third().scanState() == ThirdModule::ScanState::Locked);
    assert(router.third().enabled());
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);
}

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0);
    static_assert(KorgProfile::upperChannels[1] == 1);
    static_assert(KorgProfile::upperChannels[2] == 2);

    // Exact low-level MIDI encoding.
    const auto u1 = MidiMessage::noteOn(0, 60, 100);
    const auto u2 = MidiMessage::noteOn(1, 60, 100);
    const auto u3 = MidiMessage::noteOn(2, 60, 100);
    assert(u1.status == 0x90 && u2.status == 0x91 && u3.status == 0x92);
    const auto off0 = MidiMessage::noteOffZero(0, 60);
    assert(off0.status == 0x90 && off0.data1 == 0x3C && off0.data2 == 0x00 && off0.isNoteOff());
    const MidiMessage velocityZero{0x90, 0x3C, 0x00, 3};
    assert(velocityZero.isNoteOff());

    const auto bend0 = MidiMessage::pitchBend(0, 8192);
    const auto bend1 = MidiMessage::pitchBend(1, 8192);
    const auto bend2 = MidiMessage::pitchBend(2, 8192);
    assert(bend0.status == 0xE0 && bend0.data1 == 0x00 && bend0.data2 == 0x40);
    assert(bend1.status == 0xE1 && bend1.data1 == 0x00 && bend1.data2 == 0x40);
    assert(bend2.status == 0xE2 && bend2.data1 == 0x00 && bend2.data2 == 0x40);
    const auto bendMax = MidiMessage::pitchBend(0, 16383);
    assert(bendMax.data1 == 0x7F && bendMax.data2 == 0x7F);

    // Local-Control-OFF baseline: with all modules inactive the three Upper
    // channels are a semantic byte-for-byte bridge. No CC5/CC65/RPN/Pitch
    // injection is allowed merely because the app is connected.
    NativeMidiEngine bridgeEngine;
    assert(!bridgeEngine.router().portamento().config().enabled);
    const std::vector<MidiMessage> bridgeInput = {
        MidiMessage{0x90, 0x3C, 0x64, 3},
        MidiMessage{0x91, 0x3E, 0x55, 3},
        MidiMessage{0x92, 0x40, 0x48, 3},
        MidiMessage{0xB0, 0x01, 0x33, 3},
        MidiMessage{0xC1, 0x12, 0x00, 2},
        MidiMessage{0xE2, 0x7F, 0x3F, 3},
        MidiMessage{0x90, 0x3C, 0x00, 3},
        MidiMessage{0x91, 0x3E, 0x00, 3},
        MidiMessage{0x92, 0x40, 0x00, 3}
    };
    std::int64_t bridgeTime = 100;
    for (const auto& in : bridgeInput) {
        const auto out = bridgeEngine.handleMidiIn(in.status, in.data1, in.data2, in.size, bridgeTime++);
        assert(out.size() == 1);
        assert(out[0].status == in.status);
        assert(out[0].data1 == in.data1);
        assert(out[0].data2 == in.data2);
        assert(out[0].size == in.size);
    }
    // State-cleaning channel-mode messages remain transparent when Ribbon's
    // pitch transport is inactive: no surprise E0/E1/E2 center is appended.
    bridgeEngine.handleMidiIn(0x90, 60, 100, 3, bridgeTime++);
    const auto cc123Bridge = bridgeEngine.handleMidiIn(0xB0, 123, 0, 3, bridgeTime++);
    assert(cc123Bridge.size() == 1);
    assert(cc123Bridge[0].status == 0xB0 && cc123Bridge[0].data1 == 123 && cc123Bridge[0].data2 == 0);
    assert(bridgeEngine.router().activeNoteRefs(0, 60) == 0);
    // TIME portamento: changing the time is state-only. Enabling it forces the
    // PA600's own (rate-based) portamento OFF on U1/U2/U3 with CC65 = 0.
    const auto quietTime = bridgeEngine.router().setPortamentoTimeMs(100);
    assert(quietTime.empty());
    const auto bridgePortaOn = bridgeEngine.router().setPortamentoEnabled(true);
    assert(bridgePortaOn.size() == 3);
    for (int ch = 0; ch < 3; ++ch) {
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].status == std::uint8_t(0xB0 | ch));
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].data1 == 65);
        assert(bridgePortaOn[static_cast<std::size_t>(ch)].data2 == 0);
    }
    assert(bridgeEngine.router().setPortamentoEnabled(false).empty());
    {
        MidiRouter r;
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        assert(r.syncPortamentoChannel(2).size() == 1 && hasCc(r.syncPortamentoChannel(2), 2, 65, 0));
        // Without the Pitch Bend transport no glide is generated and notes
        // pass unchanged; the app never sends CC5 per note.
        auto n1 = r.process(MidiMessage::noteOn(0, 60, 100), 0);
        auto n2 = r.process(MidiMessage::noteOn(0, 72, 100), 1000);
        assert(n1.size() == 1 && n2.size() == 1 && lastBendFor(n2, 0) == -1);
        for (const auto& m : n2) assert(!(m.isControlChange() && m.data1 == 5));
    }

    // ---- Equal-time glide, Local OFF bridge -------------------------------
    // The PA600 sends every key on U1, U2 and U3; each Upper glides on its own.
    {
        MidiRouter r;
        r.setPitchTransportEnabled(true);          // +/-12 transport
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        auto key = [&](int note, bool on, std::int64_t t) {
            std::vector<MidiMessage> all;
            for (int ch = 0; ch < 3; ++ch) {
                auto o = r.process(on ? MidiMessage::noteOn(ch, note, 100) : MidiMessage::noteOffZero(ch, note), t);
                // Per channel: the glide Pitch Bend precedes that channel's note.
                if (on && o.size() == 2) assert(o[0].isPitchBend() && o[1].isNoteOn());
                all.insert(all.end(), o.begin(), o.end());
            }
            return all;
        };
        auto first = key(60, true, 0);
        assert(first.size() == 3 && lastBendFor(first, 0) == -1);
        key(60, false, 10000);

        const std::int64_t t0 = 1000000;
        auto up2 = key(62, true, t0);
        for (int ch = 0; ch < 3; ++ch) assert(lastBendFor(up2, ch) == 6827);
        auto half = r.poll(t0 + 50000);
        for (int ch = 0; ch < 3; ++ch) assert(lastBendFor(half, ch) == 7509);
        auto done = r.poll(t0 + 100000);
        for (int ch = 0; ch < 3; ++ch) assert(lastBendFor(done, ch) == 8192);
        assert(r.poll(t0 + 150000).empty());
        key(62, false, t0 + 200000);

        const std::int64_t t1 = 2000000;
        auto up12 = key(74, true, t1);
        assert(lastBendFor(up12, 0) == 0);
        assert(lastBendFor(r.poll(t1 + 50000), 0) == 4096);
        assert(lastBendFor(r.poll(t1 + 99000), 0) != 8192);
        assert(lastBendFor(r.poll(t1 + 100000), 0) == 8192);
        key(74, false, t1 + 200000);

        const std::int64_t t2 = 3000000;
        auto down24 = key(50, true, t2);
        assert(lastBendFor(down24, 0) == 16383);
        assert(lastBendFor(r.poll(t2 + 100000), 0) == 8192);
        key(50, false, t2 + 200000);

        const std::int64_t t3 = 4000000;
        key(62, true, t3);
        r.poll(t3 + 50000);
        auto re = key(58, true, t3 + 50000);
        assert(lastBendFor(re, 0) == 6827);

        auto off = r.setPortamentoEnabled(false);
        assert(lastBendFor(off, 0) == 8192);
    }

    // ---- A muted (untransmitted) U1 never breaks U2 glide or TERCA ---------
    {
        MidiRouter r;
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        // SCAN from U2 only (U1 muted and not sent): C E G -> C major up.
        r.setThirdScanning(true);
        for (int n : {60, 64, 67}) r.process(MidiMessage::noteOn(1, n, 90), 1);
        for (int n : {60, 64, 67}) r.process(MidiMessage::noteOffZero(1, n), 2);
        assert(r.third().tonalityValid() && r.third().scanCell() == ThirdModule::ScanCell::MajorUp);
        auto c = r.process(MidiMessage::noteOn(1, 60, 100), 1000);
        assert(hasNote(c, 1, 60, true) && hasNote(c, 2, 64, true));
        r.process(MidiMessage::noteOffZero(1, 60), 2000);
        auto d = r.process(MidiMessage::noteOn(1, 62, 100), 1000000);
        assert(lastBendFor(d, 1) == 6827);          // U2 glides by itself
        assert(lastBendFor(d, 0) == -1);            // U1 untouched
        assert(hasNote(d, 2, 65, true) && lastBendFor(d, 2) == 7509);
        auto dOff = r.process(MidiMessage::noteOffZero(1, 62), 1100000);
        assert(hasNote(dOff, 2, 65, false));
    }

    // ---- Same key on U1 AND U2 -> exactly one third, ends after both offs ---
    {
        MidiRouter r;
        scanCMajor(r, 1);
        auto on1 = r.process(MidiMessage::noteOn(0, 60, 100), 1000);
        auto on2 = r.process(MidiMessage::noteOn(1, 60, 100), 1001);
        auto on3 = r.process(MidiMessage::noteOn(2, 60, 100), 1002);   // raw U3: suppressed
        assert(countNotes(on1, 2, 64, true) == 1 && countNotes(on2, 2, 64, true) == 0 && on3.empty());
        assert(hasNote(on1, 0, 60, true) && hasNote(on2, 1, 60, true));
        auto off1 = r.process(MidiMessage::noteOffZero(0, 60), 2000);
        assert(countNotes(off1, 2, 64, false) == 0);
        auto off2 = r.process(MidiMessage::noteOffZero(1, 60), 2001);
        assert(countNotes(off2, 2, 64, false) == 1);
        assert(r.process(MidiMessage::noteOffZero(2, 60), 2002).empty());
    }

    // ---- TERCA toggle never makes U3 glide across raw <-> terca lines ------
    {
        MidiRouter r;
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 100;
        r.setPortamentoConfig(pc);
        r.process(MidiMessage::noteOn(2, 72, 100), 0);          // raw U3 line at 72
        r.process(MidiMessage::noteOffZero(2, 72), 1000);
        scanCMajor(r, 2000);                                    // TERCA now owns U3
        auto c = r.process(MidiMessage::noteOn(0, 60, 100), 100000);
        assert(hasNote(c, 2, 64, true));
        assert(lastBendFor(c, 2) == -1);                        // first terca note: no glide from 72
    }

    // ---- Glide in Local ON with TERCA: U3 follows its own line of thirds ---
    {
        MidiRouter r;
        r.setKeyboardLocal(true);
        r.setPitchTransportEnabled(true);
        Portamento::Config pc;
        pc.enabled = true;
        pc.timeMs = 200;
        r.setPortamentoConfig(pc);
        scanCMajor(r, 10);
        auto c = r.process(MidiMessage::noteOn(0, 60, 100), 100000);   // first note, E on U3
        assert(hasNote(c, 2, 64, true) && lastBendFor(c, 0) == -1);
        r.process(MidiMessage::noteOffZero(0, 60), 150000);
        auto d = r.process(MidiMessage::noteOn(0, 62, 100), 200000);   // D: U1/U2 -2, U3 E->F = -1
        assert(!hasNote(d, 0, 62, true));                               // Local ON: no echo
        assert(lastBendFor(d, 0) == 6827 && lastBendFor(d, 1) == 6827);
        assert(lastBendFor(d, 2) == 7509 && hasNote(d, 2, 65, true));
        // The U3 glide Pitch Bend precedes the generated U3 note.
        std::size_t bendIdx = 99, noteIdx = 99;
        for (std::size_t i = 0; i < d.size(); ++i) {
            if (d[i].channel() == 2 && d[i].isPitchBend()) bendIdx = i;
            if (d[i].channel() == 2 && d[i].isNoteOn()) noteIdx = i;
        }
        assert(bendIdx < noteIdx);
        auto mid = r.poll(300000);                                      // halfway
        assert(lastBendFor(mid, 0) == 7509);
        assert(lastBendFor(mid, 2) == 7851);                            // -0.5 st
        auto end = r.poll(400000);
        assert(lastBendFor(end, 0) == 8192 && lastBendFor(end, 2) == 8192);
    }

    // activeNotes/lastNote reference counting: 9n NN 00 is a real Note Off.
    MidiRouter notes;
    notes.process(MidiMessage::noteOn(0, 60, 100), 0);
    notes.process(MidiMessage::noteOn(0, 60, 110), 1);
    assert(notes.activeNoteRefs(0, 60) == 2);
    assert(notes.lastNote(0) == 60);
    notes.process(MidiMessage{0x90, 60, 0, 3}, 2);
    assert(notes.activeNoteRefs(0, 60) == 1);
    notes.process(MidiMessage::noteOff(0, 60, 0), 3);
    assert(notes.activeNoteRefs(0, 60) == 0);
    assert(notes.lastNote(0) == -1);

    // Non-Upper stays transparent.
    auto pass = notes.process(MidiMessage::noteOn(3, 48, 100), 4);
    assert(pass.size() == 1 && pass[0].status == 0x93);

    // SCAN cancel: scan Note On and its later release never leak.
    MidiRouter scanCancel;
    scanCancel.setThirdScanning(true);
    assert(scanCancel.process(MidiMessage::noteOn(0, 60, 100), 10000).empty());
    scanCancel.setThirdScanning(false);
    assert(!scanCancel.thirdScanning());
    assert(scanCancel.process(MidiMessage::noteOffZero(0, 60), 10100).empty());
    auto normalAfterCancel = scanCancel.process(MidiMessage::noteOn(0, 62, 100), 10200);
    assert(hasNote(normalAfterCancel, 0, 62, true));

    // Fixed C-major tonality; TERCA is strictly U3, never U2.
    MidiRouter harmony;
    scanCMajor(harmony, 20000);
    auto cOn = harmony.process(MidiMessage::noteOn(0, 60, 100), 21000);
    assert(hasNote(cOn, 0, 60, true));
    assert(hasNote(cOn, 2, 64, true));
    assert(!hasNote(cOn, 1, 64, true));
    const MidiMessage* tercOn = nullptr;
    for (const auto& m : cOn) if (m.channel() == 2 && m.isNoteOn()) tercOn = &m;
    assert(tercOn != nullptr && tercOn->status == 0x92 && tercOn->data1 == 0x40 && tercOn->data2 == 0x64);

    auto cOff = harmony.process(MidiMessage{0x90, 60, 0, 3}, 21100);
    assert(hasNote(cOff, 0, 60, false));
    bool exactTercaOff = false;
    for (const auto& m : cOff) {
        if (m.status == 0x92 && m.data1 == 0x40 && m.data2 == 0x00) exactTercaOff = true;
    }
    assert(exactTercaOff);

    // C-major mapping and out-of-scale policy.
    const int src[7] = {60, 62, 64, 65, 67, 69, 71};
    const int dst[7] = {64, 65, 67, 69, 71, 72, 74};
    for (int i = 0; i < 7; ++i) {
        auto on = harmony.process(MidiMessage::noteOn(0, src[i], 90), 22000 + i * 100);
        assert(hasNote(on, 2, dst[i], true));
        auto off = harmony.process(MidiMessage::noteOffZero(0, src[i]), 22100 + i * 100);
        assert(hasNote(off, 2, dst[i], false));
    }
    // Out-of-scale note in C major: C# gets the in-scale minor third E.
    auto outside = harmony.process(MidiMessage::noteOn(0, 61, 100), 23000);
    assert(hasNote(outside, 2, 64, true));
    harmony.process(MidiMessage::noteOffZero(0, 61), 23100);

    // The wheel is never swallowed by SCAN (centre during SCAN must arrive).
    {
        MidiRouter w;
        w.process(MidiMessage::pitchBend(0, 16000), 1);
        w.setThirdScanning(true);
        auto centre = w.process(MidiMessage::pitchBend(0, 8192), 2);
        assert(lastBendFor(centre, 0) == 8192);
        w.setThirdScanning(false);
    }

    // Safety sweep: releasing the last U1 source sends CC123 on U3.
    {
        MidiRouter sw;
        sw.setKeyboardLocal(true);
        scanCMajor(sw, 1);
        sw.process(MidiMessage::noteOn(0, 60, 100), 100);
        sw.process(MidiMessage::noteOn(0, 64, 100), 200);
        auto partial = sw.process(MidiMessage::noteOffZero(0, 60), 300);
        assert(hasNote(partial, 2, 64, false) && !hasCc(partial, 2, 123, 0));
        auto last = sw.process(MidiMessage::noteOffZero(0, 64), 400);
        assert(hasNote(last, 2, 67, false) && hasCc(last, 2, 123, 0));
        assert(sw.activeNoteRefs(2, 67) == 0);
        for (const auto& m : last) assert(m.channel() == 2);   // never touches U1/U2
    }

    // The user's case: D phrygian (scan D Eb F). E -> G and B -> D.
    {
        MidiRouter dp;
        dp.setKeyboardLocal(true);
        dp.setThirdScanning(true);
        dp.process(MidiMessage::noteOn(0, 62, 90), 1);
        dp.process(MidiMessage::noteOn(0, 63, 90), 2);
        dp.process(MidiMessage::noteOn(0, 65, 90), 3);
        dp.process(MidiMessage::noteOffZero(0, 62), 4);
        dp.process(MidiMessage::noteOffZero(0, 63), 5);
        dp.process(MidiMessage::noteOffZero(0, 65), 6);
        assert(dp.third().scanCell() == ThirdModule::ScanCell::PhrygianUp && dp.third().rootPitchClass() == 2);
        auto e = dp.process(MidiMessage::noteOn(0, 64, 100), 10);
        assert(e.size() == 1 && e[0].status == 0x92 && e[0].data1 == 67);
        dp.process(MidiMessage::noteOffZero(0, 64), 11);
        auto b = dp.process(MidiMessage::noteOn(0, 71, 100), 12);
        assert(b.size() == 1 && b[0].status == 0x92 && b[0].data1 == 74);
        dp.process(MidiMessage::noteOffZero(0, 71), 13);
    }

    // Generated TERCA ownership: duplicate source note cannot be killed early.
    auto dup1 = harmony.process(MidiMessage::noteOn(0, 60, 100), 24000);
    auto dup2 = harmony.process(MidiMessage::noteOn(0, 60, 100), 24100);
    assert(countNotes(dup1, 2, 64, true) == 1);
    assert(countNotes(dup2, 2, 64, true) == 0);
    auto dupOff1 = harmony.process(MidiMessage::noteOffZero(0, 60), 24200);
    assert(countNotes(dupOff1, 2, 64, false) == 0);
    auto dupOff2 = harmony.process(MidiMessage::noteOffZero(0, 60), 24300);
    assert(countNotes(dupOff2, 2, 64, false) == 1);

    // Raw U3 is suppressed only while TERCA owns it.
    assert(harmony.process(MidiMessage::noteOn(2, 70, 100), 25000).empty());
    harmony.setThirdEnabled(false);
    auto freeU3 = harmony.process(MidiMessage::noteOn(2, 70, 100), 25100);
    assert(hasNote(freeU3, 2, 70, true));
    harmony.process(MidiMessage::noteOffZero(2, 70), 25200);

    // CC123 on U1 must also terminate generated U3 state.
    harmony.setThirdEnabled(true);
    auto gen = harmony.process(MidiMessage::noteOn(0, 62, 100), 26000);
    assert(hasNote(gen, 2, 65, true));
    auto allOffU1 = harmony.process(MidiMessage::controlChange(0, 123, 0), 26100);
    assert(hasNote(allOffU1, 2, 65, false));
    assert(hasCc(allOffU1, 0, 123, 0));
    assert(harmony.activeNoteRefs(0, 62) == 0);
    assert(harmony.activeNoteRefs(2, 65) == 0);

    // With pitch transport disabled (the Local-OFF baseline), physical Pitch
    // Bend is byte-for-byte transparent and Ribbon produces no background
    // output. This is the bridge state before Ribbon is actually touched.
    MidiRouter transparentBridge;
    const MidiMessage rawPitch{0xE0, 0x7F, 0x7F, 3};
    const auto rawPitchOut = transparentBridge.process(rawPitch, 29000);
    assert(rawPitchOut.size() == 1);
    assert(rawPitchOut[0].status == 0xE0 && rawPitchOut[0].data1 == 0x7F && rawPitchOut[0].data2 == 0x7F);
    transparentBridge.ribbonMove(1.0, 29100);
    assert(transparentBridge.poll(35000).empty());

    // A physical wheel position seen while the bridge is transparent must be
    // remembered. Switching to the +/-12 Ribbon transport must preserve the
    // same musical +/-2 wheel offset instead of jumping to center/full scale.
    MidiRouter heldWheelRouter;
    const auto heldRaw = heldWheelRouter.process(MidiMessage::pitchBend(0, 16383), 29500);
    assert(lastBendFor(heldRaw, 0) == 16383);
    const auto heldEnable = heldWheelRouter.setPitchTransportEnabled(true);
    assert(lastBendFor(heldEnable, 0) == 9557);

    // Ribbon remains an independent smooth 14-bit lane on all Uppers once the
    // Android layer has intentionally enabled the +/-12 pitch transport.
    MidiRouter ribbonRouter;
    auto enablePitchTransport = ribbonRouter.setPitchTransportEnabled(true);
    assert(lastBendFor(enablePitchTransport, 0) == 8192);
    assert(lastBendFor(enablePitchTransport, 1) == 8192);
    assert(lastBendFor(enablePitchTransport, 2) == 8192);
    ribbonRouter.ribbon().setRangeSemitones(3);
    ribbonRouter.ribbon().setSensitivity(1.0);
    ribbonRouter.ribbonMove(1.0, 30000);
    int last = 8192;
    for (std::int64_t t = 32000; t <= 250000; t += 2000) {
        const auto step = ribbonRouter.poll(t);
        const int b0 = lastBendFor(step, 0);
        if (b0 >= 0) {
            assert(b0 >= last);
            last = b0;
            assert(lastBendFor(step, 1) == b0);
            assert(lastBendFor(step, 2) == b0);
        }
    }
    assert(last > 8192);
    ribbonRouter.ribbonMove(0.0, 252000);
    int center = -1;
    for (std::int64_t t = 254000; t <= 600000; t += 2000) {
        const auto step = ribbonRouter.poll(t);
        const int b0 = lastBendFor(step, 0);
        if (b0 >= 0) center = b0;
    }
    assert(center == 8192);

    // Physical bend is composed with Ribbon and portamento never touches it.
    const auto manual = ribbonRouter.process(MidiMessage::pitchBend(0, 16383), 610000);
    const int manualBend = lastBendFor(manual, 0);
    assert(manualBend > 8192);
    const auto forcedPitch = ribbonRouter.syncPitchChannel(0);
    assert(lastBendFor(forcedPitch, 0) == manualBend);

    // Panic: exact known note releases + CC123 + CC120 + centered pitch, state clear.
    MidiRouter panicRouter;
    panicRouter.process(MidiMessage::noteOn(0, 60, 100), 0);
    panicRouter.process(MidiMessage::noteOn(1, 64, 100), 1);
    auto panic = panicRouter.panic();
    assert(hasNote(panic, 0, 60, false));
    assert(hasNote(panic, 1, 64, false));
    for (int ch = 0; ch < 3; ++ch) {
        assert(hasCc(panic, ch, 123, 0));
        assert(hasCc(panic, ch, 120, 0));
        assert(lastBendFor(panic, ch) == 8192);
        assert(panicRouter.lastNote(ch) == -1);
    }
    assert(panicRouter.activeNoteRefs(0, 60) == 0);
    assert(panicRouter.activeNoteRefs(1, 64) == 0);

    // JNI-facing native class uses the same authoritative router and treats
    // 90 NN 00 as Note Off.
    NativeMidiEngine native;
    native.handleMidiIn(0x90, 60, 100, 3, 0);
    assert(native.router().activeNoteRefs(0, 60) == 1);
    native.handleMidiIn(0x90, 60, 0, 3, 1);
    assert(native.router().activeNoteRefs(0, 60) == 0);
    assert(native.router().lastNote(0) == -1);


    // ---------------------------------------------------------------------
    // TERCA: all six SCAN cells, all 12 tonalities, explicit expected notes.
    // Expected tables are written out by hand for tonic C and transposed.
    // ---------------------------------------------------------------------
    struct CellCase {
        ThirdModule::ScanCell cell;
        int scanPcs[3];
        int dir;
        int src[7];
        int dst[7];
    };
    const CellCase cellCases[6] = {
        {ThirdModule::ScanCell::MajorUp,    {0, 4, 7}, +1,
         {60, 62, 64, 65, 67, 69, 71}, {64, 65, 67, 69, 71, 72, 74}},
        {ThirdModule::ScanCell::MajorDown,  {0, 2, 4}, -1,
         {60, 62, 64, 65, 67, 69, 71}, {57, 59, 60, 62, 64, 65, 67}},
        {ThirdModule::ScanCell::MinorUp,    {0, 3, 7}, +1,
         {60, 62, 63, 65, 67, 68, 70}, {63, 65, 67, 68, 70, 72, 74}},
        {ThirdModule::ScanCell::MinorDown,  {0, 2, 3}, -1,
         {60, 62, 63, 65, 67, 68, 70}, {56, 58, 60, 62, 63, 65, 67}},
        {ThirdModule::ScanCell::PhrygianUp, {0, 1, 3}, +1,
         {60, 61, 63, 65, 67, 68, 70}, {63, 65, 67, 68, 70, 72, 73}},
        {ThirdModule::ScanCell::HijazUp,    {0, 1, 4}, +1,
         {60, 61, 64, 65, 67, 68, 70}, {64, 65, 67, 68, 70, 72, 73}},
    };
    for (const auto& cc : cellCases) {
        for (int root = 0; root < 12; ++root) {
            for (int local = 0; local < 2; ++local) {
                MidiRouter r;
                r.setKeyboardLocal(local == 1);
                r.setThirdScanning(true);
                // Scan in a different octave and in inversion (top note first,
                // highest note dropped an octave) to prove pitch-class matching.
                const int n0 = 72 + ((root + cc.scanPcs[2]) % 12);
                const int n1 = 48 + ((root + cc.scanPcs[0]) % 12);
                const int n2 = 60 + ((root + cc.scanPcs[1]) % 12);
                r.process(MidiMessage::noteOn(0, n0, 90), 1);
                r.process(MidiMessage::noteOn(0, n1, 90), 2);
                r.process(MidiMessage::noteOn(0, n2, 90), 3);
                r.process(MidiMessage::noteOffZero(0, n0), 4);
                r.process(MidiMessage::noteOffZero(0, n1), 5);
                r.process(MidiMessage::noteOffZero(0, n2), 6);
                assert(r.third().scanState() == ThirdModule::ScanState::Locked);
                assert(r.third().tonalityValid());
                assert(r.third().scanCell() == cc.cell);
                assert(r.third().rootPitchClass() == root);
                assert(r.third().direction() == cc.dir);
                assert(r.thirdScanResult() == 1 + root + 12 * static_cast<int>(cc.cell));
                for (int i = 0; i < 7; ++i) {
                    const int s = cc.src[i] + root;
                    const int d = cc.dst[i] + root;
                    auto on = r.process(MidiMessage::noteOn(0, s, 100), 100 + i);
                    assert(hasNote(on, 2, d, true));
                    assert(countNotes(on, 2, d, true) == 1);
                    // Local ON never echoes the played U1 note.
                    assert(hasNote(on, 0, s, true) == (local == 0));
                    auto off = r.process(MidiMessage::noteOffZero(0, s), 200 + i);
                    assert(hasNote(off, 2, d, false));
                }
                // Every out-of-scale note also gets a third: the minor third if
                // it lands in the scale, else the major third, else minor.
                for (int pc = 0; pc < 12; ++pc) {
                    bool inScale = false;
                    for (int i = 0; i < 7; ++i) if ((cc.src[i] - 60) == pc) inScale = true;
                    if (inScale) continue;
                    auto scaleHas = [&](int rel) {
                        const int m = ((rel % 12) + 12) % 12;
                        for (int i = 0; i < 7; ++i) if ((cc.src[i] - 60) == m) return true;
                        return false;
                    };
                    int delta = 3 * cc.dir;
                    if (!scaleHas(pc + 3 * cc.dir) && scaleHas(pc + 4 * cc.dir)) delta = 4 * cc.dir;
                    const int s = 60 + ((root + pc) % 12);
                    auto chrom = r.process(MidiMessage::noteOn(0, s, 100), 300 + pc);
                    assert(hasNote(chrom, 2, s + delta, true));
                    auto chromOff = r.process(MidiMessage::noteOffZero(0, s), 400 + pc);
                    assert(hasNote(chromOff, 2, s + delta, false));
                }
            }
        }
    }
    // Non-triad / unknown shapes never lock.
    {
        MidiRouter r;
        r.setThirdScanning(true);
        r.process(MidiMessage::noteOn(0, 60, 90), 1);
        r.process(MidiMessage::noteOn(0, 66, 90), 2);
        r.process(MidiMessage::noteOn(0, 70, 90), 3);
        assert(r.thirdScanning());
        assert(!r.third().tonalityValid());
    }

    // ---------------------------------------------------------------------
    // Local Control ON: nothing from the keyboard is ever echoed back.
    // ---------------------------------------------------------------------
    {
        MidiRouter r;
        r.setKeyboardLocal(true);
        assert(r.process(MidiMessage::noteOn(0, 60, 100), 1).empty());
        assert(r.process(MidiMessage::noteOn(1, 60, 100), 2).empty());
        assert(r.process(MidiMessage::noteOn(2, 60, 100), 3).empty());
        assert(r.process(MidiMessage::noteOn(3, 48, 100), 4).empty());      // Lower
        assert(r.process(MidiMessage::noteOn(9, 36, 100), 5).empty());      // style drum
        assert(r.process(MidiMessage::controlChange(0, 64, 127), 6).empty()); // damper
        assert(r.process(MidiMessage::pitchBend(0, 12000), 7).empty());
        assert(r.process(MidiMessage{0xC0, 5, 0, 2}, 8).empty());
        assert(r.process(MidiMessage::controlChange(0, 123, 0), 9).empty());
        assert(r.process(MidiMessage::noteOffZero(0, 60), 10).empty());
        // Enabling TIME portamento still forces Korg portamento OFF (CC65 = 0).
        auto pOn = r.setPortamentoEnabled(true);
        assert(pOn.size() == 3 && hasCc(pOn, 0, 65, 0) && hasCc(pOn, 2, 65, 0));
        // Starting SCAN must not send CC123 to the keyboard's own U1/U2.
        auto scanStart = r.setThirdScanning(true);
        for (const auto& m : scanStart) assert(!(m.isControlChange() && m.data1 == 123));
        r.process(MidiMessage::noteOn(0, 62, 90), 20);
        r.process(MidiMessage::noteOn(0, 65, 90), 21);
        r.process(MidiMessage::noteOn(0, 69, 90), 22);   // D minor, third up
        r.process(MidiMessage::noteOffZero(0, 62), 23);
        r.process(MidiMessage::noteOffZero(0, 65), 24);
        r.process(MidiMessage::noteOffZero(0, 69), 25);
        assert(r.third().scanCell() == ThirdModule::ScanCell::MinorUp && r.third().rootPitchClass() == 2);
        auto on = r.process(MidiMessage::noteOn(0, 74, 100), 30);   // D5 -> F5
        assert(on.size() == 1 && on[0].status == 0x92 && on[0].data1 == 77 && on[0].data2 == 100);
        // CC123 on U1 releases only the generated U3 note, without echoing CC123.
        auto kill = r.process(MidiMessage::controlChange(0, 123, 0), 31);
        assert(hasNote(kill, 2, 77, false));
        assert(!hasCc(kill, 0, 123, 0));
        assert(r.activeNoteRefs(2, 77) == 0);
        // With Ribbon active, a wheel move re-asserts wheel+Ribbon as one value.
        r.setPitchTransportEnabled(true);
        auto wheel = r.process(MidiMessage::pitchBend(0, 16383), 40);
        assert(lastBendFor(wheel, 0) == 9557);
        // Leaving the Ribbon transport re-asserts the raw wheel value (+/-2 scale).
        auto leave = r.setPitchTransportEnabled(false);
        assert(lastBendFor(leave, 0) == 16383);
        assert(lastBendFor(leave, 1) == 8192 && lastBendFor(leave, 2) == 8192);
        assert(r.poll(1000000).empty());
    }

    std::cout << "SILVETON LIVE MIDI full low-level regression tests passed\n";
    return 0;
}
