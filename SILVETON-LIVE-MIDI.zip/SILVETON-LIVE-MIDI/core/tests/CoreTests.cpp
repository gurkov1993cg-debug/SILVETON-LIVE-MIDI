#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include <cassert>
#include <cmath>
#include <iostream>

using namespace silveton;

static int bend(const MidiMessage& m) { return m.pitchBend14(); }

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0, "Upper 1 must be MIDI channel 1");
    static_assert(KorgProfile::upperChannels[1] == 1, "Upper 2 must be MIDI channel 2");
    static_assert(KorgProfile::upperChannels[2] == 2, "Upper 3 must be MIDI channel 3");

    MidiRouter router;
    Portamento::Config cfg;
    cfg.enabled = true;
    cfg.glideMs = 180;
    cfg.bendRangeSemitones = 12;
    cfg.updateIntervalUs = 1000;
    cfg.curve = Portamento::CurveMode::Fib;
    router.portamento().setConfig(cfg);

    auto pass = router.process(MidiMessage::noteOn(3, 48, 100), 0);
    assert(pass.size() == 1);
    assert(pass[0].status == 0x93 && pass[0].data1 == 48);

    auto first = router.process(MidiMessage::noteOn(0, 60, 100), 1000);
    assert(first.size() == 2);
    assert(first[0].isPitchBend() && bend(first[0]) == 8192);
    assert(first[1].isNoteOn() && first[1].data1 == 60);

    auto second = router.process(MidiMessage::noteOn(0, 67, 100), 10000);
    assert(second.size() == 3);
    assert(second[0].isNoteOff() && second[0].data1 == 60);
    assert(second[1].isPitchBend());
    const int expectedStart = int(std::lround(8192.0 - (7.0 / 12.0) * 8192.0));
    assert(std::abs(bend(second[1]) - expectedStart) <= 1);
    assert(second[2].isNoteOn() && second[2].data1 == 67);

    auto mid = router.poll(10000 + 90000);
    assert(!mid.empty());
    assert(mid.back().isPitchBend());
    assert(bend(mid.back()) > expectedStart && bend(mid.back()) < 8192);

    auto end = router.poll(10000 + 180000);
    assert(!end.empty());
    assert(bend(end.back()) == 8192);

    auto back = router.process(MidiMessage::noteOff(0, 67, 0), 200000);
    assert(back.size() == 3);
    assert(back[0].isNoteOff() && back[0].data1 == 67);
    assert(back[1].isPitchBend());
    assert(back[2].isNoteOn() && back[2].data1 == 60);

    auto manual = router.process(MidiMessage::pitchBend(0, 10240), 220000);
    assert(manual.size() <= 1);
    if (!manual.empty()) assert(manual[0].isPitchBend());

    auto u2 = router.process(MidiMessage::noteOn(1, 64, 90), 300000);
    assert(!u2.empty());
    assert(u2.back().channel() == 1);

    // TERCA uses the real Upper 3 stream and is gated by ON/OFF.
    auto u3Muted = router.process(MidiMessage::noteOn(2, 72, 90), 300000);
    assert(u3Muted.empty());
    auto thirdOn = router.setThirdEnabled(true);
    assert(!thirdOn.empty());
    for (const auto& m : thirdOn) assert(m.channel() == 2);
    auto u3 = router.process(MidiMessage::noteOn(2, 74, 90), 310000);
    assert(!u3.empty());
    assert(u3.back().channel() == 2);

    // SCAN TERCA detects a real minor/major third between Upper 1 and Upper 3.
    router.startThirdScan();
    router.process(MidiMessage::noteOn(0, 60, 100), 400000);
    router.process(MidiMessage::noteOn(2, 64, 100), 400500);
    assert(router.thirdScanResult() == 4);

    // Turning TERCA off must emit cleanup for Upper 3.
    auto thirdOff = router.setThirdEnabled(false);
    assert(!thirdOff.empty());
    for (const auto& m : thirdOff) assert(m.channel() == 2);

    // Ribbon is a real pitch source and is combined by Portamento on all Upper channels.
    router.ribbon().setSensitivity(1.0);
    auto rb = router.ribbonMove(0.5, 500000);
    assert(!rb.empty());
    for (const auto& m : rb) {
        assert(m.isPitchBend());
        assert(KorgProfile::isUpperChannel(m.channel()));
        assert(m.channel() != 2); // TERCA is currently OFF, so real Upper 3 stays muted.
    }

    auto center = router.ribbonMove(0.0, 510000);
    assert(!center.empty());

    // All four curve modes are live and preserve the same exact total duration.
    for (int mode = 0; mode < 4; ++mode) {
        auto c = router.portamento().config();
        c.curve = static_cast<Portamento::CurveMode>(mode);
        c.glideMs = 180;
        router.portamento().setConfig(c);
        router.panic();
        router.process(MidiMessage::noteOn(0, 60, 100), 600000 + mode * 300000);
        router.process(MidiMessage::noteOn(0, 67, 100), 610000 + mode * 300000);
        auto e = router.poll(790000 + mode * 300000);
        assert(!e.empty());
        assert(e.back().isPitchBend() && bend(e.back()) == 8192);
    }

    auto p = router.panic();
    assert(!p.empty());
    for (const auto& m : p) assert(KorgProfile::isUpperChannel(m.channel()));

    std::cout << "SILVETON LIVE MIDI core tests passed\n";
    return 0;
}
