#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include <cassert>
#include <cmath>
#include <iostream>

using namespace silveton;

static bool hasNote(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) return true;
    }
    return false;
}

static int lastBendFor(const std::vector<MidiMessage>& v, int ch) {
    int value = -1;
    for (const auto& m : v) if (m.channel() == ch && m.isPitchBend()) value = m.pitchBend14();
    return value;
}

static void noteCycle(MidiRouter& router, int note, int expectedHarmony, std::int64_t t) {
    auto on = router.process(MidiMessage::noteOn(0, note, 100), t);
    assert(hasNote(on, 0, note, true));
    if (expectedHarmony >= 0) assert(hasNote(on, 2, expectedHarmony, true));
    else {
        for (const auto& m : on) assert(!(m.channel() == 2 && m.isNoteOn()));
    }
    auto off = router.process(MidiMessage::noteOff(0, note, 0), t + 1000);
    assert(hasNote(off, 0, note, false));
    if (expectedHarmony >= 0) assert(hasNote(off, 2, expectedHarmony, false));
}

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0);
    static_assert(KorgProfile::upperChannels[1] == 1);
    static_assert(KorgProfile::upperChannels[2] == 2);

    MidiRouter router;
    Portamento::Config cfg;
    cfg.enabled = true;
    cfg.glideMs = 180;
    cfg.bendRangeSemitones = 12;
    cfg.updateIntervalUs = 1000;
    cfg.curve = Portamento::CurveMode::Fib;
    router.portamento().setConfig(cfg);

    // Non-Upper stays transparent.
    auto pass = router.process(MidiMessage::noteOn(3, 48, 100), 0);
    assert(pass.size() == 1 && pass[0].status == 0x93);

    // Portamento: one semitone must glide immediately.
    auto p1 = router.process(MidiMessage::noteOn(0, 60, 100), 1000);
    assert(hasNote(p1, 0, 60, true));
    auto p2 = router.process(MidiMessage::noteOn(0, 61, 100), 10000);
    assert(hasNote(p2, 0, 60, false));
    assert(hasNote(p2, 0, 61, true));
    const int expectedMinusOne = int(std::lround(8192.0 - (1.0 / 12.0) * 8192.0));
    assert(std::abs(lastBendFor(p2, 0) - expectedMinusOne) <= 2);
    auto pEnd = router.poll(190000);
    assert(lastBendFor(pEnd, 0) == 8192);

    // Portamento OFF is transparent and can be enabled again without stale glide state.
    router.panic();
    router.setPortamentoEnabled(false);
    auto d1 = router.process(MidiMessage::noteOn(0, 64, 100), 210000);
    auto d2 = router.process(MidiMessage::noteOn(0, 65, 100), 220000);
    assert(d1.size() == 1 && d1[0].isNoteOn());
    assert(d2.size() == 1 && d2[0].isNoteOn());
    router.process(MidiMessage::noteOff(0, 64, 0), 221000);
    router.process(MidiMessage::noteOff(0, 65, 0), 222000);
    router.setPortamentoEnabled(true);

    // TERCA SCAN is an explicit mode: first press starts, second press cancels.
    const auto rev0 = router.third().scanRevision();
    // Cancelling must never destroy the last valid tonality or ON/OFF state.
    router.setThirdScanning(true);
    assert(router.thirdScanning());
    auto muted = router.process(MidiMessage::noteOn(0, 60, 100), 300000);
    assert(muted.empty());
    router.setThirdScanning(false);
    assert(!router.thirdScanning());
    assert(router.thirdScanResult() == 0);
    assert(router.third().scanRevision() == rev0);

    // Invalid combinations stay silent in SCAN until the user cancels or a valid
    // triad is entered.  They must not mutate the locked tonality.
    router.setThirdScanning(true);
    assert(router.thirdScanning());
    assert(router.process(MidiMessage::noteOn(0, 60, 100), 310000).empty());
    assert(router.process(MidiMessage::noteOn(0, 61, 100), 310100).empty());
    assert(router.process(MidiMessage::noteOn(0, 67, 100), 310200).empty());
    assert(router.thirdScanning());
    router.setThirdScanning(false);
    assert(!router.thirdScanning());
    router.process(MidiMessage::noteOff(0, 60, 0), 311000);
    router.process(MidiMessage::noteOff(0, 61, 0), 311100);
    router.process(MidiMessage::noteOff(0, 67, 0), 311200);

    router.setThirdScanning(true);
    assert(router.thirdScanning());
    assert(router.process(MidiMessage::noteOn(0, 60, 100), 320000).empty()); // C
    assert(router.process(MidiMessage::noteOn(0, 64, 100), 320100).empty()); // E
    assert(router.process(MidiMessage::noteOn(0, 67, 100), 320200).empty()); // G
    assert(!router.thirdScanning());
    assert(router.third().tonalityValid());
    assert(router.third().enabled()); // successful SCAN must enter TERCA play mode
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);
    assert(router.thirdScanResult() == 1); // encoded C major
    assert(router.third().scanRevision() == rev0 + 1);
    assert(router.third().scanSilenceActive());

    // Trailing U2/U3 packets belonging to the scan chord must stay silent even
    // though SCAN has already succeeded and stopped blinking.
    assert(router.process(MidiMessage::noteOn(1, 67, 100), 320250).empty());
    assert(router.process(MidiMessage::noteOn(2, 67, 100), 320260).empty());
    assert(router.process(MidiMessage::noteOff(0, 60, 0), 320300).empty());
    assert(router.process(MidiMessage::noteOff(0, 64, 0), 320400).empty());
    assert(router.process(MidiMessage::noteOff(0, 67, 0), 320500).empty());
    assert(!router.third().scanSilenceActive());
    // Stray releases after the latch opens are harmless due to the note ledger.
    assert(router.process(MidiMessage::noteOff(1, 67, 0), 320510).empty());
    assert(router.process(MidiMessage::noteOff(2, 67, 0), 320520).empty());
    router.panic();

    // TERCA OFF is authoritative even if the post-scan silence latch is active.
    router.setThirdScanning(true);
    assert(router.process(MidiMessage::noteOn(0, 60, 100), 321000).empty());
    assert(router.process(MidiMessage::noteOn(0, 64, 100), 321100).empty());
    assert(router.process(MidiMessage::noteOn(0, 67, 100), 321200).empty());
    assert(router.third().scanSilenceActive());
    router.setThirdEnabled(false);
    assert(!router.third().scanSilenceActive());
    router.panic();

    // A cancelled invalid scan leaves the previous C-major lock intact.
    router.setThirdEnabled(false);
    router.setThirdScanning(true);
    assert(router.process(MidiMessage::noteOn(0, 60, 100), 330000).empty());
    assert(router.process(MidiMessage::noteOn(0, 61, 100), 330100).empty());
    assert(router.process(MidiMessage::noteOn(0, 67, 100), 330200).empty());
    assert(router.thirdScanning());
    router.setThirdScanning(false);
    assert(!router.thirdScanning());
    assert(router.third().tonalityValid());
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);
    assert(!router.third().enabled());
    router.panic();

    // Fixed C-major tonality. TERCA never adapts itself after scan.
    router.setThirdEnabled(true);
    noteCycle(router, 60, 64, 400000); // C -> E
    noteCycle(router, 62, 65, 410000); // D -> F
    noteCycle(router, 64, 67, 420000); // E -> G
    noteCycle(router, 65, 69, 430000); // F -> A
    noteCycle(router, 67, 71, 440000); // G -> B
    noteCycle(router, 69, 72, 450000); // A -> C
    noteCycle(router, 71, 74, 460000); // B -> D
    noteCycle(router, 61, -1, 470000); // C# is outside C major: no harmony note
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);

    // Low-level CC123 on Upper 3 must clear BOTH the raw U3 lane and the
    // generated TERCA lane. Otherwise the synth can go silent while the
    // harmony engine still thinks its previous note is active.
    auto hOn = router.process(MidiMessage::noteOn(0, 60, 100), 475000);
    assert(hasNote(hOn, 2, 64, true));
    MidiMessage u3AllNotesOff{0xB2, 123, 0, 3};
    auto u3Reset = router.process(u3AllNotesOff, 475100);
    assert(hasNote(u3Reset, 2, 64, false));
    auto hFresh = router.process(MidiMessage::noteOn(0, 62, 100), 475200);
    assert(hasNote(hFresh, 2, 65, true));
    router.process(MidiMessage::noteOff(0, 62, 0), 475300);

    // While TERCA is ON, raw Upper 3 notes are owned/suppressed by TERCA.
    auto rawOwned = router.process(MidiMessage::noteOn(2, 70, 100), 480000);
    assert(rawOwned.empty());

    // When TERCA is OFF, Upper 3 is independent again and Portamento works on it.
    router.setThirdEnabled(false);
    auto u3a = router.process(MidiMessage::noteOn(2, 70, 100), 490000);
    auto u3b = router.process(MidiMessage::noteOn(2, 71, 100), 500000);
    assert(hasNote(u3a, 2, 70, true));
    assert(hasNote(u3b, 2, 70, false));
    assert(hasNote(u3b, 2, 71, true));
    assert(lastBendFor(u3b, 2) >= 0);
    router.panic();

    // Portamento OFF may pass polyphonic notes. Re-enabling/panic must silence
    // every emitted note, not only the most recent one.
    router.setPortamentoEnabled(false);
    router.process(MidiMessage::noteOn(0, 60, 100), 510000);
    router.process(MidiMessage::noteOn(0, 64, 100), 510100);
    auto reenableCleanup = router.setPortamentoEnabled(true);
    assert(hasNote(reenableCleanup, 0, 60, false));
    assert(hasNote(reenableCleanup, 0, 64, false));

    // Low-level note ownership: duplicate Note Off must not kill a different
    // currently sounding note, and repeated Note On requires matching releases.
    router.setPortamentoEnabled(true);
    router.process(MidiMessage::noteOn(0, 60, 100), 515000);
    router.process(MidiMessage::noteOn(0, 60, 100), 515100);
    auto firstRelease = router.process(MidiMessage::noteOff(0, 60, 0), 515200);
    assert(!hasNote(firstRelease, 0, 60, false));
    auto secondRelease = router.process(MidiMessage::noteOff(0, 60, 0), 515300);
    assert(hasNote(secondRelease, 0, 60, false));
    router.process(MidiMessage::noteOn(0, 64, 100), 515400);
    auto duplicateRelease = router.process(MidiMessage::noteOff(0, 60, 0), 515500);
    assert(duplicateRelease.empty());
    auto continueLegato = router.process(MidiMessage::noteOn(0, 65, 100), 515600);
    assert(hasNote(continueLegato, 0, 64, false));
    assert(hasNote(continueLegato, 0, 65, true));
    router.panic();

    // All Notes Off (CC123) must reset internal Portamento state as well as reach Korg.
    router.process(MidiMessage::noteOn(0, 60, 100), 520000);
    MidiMessage allNotesOff{0xB0, 123, 0, 3};
    auto ano = router.process(allNotesOff, 520100);
    assert(hasNote(ano, 0, 60, false));
    auto fresh = router.process(MidiMessage::noteOn(0, 67, 100), 530000);
    assert(hasNote(fresh, 0, 67, true));
    // Fresh phrase: no starting glide bend should be emitted away from centre.
    const int freshBend = lastBendFor(fresh, 0);
    assert(freshBend == -1 || freshBend == 8192);
    router.panic();

    // All Sound Off (CC120) must behave identically to CC123 for our state machine.
    router.process(MidiMessage::noteOn(0, 60, 100), 531000);
    MidiMessage allSoundOff{0xB0, 120, 0, 3};
    auto aso = router.process(allSoundOff, 531100);
    assert(hasNote(aso, 0, 60, false));
    auto fresh2 = router.process(MidiMessage::noteOn(0, 67, 100), 532000);
    assert(hasNote(fresh2, 0, 67, true));
    const int freshBend2 = lastBendFor(fresh2, 0);
    assert(freshBend2 == -1 || freshBend2 == 8192);
    router.panic();

    // Ribbon is independent and targets all three Upper tracks.
    // Range and sensitivity are independent parameters.
    router.ribbon().setRangeSemitones(2);
    router.ribbon().setSensitivity(1.0);
    auto rb = router.ribbonMove(1.0, 600000);
    assert(lastBendFor(rb, 0) > 8192);
    assert(lastBendFor(rb, 1) > 8192);
    assert(lastBendFor(rb, 2) > 8192);
    const int rbFullAt2 = lastBendFor(rb, 0);

    // Full travel is exactly the manually selected range, regardless of sensitivity.
    router.ribbon().setSensitivity(2.0);
    auto rbSameEnd = router.ribbonMove(-1.0, 600500);
    assert(lastBendFor(rbSameEnd, 0) < 8192);
    auto rbSameEndPositive = router.ribbonMove(1.0, 600750);
    assert(lastBendFor(rbSameEndPositive, 0) == rbFullAt2);

    // Manual semitone range is real and can be changed independently.
    router.ribbon().setRangeSemitones(3);
    auto rb3 = router.ribbonMove(1.0, 600900);
    assert(lastBendFor(rb3, 0) > rbFullAt2);
    assert(lastBendFor(rb3, 1) > rbFullAt2);
    assert(lastBendFor(rb3, 2) > rbFullAt2);

    // Restore the default response/range used below.
    router.ribbon().setRangeSemitones(2);
    router.ribbon().setSensitivity(1.0);
    rb = router.ribbonMove(1.0, 600950);

    // Portamento and Ribbon contributions are composed centrally, not by touching each other's state.
    router.process(MidiMessage::noteOn(1, 60, 100), 610000);
    auto composed = router.process(MidiMessage::noteOn(1, 61, 100), 620000);
    // Ribbon is +2 and portamento starts at -1 => final bend is still positive (~ +1 semitone).
    const int combined = lastBendFor(composed, 1);
    assert(combined > 8192);
    assert(combined < lastBendFor(rb, 1));

    // Turning TERCA on/off must not change Ribbon or Portamento configuration.
    const auto before = router.portamento().config();
    router.setThirdEnabled(true);
    router.setThirdEnabled(false);
    const auto after = router.portamento().config();
    assert(before.enabled == after.enabled);
    assert(before.glideMs == after.glideMs);
    assert(before.bendRangeSemitones == after.bendRangeSemitones);
    assert(before.curve == after.curve);

    auto panic = router.panic();
    assert(!panic.empty());
    for (const auto& m : panic) assert(KorgProfile::isUpperChannel(m.channel()));

    // Pitch bend state sync during SCAN gate.
    // The physical wheel may move while the scan chord is held or while the
    // post-scan silence latch is active.  PitchCoordinator must stay in sync
    // so the first note after the latch clears is not detuned.
    {
        MidiRouter scanBendRouter;
        Portamento::Config sbCfg;
        sbCfg.enabled = true;
        sbCfg.glideMs = 180;
        sbCfg.bendRangeSemitones = 12;
        sbCfg.updateIntervalUs = 1000;
        sbCfg.curve = Portamento::CurveMode::Fib;
        scanBendRouter.portamento().setConfig(sbCfg);

        // Start scan, play triad so scan succeeds.
        scanBendRouter.setThirdScanning(true);
        assert(scanBendRouter.process(MidiMessage::noteOn(0, 60, 100), 600000).empty());  // C
        assert(scanBendRouter.process(MidiMessage::noteOn(0, 64, 100), 600100).empty());  // E
        assert(scanBendRouter.process(MidiMessage::noteOn(0, 67, 100), 600200).empty());  // G
        assert(!scanBendRouter.thirdScanning());
        assert(scanBendRouter.third().scanSilenceActive());

        // Move physical pitch wheel while latch is active — output must be suppressed
        // but PitchCoordinator internal state must be updated.
        MidiMessage pbMoved = MidiMessage::pitchBend(0, 9000);  // above centre
        auto pbOut = scanBendRouter.process(pbMoved, 600300);
        assert(pbOut.empty());  // suppressed: still in scan silence latch

        // Release scan chord; latch clears.
        scanBendRouter.process(MidiMessage::noteOff(0, 60, 0), 600400);
        scanBendRouter.process(MidiMessage::noteOff(0, 64, 0), 600500);
        scanBendRouter.process(MidiMessage::noteOff(0, 67, 0), 600600);
        assert(!scanBendRouter.third().scanSilenceActive());

        // Play a note: PitchCoordinator should use the updated wheel position,
        // not the stale pre-scan value.  The emitted PB must reflect the moved wheel.
        // Without the fix, PitchCoordinator still has the old centre value (8192)
        // and would emit 8192, ignoring the mid-latch wheel movement.
        auto noteAfter = scanBendRouter.process(MidiMessage::noteOn(0, 62, 100), 600700);
        assert(hasNote(noteAfter, 0, 62, true));
        // The stored manualBend14 should be 9000; since portamento starts from centre
        // (no prior note), the composed PB must be above 8192.
        const int composedBend = lastBendFor(noteAfter, 0);
        assert(composedBend > 8192);

        scanBendRouter.panic();
    }

    std::cout << "SILVETON LIVE MIDI isolated-module tests passed\n";
    return 0;
}
