#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include <cassert>
#include <cmath>
#include <iostream>

using namespace silveton;

static int bend(const MidiMessage& m) { return m.pitchBend14(); }
static bool hasNote(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    for (const auto& m : v) {
        if (m.channel() == ch && m.data1 == note && (on ? m.isNoteOn() : m.isNoteOff())) return true;
    }
    return false;
}

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0);
    static_assert(KorgProfile::upperChannels[1] == 1);
    static_assert(KorgProfile::upperChannels[2] == 2);

    MidiRouter router;
    Portamento::Config cfg;
    cfg.enabled = true;
    cfg.glideMs = 180;
    cfg.bendRangeSemitones = 12;
    cfg.updateIntervalUs = 1000;
    cfg.curve = Portamento::CurveMode::Fib;
    router.portamento().setConfig(cfg);

    // Lower/non-Upper stays transparent.
    auto pass = router.process(MidiMessage::noteOn(3, 48, 100), 0);
    assert(pass.size() == 1 && pass[0].status == 0x93);

    // IMPORTANT regression: a one-semitone legato interval must produce real glide immediately.
    auto first = router.process(MidiMessage::noteOn(0, 60, 100), 1000);
    assert(hasNote(first, 0, 60, true));
    auto small = router.process(MidiMessage::noteOn(0, 61, 100), 10000);
    assert(hasNote(small, 0, 60, false));
    assert(hasNote(small, 0, 61, true));
    bool sawSmallBend = false;
    const int expectedSmall = int(std::lround(8192.0 - (1.0 / 12.0) * 8192.0));
    for (const auto& m : small) if (m.isPitchBend()) {
        sawSmallBend = true;
        assert(std::abs(bend(m) - expectedSmall) <= 1);
    }
    assert(sawSmallBend);
    auto smallEnd = router.poll(190000);
    assert(!smallEnd.empty() && smallEnd.back().isPitchBend() && bend(smallEnd.back()) == 8192);

    // Global Portamento OFF really bypasses glide.
    router.panic();
    router.setPortamentoEnabled(false);
    auto direct1 = router.process(MidiMessage::noteOn(0, 64, 100), 300000);
    auto direct2 = router.process(MidiMessage::noteOn(0, 65, 100), 310000);
    assert(direct1.size() == 1 && direct1[0].isNoteOn());
    assert(direct2.size() == 1 && direct2[0].isNoteOn());
    router.setPortamentoEnabled(true);

    // SCAN TERCA: all Upper sound is muted while scan is active.
    auto scanCleanup = router.startThirdScan();
    assert(router.thirdScanning());
    assert(!scanCleanup.empty());
    auto silentA = router.process(MidiMessage::noteOn(0, 60, 100), 400000);
    assert(silentA.empty());
    auto silentB = router.process(MidiMessage::noteOn(2, 64, 100), 400500);
    assert(silentB.empty());
    assert(!router.thirdScanning());
    assert(router.thirdScanResult() == 4);

    // TERCA ON is a real generator: Upper 1 C -> Upper 3 E.
    router.setThirdEnabled(true);
    auto harmony = router.process(MidiMessage::noteOn(0, 60, 100), 500000);
    assert(hasNote(harmony, 0, 60, true));
    assert(hasNote(harmony, 2, 64, true));
    auto harmonyOff = router.process(MidiMessage::noteOff(0, 60, 0), 520000);
    assert(hasNote(harmonyOff, 0, 60, false));
    assert(hasNote(harmonyOff, 2, 64, false));

    // Raw physical Upper 3 must not double the generated third.
    auto rawU3 = router.process(MidiMessage::noteOn(2, 70, 100), 530000);
    assert(rawU3.empty());

    // Ribbon is separate from manual Pitch Bend and targets Upper 2 + Upper 3 only.
    router.ribbon().setSensitivity(1.0);
    auto rb = router.ribbonMove(1.0, 600000);
    bool sawU2 = false, sawU3 = false;
    for (const auto& m : rb) {
        assert(m.isPitchBend());
        assert(m.channel() != 0); // never Upper 1
        if (m.channel() == 1) sawU2 = true;
        if (m.channel() == 2) sawU3 = true;
    }
    assert(sawU2 && sawU3);

    // TERCA OFF silences Upper 3 but Ribbon still remains on Upper 2.
    router.setThirdEnabled(false);
    auto rbOff = router.ribbonMove(-0.5, 610000);
    bool onlyU2Changed = false;
    for (const auto& m : rbOff) {
        assert(m.channel() != 0);
        if (m.channel() == 1) onlyU2Changed = true;
    }
    assert(onlyU2Changed);

    auto p = router.panic();
    assert(!p.empty());
    for (const auto& m : p) assert(KorgProfile::isUpperChannel(m.channel()));

    std::cout << "SILVETON LIVE MIDI core tests passed\n";
    return 0;
}
