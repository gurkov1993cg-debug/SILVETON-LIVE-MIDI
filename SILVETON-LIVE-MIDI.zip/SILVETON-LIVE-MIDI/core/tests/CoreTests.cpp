#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include <cassert>
#include <cmath>
#include <iostream>

using namespace silveton;

static int bend(const MidiMessage& m) { return m.pitchBend14(); }

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0, "Upper 1 must be MIDI channel 1");
    static_assert(KorgProfile::upperChannels[1] == 1, "Upper 2 must be MIDI channel 2");
    static_assert(KorgProfile::upperChannels[2] == 2, "Upper 3 must be MIDI channel 3");

    MidiRouter router;
    Portamento::Config cfg;
    cfg.enabled = true;
    cfg.glideMs = 180;
    cfg.bendRangeSemitones = 12;
    cfg.updateIntervalUs = 1000;
    router.portamento().setConfig(cfg);

    // Non-Upper passes through unchanged.
    auto pass = router.process(MidiMessage::noteOn(3, 48, 100), 0);
    assert(pass.size() == 1);
    assert(pass[0].status == 0x93 && pass[0].data1 == 48);

    // First note: bend center before Note On, no glide.
    auto first = router.process(MidiMessage::noteOn(0, 60, 100), 1000);
    assert(first.size() == 2);
    assert(first[0].isPitchBend() && bend(first[0]) == 8192);
    assert(first[1].isNoteOn() && first[1].data1 == 60);

    // C4 -> G4. Target note is re-anchored with -7 semitones, then glides to center.
    auto second = router.process(MidiMessage::noteOn(0, 67, 100), 10000);
    assert(second.size() == 3);
    assert(second[0].isNoteOff() && second[0].data1 == 60);
    assert(second[1].isPitchBend());
    const int expectedStart = int(std::lround(8192.0 - (7.0 / 12.0) * 8192.0));
    assert(std::abs(bend(second[1]) - expectedStart) <= 1);
    assert(second[2].isNoteOn() && second[2].data1 == 67);

    // Mid-glide should be between start and center.
    auto mid = router.poll(10000 + 90000);
    assert(!mid.empty());
    assert(mid.back().isPitchBend());
    assert(bend(mid.back()) > expectedStart && bend(mid.back()) < 8192);

    // Fixed-time end is exactly 180 ms independent of interval.
    auto end = router.poll(10000 + 180000);
    assert(!end.empty());
    assert(bend(end.back()) == 8192);

    // Release target while C is still held => glide back to C in the same 180ms duration.
    auto back = router.process(MidiMessage::noteOff(0, 67, 0), 200000);
    assert(back.size() == 3);
    assert(back[0].isNoteOff() && back[0].data1 == 67);
    assert(back[1].isPitchBend());
    assert(back[2].isNoteOn() && back[2].data1 == 60);

    // Manual pitch bend is combined instead of fighting Portamento.
    auto manual = router.process(MidiMessage::pitchBend(0, 10240), 220000);
    assert(manual.size() <= 1);
    if (!manual.empty()) assert(manual[0].isPitchBend());

    // Upper 2 and Upper 3 are independent state machines.
    auto u2 = router.process(MidiMessage::noteOn(1, 64, 90), 300000);
    auto u3 = router.process(MidiMessage::noteOn(2, 72, 90), 300000);
    assert(!u2.empty() && !u3.empty());
    assert(u2.back().channel() == 1);
    assert(u3.back().channel() == 2);

    // Panic must terminate active Upper voices and center bend.
    auto p = router.panic();
    assert(!p.empty());
    for (const auto& m : p) assert(KorgProfile::isUpperChannel(m.channel()));

    std::cout << "SILVETON LIVE MIDI core tests passed\n";
    return 0;
}
