#include "silveton/KorgProfile.h"
#include "silveton/MidiRouter.h"
#include <cassert>
#include <cmath>
#include <iostream>

using namespace silveton;

static bool hasNote(const std::vector<MidiMessage>& v, int ch, int note, bool on) {
    for (const auto& m : v) {
        if (m.channel() == ch && int(m.data1) == note && (on ? m.isNoteOn() : m.isNoteOff())) return true;
    }
    return false;
}

static int lastBendFor(const std::vector<MidiMessage>& v, int ch) {
    int value = -1;
    for (const auto& m : v) if (m.channel() == ch && m.isPitchBend()) value = m.pitchBend14();
    return value;
}

static void noteCycle(MidiRouter& router, int note, int expectedHarmony, std::int64_t t) {
    auto on = router.process(MidiMessage::noteOn(0, note, 100), t);
    assert(hasNote(on, 0, note, true));
    if (expectedHarmony >= 0) assert(hasNote(on, 2, expectedHarmony, true));
    else {
        for (const auto& m : on) assert(!(m.channel() == 2 && m.isNoteOn()));
    }
    auto off = router.process(MidiMessage::noteOff(0, note, 0), t + 1000);
    assert(hasNote(off, 0, note, false));
    if (expectedHarmony >= 0) assert(hasNote(off, 2, expectedHarmony, false));
}

int main() {
    static_assert(KorgProfile::upperChannels[0] == 0);
    static_assert(KorgProfile::upperChannels[1] == 1);
    static_assert(KorgProfile::upperChannels[2] == 2);

    MidiRouter router;
    Portamento::Config cfg;
    cfg.enabled = true;
    cfg.glideMs = 180;
    cfg.bendRangeSemitones = 12;
    cfg.updateIntervalUs = 1000;
    cfg.curve = Portamento::CurveMode::Fib;
    router.portamento().setConfig(cfg);

    // Non-Upper stays transparent.
    auto pass = router.process(MidiMessage::noteOn(3, 48, 100), 0);
    assert(pass.size() == 1 && pass[0].status == 0x93);

    // Portamento: one semitone must glide immediately.
    auto p1 = router.process(MidiMessage::noteOn(0, 60, 100), 1000);
    assert(hasNote(p1, 0, 60, true));
    auto p2 = router.process(MidiMessage::noteOn(0, 61, 100), 10000);
    assert(hasNote(p2, 0, 60, false));
    assert(hasNote(p2, 0, 61, true));
    const int expectedMinusOne = int(std::lround(8192.0 - (1.0 / 12.0) * 8192.0));
    assert(std::abs(lastBendFor(p2, 0) - expectedMinusOne) <= 2);
    auto pEnd = router.poll(190000);
    assert(lastBendFor(pEnd, 0) == 8192);

    // Portamento OFF is transparent and can be enabled again without stale glide state.
    router.panic();
    router.setPortamentoEnabled(false);
    auto d1 = router.process(MidiMessage::noteOn(0, 64, 100), 210000);
    auto d2 = router.process(MidiMessage::noteOn(0, 65, 100), 220000);
    assert(d1.size() == 1 && d1[0].isNoteOn());
    assert(d2.size() == 1 && d2[0].isNoteOn());
    router.process(MidiMessage::noteOff(0, 64, 0), 221000);
    router.process(MidiMessage::noteOff(0, 65, 0), 222000);
    router.setPortamentoEnabled(true);

    // TERCA SCAN toggle: first press starts, second press cancels. No stuck scan state.
    router.setThirdScanning(true);
    assert(router.thirdScanning());
    auto muted = router.process(MidiMessage::noteOn(0, 60, 100), 300000);
    assert(muted.empty());
    router.setThirdScanning(false);
    assert(!router.thirdScanning());
    assert(router.thirdScanResult() == 0);

    // Start again. Invalid triad stays in scan, then release and scan a valid C-major triad.
    router.setThirdScanning(true);
    assert(router.thirdScanning());
    assert(router.process(MidiMessage::noteOn(0, 60, 100), 310000).empty());
    assert(router.process(MidiMessage::noteOn(0, 61, 100), 310100).empty());
    assert(router.process(MidiMessage::noteOn(0, 67, 100), 310200).empty());
    assert(router.thirdScanning());
    router.process(MidiMessage::noteOff(0, 60, 0), 311000);
    router.process(MidiMessage::noteOff(0, 61, 0), 311100);
    router.process(MidiMessage::noteOff(0, 67, 0), 311200);

    assert(router.process(MidiMessage::noteOn(0, 60, 100), 320000).empty()); // C
    assert(router.process(MidiMessage::noteOn(0, 64, 100), 320100).empty()); // E
    assert(router.process(MidiMessage::noteOn(0, 67, 100), 320200).empty()); // G
    assert(!router.thirdScanning());
    assert(router.third().tonalityValid());
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);
    assert(router.thirdScanResult() == 1); // encoded C major
    router.panic();

    // Fixed C-major tonality. TERCA never adapts itself after scan.
    router.setThirdEnabled(true);
    noteCycle(router, 60, 64, 400000); // C -> E
    noteCycle(router, 62, 65, 410000); // D -> F
    noteCycle(router, 64, 67, 420000); // E -> G
    noteCycle(router, 65, 69, 430000); // F -> A
    noteCycle(router, 67, 71, 440000); // G -> B
    noteCycle(router, 69, 72, 450000); // A -> C
    noteCycle(router, 71, 74, 460000); // B -> D
    noteCycle(router, 61, -1, 470000); // C# is outside C major: no harmony note
    assert(router.third().rootPitchClass() == 0);
    assert(router.third().scaleMode() == ThirdModule::ScaleMode::Major);

    // While TERCA is ON, raw Upper 3 notes are owned/suppressed by TERCA.
    auto rawOwned = router.process(MidiMessage::noteOn(2, 70, 100), 480000);
    assert(rawOwned.empty());

    // When TERCA is OFF, Upper 3 is independent again and Portamento works on it.
    router.setThirdEnabled(false);
    auto u3a = router.process(MidiMessage::noteOn(2, 70, 100), 490000);
    auto u3b = router.process(MidiMessage::noteOn(2, 71, 100), 500000);
    assert(hasNote(u3a, 2, 70, true));
    assert(hasNote(u3b, 2, 70, false));
    assert(hasNote(u3b, 2, 71, true));
    assert(lastBendFor(u3b, 2) >= 0);
    router.panic();

    // Ribbon is independent and always targets Upper 2 + Upper 3, regardless of TERCA state.
    router.ribbon().setSensitivity(1.0);
    auto rb = router.ribbonMove(1.0, 600000);
    assert(lastBendFor(rb, 0) == -1);
    assert(lastBendFor(rb, 1) > 8192);
    assert(lastBendFor(rb, 2) > 8192);

    // Portamento and Ribbon contributions are composed centrally, not by touching each other's state.
    router.process(MidiMessage::noteOn(1, 60, 100), 610000);
    auto composed = router.process(MidiMessage::noteOn(1, 61, 100), 620000);
    // Ribbon is +2 and portamento starts at -1 => final bend is still positive (~ +1 semitone).
    const int combined = lastBendFor(composed, 1);
    assert(combined > 8192);
    assert(combined < lastBendFor(rb, 1));

    // Turning TERCA on/off must not change Ribbon or Portamento configuration.
    const auto before = router.portamento().config();
    router.setThirdEnabled(true);
    router.setThirdEnabled(false);
    const auto after = router.portamento().config();
    assert(before.enabled == after.enabled);
    assert(before.glideMs == after.glideMs);
    assert(before.bendRangeSemitones == after.bendRangeSemitones);
    assert(before.curve == after.curve);

    auto panic = router.panic();
    assert(!panic.empty());
    for (const auto& m : panic) assert(KorgProfile::isUpperChannel(m.channel()));

    std::cout << "SILVETON LIVE MIDI isolated-module tests passed\n";
    return 0;
}
