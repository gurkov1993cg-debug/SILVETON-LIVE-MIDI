# SILVETON-LIVE-MIDI Test Status

## Current Local-OFF bridge correction

Integrated in the full project:
- Transparent connect baseline: no automatic RPN, CC5, CC65 or Pitch Bend reset while effects are OFF.
- Portamento defaults OFF for a safe Local-Control-OFF startup.
- One-time preference migration disables stale Portamento/TERCA enable flags from older builds; later user choices persist normally.
- Portamento TIME changes are cached while Portamento is OFF and are emitted only when the module is enabled.
- Native PA600 Portamento remains CC#5/CC#65 only; note traffic is not converted to software glide.
- Program Change re-syncs Portamento/Pitch only when the corresponding module is active.
- Incoming CC120/CC123 clears native note state without injecting an unrelated Pitch Bend while Ribbon transport is inactive.
- GUI layout/artwork and LiveMidiView source are unchanged.

## Actually run in this environment

PASS:
- C++ Release build and regression tests.
- GCC strict checks: -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror.
- Clang strict build and regression tests.
- AddressSanitizer + UndefinedBehaviorSanitizer regression run.
- Local-OFF byte-for-byte bridge regression for U1/U2/U3 Note On/Off, CC, Program Change and physical Pitch Bend.
- Note On velocity 0 -> Note Off state cleanup.
- CC123 state cleanup without extra Pitch Bend in transparent mode.
- Native Portamento enable order: CC5 then CC65 on U1/U2/U3.
- Adjacent and wide note paths remain unchanged for native PA600 Portamento.
- TERCA fixed-tonality U3 regression tests and generated-note ownership tests.
- Kotlin changed-path compile using Android API stubs.
- MIDI byte-stream parser running-status regression.
- Kotlin native declarations vs JNI exports: 18/18 exact names.
- NativeBridge.cpp strict C++ syntax check.
- Host JNI shared-object build and JNI export inspection (x86_64 host only).
- arm64-v8a is the only configured Android ABI.
- XML/Manifest parse and ZIP integrity checks.

## Not claimed / requires external environment

NOT TESTED HERE:
- Full Android Gradle/APK build: Android SDK/NDK are not installed in this execution environment.
- Android arm64-v8a ELF inspection of the final APK .so for the same reason.
- Physical Korg PA600 behavior. The software byte stream is verified, but native PA600 glide audibility on adjacent/wide intervals must be confirmed on the real keyboard/Sound configuration.
