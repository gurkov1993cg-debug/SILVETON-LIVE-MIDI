# SILVETON-LIVE-MIDI Test Status — v0.3.0

## Changes in this version
- Keyboard Local mode (`LOCAL ON` default / `LOCAL OFF`) in native router, JNI, controller and UI.
- Local ON never echoes keyboard traffic; Local OFF bridges only U1/U2/U3 + Lower channel.
- System Realtime, SysEx and style/chord/player/global channels are never returned to the PA600.
- USB-only device selection with KORG/PA preference (no virtual/Bluetooth ports).
- Runaway MIDI loop breaker with automatic PANIC and on-screen warning.
- PANIC button in the top bar (panic now also covers the Lower channel).
- TERCA: six scan cells (major/minor up & down, phrygian up, hijaz up), all 12 tonalities; result shown in UI.
- Ribbon: RPN range restored to ±2 and raw wheel re-asserted after release.
- UI: PORTA TIME drag zone no longer steals TERCA button presses; drags follow pointer id
  (second finger can no longer make the Ribbon jump).
- Poller runs at 2 ms only while Ribbon/SCAN is active (15 ms idle, no JNI poll when idle).
- `LoopGuard.kt` removed.

## Actually run in this environment

PASS:
- C++ core Release build + regression tests (GCC, -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror).
- Clang build + regression tests.
- AddressSanitizer + UndefinedBehaviorSanitizer regression run.
- New tests: 6 scan cells × 12 tonalities × 2 Local modes with hand-written expected notes;
  inversion/octave-independent scan; unknown shapes never lock; Local ON never echoes
  U1/U2/U3/Lower/style/damper/Pitch Bend/Program Change/CC123; Local ON SCAN sends no CC123 to U1/U2;
  Ribbon transport exit re-asserts raw wheel.
- All previous regression tests unchanged and passing (Local OFF bridge behaviour preserved).
- Kotlin: all app sources compiled with kotlinc 2.0.21 against android.jar (API 34) + androidx stubs.
- JNI: host shared library built from NativeBridge.cpp + core; Kotlin externals vs exports 19/19.

## Not tested here
- Full Gradle/APK build (Android SDK/Google Maven not reachable here) — GitHub Actions builds the APK.
- Physical PA600 behaviour. Must be verified on the keyboard following KORG_SETUP.md.
