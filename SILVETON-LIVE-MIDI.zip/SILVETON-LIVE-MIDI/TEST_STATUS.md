# SILVETON-LIVE-MIDI Test Status — v0.4.2

## v0.4.2 — all Uppers with all effects, no conflicts
- Local OFF: each Upper glides from its own notes (a muted/untransmitted Upper never affects another).
- TERCA source = U1 and/or U2 (same key on both = exactly one third, released after both offs).
- U3 glide is reset whenever TERCA ownership of U3 changes (no raw<->terca cross-glide).
- FIX: SCAN no longer swallows Pitch Bend — a wheel returning to centre during SCAN left the
  Upper permanently bent (found by the fuzz test).
- New `core/tests/FuzzTests.cpp` in CTest (runs in CI, also under ASan/UBSan): 6000 random
  PA600-like sessions on U1/U2/U3 with random muted Uppers, wheel, Ribbon, SCAN, TERCA,
  TIME portamento and transport toggles in both Local modes. Pass criteria: no hanging note
  on any channel, every Upper's pitch back at centre. Result: 0 failures (30 000 locally).


## v0.4.1
- TERCA safety sweep: releasing the last U1 source sends Note Offs for anything still known on
  U3 plus CC123 on U3 only (never U1/U2).
- Fuzz: 20 000 random sequences (notes, legato overlaps, SCAN, TERCA/PORTA/transport toggles,
  both Local modes) — zero stuck notes on U3/U1 (ASan+UBSan).
- Setup guide: LOCAL OFF + Track Mute Active ON is the recommended mode for TERCA/Ribbon/PORTA.


## v0.4.0
- TIME portamento: equal total glide time for every interval (Pitch Bend, ±12 transport),
  U3 glides along the TERCA line; Korg CC65 forced OFF while enabled. TIME shown in ms.
- TERCA: every key gets a third (out-of-scale: in-scale m3, else in-scale M3, else m3).
- Tests: glide 2 / 12 / 24 semitones all finish at exactly the set time; halfway values;
  mid-glide retarget; Pitch Bend precedes the note; Local ON + TERCA U3 glide by its own
  interval; disable returns to centre; chromatic thirds for all 6 cells × 12 keys; D phrygian E→G, B→D.
- Kotlin compiled (kotlinc 2.0.21), JNI 19/19.


## Changes in this version
- Keyboard Local mode (`LOCAL ON` default / `LOCAL OFF`) in native router, JNI, controller and UI.
- Local ON never echoes keyboard traffic; Local OFF bridges only U1/U2/U3 + Lower channel.
- System Realtime, SysEx and style/chord/player/global channels are never returned to the PA600.
- USB-only device selection with KORG/PA preference (no virtual/Bluetooth ports).
- Runaway MIDI loop breaker with automatic PANIC and on-screen warning.
- PANIC button in the top bar (panic now also covers the Lower channel).
- TERCA: six scan cells (major/minor up & down, phrygian up, hijaz up), all 12 tonalities; result shown in UI.
- Ribbon: RPN range restored to ±2 and raw wheel re-asserted after release.
- UI: PORTA TIME drag zone no longer steals TERCA button presses; drags follow pointer id
  (second finger can no longer make the Ribbon jump).
- Poller runs at 2 ms only while Ribbon/SCAN is active (15 ms idle, no JNI poll when idle).
- `LoopGuard.kt` removed.

## Actually run in this environment

PASS:
- C++ core Release build + regression tests (GCC, -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror).
- Clang build + regression tests.
- AddressSanitizer + UndefinedBehaviorSanitizer regression run.
- New tests: 6 scan cells × 12 tonalities × 2 Local modes with hand-written expected notes;
  inversion/octave-independent scan; unknown shapes never lock; Local ON never echoes
  U1/U2/U3/Lower/style/damper/Pitch Bend/Program Change/CC123; Local ON SCAN sends no CC123 to U1/U2;
  Ribbon transport exit re-asserts raw wheel.
- All previous regression tests unchanged and passing (Local OFF bridge behaviour preserved).
- Kotlin: all app sources compiled with kotlinc 2.0.21 against android.jar (API 34) + androidx stubs.
- JNI: host shared library built from NativeBridge.cpp + core; Kotlin externals vs exports 19/19.

## Not tested here
- Full Gradle/APK build (Android SDK/Google Maven not reachable here) — GitHub Actions builds the APK.
- Physical PA600 behaviour. Must be verified on the keyboard following KORG_SETUP.md.
