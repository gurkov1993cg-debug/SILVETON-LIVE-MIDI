# SILVETON-LIVE-MIDI Test Status — v0.7.0

## v0.7.0 — RIBBON as an independent module
- `Ribbon` rewritten as a stand-alone module with its own settings: RANGE ±1..24, SENSITIVITY,
  MODE Relative/Absolute, RELEASE Return/Hold (tap clears), OUTPUT PitchBend/Tuning, INVERT,
  SMOOTH, RETURN, ROUNDING + ROUND RATE (average-based, vibrato preserved), ROUND INITIAL.
  Design references: Doepfer R2M (absolute/relative), Korg Lock (hold), Haken Continuum (rounding).
- TUNING output: RPN 1 Fine + RPN 2 Coarse on U1/U2/U3 with hysteresis (coarse written only when
  fine cannot cover the pitch; within ±1 semitone only Fine is used), max 250 updates/s, RPN null
  at rest. Never sends Pitch Bend or RPN 0 — the wheel and the blend's bend range stay untouched.
- UI: SETUP overlay; strip sends down/move/up by pointer id; HOLD keeps the marker.
- PANIC returns the ribbon to 0 on its destination (tuning reset).
- Tests: relative no-jump, absolute mapping + dead zone, invert/24 st, hold/continue/tap-clear,
  rounding pulls 3.3 -> 3.0 and keeps vibrato depth, round-initial, router TUNING output emits no
  Pitch Bend and no RPN 0 and returns to coarse 0 / fine centre + RPN null, ±1 range never writes Coarse.
- Fuzz (CTest + 40 000 local, ASan/UBSan) now includes random ribbon settings/touches/output
  switches; criteria add "tuning back at 0": 0 failures. Found and fixed: tuning could rest at
  coarse -1 / fine +1 (≈0 but not reset).
- JNI 23/23. Kotlin compiled.


## v0.6.1-test — hardware probe build
- Settings -> TUNING TEST -> RUN: sends RPN 1 Fine Tuning sweep (-100..+100 cents, 3 s) and
  RPN 2 Coarse Tuning steps (+1..+5, then 0) on U1/U2/U3, then resets tuning to 0 and RPN null.
  Purpose: find out whether the PA600 applies RPN tuning live to a sounding note, so Ribbon and
  TIME portamento can move off Pitch Bend entirely (wheel and blend bend range untouched).


## v0.6.0
- UI: the PA600 LOCAL switch and the LOCAL label are removed. The app always runs the
  Local-OFF bridge; the keyboard's Local Control must be OFF. (Local-ON support stays in the
  native core and its tests, but the app never enables it.)
- Kotlin compiled (kotlinc 2.0.21), JNI unchanged.


## v0.5.3 — automatic MONO
- MONO legato is automatic: on for U1/U2/U3 while TIME portamento is ON, on for the TERCA
  source while TERCA owns U3; otherwise every Upper is untouched (poly blends play chords).
  Key memory is cleared whenever MONO switches on/off for a channel.
- Tests updated for the mono TERCA line; new test: poly chord with PORTA OFF, mono with PORTA ON.
- Fuzz 30 000 sessions (ASan/UBSan): 0 failures.


## v0.5.2
- App MONO is OFF: mono/poly is decided by the PA600 Sound (poly blends play chords normally).
  The MONO stage and both v0.5.1 fuzz-found fixes remain; fuzz still exercises MONO on/off.


## v0.5.1 — MONO legato always on
- MONO legato for U1/U2/U3 and the TERCA line (last-note priority, return to a held key,
  legato order new-on then old-off). Always on, no UI button. Unknown Note Offs pass through.
- FIX: SCAN start clears MONO memory (SCAN swallows releases of keys held at that moment;
  MONO could later "return" to a key already up -> stuck note). Found by fuzz.
- FIX: a Pitch Bend transport change drops any running glide offset (stale glide lane could
  leave an Upper detuned). Found by fuzz.
- Fuzz: 30 000 sessions under ASan/UBSan + 100 000 sessions (-O2): 0 failures.


## v0.5.0 — Local ON without wheel conflicts
- Local ON: the native core owns RPN 0 (Pitch Bend Sensitivity). It stays at ±2 so the PA600's
  own wheel keeps its normal feel, widens to ±12 only while a glide wider than 2 semitones or a
  Ribbon with RANGE > 2 needs it (RPN before the Pitch Bend), and returns to ±2 150 ms after.
  Program Change re-asserts the current range. The Android layer no longer sends RPN 12 in Local ON.
- Tests: wheel full-up stays 16383 at ±2; 2-semitone glide without any RPN; 7-semitone glide
  switches to 12 first and returns to 2; Ribbon ≤2 never switches; Ribbon 7 widens and returns.
- Fuzz (CTest + 30 000 local sessions): also requires Local ON to end at RPN ±2 — 0 failures.


## v0.4.3
- Local OFF: TERCA source is Upper 3 itself (raw U3 keys are consumed and replaced by their
  thirds). U1/U2 are fully independent of TERCA; CC123 on U1 no longer touches U3.
- Local ON: source stays U1 (only channel 1 is transmitted in that mode).
- SCAN recognises the chord from any Upper (works while U3 is muted).
- All TERCA tests run on the mode's source channel; fuzz 30 000 sessions: 0 failures.


## v0.4.2 — all Uppers with all effects, no conflicts
- Local OFF: each Upper glides from its own notes (a muted/untransmitted Upper never affects another).
- TERCA source = U1 and/or U2 (same key on both = exactly one third, released after both offs).
- U3 glide is reset whenever TERCA ownership of U3 changes (no raw<->terca cross-glide).
- FIX: SCAN no longer swallows Pitch Bend — a wheel returning to centre during SCAN left the
  Upper permanently bent (found by the fuzz test).
- New `core/tests/FuzzTests.cpp` in CTest (runs in CI, also under ASan/UBSan): 6000 random
  PA600-like sessions on U1/U2/U3 with random muted Uppers, wheel, Ribbon, SCAN, TERCA,
  TIME portamento and transport toggles in both Local modes. Pass criteria: no hanging note
  on any channel, every Upper's pitch back at centre. Result: 0 failures (30 000 locally).


## v0.4.1
- TERCA safety sweep: releasing the last U1 source sends Note Offs for anything still known on
  U3 plus CC123 on U3 only (never U1/U2).
- Fuzz: 20 000 random sequences (notes, legato overlaps, SCAN, TERCA/PORTA/transport toggles,
  both Local modes) — zero stuck notes on U3/U1 (ASan+UBSan).
- Setup guide: LOCAL OFF + Track Mute Active ON is the recommended mode for TERCA/Ribbon/PORTA.


## v0.4.0
- TIME portamento: equal total glide time for every interval (Pitch Bend, ±12 transport),
  U3 glides along the TERCA line; Korg CC65 forced OFF while enabled. TIME shown in ms.
- TERCA: every key gets a third (out-of-scale: in-scale m3, else in-scale M3, else m3).
- Tests: glide 2 / 12 / 24 semitones all finish at exactly the set time; halfway values;
  mid-glide retarget; Pitch Bend precedes the note; Local ON + TERCA U3 glide by its own
  interval; disable returns to centre; chromatic thirds for all 6 cells × 12 keys; D phrygian E→G, B→D.
- Kotlin compiled (kotlinc 2.0.21), JNI 19/19.


## Changes in this version
- Keyboard Local mode (`LOCAL ON` default / `LOCAL OFF`) in native router, JNI, controller and UI.
- Local ON never echoes keyboard traffic; Local OFF bridges only U1/U2/U3 + Lower channel.
- System Realtime, SysEx and style/chord/player/global channels are never returned to the PA600.
- USB-only device selection with KORG/PA preference (no virtual/Bluetooth ports).
- Runaway MIDI loop breaker with automatic PANIC and on-screen warning.
- PANIC button in the top bar (panic now also covers the Lower channel).
- TERCA: six scan cells (major/minor up & down, phrygian up, hijaz up), all 12 tonalities; result shown in UI.
- Ribbon: RPN range restored to ±2 and raw wheel re-asserted after release.
- UI: PORTA TIME drag zone no longer steals TERCA button presses; drags follow pointer id
  (second finger can no longer make the Ribbon jump).
- Poller runs at 2 ms only while Ribbon/SCAN is active (15 ms idle, no JNI poll when idle).
- `LoopGuard.kt` removed.

## Actually run in this environment

PASS:
- C++ core Release build + regression tests (GCC, -Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror).
- Clang build + regression tests.
- AddressSanitizer + UndefinedBehaviorSanitizer regression run.
- New tests: 6 scan cells × 12 tonalities × 2 Local modes with hand-written expected notes;
  inversion/octave-independent scan; unknown shapes never lock; Local ON never echoes
  U1/U2/U3/Lower/style/damper/Pitch Bend/Program Change/CC123; Local ON SCAN sends no CC123 to U1/U2;
  Ribbon transport exit re-asserts raw wheel.
- All previous regression tests unchanged and passing (Local OFF bridge behaviour preserved).
- Kotlin: all app sources compiled with kotlinc 2.0.21 against android.jar (API 34) + androidx stubs.
- JNI: host shared library built from NativeBridge.cpp + core; Kotlin externals vs exports 19/19.

## Not tested here
- Full Gradle/APK build (Android SDK/Google Maven not reachable here) — GitHub Actions builds the APK.
- Physical PA600 behaviour. Must be verified on the keyboard following KORG_SETUP.md.
