# SILVETON-LIVE-MIDI test status

## Integrated

- Full Android project, not a mini/example project.
- Native PA600 Portamento only: CC#5 Time + CC#65 On/Off on U1/U2/U3.
- No software Portamento Pitch-Bend glide remains in the production path.
- `9n NN 00` is Note Off.
- C++ active-note reference ledger + `lastNote` state.
- Final Kotlin `MidiInputPort.send()` note mirror (`Pa600MidiSender`).
- Panic releases known notes, sends CC123 + CC120 and centers pitch on all three Uppers.
- TERCA fixed scanned tonality, output only on U3.
- TERCA scan state machine: Idle / Scanning / WaitingForRelease / Locked.
- TERCA generated-note ownership/reference counting.
- Ribbon independent from Portamento/TERCA, U1/U2/U3, manual ±1..±12 range.
- Physical/manual Pitch Bend composed independently with Ribbon.
- Channel voice messages bypass timing-based LoopGuard filtering.
- Debug final-byte trace at the Android MIDI output boundary.
- arm64-v8a is the only configured Android ABI.

## Actually executed in this environment

- GCC Release core compile: PASS
- Core regression tests: PASS
- GCC strict warnings (`-Wall -Wextra -Wpedantic -Wconversion -Wshadow -Werror`): PASS
- Clang strict warnings: PASS
- AddressSanitizer: PASS
- UndefinedBehaviorSanitizer: PASS
- GCC static analyzer (`-fanalyzer`): PASS during integration
- JNI C++ strict syntax, GCC + Clang: PASS
- Kotlin full-source compile with Android API stubs: PASS
- Kotlin MIDI byte-stream parser runtime test: PASS
- Kotlin final MIDI sender/exact-byte runtime test: PASS
- Kotlin ↔ JNI method mapping: PASS (17/17)
- XML/AndroidManifest parsing: PASS
- GUI source/image unchanged from the input full project: PASS
- No stale software-Portamento/old TERCA implementation found in production source: PASS

## Exact byte regression examples

Portamento Time 64 + ON:

- U1: `B0 05 40`, `B0 41 7F`
- U2: `B1 05 40`, `B1 41 7F`
- U3: `B2 05 40`, `B2 41 7F`

C4 + fixed C-major TERCA:

- U1: `90 3C 64`
- U3: `92 40 64`

Generated U3 release:

- `92 40 00`

Pitch Bend center:

- U1 `E0 00 40`
- U2 `E1 00 40`
- U3 `E2 00 40`

The Kotlin low-level test also verifies the requested six-message sequence:

`B0 05 40` → `B0 41 7F` → `B2 05 40` → `B2 41 7F` → `90 3C 64` → `92 40 64`

## Not verified here

- Android APK was NOT built because this execution environment does not contain Android SDK/NDK/Gradle tooling.
- Therefore no arm64-v8a Android `.so` from an APK was inspected here.
- A host ELF shared-library build was inspected for JNI exports, but it is x86-64 Linux and is not claimed to be the Android binary.
- Physical behavior on a real Korg PA600 is NOT tested here. Native Portamento glide on adjacent and wide intervals still requires the real PA600 test.
