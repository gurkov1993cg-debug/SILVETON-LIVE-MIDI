package com.silveton.livemidi

class NativeMidiEngine {
    init {
        System.loadLibrary("silveton_jni")
        nativeInit()
    }

    external fun nativeInit()
    external fun nativeSetPortamentoEnabled(enabled: Boolean): IntArray
    external fun nativeSetGlideMs(value: Int)
    external fun nativeSetCurveMode(value: Int)

    external fun nativeSetThirdEnabled(enabled: Boolean): IntArray
    external fun nativeSetThirdScanning(scanning: Boolean): IntArray
    external fun nativeThirdScanResult(): Int
    external fun nativeThirdScanRevision(): Int
    external fun nativeThirdScanning(): Boolean

    external fun nativeSetRibbonSensitivity(value: Float)
    external fun nativeSetRibbonRangeSemitones(value: Int)
    external fun nativeRibbon(value: Float, nowUs: Long): IntArray

    external fun nativeProcess(status: Int, data1: Int, data2: Int, size: Int, nowUs: Long): IntArray
    external fun nativePoll(nowUs: Long): IntArray
    external fun nativePanic(): IntArray
}
