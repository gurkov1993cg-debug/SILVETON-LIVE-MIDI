package com.silveton.livemidi

class NativeMidiEngine {
    init {
        System.loadLibrary("silveton_jni")
        nativeInit()
    }

    external fun nativeInit()
    external fun nativeSetKeyboardLocal(keyboardLocal: Boolean)
    external fun nativeSetPortamentoEnabled(enabled: Boolean): IntArray
    external fun nativeSetPortamentoTimeMs(ms: Int): IntArray
    external fun nativeSyncPortamento(): IntArray
    external fun nativeSyncPortamentoChannel(upper: Int): IntArray
    external fun nativeSyncPitchChannel(upper: Int): IntArray
    external fun nativeSetPitchTransportEnabled(enabled: Boolean): IntArray

    external fun nativeSetThirdEnabled(enabled: Boolean): IntArray
    external fun nativeSetThirdScanning(scanning: Boolean): IntArray
    external fun nativeThirdScanResult(): Int
    external fun nativeThirdScanRevision(): Int
    external fun nativeThirdScanning(): Boolean

    external fun nativeSetRibbonSensitivity(value: Float)
    external fun nativeSetRibbonRangeSemitones(value: Int)
    external fun nativeRibbon(value: Float, nowUs: Long): IntArray
    external fun nativeRibbonTouch(action: Int, position: Float, nowUs: Long): IntArray
    external fun nativeSetRibbonSettings(
        mode: Int, release: Int, output: Int, range: Int, sensitivity: Float, invert: Boolean,
        smoothMs: Int, returnMs: Int, rounding: Boolean, roundRateMs: Int, roundInitial: Boolean
    ): IntArray
    external fun nativeRibbonReset(): IntArray
    external fun nativeRibbonActive(): Boolean

    external fun nativeProcess(status: Int, data1: Int, data2: Int, size: Int, nowUs: Long): IntArray
    external fun nativePoll(nowUs: Long): IntArray
    external fun nativePanic(): IntArray
}
