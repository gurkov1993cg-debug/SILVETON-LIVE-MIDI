package com.silveton.livemidi

import android.content.SharedPreferences

/** Independent settings of the RIBBON module (mirrors silveton::Ribbon::Settings). */
data class RibbonConfig(
    val relative: Boolean = true,        // RELATIVE: touch point = 0 (no jump); else ABSOLUTE
    val hold: Boolean = false,           // HOLD after release (tap to clear); else RETURN
    val tuningOutput: Boolean = false,   // TUNING (RPN fine/coarse); else PITCH BEND
    val rangeSemitones: Int = 2,         // 1..24
    val sensitivity: Float = 1.0f,       // 0.25..2.0 response curve
    val invert: Boolean = false,
    val smoothMs: Int = 36,              // 0..200
    val returnMs: Int = 60,              // 0..2000
    val rounding: Boolean = false,
    val roundRateMs: Int = 150,          // 10..2000
    val roundInitial: Boolean = false
) {
    fun save(e: SharedPreferences.Editor): SharedPreferences.Editor = e
        .putBoolean("rb_relative", relative).putBoolean("rb_hold", hold)
        .putBoolean("rb_tuning", tuningOutput).putInt("ribbon_range_semitones", rangeSemitones)
        .putFloat("ribbon_sensitivity", sensitivity).putBoolean("rb_invert", invert)
        .putInt("rb_smooth", smoothMs).putInt("rb_return", returnMs)
        .putBoolean("rb_round", rounding).putInt("rb_round_rate", roundRateMs)
        .putBoolean("rb_round_initial", roundInitial)

    companion object {
        fun load(p: SharedPreferences) = RibbonConfig(
            relative = p.getBoolean("rb_relative", true),
            hold = p.getBoolean("rb_hold", false),
            tuningOutput = p.getBoolean("rb_tuning", false),
            rangeSemitones = p.getInt("ribbon_range_semitones", 2).coerceIn(1, 24),
            sensitivity = p.getFloat("ribbon_sensitivity", 1.0f).coerceIn(0.25f, 2.0f),
            invert = p.getBoolean("rb_invert", false),
            smoothMs = p.getInt("rb_smooth", 36).coerceIn(0, 200),
            returnMs = p.getInt("rb_return", 60).coerceIn(0, 2000),
            rounding = p.getBoolean("rb_round", false),
            roundRateMs = p.getInt("rb_round_rate", 150).coerceIn(10, 2000),
            roundInitial = p.getBoolean("rb_round_initial", false)
        )
    }
}
