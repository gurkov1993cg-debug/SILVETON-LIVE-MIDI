package com.silveton.livemidi

import android.media.midi.MidiInputPort
import android.util.Log
import java.io.IOException

/**
 * The single final Android MIDI-output transport.
 *
 * It mirrors the notes that were ACTUALLY accepted by MidiInputPort.send(), so
 * debug traces and emergency cleanup describe the final physical byte stream,
 * after canonical U1/U2/U3 -> user channel mapping.
 */
class Pa600MidiSender {
    private var port: MidiInputPort? = null

    val activeNotes: Array<MutableSet<Int>> = Array(16) { linkedSetOf() }
    val lastNote: IntArray = IntArray(16) { -1 }
    private val noteRefs: Array<IntArray> = Array(16) { IntArray(128) }

    @Synchronized
    fun attach(newPort: MidiInputPort?) {
        port = newPort
        if (newPort == null) clearState()
    }

    @Synchronized
    fun send(message: ByteArray, label: String): Boolean {
        val out = port ?: return false
        return try {
            out.send(message, 0, message.size)
            trackSuccessfulOutput(message)
            if (traceEnabled()) {
                Log.d("MIDI_TRACE", "OUT ${hex(message)} $label")
            }
            true
        } catch (e: IOException) {
            if (traceEnabled()) {
                Log.e("MIDI_TRACE", "SEND FAILED ${hex(message)} $label", e)
            }
            false
        }
    }

    @Synchronized
    fun clearState() {
        for (ch in 0 until 16) {
            activeNotes[ch].clear()
            noteRefs[ch].fill(0)
            lastNote[ch] = -1
        }
    }

    // Direct low-level helpers used by regression/instrumentation tests.
    fun noteOn(upper: Int, note: Int, velocity: Int): Boolean {
        require(upper in 0..15)
        val n = note.coerceIn(0, 127)
        val v = velocity.coerceIn(0, 127)
        if (v == 0) return noteOff(upper, n)
        return send(byteArrayOf((0x90 or upper).toByte(), n.toByte(), v.toByte()), "NOTE ON CH${upper + 1}")
    }

    fun noteOff(upper: Int, note: Int): Boolean {
        require(upper in 0..15)
        val n = note.coerceIn(0, 127)
        return send(byteArrayOf((0x90 or upper).toByte(), n.toByte(), 0x00), "NOTE OFF CH${upper + 1}")
    }

    fun portamento(upper: Int, time: Int, enabled: Boolean): Boolean {
        require(upper in 0..15)
        val t = time.coerceIn(0, 127)
        val timeOk = send(byteArrayOf((0xB0 or upper).toByte(), 0x05.toByte(), t.toByte()), "PORTA TIME CH${upper + 1}")
        val switchOk = send(
            byteArrayOf((0xB0 or upper).toByte(), 0x41.toByte(), if (enabled) 0x7F.toByte() else 0x00.toByte()),
            if (enabled) "PORTA ON CH${upper + 1}" else "PORTA OFF CH${upper + 1}"
        )
        return timeOk && switchOk
    }

    fun pitchBend(upper: Int, bend14: Int): Boolean {
        require(upper in 0..15)
        val value = bend14.coerceIn(0, 16383)
        val lsb = value and 0x7F
        val msb = (value shr 7) and 0x7F
        return send(byteArrayOf((0xE0 or upper).toByte(), lsb.toByte(), msb.toByte()), "PITCH CH${upper + 1}")
    }

    // Exact low-level primitive requested for PA600 native portamento:
    // CC5 -> CC65 -> Note On on the same channel.
    fun playWithPortamento(upper: Int, note: Int, velocity: Int, time: Int): Boolean {
        require(upper in 0..15)
        val p = portamento(upper, time, true)
        val n = noteOn(upper, note, velocity)
        return p && n
    }

    // Low-level TERCA sender. harmonyNote is already calculated by the C++
    // fixed-tonality engine. U1 is main, U3 is mandatory harmony output.
    fun playTerca(mainNote: Int, harmonyNote: Int, velocity: Int, time: Int): Boolean {
        val main = mainNote.coerceIn(0, 127)
        val harmony = harmonyNote.coerceIn(0, 127)
        val vel = velocity.coerceIn(1, 127)
        val u1Porta = portamento(0, time, true)
        val u3Porta = portamento(2, time, true)
        val mainOn = noteOn(0, main, vel)
        val thirdOn = noteOn(2, harmony, vel)
        return u1Porta && u3Porta && mainOn && thirdOn
    }

    @Synchronized
    fun panic(physicalUpperChannels: IntArray) {
        for (ch in physicalUpperChannels.take(3)) {
            if (ch !in 0..15) continue
            val refs = noteRefs[ch].copyOf()
            for (note in 0..127) repeat(refs[note]) { noteOff(ch, note) }
            send(byteArrayOf((0xB0 or ch).toByte(), 0x7B.toByte(), 0x00.toByte()), "ALL NOTES OFF CH${ch + 1}")
            send(byteArrayOf((0xB0 or ch).toByte(), 0x78.toByte(), 0x00.toByte()), "ALL SOUND OFF CH${ch + 1}")
            pitchBend(ch, 8192)
        }
        clearState()
    }

    private fun trackSuccessfulOutput(message: ByteArray) {
        if (message.size < 2) return
        val status = message[0].toInt() and 0xFF
        if (status !in 0x80..0xEF) return
        val command = status and 0xF0
        val ch = status and 0x0F
        val d1 = message[1].toInt() and 0x7F
        val d2 = if (message.size > 2) message[2].toInt() and 0x7F else 0

        if (command == 0x90 && d2 != 0) {
            noteRefs[ch][d1]++
            activeNotes[ch].add(d1)
            lastNote[ch] = d1
            return
        }

        if (command == 0x80 || (command == 0x90 && d2 == 0)) {
            if (noteRefs[ch][d1] > 0) noteRefs[ch][d1]--
            if (noteRefs[ch][d1] == 0) activeNotes[ch].remove(d1)
            if (lastNote[ch] == d1 && noteRefs[ch][d1] == 0) lastNote[ch] = activeNotes[ch].lastOrNull() ?: -1
            return
        }

        if (command == 0xB0 && (d1 == 120 || d1 == 123)) {
            activeNotes[ch].clear()
            noteRefs[ch].fill(0)
            lastNote[ch] = -1
        }
    }

    private fun traceEnabled(): Boolean = Log.isLoggable("MIDI_TRACE", Log.DEBUG)

    private fun hex(message: ByteArray): String = message.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
}
