package com.silveton.livemidi

import kotlin.math.pow
import kotlin.math.roundToInt

/** TIME slider (0..127) <-> total glide time in milliseconds (10 ms .. 3 s, exponential). */
object PortaTime {
    private const val MIN_MS = 10.0
    private const val MAX_MS = 3000.0

    fun msForSlider(value: Int): Int {
        val n = value.coerceIn(0, 127) / 127.0
        return (MIN_MS * (MAX_MS / MIN_MS).pow(n)).roundToInt()
    }
}
