package com.silveton.livemidi

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.os.SystemClock
import android.view.View
import kotlin.math.*

class LiveMidiView(context: Context) : View(context) {

    interface Listener {
        fun onPortamentoEnabled(enabled: Boolean)
        fun onGlideMs(value: Int)
        fun onCurveMode(value: Int)
        fun onThirdScan(scanning: Boolean)
        fun onThirdEnabled(enabled: Boolean)
        fun onRibbonSensitivity(value: Float)
        fun onRibbon(value: Float)
        fun onChannelMapChanged(slot: Int, midiChannel1Based: Int)
    }

    var listener: Listener? = null

    var connected: Boolean = false
        set(value) { field = value; invalidate() }

    var thirdScanResult: Int = 0
        set(value) { field = value; if (value != 0) thirdScanning = false; invalidate() }

    var channelMap: IntArray = intArrayOf(1, 2, 3)
        set(value) { field = value.copyOf(); invalidate() }

    private var portamentoEnabled = true
    private var glideMs = 180
    private var curveMode = 2 // FIB = the tested/approved curve.
    private var thirdEnabled = false
    private var thirdScanning = false
    private var ribbonSensitivity = 1.0f
    private var ribbonValue = 0f
    private var settingsOpen = false

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val gearRect = RectF()
    private val portPanel = RectF()
    private val thirdPanel = RectF()
    private val ribbonPanel = RectF()
    private val ribbonTouch = RectF()
    private val timeTrack = RectF()
    private val portToggleRect = RectF()
    private val sensTrack = RectF()
    private val scanRect = RectF()
    private val thirdToggleRect = RectF()
    private val sensMinusRect = RectF()
    private val sensPlusRect = RectF()
    private val curveRects = Array(4) { RectF() }
    private val settingsRows = Array(3) { RectF() }
    private val settingsMinus = Array(3) { RectF() }
    private val settingsPlus = Array(3) { RectF() }
    private val settingsPanel = RectF()

    private enum class DragTarget { NONE, TIME, SENS, RIBBON }
    private var dragTarget = DragTarget.NONE

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isFocusable = true
        keepScreenOn = true
        contentDescription = "SILVETON LIVE MIDI"
    }

    private fun sx(v: Float) = width * v
    private fun sy(v: Float) = height * v
    private fun radius(v: Float) = min(width, height) * v

    private fun layoutRects() {
        val marginX = sx(0.019f)
        val gap = sx(0.010f)
        val top = sy(0.128f)
        val panelBottom = sy(0.414f)
        val usable = width - 2f * marginX - gap
        val leftW = usable * 0.55f

        gearRect.set(sx(0.040f), sy(0.033f), sx(0.092f), sy(0.105f))
        portPanel.set(marginX, top, marginX + leftW, panelBottom)
        thirdPanel.set(portPanel.right + gap, top, width - marginX, panelBottom)

        ribbonPanel.set(marginX, sy(0.430f), width - marginX, sy(0.965f))
        ribbonTouch.set(sx(0.032f), sy(0.530f), sx(0.968f), sy(0.875f))

        val buttonY = portPanel.top + portPanel.height() * 0.28f
        val buttonH = portPanel.height() * 0.21f
        val buttonLeft = portPanel.left + portPanel.width() * 0.14f
        val buttonRight = portPanel.left + portPanel.width() * 0.75f
        val segW = (buttonRight - buttonLeft) / 4f
        for (i in 0..3) {
            curveRects[i].set(buttonLeft + i * segW, buttonY, buttonLeft + (i + 1) * segW, buttonY + buttonH)
        }
        portToggleRect.set(
            portPanel.left + portPanel.width() * 0.79f, buttonY,
            portPanel.left + portPanel.width() * 0.94f, buttonY + buttonH
        )

        timeTrack.set(
            portPanel.left + portPanel.width() * 0.17f,
            portPanel.top + portPanel.height() * 0.80f,
            portPanel.right - portPanel.width() * 0.14f,
            portPanel.top + portPanel.height() * 0.84f
        )

        scanRect.set(
            thirdPanel.left + thirdPanel.width() * 0.08f,
            thirdPanel.top + thirdPanel.height() * 0.37f,
            thirdPanel.left + thirdPanel.width() * 0.46f,
            thirdPanel.top + thirdPanel.height() * 0.74f
        )
        thirdToggleRect.set(
            thirdPanel.left + thirdPanel.width() * 0.53f,
            thirdPanel.top + thirdPanel.height() * 0.37f,
            thirdPanel.right - thirdPanel.width() * 0.08f,
            thirdPanel.top + thirdPanel.height() * 0.74f
        )

        val sensY = ribbonPanel.top + ribbonPanel.height() * 0.10f
        val controlW = ribbonPanel.width()
        sensMinusRect.set(
            ribbonPanel.left + controlW * 0.455f, sensY - sy(0.027f),
            ribbonPanel.left + controlW * 0.500f, sensY + sy(0.027f)
        )
        sensTrack.set(
            ribbonPanel.left + controlW * 0.52f, sensY - sy(0.010f),
            ribbonPanel.left + controlW * 0.75f, sensY + sy(0.010f)
        )
        sensPlusRect.set(
            ribbonPanel.left + controlW * 0.775f, sensY - sy(0.027f),
            ribbonPanel.left + controlW * 0.820f, sensY + sy(0.027f)
        )

        settingsPanel.set(sx(0.30f), sy(0.18f), sx(0.70f), sy(0.82f))
        val rowTop = settingsPanel.top + settingsPanel.height() * 0.20f
        val rowH = settingsPanel.height() * 0.19f
        val rowGap = settingsPanel.height() * 0.045f
        for (i in 0..2) {
            val y = rowTop + i * (rowH + rowGap)
            settingsRows[i].set(
                settingsPanel.left + settingsPanel.width() * 0.08f, y,
                settingsPanel.right - settingsPanel.width() * 0.08f, y + rowH
            )
            settingsMinus[i].set(
                settingsRows[i].left + settingsRows[i].width() * 0.50f,
                y + rowH * 0.16f,
                settingsRows[i].left + settingsRows[i].width() * 0.62f,
                y + rowH * 0.84f
            )
            settingsPlus[i].set(
                settingsRows[i].left + settingsRows[i].width() * 0.82f,
                y + rowH * 0.16f,
                settingsRows[i].left + settingsRows[i].width() * 0.94f,
                y + rowH * 0.84f
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        layoutRects()

        canvas.drawColor(Color.rgb(1, 5, 8))

        drawTopBar(canvas)
        drawPortamento(canvas)
        drawThird(canvas)
        drawRibbon(canvas)

        if (settingsOpen) drawSettings(canvas)
    }

    private fun setText(size: Float, color: Int = Color.WHITE, bold: Boolean = true, align: Paint.Align = Paint.Align.CENTER) {
        p.reset()
        p.isAntiAlias = true
        p.color = color
        p.textSize = size
        p.textAlign = align
        p.typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun drawRound(canvas: Canvas, rect: RectF, fill: Int, stroke: Int? = null, strokeWidth: Float = 2f, r: Float = radius(0.018f), glow: Float = 0f) {
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.FILL
        p.color = fill
        if (glow > 0f && stroke != null) p.setShadowLayer(glow, 0f, 0f, stroke)
        canvas.drawRoundRect(rect, r, r, p)
        p.clearShadowLayer()
        if (stroke != null) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = strokeWidth
            p.color = stroke
            if (glow > 0f) p.setShadowLayer(glow, 0f, 0f, stroke)
            canvas.drawRoundRect(rect, r, r, p)
            p.clearShadowLayer()
        }
    }

    private fun gradientPaint(rect: RectF, c1: Int, c2: Int, vertical: Boolean = true): Paint {
        val gp = Paint(Paint.ANTI_ALIAS_FLAG)
        gp.shader = if (vertical) {
            LinearGradient(rect.left, rect.top, rect.left, rect.bottom, c1, c2, Shader.TileMode.CLAMP)
        } else {
            LinearGradient(rect.left, rect.centerY(), rect.right, rect.centerY(), c1, c2, Shader.TileMode.CLAMP)
        }
        return gp
    }

    private fun drawTopBar(canvas: Canvas) {
        val bar = RectF(sx(0.012f), sy(0.012f), sx(0.988f), sy(0.116f))
        drawRound(canvas, bar, Color.rgb(2, 10, 15), Color.rgb(16, 35, 48), radius(0.004f), radius(0.016f))

        drawRound(canvas, gearRect, Color.rgb(9, 15, 22), Color.rgb(83, 99, 116), radius(0.003f), radius(0.012f))
        drawGear(canvas, gearRect.centerX(), gearRect.centerY(), min(gearRect.width(), gearRect.height()) * 0.29f)

        val titleY = sy(0.082f)
        setText(min(width, height) * 0.047f, Color.WHITE, true)
        val left = "SILVETON "
        val right = "LIVE MIDI"
        val total = p.measureText(left) + p.measureText(right)
        var x = width / 2f - total / 2f
        p.textAlign = Paint.Align.LEFT
        p.color = Color.rgb(226, 233, 239)
        p.setShadowLayer(radius(0.006f), 0f, 0f, Color.rgb(100, 140, 170))
        canvas.drawText(left, x, titleY, p)
        x += p.measureText(left)
        p.color = Color.rgb(0, 172, 255)
        p.setShadowLayer(radius(0.010f), 0f, 0f, Color.rgb(0, 125, 255))
        canvas.drawText(right, x, titleY, p)
        p.clearShadowLayer()

        val dotX = sx(0.894f)
        val dotY = sy(0.068f)
        p.style = Paint.Style.FILL
        p.color = if (connected) Color.rgb(0, 255, 96) else Color.rgb(70, 78, 84)
        p.setShadowLayer(radius(0.012f), 0f, 0f, p.color)
        canvas.drawCircle(dotX, dotY, radius(0.010f), p)
        p.clearShadowLayer()
        setText(min(width, height) * 0.029f, Color.WHITE, true, Paint.Align.LEFT)
        canvas.drawText("MIDI", dotX + sx(0.018f), dotY + p.textSize * 0.34f, p)
    }

    private fun drawGear(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        p.reset()
        p.isAntiAlias = true
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.34f
        for (i in 0 until 8) {
            val a = i * Math.PI / 4.0
            val x1 = cx + cos(a).toFloat() * r * 0.78f
            val y1 = cy + sin(a).toFloat() * r * 0.78f
            val x2 = cx + cos(a).toFloat() * r * 1.12f
            val y2 = cy + sin(a).toFloat() * r * 1.12f
            canvas.drawLine(x1, y1, x2, y2, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.45f
        canvas.drawCircle(cx, cy, r * 0.72f, p)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(8, 14, 20)
        canvas.drawCircle(cx, cy, r * 0.28f, p)
    }

    private fun drawPortamento(canvas: Canvas) {
        val cyan = Color.rgb(0, 159, 255)
        drawRound(canvas, portPanel, Color.rgb(2, 11, 17), cyan, radius(0.003f), radius(0.018f))

        setText(min(width, height) * 0.041f, Color.rgb(235, 239, 244), true)
        canvas.drawText("PORTAMENTO", portPanel.centerX(), portPanel.top + portPanel.height() * 0.20f, p)

        val labels = arrayOf("FIX", "LIN", "FIB", "REAL")
        for (i in 0..3) {
            val r = curveRects[i]
            if (curveMode == i) {
                val gp = gradientPaint(r, Color.rgb(0, 202, 255), Color.rgb(0, 82, 255))
                gp.setShadowLayer(radius(0.012f), 0f, 0f, cyan)
                canvas.drawRoundRect(r, radius(0.012f), radius(0.012f), gp)
                gp.clearShadowLayer()
                p.style = Paint.Style.STROKE
                p.strokeWidth = radius(0.002f)
                p.color = Color.rgb(0, 217, 255)
                canvas.drawRoundRect(r, radius(0.012f), radius(0.012f), p)
            } else {
                drawRound(canvas, r, Color.rgb(17, 25, 36), Color.rgb(62, 73, 87), radius(0.002f), radius(0.010f))
            }
            setText(min(width, height) * 0.028f, Color.WHITE, true)
            canvas.drawText(labels[i], r.centerX(), r.centerY() - (p.ascent() + p.descent()) / 2f, p)
        }

        val portTg = if (portamentoEnabled) {
            gradientPaint(portToggleRect, Color.rgb(0, 202, 255), Color.rgb(0, 82, 255))
        } else {
            gradientPaint(portToggleRect, Color.rgb(46, 50, 61), Color.rgb(24, 28, 36))
        }
        canvas.drawRoundRect(portToggleRect, radius(0.012f), radius(0.012f), portTg)
        p.style = Paint.Style.STROKE
        p.strokeWidth = radius(0.002f)
        p.color = if (portamentoEnabled) cyan else Color.rgb(105, 115, 130)
        canvas.drawRoundRect(portToggleRect, radius(0.012f), radius(0.012f), p)
        setText(min(width, height) * 0.023f, Color.WHITE, true)
        canvas.drawText(if (portamentoEnabled) "ON" else "OFF", portToggleRect.centerX(), portToggleRect.centerY() - (p.ascent() + p.descent()) / 2f, p)

        setText(min(width, height) * 0.025f, Color.WHITE, true, Paint.Align.LEFT)
        canvas.drawText("TIME", portPanel.left + portPanel.width() * 0.17f, timeTrack.top - sy(0.032f), p)
        setText(min(width, height) * 0.034f, cyan, true, Paint.Align.RIGHT)
        canvas.drawText("$glideMs ms", timeTrack.right, timeTrack.top - sy(0.032f), p)

        drawSlider(canvas, timeTrack, (glideMs - 20f) / 980f, cyan)
    }

    private fun drawThird(canvas: Canvas) {
        val purple = Color.rgb(184, 70, 255)
        drawRound(canvas, thirdPanel, Color.rgb(10, 6, 17), purple, radius(0.003f), radius(0.018f))

        setText(min(width, height) * 0.041f, Color.rgb(239, 232, 244), true)
        canvas.drawText("TERCA", thirdPanel.centerX(), thirdPanel.top + thirdPanel.height() * 0.20f, p)

        val blinkOn = !thirdScanning || ((SystemClock.uptimeMillis() / 250L) % 2L == 0L)
        if (thirdScanning) postInvalidateDelayed(120L)
        val scanTop = if (thirdScanResult != 0) Color.rgb(18, 198, 124)
                      else if (thirdScanning && blinkOn) Color.rgb(0, 195, 255)
                      else if (thirdScanning) Color.rgb(16, 24, 34)
                      else Color.rgb(174, 36, 255)
        val scanBottom = if (thirdScanResult != 0) Color.rgb(9, 112, 77)
                         else if (thirdScanning && blinkOn) Color.rgb(0, 90, 220)
                         else if (thirdScanning) Color.rgb(5, 10, 18)
                         else Color.rgb(101, 0, 220)
        val sg = gradientPaint(scanRect, scanTop, scanBottom)
        sg.setShadowLayer(radius(0.010f), 0f, 0f, if (thirdScanResult != 0) Color.GREEN else purple)
        canvas.drawRoundRect(scanRect, radius(0.016f), radius(0.016f), sg)
        sg.clearShadowLayer()
        setText(min(width, height) * 0.027f, Color.WHITE, true)
        canvas.drawText("SCAN TERCA", scanRect.centerX(), scanRect.centerY() - (p.ascent() + p.descent()) / 2f, p)

        val tg = if (thirdEnabled) {
            gradientPaint(thirdToggleRect, Color.rgb(185, 47, 255), Color.rgb(99, 0, 210))
        } else {
            gradientPaint(thirdToggleRect, Color.rgb(46, 50, 61), Color.rgb(24, 28, 36))
        }
        canvas.drawRoundRect(thirdToggleRect, radius(0.016f), radius(0.016f), tg)
        p.style = Paint.Style.STROKE
        p.strokeWidth = radius(0.002f)
        p.color = if (thirdEnabled) purple else Color.rgb(105, 115, 130)
        canvas.drawRoundRect(thirdToggleRect, radius(0.016f), radius(0.016f), p)
        setText(min(width, height) * 0.027f, Color.WHITE, true)
        canvas.drawText("ON / OFF", thirdToggleRect.centerX(), thirdToggleRect.centerY() - (p.ascent() + p.descent()) / 2f, p)
    }

    private fun drawRibbon(canvas: Canvas) {
        val cyan = Color.rgb(0, 174, 255)
        drawRound(canvas, ribbonPanel, Color.rgb(2, 10, 15), Color.rgb(20, 73, 110), radius(0.003f), radius(0.018f))

        setText(min(width, height) * 0.025f, Color.WHITE, true, Paint.Align.RIGHT)
        canvas.drawText("RIBBON SENSITIVITY", sensMinusRect.left - sx(0.025f), sensTrack.centerY() - (p.ascent() + p.descent()) / 2f, p)

        drawSmallButton(canvas, sensMinusRect, "−")
        drawSmallButton(canvas, sensPlusRect, "+")
        val sensNorm = (ribbonSensitivity - 0.25f) / 1.75f
        drawSlider(canvas, sensTrack, sensNorm, cyan)

        val zoneGradient = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                ribbonTouch.left, ribbonTouch.top, ribbonTouch.right, ribbonTouch.bottom,
                intArrayOf(Color.rgb(3, 42, 88), Color.rgb(2, 13, 25), Color.rgb(2, 34, 75)),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(ribbonTouch, radius(0.012f), radius(0.012f), zoneGradient)
        p.style = Paint.Style.STROKE
        p.strokeWidth = radius(0.002f)
        p.color = cyan
        p.setShadowLayer(radius(0.008f), 0f, 0f, cyan)
        canvas.drawRoundRect(ribbonTouch, radius(0.012f), radius(0.012f), p)
        p.clearShadowLayer()

        // Fine vertical guide lines.
        p.strokeWidth = max(1f, radius(0.001f))
        p.color = Color.argb(50, 0, 166, 255)
        for (i in 1 until 36) {
            val x = ribbonTouch.left + ribbonTouch.width() * i / 36f
            canvas.drawLine(x, ribbonTouch.top, x, ribbonTouch.bottom, p)
        }

        val centerX = ribbonTouch.centerX()
        p.strokeWidth = radius(0.0025f)
        p.color = Color.WHITE
        p.setShadowLayer(radius(0.010f), 0f, 0f, cyan)
        canvas.drawLine(centerX, ribbonTouch.top, centerX, ribbonTouch.bottom, p)
        p.clearShadowLayer()

        drawArrow(canvas, ribbonTouch.left + ribbonTouch.width() * 0.04f, ribbonTouch.centerY(), false, cyan)
        drawArrow(canvas, ribbonTouch.right - ribbonTouch.width() * 0.04f, ribbonTouch.centerY(), true, cyan)

        // The round center orientation marker rests in the middle; while touched it follows the finger.
        val markerX = centerX + ribbonValue * ribbonTouch.width() * 0.5f
        p.style = Paint.Style.FILL
        p.color = Color.rgb(14, 20, 28)
        p.setShadowLayer(radius(0.013f), 0f, 0f, cyan)
        canvas.drawCircle(markerX, ribbonTouch.centerY(), radius(0.036f), p)
        p.clearShadowLayer()
        p.style = Paint.Style.STROKE
        p.strokeWidth = radius(0.006f)
        p.color = Color.rgb(0, 210, 255)
        canvas.drawCircle(markerX, ribbonTouch.centerY(), radius(0.036f), p)

    }

    private fun drawSlider(canvas: Canvas, track: RectF, norm: Float, color: Int) {
        val n = norm.coerceIn(0f, 1f)
        val r = RectF(track.left, track.centerY() - max(radius(0.004f), track.height() / 2f), track.right, track.centerY() + max(radius(0.004f), track.height() / 2f))
        drawRound(canvas, r, Color.rgb(42, 48, 58), Color.rgb(70, 80, 92), radius(0.0015f), radius(0.006f))
        val fill = RectF(r.left, r.top, r.left + r.width() * n, r.bottom)
        if (fill.width() > 0f) drawRound(canvas, fill, color, null, 0f, radius(0.006f), 0f)
        val x = r.left + r.width() * n
        p.style = Paint.Style.FILL
        p.color = color
        p.setShadowLayer(radius(0.010f), 0f, 0f, color)
        canvas.drawCircle(x, r.centerY(), radius(0.025f), p)
        p.clearShadowLayer()
        p.style = Paint.Style.STROKE
        p.strokeWidth = radius(0.002f)
        p.color = Color.rgb(0, 230, 255)
        canvas.drawCircle(x, r.centerY(), radius(0.025f), p)
    }

    private fun drawSmallButton(canvas: Canvas, rect: RectF, label: String) {
        drawRound(canvas, rect, Color.rgb(17, 24, 34), Color.rgb(63, 73, 87), radius(0.002f), radius(0.010f))
        setText(min(width, height) * 0.036f, Color.WHITE, true)
        canvas.drawText(label, rect.centerX(), rect.centerY() - (p.ascent() + p.descent()) / 2f, p)
    }

    private fun drawArrow(canvas: Canvas, cx: Float, cy: Float, right: Boolean, color: Int) {
        val w = radius(0.028f)
        val h = radius(0.042f)
        path.reset()
        if (right) {
            path.moveTo(cx - w, cy - h)
            path.lineTo(cx, cy)
            path.lineTo(cx - w, cy + h)
        } else {
            path.moveTo(cx + w, cy - h)
            path.lineTo(cx, cy)
            path.lineTo(cx + w, cy + h)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = radius(0.008f)
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
        p.setShadowLayer(radius(0.008f), 0f, 0f, color)
        canvas.drawPath(path, p)
        p.clearShadowLayer()
    }

    private fun drawSettings(canvas: Canvas) {
        p.style = Paint.Style.FILL
        p.color = Color.argb(205, 0, 0, 0)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)

        val cyan = Color.rgb(0, 174, 255)
        drawRound(canvas, settingsPanel, Color.rgb(3, 10, 16), cyan, radius(0.004f), radius(0.018f))

        for (i in 0..2) {
            val row = settingsRows[i]
            drawRound(canvas, row, Color.rgb(7, 16, 24), Color.rgb(29, 65, 90), radius(0.0018f), radius(0.009f))
            setText(min(width, height) * 0.030f, Color.WHITE, true, Paint.Align.LEFT)
            canvas.drawText("CHANNEL ${i + 1}", row.left + row.width() * 0.06f, row.centerY() - (p.ascent() + p.descent()) / 2f, p)

            drawSmallButton(canvas, settingsMinus[i], "−")
            setText(min(width, height) * 0.034f, cyan, true)
            val valueX = (settingsMinus[i].right + settingsPlus[i].left) / 2f
            canvas.drawText(channelMap[i].toString(), valueX, row.centerY() - (p.ascent() + p.descent()) / 2f, p)
            drawSmallButton(canvas, settingsPlus[i], "+")
        }
    }

    fun applyInitialSettings(
        portamentoEnabled: Boolean,
        glideMs: Int,
        curveMode: Int,
        thirdEnabled: Boolean,
        ribbonSensitivity: Float,
        channels: IntArray
    ) {
        this.portamentoEnabled = portamentoEnabled
        this.glideMs = glideMs.coerceIn(20, 1000)
        this.curveMode = curveMode.coerceIn(0, 3)
        this.thirdEnabled = thirdEnabled
        this.ribbonSensitivity = ribbonSensitivity.coerceIn(0.25f, 2.0f)
        if (channels.size >= 3 && channels.take(3).toSet().size == 3) {
            this.channelMap = channels.take(3).toIntArray()
        }
        invalidate()
    }

    private fun updateTime(x: Float) {
        val n = ((x - timeTrack.left) / timeTrack.width()).coerceIn(0f, 1f)
        glideMs = (20 + n * 980f).roundToInt()
        listener?.onGlideMs(glideMs)
        invalidate()
    }

    private fun updateSens(x: Float) {
        val n = ((x - sensTrack.left) / sensTrack.width()).coerceIn(0f, 1f)
        ribbonSensitivity = 0.25f + n * 1.75f
        listener?.onRibbonSensitivity(ribbonSensitivity)
        invalidate()
    }

    private fun updateRibbon(x: Float) {
        ribbonValue = (((x - ribbonTouch.centerX()) / (ribbonTouch.width() / 2f))).coerceIn(-1f, 1f)
        listener?.onRibbon(ribbonValue)
        invalidate()
    }

    private fun changeChannel(slot: Int, delta: Int) {
        var next = channelMap[slot] + delta
        if (next < 1) next = 16
        if (next > 16) next = 1

        val other = channelMap.indexOf(next)
        if (other >= 0 && other != slot) {
            val old = channelMap[slot]
            channelMap[other] = old
        }
        channelMap[slot] = next
        listener?.onChannelMapChanged(slot, next)
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (settingsOpen) {
                    if (gearRect.contains(x, y) || !settingsPanel.contains(x, y)) {
                        settingsOpen = false
                        invalidate()
                        return true
                    }
                    for (i in 0..2) {
                        if (settingsMinus[i].contains(x, y)) { changeChannel(i, -1); return true }
                        if (settingsPlus[i].contains(x, y)) { changeChannel(i, +1); return true }
                    }
                    return true
                }

                if (gearRect.contains(x, y)) {
                    settingsOpen = true
                    invalidate()
                    return true
                }

                if (portToggleRect.contains(x, y)) {
                    portamentoEnabled = !portamentoEnabled
                    listener?.onPortamentoEnabled(portamentoEnabled)
                    invalidate()
                    return true
                }

                for (i in 0..3) {
                    if (curveRects[i].contains(x, y)) {
                        curveMode = i
                        listener?.onCurveMode(i)
                        invalidate()
                        return true
                    }
                }

                if (timeTrack.contains(x, y) || y in (timeTrack.top - sy(0.035f))..(timeTrack.bottom + sy(0.035f))) {
                    dragTarget = DragTarget.TIME
                    updateTime(x)
                    return true
                }

                if (scanRect.contains(x, y)) {
                    // Real toggle: first press starts SCAN, second press cancels it immediately.
                    thirdScanning = !thirdScanning
                    if (thirdScanning) thirdScanResult = 0
                    listener?.onThirdScan(thirdScanning)
                    invalidate()
                    return true
                }

                if (thirdToggleRect.contains(x, y)) {
                    thirdEnabled = !thirdEnabled
                    listener?.onThirdEnabled(thirdEnabled)
                    invalidate()
                    return true
                }

                if (sensMinusRect.contains(x, y)) {
                    ribbonSensitivity = (ribbonSensitivity - 0.10f).coerceAtLeast(0.25f)
                    listener?.onRibbonSensitivity(ribbonSensitivity)
                    invalidate()
                    return true
                }

                if (sensPlusRect.contains(x, y)) {
                    ribbonSensitivity = (ribbonSensitivity + 0.10f).coerceAtMost(2.0f)
                    listener?.onRibbonSensitivity(ribbonSensitivity)
                    invalidate()
                    return true
                }

                if (sensTrack.contains(x, y) || y in (sensTrack.top - sy(0.035f))..(sensTrack.bottom + sy(0.035f))) {
                    dragTarget = DragTarget.SENS
                    updateSens(x)
                    return true
                }

                if (ribbonTouch.contains(x, y)) {
                    dragTarget = DragTarget.RIBBON
                    updateRibbon(x)
                    return true
                }
            }

            MotionEvent.ACTION_MOVE -> {
                when (dragTarget) {
                    DragTarget.TIME -> updateTime(x)
                    DragTarget.SENS -> updateSens(x)
                    DragTarget.RIBBON -> updateRibbon(x)
                    else -> Unit
                }
                if (dragTarget != DragTarget.NONE) return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragTarget == DragTarget.RIBBON) {
                    ribbonValue = 0f
                    listener?.onRibbon(0f)
                    invalidate()
                }
                dragTarget = DragTarget.NONE
                return true
            }
        }
        return true
    }
}
