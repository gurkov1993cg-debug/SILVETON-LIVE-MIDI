package com.silveton.livemidi

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var controller: MidiController
    private lateinit var deviceSpinner: Spinner
    private lateinit var statusView: TextView
    private var deviceList = emptyList<android.media.midi.MidiDeviceInfo>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()
        val gap = (8 * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "SILVETON"
            textSize = 24f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, pad)
        })

        deviceSpinner = Spinner(this)
        root.addView(
            deviceSpinner,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val linkRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, gap, 0, 0)
        }
        val scan = Button(this).apply {
            text = "SCAN"
            contentDescription = "Scan MIDI devices"
        }
        val connect = Button(this).apply {
            text = "CONNECT"
            contentDescription = "Connect MIDI device"
        }
        val off = Button(this).apply {
            text = "OFF"
            contentDescription = "Disconnect MIDI device"
        }
        linkRow.addView(scan, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        linkRow.addView(connect, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        linkRow.addView(off, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(linkRow)

        val portaRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, pad, 0, 0)
        }
        val portaLabel = TextView(this).apply {
            text = "PORTA"
            textSize = 18f
        }
        val timeLabel = TextView(this).apply {
            text = "180 ms"
            textSize = 18f
            gravity = Gravity.END
        }
        portaRow.addView(portaLabel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        portaRow.addView(timeLabel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(portaRow)

        val seek = SeekBar(this).apply {
            max = 980
            progress = 160
            contentDescription = "Portamento time"
        }
        root.addView(seek)

        statusView = TextView(this).apply {
            text = "OFF"
            textSize = 16f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, pad, 0, 0)
        }
        root.addView(statusView)

        setContentView(root)

        controller = MidiController(this) { text ->
            runOnUiThread { statusView.text = text }
        }
        controller.setGlideMs(180)

        fun refreshDevices() {
            deviceList = controller.devices
            val names = if (deviceList.isEmpty()) listOf("USB MIDI") else deviceList.map(controller::deviceName)
            deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        }

        scan.setOnClickListener { refreshDevices() }
        connect.setOnClickListener {
            val index = deviceSpinner.selectedItemPosition
            if (index in deviceList.indices) controller.connect(deviceList[index])
            else statusView.text = "USB?"
        }
        off.setOnClickListener { controller.disconnect() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val ms = progress + 20
                timeLabel.text = "$ms ms"
                controller.setGlideMs(ms)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        refreshDevices()
    }

    override fun onDestroy() {
        controller.close()
        super.onDestroy()
    }
}
