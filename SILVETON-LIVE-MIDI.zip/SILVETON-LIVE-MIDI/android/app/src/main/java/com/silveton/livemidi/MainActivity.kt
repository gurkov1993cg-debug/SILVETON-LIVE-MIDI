package com.silveton.livemidi

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {
    private lateinit var controller: MidiController
    private lateinit var liveView: LiveMidiView

    private val prefs by lazy { getSharedPreferences("silveton_live_midi", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        val glideMs = prefs.getInt("glide_ms", 180)
        val curveMode = prefs.getInt("curve_mode", 2)
        val thirdEnabled = prefs.getBoolean("third_enabled", false)
        val sensitivity = prefs.getFloat("ribbon_sensitivity", 1.0f)
        val channels = intArrayOf(
            prefs.getInt("channel_1", 1),
            prefs.getInt("channel_2", 2),
            prefs.getInt("channel_3", 3)
        )

        liveView = LiveMidiView(this)
        liveView.applyInitialSettings(glideMs, curveMode, thirdEnabled, sensitivity, channels)
        setContentView(liveView)

        controller = MidiController(
            this,
            connectionChanged = { connected ->
                runOnUiThread { liveView.connected = connected }
            },
            thirdScanChanged = { interval ->
                runOnUiThread { liveView.thirdScanResult = interval }
            }
        )

        controller.setChannelMap(channels)
        controller.setGlideMs(glideMs)
        controller.setCurveMode(curveMode)
        controller.setRibbonSensitivity(sensitivity)
        controller.setThirdEnabled(thirdEnabled)

        liveView.listener = object : LiveMidiView.Listener {
            override fun onGlideMs(value: Int) {
                controller.setGlideMs(value)
                prefs.edit().putInt("glide_ms", value).apply()
            }

            override fun onCurveMode(value: Int) {
                controller.setCurveMode(value)
                prefs.edit().putInt("curve_mode", value).apply()
            }

            override fun onThirdScan() {
                controller.startThirdScan()
            }

            override fun onThirdEnabled(enabled: Boolean) {
                controller.setThirdEnabled(enabled)
                prefs.edit().putBoolean("third_enabled", enabled).apply()
            }

            override fun onRibbonSensitivity(value: Float) {
                controller.setRibbonSensitivity(value)
                prefs.edit().putFloat("ribbon_sensitivity", value).apply()
            }

            override fun onRibbon(value: Float) {
                controller.setRibbon(value)
            }

            override fun onChannelMapChanged(slot: Int, midiChannel1Based: Int) {
                val map = liveView.channelMap
                controller.setChannelMap(map)
                prefs.edit()
                    .putInt("channel_1", map[0])
                    .putInt("channel_2", map[1])
                    .putInt("channel_3", map[2])
                    .apply()
            }
        }

        controller.start()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    private fun hideSystemUi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onDestroy() {
        controller.close()
        super.onDestroy()
    }
}
