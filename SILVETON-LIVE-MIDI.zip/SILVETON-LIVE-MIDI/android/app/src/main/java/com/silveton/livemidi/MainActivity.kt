package com.silveton.livemidi

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {
    private lateinit var controller: MidiController
    private lateinit var liveView: LiveMidiView

    private val prefs by lazy { getSharedPreferences("silveton_live_midi", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUi()

        // One-time migration from older builds that booted with effects already
        // armed. This guarantees the first Local-OFF test of the corrected
        // bridge starts transparent even when old SharedPreferences survived
        // an APK update. Later user choices are persisted normally.
        if (!prefs.getBoolean("transparent_bridge_migrated_v1", false)) {
            prefs.edit()
                .putBoolean("portamento_enabled", false)
                .putBoolean("third_enabled", false)
                .putBoolean("transparent_bridge_migrated_v1", true)
                .apply()
        }

        val portamentoEnabled = prefs.getBoolean("portamento_enabled", false)
        val portamentoTime = prefs.getInt("portamento_time", 64)
        val thirdEnabled = prefs.getBoolean("third_enabled", false)
        val sensitivity = prefs.getFloat("ribbon_sensitivity", 1.0f)
        val ribbonRange = prefs.getInt("ribbon_range_semitones", 2)
        // Default is the safe mode: PA600 Local Control ON, the app echoes
        // nothing back. Local OFF bridging must be chosen explicitly.
        val keyboardLocal = prefs.getBoolean("keyboard_local", true)
        val lowerChannel = prefs.getInt("lower_channel", 4)
        val channels = intArrayOf(
            prefs.getInt("channel_1", 1),
            prefs.getInt("channel_2", 2),
            prefs.getInt("channel_3", 3)
        )

        liveView = LiveMidiView(this)
        liveView.applyInitialSettings(
            portamentoEnabled, portamentoTime, thirdEnabled, sensitivity, ribbonRange, channels,
            keyboardLocal, lowerChannel
        )
        setContentView(liveView)

        controller = MidiController(
            this,
            connectionChanged = { connected ->
                runOnUiThread { liveView.connected = connected }
            },
            thirdScanChanged = { interval ->
                runOnUiThread { liveView.thirdScanResult = interval }
            },
            thirdScanningChanged = { scanning ->
                runOnUiThread { liveView.syncThirdScanning(scanning) }
            },
            statusChanged = { warning ->
                runOnUiThread { liveView.warning = warning }
            }
        )

        controller.setKeyboardLocal(keyboardLocal)
        controller.setLowerChannel(lowerChannel)
        controller.setChannelMap(channels)
        controller.setPortamentoTime(portamentoTime)
        controller.setPortamentoEnabled(portamentoEnabled)
        controller.setRibbonSensitivity(sensitivity)
        controller.setRibbonRangeSemitones(ribbonRange)
        controller.setThirdEnabled(thirdEnabled)

        liveView.listener = object : LiveMidiView.Listener {
            override fun onPortamentoEnabled(enabled: Boolean) {
                controller.setPortamentoEnabled(enabled)
                prefs.edit().putBoolean("portamento_enabled", enabled).apply()
            }

            override fun onPortamentoTime(value: Int) {
                controller.setPortamentoTime(value)
                prefs.edit().putInt("portamento_time", value).apply()
            }

            override fun onThirdScan(scanning: Boolean) {
                controller.setThirdScanning(scanning)
            }

            override fun onThirdEnabled(enabled: Boolean) {
                controller.setThirdEnabled(enabled)
                prefs.edit().putBoolean("third_enabled", enabled).apply()
            }

            override fun onRibbonSensitivity(value: Float) {
                controller.setRibbonSensitivity(value)
                prefs.edit().putFloat("ribbon_sensitivity", value).apply()
            }

            override fun onRibbonRangeSemitones(value: Int) {
                controller.setRibbonRangeSemitones(value)
                prefs.edit().putInt("ribbon_range_semitones", value).apply()
            }

            override fun onRibbon(value: Float) {
                controller.setRibbon(value)
            }

            override fun onPanic() {
                controller.panic()
            }

            override fun onKeyboardLocal(keyboardLocal: Boolean) {
                controller.setKeyboardLocal(keyboardLocal)
                prefs.edit().putBoolean("keyboard_local", keyboardLocal).apply()
            }

            override fun onLowerChannel(midiChannel1Based: Int) {
                controller.setLowerChannel(midiChannel1Based)
                prefs.edit().putInt("lower_channel", midiChannel1Based).apply()
            }

            override fun onChannelMapChanged(slot: Int, midiChannel1Based: Int) {
                val map = liveView.channelMap
                controller.setChannelMap(map)
                prefs.edit()
                    .putInt("channel_1", map[0])
                    .putInt("channel_2", map[1])
                    .putInt("channel_3", map[2])
                    .apply()
            }
        }

        controller.start()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    private fun hideSystemUi() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onDestroy() {
        controller.close()
        super.onDestroy()
    }
}
