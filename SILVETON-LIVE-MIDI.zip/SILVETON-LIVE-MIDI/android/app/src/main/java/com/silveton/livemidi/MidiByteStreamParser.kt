package com.silveton.livemidi

class MidiByteStreamParser(private val emit: (ByteArray) -> Unit) {
    private var runningStatus = 0
    private var pendingStatus = 0
    private var needed = 0
    private var count = 0
    private val shortData = IntArray(2)
    private var inSysEx = false
    private val sysEx = ArrayList<Byte>(256)

    fun feed(data: ByteArray, offset: Int, length: Int) {
        for (i in offset until offset + length) feedByte(data[i].toInt() and 0xFF)
    }

    private fun feedByte(b: Int) {
        if (b >= 0xF8) {
            emit(byteArrayOf(b.toByte()))
            return
        }

        if (inSysEx) {
            sysEx.add(b.toByte())
            if (b == 0xF7 || sysEx.size >= 65536) {
                emit(sysEx.toByteArray())
                sysEx.clear()
                inSysEx = false
            }
            return
        }

        if (b and 0x80 != 0) {
            if (b == 0xF0) {
                runningStatus = 0
                pendingStatus = 0
                needed = 0
                count = 0
                inSysEx = true
                sysEx.clear()
                sysEx.add(b.toByte())
                return
            }

            pendingStatus = b
            count = 0
            needed = dataBytesForStatus(b)
            if (b < 0xF0) runningStatus = b else runningStatus = 0
            if (needed == 0) {
                emit(byteArrayOf(b.toByte()))
                pendingStatus = 0
            }
            return
        }

        if (pendingStatus == 0) {
            if (runningStatus == 0) return
            pendingStatus = runningStatus
            needed = dataBytesForStatus(runningStatus)
            count = 0
        }

        if (count < shortData.size) shortData[count] = b and 0x7F
        count++
        if (count >= needed) {
            val message = ByteArray(1 + needed)
            message[0] = pendingStatus.toByte()
            for (j in 0 until needed) message[j + 1] = shortData[j].toByte()
            emit(message)
            pendingStatus = if (runningStatus != 0) runningStatus else 0
            count = 0
            needed = if (pendingStatus != 0) dataBytesForStatus(pendingStatus) else 0
        }
    }

    private fun dataBytesForStatus(status: Int): Int {
        return when {
            status in 0x80..0xBF -> 2
            status in 0xC0..0xDF -> 1
            status in 0xE0..0xEF -> 2
            status == 0xF1 -> 1
            status == 0xF2 -> 2
            status == 0xF3 -> 1
            status == 0xF6 || status == 0xF7 -> 0
            else -> 0
        }
    }
}
