package com.silveton.livemidi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import java.io.IOException

class MidiController(
    context: Context,
    private val connectionChanged: (Boolean) -> Unit,
    private val thirdScanChanged: (Int) -> Unit
) {
    private val midiManager = context.getSystemService(MidiManager::class.java)
    private val engine = NativeMidiEngine()
    private val loopGuard = LoopGuard()
    private val parser = MidiByteStreamParser(::onMidiMessage)

    private var device: MidiDevice? = null
    private var deviceInfo: MidiDeviceInfo? = null
    private var toKorg: MidiInputPort? = null
    private var fromKorg: MidiOutputPort? = null
    private var receiver: MidiReceiver? = null

    private val midiThread = HandlerThread("SilvetonMidi", Process.THREAD_PRIORITY_URGENT_AUDIO).apply { start() }
    private val handler = Handler(midiThread.looper)
    @Volatile private var running = false
    @Volatile private var closed = false

    // Physical MIDI channels, zero-based. Defaults are Upper 1/2/3 -> MIDI 1/2/3.
    private val channelMap = intArrayOf(0, 1, 2)
    private var lastScanResult = 0

    private val poller = object : Runnable {
        override fun run() {
            if (!running) return
            sendPacked(engine.nativePoll(nowUs()))
            val scan = engine.nativeThirdScanResult()
            if (scan != lastScanResult) {
                lastScanResult = scan
                thirdScanChanged(scan)
            }
            handler.postDelayed(this, 1L)
        }
    }

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            handler.post { if (!running) tryAutoConnect() }
        }

        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            if (deviceInfo?.id == info.id) {
                handler.post {
                    disconnectInternal()
                    tryAutoConnect()
                }
            }
        }
    }

    fun start() {
        midiManager.registerDeviceCallback(deviceCallback, handler)
        handler.post { tryAutoConnect() }
    }

    fun setPortamentoEnabled(enabled: Boolean) {
        handler.post { sendPacked(engine.nativeSetPortamentoEnabled(enabled)) }
    }

    fun setGlideMs(ms: Int) {
        handler.post { engine.nativeSetGlideMs(ms.coerceIn(20, 1000)) }
    }

    fun setCurveMode(mode: Int) {
        handler.post { engine.nativeSetCurveMode(mode.coerceIn(0, 3)) }
    }

    fun setThirdEnabled(enabled: Boolean) {
        handler.post {
            sendPacked(engine.nativeSetThirdEnabled(enabled))
        }
    }

    fun startThirdScan() {
        handler.post {
            lastScanResult = 0
            sendPacked(engine.nativeStartThirdScan())
        }
    }

    fun setRibbonSensitivity(value: Float) {
        handler.post { engine.nativeSetRibbonSensitivity(value.coerceIn(0.25f, 2.0f)) }
    }

    fun setRibbon(position: Float) {
        val p = position.coerceIn(-1f, 1f)
        handler.post {
            if (running) sendPacked(engine.nativeRibbon(p, nowUs()))
        }
    }

    fun setUpperChannel(slot: Int, midiChannel1Based: Int): IntArray {
        if (slot !in 0..2) return channelMap.map { it + 1 }.toIntArray()
        val target = (midiChannel1Based - 1).coerceIn(0, 15)

        handler.post {
            sendPacked(engine.nativePanic())
            val old = channelMap[slot]
            val other = channelMap.indexOf(target)
            if (other >= 0 && other != slot) channelMap[other] = old
            channelMap[slot] = target
        }

        val preview = channelMap.copyOf()
        val old = preview[slot]
        val other = preview.indexOf(target)
        if (other >= 0 && other != slot) preview[other] = old
        preview[slot] = target
        return preview.map { it + 1 }.toIntArray()
    }

    fun setChannelMap(values1Based: IntArray) {
        if (values1Based.size < 3) return
        val candidate = intArrayOf(
            (values1Based[0] - 1).coerceIn(0, 15),
            (values1Based[1] - 1).coerceIn(0, 15),
            (values1Based[2] - 1).coerceIn(0, 15)
        )
        if (candidate.toSet().size != 3) return
        handler.post {
            sendPacked(engine.nativePanic())
            for (i in 0..2) channelMap[i] = candidate[i]
            configurePitchBendRange()
        }
    }

    fun channelMap1Based(): IntArray = channelMap.map { it + 1 }.toIntArray()

    private fun tryAutoConnect() {
        if (closed || running) return
        val info = midiManager.devices.firstOrNull { it.inputPortCount > 0 && it.outputPortCount > 0 }
        if (info == null) {
            connectionChanged(false)
            return
        }
        open(info)
    }

    private fun open(info: MidiDeviceInfo) {
        midiManager.openDevice(info, { opened ->
            if (opened == null) {
                connectionChanged(false)
                return@openDevice
            }
            handler.post {
                if (closed) {
                    opened.close()
                    return@post
                }
                val input = opened.openInputPort(0)
                val output = opened.openOutputPort(0)
                if (input == null || output == null) {
                    input?.close()
                    output?.close()
                    opened.close()
                    connectionChanged(false)
                    return@post
                }

                val rx = object : MidiReceiver() {
                    override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                        val copy = msg.copyOfRange(offset, offset + count)
                        handler.post { parser.feed(copy, 0, copy.size) }
                    }
                }
                output.connect(rx)

                device = opened
                deviceInfo = info
                toKorg = input
                fromKorg = output
                receiver = rx
                loopGuard.clear()
                running = true
                configurePitchBendRange()
                handler.removeCallbacks(poller)
                handler.post(poller)
                connectionChanged(true)
            }
        }, handler)
    }


    // Standard MIDI RPN 0,0: Pitch Bend Sensitivity = +/-12 semitones.
    // Portamento needs this exact range so a 1-semitone glide is as real/audible as an octave glide.
    private fun configurePitchBendRange() {
        if (!running) return
        for (physicalChannel in channelMap) {
            val st = 0xB0 or physicalChannel
            sendRaw(byteArrayOf(st.toByte(), 101.toByte(), 0))
            sendRaw(byteArrayOf(st.toByte(), 100.toByte(), 0))
            sendRaw(byteArrayOf(st.toByte(), 6.toByte(), 12.toByte()))
            sendRaw(byteArrayOf(st.toByte(), 38.toByte(), 0))
            sendRaw(byteArrayOf(st.toByte(), 101.toByte(), 127.toByte()))
            sendRaw(byteArrayOf(st.toByte(), 100.toByte(), 127.toByte()))
        }
    }

    private fun canonicalSlotForPhysical(physicalChannel: Int): Int {
        for (i in 0..2) if (channelMap[i] == physicalChannel) return i
        return -1
    }

    private fun physicalChannelForCanonical(canonicalChannel: Int): Int {
        return if (canonicalChannel in 0..2) channelMap[canonicalChannel] else canonicalChannel
    }

    private fun onMidiMessage(message: ByteArray) {
        if (!running || message.isEmpty()) return
        if (loopGuard.isEcho(message)) return

        val statusByte = message[0].toInt() and 0xFF
        val isChannel = statusByte in 0x80..0xEF
        if (!isChannel || message.size > 3) {
            sendRaw(message)
            return
        }

        val physicalChannel = statusByte and 0x0F
        val canonical = canonicalSlotForPhysical(physicalChannel)
        if (canonical < 0) {
            // Lower, Style and all non-Upper channels stay transparent.
            sendRaw(message)
            return
        }

        val canonicalStatus = (statusByte and 0xF0) or canonical
        val d1 = if (message.size > 1) message[1].toInt() and 0x7F else 0
        val d2 = if (message.size > 2) message[2].toInt() and 0x7F else 0
        val packed = engine.nativeProcess(canonicalStatus, d1, d2, message.size, nowUs())
        sendPacked(packed)
    }

    private fun sendPacked(packed: IntArray) {
        var i = 0
        while (i + 3 < packed.size) {
            val size = packed[i + 3].coerceIn(1, 3)
            val status = packed[i] and 0xFF
            val bytes = ByteArray(size)
            if (status in 0x80..0xEF) {
                val canonical = status and 0x0F
                val physical = physicalChannelForCanonical(canonical)
                bytes[0] = ((status and 0xF0) or physical).toByte()
            } else {
                bytes[0] = status.toByte()
            }
            if (size > 1) bytes[1] = packed[i + 1].toByte()
            if (size > 2) bytes[2] = packed[i + 2].toByte()
            sendRaw(bytes)
            i += 4
        }
    }

    private fun sendRaw(message: ByteArray) {
        val port = toKorg ?: return
        try {
            loopGuard.remember(message)
            port.send(message, 0, message.size)
        } catch (_: IOException) {
            connectionChanged(false)
        }
    }

    private fun disconnectInternal() {
        if (running) {
            sendPacked(engine.nativePanic())
        }
        running = false
        handler.removeCallbacks(poller)
        try { fromKorg?.close() } catch (_: IOException) {}
        try { toKorg?.close() } catch (_: IOException) {}
        try { device?.close() } catch (_: IOException) {}
        fromKorg = null
        toKorg = null
        device = null
        deviceInfo = null
        receiver = null
        loopGuard.clear()
        connectionChanged(false)
    }

    fun close() {
        closed = true
        handler.post {
            disconnectInternal()
            midiManager.unregisterDeviceCallback(deviceCallback)
            midiThread.quitSafely()
        }
    }

    private fun nowUs(): Long = System.nanoTime() / 1000L
}
