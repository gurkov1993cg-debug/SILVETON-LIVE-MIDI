package com.silveton.livemidi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import java.io.IOException

class MidiController(
    context: Context,
    private val status: (String) -> Unit
) {
    private val midiManager = context.getSystemService(MidiManager::class.java)
    private val engine = NativeMidiEngine()
    private val loopGuard = LoopGuard()
    private val parser = MidiByteStreamParser(::onMidiMessage)

    private var device: MidiDevice? = null
    private var toKorg: MidiInputPort? = null
    private var fromKorg: MidiOutputPort? = null

    private val midiThread = HandlerThread("SilvetonMidi", Process.THREAD_PRIORITY_URGENT_AUDIO).apply { start() }
    private val handler = Handler(midiThread.looper)
    @Volatile private var running = false

    private val poller = object : Runnable {
        override fun run() {
            if (!running) return
            sendPacked(engine.nativePoll(System.nanoTime() / 1000L))
            handler.postDelayed(this, 1L)
        }
    }

    val devices: List<MidiDeviceInfo>
        get() = midiManager.devices.filter { it.inputPortCount > 0 && it.outputPortCount > 0 }

    fun setGlideMs(ms: Int) = engine.nativeSetGlideMs(ms.coerceIn(20, 1000))

    fun connect(info: MidiDeviceInfo) {
        disconnect()
        status("…")
        midiManager.openDevice(info, { opened ->
            if (opened == null) {
                status("USB?")
                return@openDevice
            }
            handler.post {
                val input = opened.openInputPort(0)
                val output = opened.openOutputPort(0)
                if (input == null || output == null) {
                    input?.close(); output?.close(); opened.close()
                    status("MIDI?")
                    return@post
                }
                device = opened
                toKorg = input
                fromKorg = output
                output.connect(object : MidiReceiver() {
                    override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                        val copy = msg.copyOfRange(offset, offset + count)
                        handler.post { parser.feed(copy, 0, copy.size) }
                    }
                })
                loopGuard.clear()
                running = true
                handler.removeCallbacks(poller)
                handler.post(poller)
                status("ON")
            }
        }, handler)
    }

    fun disconnect() {
        running = false
        handler.removeCallbacks(poller)
        sendPacked(engine.nativePanic())
        try { fromKorg?.close() } catch (_: IOException) {}
        try { toKorg?.close() } catch (_: IOException) {}
        try { device?.close() } catch (_: IOException) {}
        fromKorg = null
        toKorg = null
        device = null
        loopGuard.clear()
        status("OFF")
    }

    fun close() {
        disconnect()
        midiThread.quitSafely()
    }

    private fun onMidiMessage(message: ByteArray) {
        if (!running || message.isEmpty()) return
        if (loopGuard.isEcho(message)) return

        val statusByte = message[0].toInt() and 0xFF
        val isChannel = statusByte in 0x80..0xEF
        if (!isChannel || message.size > 3) {
            sendRaw(message)
            return
        }

        val d1 = if (message.size > 1) message[1].toInt() and 0x7F else 0
        val d2 = if (message.size > 2) message[2].toInt() and 0x7F else 0
        val packed = engine.nativeProcess(statusByte, d1, d2, message.size, System.nanoTime() / 1000L)
        sendPacked(packed)
    }

    private fun sendPacked(packed: IntArray) {
        var i = 0
        while (i + 3 < packed.size) {
            val size = packed[i + 3].coerceIn(1, 3)
            val bytes = ByteArray(size)
            bytes[0] = packed[i].toByte()
            if (size > 1) bytes[1] = packed[i + 1].toByte()
            if (size > 2) bytes[2] = packed[i + 2].toByte()
            sendRaw(bytes)
            i += 4
        }
    }

    private fun sendRaw(message: ByteArray) {
        val port = toKorg ?: return
        try {
            loopGuard.remember(message)
            port.send(message, 0, message.size)
        } catch (_: IOException) {
            status("USB!")
        }
    }

    fun deviceName(info: MidiDeviceInfo): String {
        val p = info.properties
        return p.getString(MidiDeviceInfo.PROPERTY_NAME)
            ?: p.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
            ?: "MIDI device ${info.id}"
    }
}
