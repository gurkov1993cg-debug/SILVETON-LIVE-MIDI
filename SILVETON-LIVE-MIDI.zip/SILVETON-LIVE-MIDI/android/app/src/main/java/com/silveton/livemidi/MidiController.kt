package com.silveton.livemidi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import java.io.IOException

class MidiController(
    context: Context,
    private val connectionChanged: (Boolean) -> Unit,
    private val thirdScanChanged: (Int) -> Unit,
    private val thirdScanningChanged: (Boolean) -> Unit,
    private val statusChanged: (String?) -> Unit = {}
) {
    private val midiManager = context.getSystemService(MidiManager::class.java)
    private val engine = NativeMidiEngine()
    private val sender = Pa600MidiSender()
    private val parser = MidiByteStreamParser(::onMidiMessage)

    private var device: MidiDevice? = null
    private var deviceInfo: MidiDeviceInfo? = null
    private var toKorg: MidiInputPort? = null
    private var fromKorg: MidiOutputPort? = null
    private var receiver: MidiReceiver? = null

    private val midiThread = HandlerThread("SilvetonMidi", Process.THREAD_PRIORITY_URGENT_AUDIO).apply { start() }
    private val handler = Handler(midiThread.looper)
    @Volatile private var running = false
    @Volatile private var closed = false

    // Physical MIDI channels, zero-based. Defaults are Upper 1/2/3 -> MIDI 1/2/3.
    private val channelMap = intArrayOf(0, 1, 2)
    private var lastScanResult = 0
    private var lastScanRevision = 0
    private var lastScanning = false
    private var thirdEnabledState = false
    private var thirdTonalityValidState = false
    private var portamentoEnabledState = false
    private var portamentoTimeState = 120 // milliseconds
    // true  = PA600 Local Control ON: the keyboard sounds its own keybed, the
    //         app echoes NOTHING back and only sends what it generates.
    // false = PA600 Local Control OFF: the app bridges U1/U2/U3 (+ Lower).
    private var keyboardLocal = true
    // Zero-based Lower MIDI channel bridged in Local-OFF mode; -1 = none.
    private var lowerChannel = 3

    // Runaway-traffic breaker. A human on a PA600 cannot produce anywhere near
    // this many channel messages; a MIDI feedback loop produces far more.
    private var rateWindowStartNs = 0L
    private var rateWindowCount = 0
    private var loopMutedUntilNs = 0L
    private val loopWindowNs = 100_000_000L
    private val loopMaxPerWindow = 500
    private val loopCooldownNs = 2_000_000_000L

    // Ribbon rest handling: after the finger leaves and the ribbon has settled,
    // the PA600 is returned to its normal +/-2 bend range.
    private var ribbonTarget = 0f
    private var ribbonRestGeneration = 0
    private val ribbonRestDelayMs = 250L

    // False means physical PA600 Pitch Bend is byte-for-byte pass-through at
    // the normal +/-2 range. It becomes true only after Ribbon is actually used.
    private var pitchTransportConfigured = false

    private val poller = object : Runnable {
        override fun run() {
            if (!running) return
            if (pitchTransportConfigured) sendPacked(engine.nativePoll(nowUs()))
            if (loopMutedUntilNs != 0L && System.nanoTime() >= loopMutedUntilNs) {
                loopMutedUntilNs = 0L
                statusChanged(null)
            }
            val revision = engine.nativeThirdScanRevision()
            if (revision != lastScanRevision) {
                lastScanRevision = revision
                val scan = engine.nativeThirdScanResult()
                lastScanResult = scan
                if (scan != 0) {
                    thirdEnabledState = true
                    thirdTonalityValidState = true
                }
                thirdScanChanged(scan)
            }
            val scanning = engine.nativeThirdScanning()
            if (scanning != lastScanning) {
                lastScanning = scanning
                thirdScanningChanged(scanning)
            }
            val fast = pitchTransportConfigured || lastScanning
            handler.postDelayed(this, if (fast) 2L else 15L)
        }
    }

    private val deviceCallback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) {
            handler.post { if (!running) tryAutoConnect() }
        }

        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            if (deviceInfo?.id == info.id) {
                handler.post {
                    disconnectInternal()
                    tryAutoConnect()
                }
            }
        }
    }

    fun start() {
        midiManager.registerDeviceCallback(deviceCallback, handler)
        handler.post { tryAutoConnect() }
    }

    fun setPortamentoEnabled(enabled: Boolean) {
        handler.post {
            portamentoEnabledState = enabled
            if (!running) {
                engine.nativeSetPortamentoEnabled(enabled)
                return@post
            }
            // TIME portamento is rendered as Pitch Bend on the +/-12 transport.
            if (enabled) engagePitchTransport()
            sendPacked(engine.nativeSetPortamentoEnabled(enabled))
            if (!enabled && kotlin.math.abs(ribbonTarget) <= 0.0005f) scheduleRibbonRest()
        }
    }

    /** value = TIME slider position 0..127 (converted to milliseconds). */
    fun setPortamentoTime(value: Int) {
        val ms = PortaTime.msForSlider(value)
        handler.post {
            portamentoTimeState = ms
            sendPacked(engine.nativeSetPortamentoTimeMs(ms))
        }
    }

    private fun engagePitchTransport() {
        if (!running || pitchTransportConfigured) return
        // Local OFF: fixed +/-12 transport. Local ON: the native core owns the
        // range (keeps the keyboard's +/-2 and widens only while needed).
        if (!keyboardLocal) configurePitchBendRange(12)
        sendPacked(engine.nativeSetPitchTransportEnabled(true))
        pitchTransportConfigured = true
    }

    /** After a panic/reset the transport is gone; bring PORTA back if it is ON. */
    private fun reengagePortamento() {
        if (!running || !portamentoEnabledState) return
        engagePitchTransport()
        sendPacked(engine.nativeSyncPortamento())
    }

    fun setThirdEnabled(enabled: Boolean) {
        handler.post {
            thirdEnabledState = enabled
            sendPacked(engine.nativeSetThirdEnabled(enabled))
        }
    }

    fun setThirdScanning(scanning: Boolean) {
        handler.post {
            sendPacked(engine.nativeSetThirdScanning(scanning))
            val actual = engine.nativeThirdScanning()
            if (actual != lastScanning) {
                lastScanning = actual
                thirdScanningChanged(actual)
            }
        }
    }

    fun setKeyboardLocal(local: Boolean) {
        handler.post {
            if (keyboardLocal == local) {
                engine.nativeSetKeyboardLocal(local)
                return@post
            }
            // A mode change is a session boundary: release everything first so
            // no note that was started in one mode is left hanging in the other.
            panicOutputAndReset()
            keyboardLocal = local
            engine.nativeSetKeyboardLocal(local)
            reengagePortamento()
        }
    }

    fun setLowerChannel(midiChannel1Based: Int) {
        handler.post {
            lowerChannel = if (midiChannel1Based in 1..16) midiChannel1Based - 1 else -1
        }
    }

    fun setRibbonSensitivity(value: Float) {
        handler.post { engine.nativeSetRibbonSensitivity(value.coerceIn(0.25f, 2.0f)) }
    }

    fun setRibbonRangeSemitones(value: Int) {
        handler.post { engine.nativeSetRibbonRangeSemitones(value.coerceIn(1, 12)) }
    }

    fun setRibbon(position: Float) {
        val p = position.coerceIn(-1f, 1f)
        handler.post {
            if (!running) return@post
            ribbonTarget = p
            ribbonRestGeneration++

            // The PA600 stays at its normal +/-2 bend range until Ribbon is
            // really moved. Only then is the +/-12 transport configured.
            if (!pitchTransportConfigured && kotlin.math.abs(p) > 0.0005f) engagePitchTransport()
            if (pitchTransportConfigured) {
                sendPacked(engine.nativeRibbon(p, nowUs()))
                if (kotlin.math.abs(p) <= 0.0005f) scheduleRibbonRest()
            }
        }
    }

    private fun scheduleRibbonRest() {
        val generation = ribbonRestGeneration
        handler.postDelayed({
            if (!running || !pitchTransportConfigured) return@postDelayed
            if (generation != ribbonRestGeneration) return@postDelayed
            // TIME portamento needs the transport; keep it while PORTA is ON.
            if (portamentoEnabledState) return@postDelayed
            if (kotlin.math.abs(ribbonTarget) > 0.0005f) return@postDelayed
            // Let the smoothed return reach center, then hand the wheel back:
            // RPN range 2 first, then the raw physical wheel position.
            sendPacked(engine.nativePoll(nowUs()))
            configurePitchBendRange(2)
            sendPacked(engine.nativeSetPitchTransportEnabled(false))
            pitchTransportConfigured = false
        }, ribbonRestDelayMs)
    }

    fun setUpperChannel(slot: Int, midiChannel1Based: Int): IntArray {
        if (slot !in 0..2) return channelMap.map { it + 1 }.toIntArray()
        val target = (midiChannel1Based - 1).coerceIn(0, 15)

        handler.post {
            panicOutputAndReset()
            val old = channelMap[slot]
            val other = channelMap.indexOf(target)
            if (other >= 0 && other != slot) channelMap[other] = old
            channelMap[slot] = target
            reengagePortamento()
        }

        val preview = channelMap.copyOf()
        val old = preview[slot]
        val other = preview.indexOf(target)
        if (other >= 0 && other != slot) preview[other] = old
        preview[slot] = target
        return preview.map { it + 1 }.toIntArray()
    }

    fun setChannelMap(values1Based: IntArray) {
        if (values1Based.size < 3) return
        val candidate = intArrayOf(
            (values1Based[0] - 1).coerceIn(0, 15),
            (values1Based[1] - 1).coerceIn(0, 15),
            (values1Based[2] - 1).coerceIn(0, 15)
        )
        if (candidate.toSet().size != 3) return
        handler.post {
            panicOutputAndReset()
            for (i in 0..2) channelMap[i] = candidate[i]
            reengagePortamento()
        }
    }

    fun channelMap1Based(): IntArray = channelMap.map { it + 1 }.toIntArray()

    private fun tryAutoConnect() {
        if (closed || running) return
        val info = pickKorgDevice(midiManager.devices)
        if (info == null) {
            connectionChanged(false)
            return
        }
        open(info)
    }

    /**
     * Only a real USB MIDI device with both directions is accepted. Virtual
     * ports (other apps, loopback drivers) and Bluetooth are never chosen:
     * bridging into a virtual port that echoes back is an instant MIDI loop.
     * A device whose name mentions KORG / PA is preferred.
     */
    private fun pickKorgDevice(devices: Array<MidiDeviceInfo>): MidiDeviceInfo? {
        return devices
            .filter { it.type == MidiDeviceInfo.TYPE_USB && it.inputPortCount > 0 && it.outputPortCount > 0 }
            .maxByOrNull { info ->
                val props = info.properties
                val text = listOfNotNull(
                    props.getString(MidiDeviceInfo.PROPERTY_NAME),
                    props.getString(MidiDeviceInfo.PROPERTY_MANUFACTURER),
                    props.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
                ).joinToString(" ").uppercase()
                when {
                    "PA600" in text || "PA 600" in text -> 3
                    "KORG" in text -> 2
                    Regex("\\bPA\\d").containsMatchIn(text) -> 1
                    else -> 0
                }
            }
    }

    private fun open(info: MidiDeviceInfo) {
        midiManager.openDevice(info, { opened ->
            if (opened == null) {
                connectionChanged(false)
                return@openDevice
            }
            handler.post {
                if (closed) {
                    opened.close()
                    return@post
                }
                val input = opened.openInputPort(0)
                val output = opened.openOutputPort(0)
                if (input == null || output == null) {
                    input?.close()
                    output?.close()
                    opened.close()
                    connectionChanged(false)
                    return@post
                }

                val rx = object : MidiReceiver() {
                    override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
                        val copy = msg.copyOfRange(offset, offset + count)
                        handler.post { parser.feed(copy, 0, copy.size) }
                    }
                }
                output.connect(rx)

                device = opened
                deviceInfo = info
                toKorg = input
                sender.attach(input)
                fromKorg = output
                receiver = rx
                running = true
                engine.nativeSetKeyboardLocal(keyboardLocal)
                // True transparent baseline for Local Control OFF. Connecting
                // must not alter the PA600: no RPN, no CC5/CC65 and no Pitch
                // Bend reset are emitted here. We only reset the app's internal
                // pitch-composition state.
                pitchTransportConfigured = false
                engine.nativeSetPitchTransportEnabled(false)
                // Restore Portamento only when the user explicitly left it ON.
                // With it OFF, connection remains byte-for-byte transparent.
                engine.nativeSetPortamentoTimeMs(portamentoTimeState)
                reengagePortamento()
                handler.removeCallbacks(poller)
                handler.post(poller)
                connectionChanged(true)
            }
        }, handler)
    }


    // Standard MIDI RPN 0,0.  Baseline is +/-2 for transparent physical
    // Pitch Bend. Ribbon temporarily uses +/-12 as an internal transport.
    private fun configurePitchBendRange(semitones: Int) {
        if (!running) return
        for (physicalChannel in channelMap) {
            configurePitchBendRangeForChannel(physicalChannel, semitones)
        }
    }

    private fun configurePitchBendRangeForChannel(physicalChannel: Int, semitones: Int) {
        if (!running) return
        val ch = physicalChannel.coerceIn(0, 15)
        val range = semitones.coerceIn(1, 24)
        val st = 0xB0 or ch
        sendRaw(byteArrayOf(st.toByte(), 101.toByte(), 0))
        sendRaw(byteArrayOf(st.toByte(), 100.toByte(), 0))
        sendRaw(byteArrayOf(st.toByte(), 6.toByte(), range.toByte()))
        sendRaw(byteArrayOf(st.toByte(), 38.toByte(), 0))
        // RPN Null prevents later Data Entry from accidentally changing PB range.
        sendRaw(byteArrayOf(st.toByte(), 101.toByte(), 127.toByte()))
        sendRaw(byteArrayOf(st.toByte(), 100.toByte(), 127.toByte()))
    }

    private fun canonicalSlotForPhysical(physicalChannel: Int): Int {
        for (i in 0..2) if (channelMap[i] == physicalChannel) return i
        return -1
    }

    private fun physicalChannelForCanonical(canonicalChannel: Int): Int {
        return if (canonicalChannel in 0..2) channelMap[canonicalChannel] else canonicalChannel
    }

    private fun onMidiMessage(message: ByteArray) {
        if (!running || message.isEmpty()) return

        val statusByte = message[0].toInt() and 0xFF
        // System messages (MIDI Clock, Active Sensing, Start/Stop, SysEx, ...)
        // are never returned to the PA600. Echoing Clock/Active Sensing/SysEx
        // back into the instrument is a classic source of loops and freezes.
        if (statusByte !in 0x80..0xEF || message.size > 3) return

        if (loopBreakerTripped()) return

        val command = statusByte and 0xF0
        val physicalChannel = statusByte and 0x0F
        val canonical = canonicalSlotForPhysical(physicalChannel)
        if (canonical < 0) {
            // Local OFF: the Lower part must be returned or it stays silent.
            // Style/Drum/Chord/Player/Global channels are never echoed: the
            // PA600 already plays them, returning them doubles them, and a
            // Global-channel echo re-enters the keyboard -> infinite loop.
            if (!keyboardLocal && physicalChannel == lowerChannel) sendRaw(message)
            return
        }

        val canonicalStatus = command or canonical
        val d1 = if (message.size > 1) message[1].toInt() and 0x7F else 0
        val d2 = if (message.size > 2) message[2].toInt() and 0x7F else 0
        // The native router applies the Local mode: in Local ON it returns only
        // generated TERCA notes / composed Ribbon bend, never the raw message.
        val packed = engine.nativeProcess(canonicalStatus, d1, d2, message.size, nowUs())
        sendPacked(packed)

        // A completed Sound/STS selection is represented by Program Change.
        // Re-assert only this Upper channel once, after Program Change. Do not
        // inject RPN/Portamento traffic between Bank Select MSB/LSB messages.
        if (command == 0xC0) {
            if (pitchTransportConfigured) {
                // Local ON: nativeSyncPitchChannel re-sends the core's own range.
                if (!keyboardLocal) configurePitchBendRangeForChannel(physicalChannel, 12)
                sendPacked(engine.nativeSyncPitchChannel(canonical))
            }
            if (portamentoEnabledState) sendPacked(engine.nativeSyncPortamentoChannel(canonical))
        }
    }

    private fun loopBreakerTripped(): Boolean {
        val now = System.nanoTime()
        if (loopMutedUntilNs != 0L) {
            if (now < loopMutedUntilNs) return true
            loopMutedUntilNs = 0L
            statusChanged(null)
        }
        if (now - rateWindowStartNs > loopWindowNs) {
            rateWindowStartNs = now
            rateWindowCount = 0
        }
        rateWindowCount++
        if (rateWindowCount <= loopMaxPerWindow) return false

        // Runaway traffic: stop everything, release all notes, and ignore input
        // for a short cooldown so the loop dies out.
        loopMutedUntilNs = now + loopCooldownNs
        rateWindowCount = 0
        panicOutputAndReset()
        reengagePortamento()
        statusChanged("MIDI LOOP STOPPED")
        return true
    }

    private fun sendPacked(packed: IntArray) {
        var i = 0
        while (i + 3 < packed.size) {
            val size = packed[i + 3].coerceIn(1, 3)
            val status = packed[i] and 0xFF
            val bytes = ByteArray(size)
            var canonical = -1
            if (status in 0x80..0xEF) {
                canonical = status and 0x0F
                val physical = physicalChannelForCanonical(canonical)
                bytes[0] = ((status and 0xF0) or physical).toByte()
            } else {
                bytes[0] = status.toByte()
            }
            if (size > 1) bytes[1] = (packed[i + 1] and 0x7F).toByte()
            if (size > 2) bytes[2] = (packed[i + 2] and 0x7F).toByte()
            sendRaw(bytes, traceLabel(status, packed[i + 1], packed[i + 2], canonical))
            i += 4
        }
    }

    private fun traceLabel(status: Int, data1: Int, data2: Int, canonical: Int): String {
        if (status !in 0x80..0xEF) return "SYSTEM"
        val command = status and 0xF0
        val upper = if (canonical in 0..2) "U${canonical + 1}" else "CH${(status and 0x0F) + 1}"
        return when {
            command == 0x90 && (data2 and 0x7F) != 0 && canonical == 2 && thirdEnabledState && thirdTonalityValidState -> "TERCA $upper"
            command == 0x90 && (data2 and 0x7F) != 0 -> "NOTE ON $upper"
            command == 0x80 || (command == 0x90 && (data2 and 0x7F) == 0) -> "NOTE OFF $upper"
            command == 0xB0 && (data1 and 0x7F) == 5 -> "PORTA TIME $upper"
            command == 0xB0 && (data1 and 0x7F) == 65 && (data2 and 0x7F) != 0 -> "PORTA ON $upper"
            command == 0xB0 && (data1 and 0x7F) == 65 -> "PORTA OFF $upper"
            command == 0xB0 && (data1 and 0x7F) == 123 -> "ALL NOTES OFF $upper"
            command == 0xB0 && (data1 and 0x7F) == 120 -> "ALL SOUND OFF $upper"
            command == 0xE0 -> "PITCH $upper"
            else -> "MIDI $upper"
        }
    }

    private fun sendRaw(message: ByteArray, label: String = "PASS") {
        if (!sender.send(message, label)) {
            if (running) {
                running = false
                handler.post {
                    disconnectInternal()
                    tryAutoConnect()
                }
            }
            return
        }
    }

    private fun panicOutputAndReset() {
        // The final Android sender is the physical source of truth: it knows
        // exactly which Note Ons were successfully accepted by MidiInputPort.
        if (running) {
            val panicChannels = if (lowerChannel in 0..15 && lowerChannel !in channelMap) {
                channelMap.copyOf() + lowerChannel
            } else {
                channelMap.copyOf()
            }
            sender.panic(panicChannels)
            if (pitchTransportConfigured) configurePitchBendRange(2)
        } else {
            sender.clearState()
        }

        // Clear the independent native ledgers/states without re-sending a
        // second set of panic packets. nativePanic() performs the state reset;
        // its returned packets are deliberately ignored here.
        engine.nativePanic()
        pitchTransportConfigured = false
        ribbonTarget = 0f
        ribbonRestGeneration++
    }

    private fun disconnectInternal() {
        panicOutputAndReset()
        running = false
        handler.removeCallbacks(poller)
        try { fromKorg?.close() } catch (_: IOException) {}
        try { toKorg?.close() } catch (_: IOException) {}
        try { device?.close() } catch (_: IOException) {}
        sender.attach(null)
        parser.reset()
        fromKorg = null
        toKorg = null
        device = null
        deviceInfo = null
        receiver = null
        connectionChanged(false)
    }

    fun panic() {
        handler.post {
            panicOutputAndReset()
            parser.reset()
            reengagePortamento()
        }
    }

    fun close() {
        closed = true
        handler.post {
            disconnectInternal()
            midiManager.unregisterDeviceCallback(deviceCallback)
            midiThread.quitSafely()
        }
    }

    private fun nowUs(): Long = System.nanoTime() / 1000L
}
