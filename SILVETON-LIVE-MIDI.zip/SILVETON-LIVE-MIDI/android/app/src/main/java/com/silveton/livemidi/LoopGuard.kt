package com.silveton.livemidi

import java.util.ArrayDeque

class LoopGuard {
    private data class Sent(val hash: Int, val timeNs: Long)
    private val recent = ArrayDeque<Sent>()
    private val windowNs = 3_000_000L
    private val maxEntries = 64

    @Synchronized
    fun remember(message: ByteArray) {
        val now = System.nanoTime()
        prune(now)
        recent.addLast(Sent(hash(message), now))
        while (recent.size > maxEntries) recent.removeFirst()
    }

    @Synchronized
    fun isEcho(message: ByteArray): Boolean {
        val now = System.nanoTime()
        prune(now)
        val h = hash(message)
        return recent.any { it.hash == h && now - it.timeNs <= windowNs }
    }

    @Synchronized
    fun clear() = recent.clear()

    private fun prune(now: Long) {
        while (recent.isNotEmpty() && now - recent.peekFirst().timeNs > windowNs) recent.removeFirst()
    }

    private fun hash(message: ByteArray): Int {
        var h = 17
        for (b in message) h = h * 31 + (b.toInt() and 0xFF)
        return h
    }
}
