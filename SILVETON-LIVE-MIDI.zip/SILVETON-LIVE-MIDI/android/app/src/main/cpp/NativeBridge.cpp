#include <jni.h>
#include "silveton/MidiRouter.h"
#include <memory>
#include <vector>

namespace {
using silveton::MidiMessage;
using silveton::MidiRouter;

std::unique_ptr<MidiRouter> gRouter;

MidiRouter& router() {
    if (!gRouter) gRouter = std::make_unique<MidiRouter>();
    return *gRouter;
}

jintArray pack(JNIEnv* env, const std::vector<MidiMessage>& messages) {
    std::vector<jint> flat;
    flat.reserve(messages.size() * 4);
    for (const auto& m : messages) {
        flat.push_back(m.status);
        flat.push_back(m.data1);
        flat.push_back(m.data2);
        flat.push_back(m.size);
    }
    jintArray result = env->NewIntArray(static_cast<jsize>(flat.size()));
    if (result && !flat.empty()) {
        env->SetIntArrayRegion(result, 0, static_cast<jsize>(flat.size()), flat.data());
    }
    return result;
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeInit(JNIEnv*, jobject) {
    gRouter = std::make_unique<MidiRouter>();
    silveton::Portamento::Config cfg;
    cfg.enabled = true;
    cfg.time = 64;
    gRouter->setPortamentoConfig(cfg);
    gRouter->ribbon().setSensitivity(1.0);
    gRouter->ribbon().setRangeSemitones(2);
    gRouter->third().setEnabled(false);
}


extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetPortamentoEnabled(JNIEnv* env, jobject, jboolean enabled) {
    return pack(env, router().setPortamentoEnabled(enabled == JNI_TRUE));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetPortamentoTime(JNIEnv* env, jobject, jint value) {
    return pack(env, router().setPortamentoTime(static_cast<int>(value)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSyncPortamento(JNIEnv* env, jobject) {
    return pack(env, router().syncPortamento());
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetThirdEnabled(JNIEnv* env, jobject, jboolean enabled) {
    return pack(env, router().setThirdEnabled(enabled == JNI_TRUE));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetThirdScanning(JNIEnv* env, jobject, jboolean scanning) {
    return pack(env, router().setThirdScanning(scanning == JNI_TRUE));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeThirdScanning(JNIEnv*, jobject) {
    return router().thirdScanning() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeThirdScanResult(JNIEnv*, jobject) {
    return router().thirdScanResult();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeThirdScanRevision(JNIEnv*, jobject) {
    return static_cast<jint>(router().third().scanRevision());
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetRibbonSensitivity(JNIEnv*, jobject, jfloat value) {
    router().ribbon().setSensitivity(static_cast<double>(value));
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetRibbonRangeSemitones(JNIEnv*, jobject, jint value) {
    router().ribbon().setRangeSemitones(static_cast<int>(value));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeRibbon(JNIEnv* env, jobject, jfloat value, jlong nowUs) {
    return pack(env, router().ribbonMove(static_cast<double>(value), nowUs));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeProcess(JNIEnv* env, jobject,
                                                           jint status, jint data1, jint data2,
                                                           jint size, jlong nowUs) {
    MidiMessage m{static_cast<std::uint8_t>(status & 0xFF),
                  static_cast<std::uint8_t>(data1 & 0x7F),
                  static_cast<std::uint8_t>(data2 & 0x7F),
                  static_cast<std::uint8_t>(size)};
    return pack(env, router().process(m, nowUs));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativePoll(JNIEnv* env, jobject, jlong nowUs) {
    return pack(env, router().poll(nowUs));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativePanic(JNIEnv* env, jobject) {
    return pack(env, router().panic());
}
