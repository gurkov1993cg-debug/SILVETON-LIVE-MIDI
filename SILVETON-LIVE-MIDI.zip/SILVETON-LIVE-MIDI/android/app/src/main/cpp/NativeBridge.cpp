#include <jni.h>
#include "silveton/MidiRouter.h"
#include <memory>
#include <vector>

namespace {
using silveton::MidiMessage;
using silveton::MidiRouter;

std::unique_ptr<MidiRouter> gRouter;

MidiRouter& router() {
    if (!gRouter) gRouter = std::make_unique<MidiRouter>();
    return *gRouter;
}

jintArray pack(JNIEnv* env, const std::vector<MidiMessage>& messages) {
    std::vector<jint> flat;
    flat.reserve(messages.size() * 4);
    for (const auto& m : messages) {
        flat.push_back(m.status);
        flat.push_back(m.data1);
        flat.push_back(m.data2);
        flat.push_back(m.size);
    }
    jintArray result = env->NewIntArray(static_cast<jsize>(flat.size()));
    if (result && !flat.empty()) {
        env->SetIntArrayRegion(result, 0, static_cast<jsize>(flat.size()), flat.data());
    }
    return result;
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeInit(JNIEnv*, jobject) {
    gRouter = std::make_unique<MidiRouter>();
    silveton::Portamento::Config cfg;
    cfg.enabled = true;
    cfg.glideMs = 180;
    cfg.bendRangeSemitones = 12;
    cfg.updateIntervalUs = 1000;
    gRouter->portamento().setConfig(cfg);
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetGlideMs(JNIEnv*, jobject, jint value) {
    auto cfg = router().portamento().config();
    cfg.glideMs = value;
    router().portamento().setConfig(cfg);
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeProcess(JNIEnv* env, jobject,
                                                           jint status, jint data1, jint data2,
                                                           jint size, jlong nowUs) {
    MidiMessage m{static_cast<std::uint8_t>(status & 0xFF),
                  static_cast<std::uint8_t>(data1 & 0x7F),
                  static_cast<std::uint8_t>(data2 & 0x7F),
                  static_cast<std::uint8_t>(size)};
    return pack(env, router().process(m, nowUs));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativePoll(JNIEnv* env, jobject, jlong nowUs) {
    return pack(env, router().poll(nowUs));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativePanic(JNIEnv* env, jobject) {
    return pack(env, router().panic());
}
