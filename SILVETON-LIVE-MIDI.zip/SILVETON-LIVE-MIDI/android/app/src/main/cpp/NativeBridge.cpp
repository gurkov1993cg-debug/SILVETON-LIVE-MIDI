#include <jni.h>
#include "silveton/NativeMidiEngine.h"
#include <cstdint>
#include <memory>
#include <vector>

namespace {
using silveton::MidiMessage;
using silveton::NativeMidiEngine;

std::unique_ptr<NativeMidiEngine> gEngine;

NativeMidiEngine& engine() {
    if (!gEngine) gEngine = std::make_unique<NativeMidiEngine>();
    return *gEngine;
}

jintArray pack(JNIEnv* env, const std::vector<MidiMessage>& messages) {
    std::vector<jint> flat;
    flat.reserve(messages.size() * 4U);
    for (const auto& m : messages) {
        flat.push_back(static_cast<jint>(m.status));
        flat.push_back(static_cast<jint>(m.data1));
        flat.push_back(static_cast<jint>(m.data2));
        flat.push_back(static_cast<jint>(m.size));
    }
    jintArray result = env->NewIntArray(static_cast<jsize>(flat.size()));
    if (result != nullptr && !flat.empty()) {
        env->SetIntArrayRegion(result, 0, static_cast<jsize>(flat.size()), flat.data());
    }
    return result;
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeInit(JNIEnv*, jobject) {
    gEngine = std::make_unique<NativeMidiEngine>();
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetPortamentoEnabled(JNIEnv* env, jobject, jboolean enabled) {
    return pack(env, engine().router().setPortamentoEnabled(enabled == JNI_TRUE));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetPortamentoTime(JNIEnv* env, jobject, jint value) {
    return pack(env, engine().router().setPortamentoTime(static_cast<int>(value)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSyncPortamento(JNIEnv* env, jobject) {
    return pack(env, engine().router().syncPortamento());
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSyncPortamentoChannel(JNIEnv* env, jobject, jint upper) {
    return pack(env, engine().router().syncPortamentoChannel(static_cast<int>(upper)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSyncPitchChannel(JNIEnv* env, jobject, jint upper) {
    return pack(env, engine().router().syncPitchChannel(static_cast<int>(upper)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetThirdEnabled(JNIEnv* env, jobject, jboolean enabled) {
    return pack(env, engine().router().setThirdEnabled(enabled == JNI_TRUE));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetThirdScanning(JNIEnv* env, jobject, jboolean scanning) {
    return pack(env, engine().router().setThirdScanning(scanning == JNI_TRUE));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeThirdScanning(JNIEnv*, jobject) {
    return engine().router().thirdScanning() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeThirdScanResult(JNIEnv*, jobject) {
    return static_cast<jint>(engine().router().thirdScanResult());
}

extern "C" JNIEXPORT jint JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeThirdScanRevision(JNIEnv*, jobject) {
    return static_cast<jint>(engine().router().third().scanRevision());
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetRibbonSensitivity(JNIEnv*, jobject, jfloat value) {
    engine().router().ribbon().setSensitivity(static_cast<double>(value));
}

extern "C" JNIEXPORT void JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeSetRibbonRangeSemitones(JNIEnv*, jobject, jint value) {
    engine().router().ribbon().setRangeSemitones(static_cast<int>(value));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeRibbon(JNIEnv* env, jobject, jfloat value, jlong nowUs) {
    return pack(env, engine().router().ribbonMove(static_cast<double>(value), static_cast<std::int64_t>(nowUs)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativeProcess(JNIEnv* env, jobject,
                                                           jint status, jint data1, jint data2,
                                                           jint size, jlong nowUs) {
    return pack(env, engine().handleMidiIn(static_cast<std::uint8_t>(status & 0xFF),
                                           static_cast<std::uint8_t>(data1 & 0x7F),
                                           static_cast<std::uint8_t>(data2 & 0x7F),
                                           static_cast<std::uint8_t>(size),
                                           static_cast<std::int64_t>(nowUs)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativePoll(JNIEnv* env, jobject, jlong nowUs) {
    return pack(env, engine().router().poll(static_cast<std::int64_t>(nowUs)));
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_silveton_livemidi_NativeMidiEngine_nativePanic(JNIEnv* env, jobject) {
    return pack(env, engine().router().panic());
}
