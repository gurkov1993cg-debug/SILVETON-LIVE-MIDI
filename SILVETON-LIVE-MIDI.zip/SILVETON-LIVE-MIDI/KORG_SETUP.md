# Korg Pa600 setup

- Connect the Android device and Pa600 by USB MIDI/OTG.
- Use Local Control OFF when routing the Pa600 keybed through the application, to avoid doubled local + returned notes.
- Default application mapping: Upper 1 = MIDI Ch1, Upper 2 = MIDI Ch2, Upper 3 = MIDI Ch3.
- Native Portamento is controlled by Pa600-recognized MIDI controllers:
  - CC#65 = Portamento On/Off
  - CC#5 = Portamento Time (0..127)
- The application sends the same native Portamento state to all three Upper channels and re-applies it after Bank/Program changes.
- Ribbon uses Pitch Bend independently. For its selectable semitone range the application configures the Upper channels' Pitch Bend Sensitivity with RPN 0,0 / Data Entry; allow these incoming MIDI controller messages in the Pa600 MIDI filters.
- TERCA remains an independent Upper-3 harmony module and does not alter Portamento state.
