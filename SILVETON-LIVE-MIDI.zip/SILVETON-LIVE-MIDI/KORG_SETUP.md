# KORG SETUP

- USB-C OTG -> Korg USB MIDI
- Local Control: OFF
- Upper 1: MIDI 1
- Upper 2: MIDI 2
- Upper 3: MIDI 3
- App connects automatically.
- Lower/Style MIDI is passed through unchanged.
- Global MIDI input filtering must allow RPN/Data Entry messages. SILVETON sends RPN 0,0 to keep Upper 1/2/3 Pitch Bend Sensitivity at +/-12 semitones for the fixed-time Portamento engine.
