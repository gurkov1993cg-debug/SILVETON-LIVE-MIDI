# Korg Pa600+ setup for SILVETON LIVE MIDI

Use the app over USB OTG.

## Required live setup
1. Set **Local Control = OFF** on the Korg while SILVETON LIVE MIDI is connected.
2. Set the Korg MIDI transmit/receive routing so:
   - **Upper 1 = MIDI channel 1**
   - **Upper 2 = MIDI channel 2**
   - **Upper 3 = MIDI channel 3**
3. Keep Lower / arranger / chord-recognition traffic on channels other than 1, 2 and 3. SILVETON passes all non-Upper channels through unchanged.
4. Set the Upper sounds' pitch-bend sensitivity to **+/-12 semitones** for the current Portamento engine.
5. Connect: **POCO X8 Pro -> USB-C OTG -> USB cable -> Korg USB device port**.

## Why Local Off
With Local Control ON, the Korg can sound the physical key immediately and then sound the MIDI note returned by the Android app as well. That produces the double-trigger / conflict heard in the previous version. Local Off makes the app the single MIDI route for the processed Upper voices.

## Portamento behavior
- First note after all keys are released: immediate, no glide.
- Legato note: starts at the currently sounding pitch and glides continuously to the new target.
- Glide duration is fixed: e.g. 180 ms remains 180 ms for a whole tone or an octave.
- Last-note priority is used independently on Upper 1, Upper 2 and Upper 3.
- Hardware Pitch Bend on Upper channels is combined with the Portamento bend instead of overwriting it.
