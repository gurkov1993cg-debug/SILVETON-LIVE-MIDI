# KORG SETUP

- USB-C OTG -> Korg USB MIDI
- Local Control: OFF
- Upper 1: MIDI 1
- Upper 2: MIDI 2
- Upper 3: MIDI 3
- App connects automatically.
- Lower/Style MIDI is passed through unchanged.
