# Korg Pa600 setup

- Connect Android and Pa600 with USB MIDI/OTG.
- Use Local Control OFF when routing the Pa600 keybed through the application, otherwise local and returned notes can double.
- Default mapping: U1=MIDI Ch1, U2=MIDI Ch2, U3=MIDI Ch3.
- Native Portamento control: CC#5 = Time (0..127), CC#65 = On/Off.
- Portamento desired state is sent on all three Upper channels at connect/control changes and re-applied only to the affected Upper after Program Change.
- Ribbon uses 14-bit Pitch Bend and configures Upper Pitch Bend Sensitivity with standard RPN 0,0 / Data Entry for the internal ±12 transport. Allow those incoming controllers in the Pa600 MIDI filters.
- TERCA always uses U3. When TERCA is OFF, U3 is a normal independent Upper.
- Keep MIDI Thru/echo routing disabled on the Pa600 path unless specifically needed. The app deliberately does not use a timing filter on channel voice messages because a real Note Off must never be dropped.
