package bg.silveton.live.midi

object MidiMessageFormatter {
    fun format(bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""
        val hex = bytes.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
        val status = bytes[0].toInt() and 0xFF
        val ch = (status and 0x0F) + 1
        val description = when (status and 0xF0) {
            0x80 -> if (bytes.size >= 3) "NoteOff ch$ch n=${u(bytes[1])} v=${u(bytes[2])}" else "NoteOff"
            0x90 -> if (bytes.size >= 3) {
                if (u(bytes[2]) == 0) "NoteOff ch$ch n=${u(bytes[1])}" else "NoteOn ch$ch n=${u(bytes[1])} v=${u(bytes[2])}"
            } else "NoteOn"
            0xA0 -> "PolyPressure ch$ch"
            0xB0 -> if (bytes.size >= 3) "CC ch$ch #${u(bytes[1])}=${u(bytes[2])}" else "CC"
            0xC0 -> if (bytes.size >= 2) "Program ch$ch ${u(bytes[1])}" else "Program"
            0xD0 -> "ChannelPressure ch$ch"
            0xE0 -> if (bytes.size >= 3) {
                val bend = u(bytes[1]) or (u(bytes[2]) shl 7)
                "PitchBend ch$ch $bend"
            } else "PitchBend"
            0xF0 -> when (status) {
                0xF0 -> "SysEx"
                0xF8 -> "Clock"
                0xFA -> "Start"
                0xFB -> "Continue"
                0xFC -> "Stop"
                0xFE -> "ActiveSense"
                else -> "System"
            }
            else -> "MIDI"
        }
        return "$description  [$hex]"
    }

    private fun u(b: Byte) = b.toInt() and 0xFF
}
