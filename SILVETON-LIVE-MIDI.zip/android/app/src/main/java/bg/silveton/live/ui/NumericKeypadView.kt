package bg.silveton.live.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Always-visible keypad used by the PORTA custom millisecond control. */
class NumericKeypadView(context: Context) : LinearLayout(context) {
    interface Listener { fun onAccepted(value: Double) }
    var listener: Listener? = null

    private val display = TextView(context)
    private var digits = "10"

    init {
        orientation = VERTICAL
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = SilvetonTheme.panelDrawable(dpF(18), SilvetonTheme.border)

        val title = TextView(context).apply {
            text = "CUSTOM · MS"
            setTextColor(SilvetonTheme.muted)
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = SilvetonTheme.condensedBold()
            letterSpacing = 0.12f
        }
        addView(title, LayoutParams(LayoutParams.MATCH_PARENT, dp(30)))

        display.apply {
            setTextColor(Color.rgb(255, 247, 221))
            background = SilvetonTheme.insetPanelDrawable(dpF(13))
            textSize = 32f
            gravity = Gravity.CENTER
            typeface = SilvetonTheme.monoBold()
            text = digits
            includeFontPadding = false
        }
        addView(display, LayoutParams(LayoutParams.MATCH_PARENT, dp(68)))

        val grid = GridLayout(context).apply {
            columnCount = 3
            rowCount = 4
            setPadding(0, dp(8), 0, 0)
        }
        val keys = listOf("1","2","3","4","5","6","7","8","9","C","0","OK")
        keys.forEach { key ->
            val b = Button(context).apply {
                text = key
                when (key) {
                    "OK" -> { SilvetonTheme.styleControl(this, SilvetonTheme.amber, 17f, dpF(12)); isSelected = true }
                    "C" -> {
                        SilvetonTheme.styleControl(this, SilvetonTheme.red, 17f, dpF(12))
                        setTextColor(SilvetonTheme.red)
                    }
                    else -> SilvetonTheme.styleControl(this, SilvetonTheme.blue, 17f, dpF(12))
                }
                setOnClickListener { press(key) }
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    fun setValue(value: Double) {
        val n = value.toInt().coerceIn(1, 5000)
        digits = n.toString()
        display.text = digits
    }

    private fun press(key: String) {
        when (key) {
            "C" -> digits = ""
            "OK" -> {
                val v = digits.toIntOrNull()?.coerceIn(1, 5000) ?: return
                digits = v.toString()
                display.text = digits
                listener?.onAccepted(v.toDouble())
                return
            }
            else -> {
                val next = (digits + key).trimStart('0').ifEmpty { "0" }
                if (next.length <= 4 && (next.toIntOrNull() ?: 0) <= 5000) digits = next
            }
        }
        display.text = digits.ifEmpty { "0" }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpF(v: Int): Float = v * resources.displayMetrics.density
}
