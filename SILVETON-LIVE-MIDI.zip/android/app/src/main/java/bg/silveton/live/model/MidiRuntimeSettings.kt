package bg.silveton.live.model

data class MidiRuntimeSettings(
    val performanceInputChannel: Int,
    val performanceInputOmni: Boolean,
    val upper1Channel: Int,
    val upper2Channel: Int,
    val upper3Channel: Int,
    val midiThru: Boolean,
    val pitchBendRangeSemitones: Int,
    val autoReconnect: Boolean
)
