package bg.silveton.live.model

import android.content.Context
import bg.silveton.live.midi.HarmonyDegree
import bg.silveton.live.midi.RibbonOutput
import bg.silveton.live.midi.RibbonRelease
import bg.silveton.live.midi.ScaleType

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("silveton_live_midi", Context.MODE_PRIVATE)

    var selectedModelId: String
        get() = prefs.getString("selected_model", "pa600") ?: "pa600"
        set(value) { prefs.edit().putString("selected_model", value).apply() }
    var midiChannel: Int
        get() = prefs.getInt("midi_channel", 0).coerceIn(0, 15)
        set(value) { prefs.edit().putInt("midi_channel", value.coerceIn(0, 15)).apply() }

    var performanceInputChannel: Int
        get() = prefs.getInt("performance_input_channel", 0).coerceIn(0, 15)
        set(value) { prefs.edit().putInt("performance_input_channel", value.coerceIn(0, 15)).apply() }
    var performanceInputOmni: Boolean
        get() = false
        set(@Suppress("UNUSED_PARAMETER") value) { prefs.edit().putBoolean("performance_input_omni", false).apply() }
    var rightHandRoutingMigrationDone: Boolean
        get() = prefs.getBoolean("right_hand_routing_migration_v1", false)
        set(value) { prefs.edit().putBoolean("right_hand_routing_migration_v1", value).apply() }

    var upper1Channel: Int
        get() = prefs.getInt("upper1_channel", 0).coerceIn(0, 15)
        set(value) { prefs.edit().putInt("upper1_channel", value.coerceIn(0, 15)).apply() }
    var upper2Channel: Int
        get() = prefs.getInt("upper2_channel", 1).coerceIn(0, 15)
        set(value) { prefs.edit().putInt("upper2_channel", value.coerceIn(0, 15)).apply() }
    var upper3Channel: Int
        get() = prefs.getInt("upper3_channel", 2).coerceIn(0, 15)
        set(value) { prefs.edit().putInt("upper3_channel", value.coerceIn(0, 15)).apply() }

    var lastDeviceKey: String?
        get() = prefs.getString("last_device_key", null)
        set(value) { prefs.edit().putString("last_device_key", value).apply() }
    var lastInputPort: Int
        get() = prefs.getInt("last_input_port", 0)
        set(value) { prefs.edit().putInt("last_input_port", value).apply() }
    var lastOutputPort: Int
        get() = prefs.getInt("last_output_port", -1)
        set(value) { prefs.edit().putInt("last_output_port", value).apply() }
    var autoReconnect: Boolean
        get() = prefs.getBoolean("auto_reconnect", true)
        set(value) { prefs.edit().putBoolean("auto_reconnect", value).apply() }

    var portamentoEnabled: Boolean
        get() = prefs.getBoolean("porta_enabled", false)
        set(value) { prefs.edit().putBoolean("porta_enabled", value).apply() }
    var portamentoDurationMs: Double
        get() = java.lang.Double.longBitsToDouble(prefs.getLong("porta_ms_bits", java.lang.Double.doubleToLongBits(20.0))).coerceIn(1.0, 5000.0)
        set(value) { prefs.edit().putLong("porta_ms_bits", java.lang.Double.doubleToLongBits(value.coerceIn(1.0, 5000.0))).apply() }
    /** Pitch Bend sensitivity used by SILVETON PORTA; synchronized by RPN only when PORTA is explicitly enabled. */
    var portamentoBendRangeReference: Int
        get() = prefs.getInt("porta_local_bend_range_v3", 12).coerceIn(1, 12)
        set(value) { prefs.edit().putInt("porta_local_bend_range_v3", value.coerceIn(1, 12)).apply() }
    var targetUpperMask: Int
        get() = prefs.getInt("target_upper_mask", 7).and(0x7).let { if (it == 0) 7 else it }
        set(value) { prefs.edit().putInt("target_upper_mask", value.and(0x7).let { if (it == 0) 7 else it }).apply() }
    var portamentoAllUppersMigrationDone: Boolean
        get() = prefs.getBoolean("porta_all_uppers_v1", false)
        set(value) { prefs.edit().putBoolean("porta_all_uppers_v1", value).apply() }

    var harmonyEnabled: Boolean
        get() = prefs.getBoolean("harmony_enabled", false)
        set(value) { prefs.edit().putBoolean("harmony_enabled", value).apply() }
    var harmonyTonic: Int
        get() = prefs.getInt("harmony_tonic", 0).coerceIn(0, 11)
        set(value) { prefs.edit().putInt("harmony_tonic", value.coerceIn(0, 11)).apply() }
    var harmonyScale: ScaleType
        get() = enumValueOr(prefs.getString("harmony_scale", null), ScaleType.MAJOR)
        set(value) { prefs.edit().putString("harmony_scale", value.name).apply() }
    var tercaDegree: HarmonyDegree
        get() = enumValueOr(prefs.getString("terca_degree", null), HarmonyDegree.THIRD)
        set(value) { prefs.edit().putString("terca_degree", value.name).apply() }

    var midiThru: Boolean
        get() = prefs.getBoolean("midi_thru", false)
        set(value) { prefs.edit().putBoolean("midi_thru", value).apply() }

    var ribbonOutput: RibbonOutput
        get() = enumValueOr(prefs.getString("ribbon_output", null), RibbonOutput.PITCH_BEND)
        set(value) { prefs.edit().putString("ribbon_output", value.name).apply() }
    var pa600RibbonPitchBendMigrationDone: Boolean
        get() = prefs.getBoolean("pa600_ribbon_pitch_bend_migration_v1", false)
        set(value) { prefs.edit().putBoolean("pa600_ribbon_pitch_bend_migration_v1", value).apply() }
    var ribbonRelease: RibbonRelease
        get() = RibbonRelease.CENTER
        set(@Suppress("UNUSED_PARAMETER") value) { prefs.edit().putString("ribbon_release", RibbonRelease.CENTER.name).apply() }

    var padBank: Int
        get() = prefs.getInt("pad_bank", 0).coerceIn(0, 2)
        set(value) { prefs.edit().putInt("pad_bank", value.coerceIn(0, 2)).apply() }

    private inline fun <reified T : Enum<T>> enumValueOr(name: String?, fallback: T): T =
        runCatching { if (name == null) fallback else enumValueOf<T>(name) }.getOrDefault(fallback)
}
