package bg.silveton.live.model

data class KorgModel(val id: String, val displayName: String)

object KorgModels {
    val supportedTargets = listOf(
        KorgModel("pa600", "KORG PA600"),
        KorgModel("pa700", "KORG PA700"),
        KorgModel("pa900", "KORG PA900"),
        KorgModel("pa1000", "KORG PA1000"),
        KorgModel("pa4x", "KORG PA4X"),
        KorgModel("pa5x", "KORG PA5X"),
    )

    /** Safe metadata-only hinting. This never claims a MIDI identity mapping. */
    fun guessFromDeviceText(vararg parts: String?): KorgModel? {
        val text = parts.filterNotNull().joinToString(" ").lowercase()
            .replace("-", "").replace("_", "").replace(" ", "")
        return supportedTargets.firstOrNull { model ->
            val token = model.id.lowercase().replace("-", "")
            text.contains(token)
        }
    }
}
