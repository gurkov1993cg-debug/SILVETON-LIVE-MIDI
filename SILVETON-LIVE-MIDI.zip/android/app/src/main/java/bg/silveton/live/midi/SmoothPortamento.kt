package bg.silveton.live.midi

import java.io.Closeable
import java.util.ArrayDeque
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * SILVETON portamento.
 *
 * Own implementation: channel Pitch Bend is used as a temporary pitch offset between
 * consecutive melody notes. The glide is time-based (not distance-based), therefore a
 * 1-semitone and a 12-semitone transition finish in the same requested time.
 *
 * The engine itself emits only 14-bit Pitch Bend. RPN messages used to align the KORG
 * Pitch Bend sensitivity are generated explicitly by [pitchBendSensitivityMessages]
 * and are sent only when PORTAMENTO is enabled by the user, never on app connect.
 */
class SmoothPortamento(private val send: (ByteArray) -> Unit) : Closeable {
    private data class ChannelState(
        val held: ArrayDeque<Int> = ArrayDeque(),
        var anchorNote: Int? = null,
        var lastNote: Int? = null,
        var lastReleaseNanos: Long = Long.MIN_VALUE,
        var physicalBend: Int = CENTER,
        var glideSemitones: Double = 0.0,
        var glideStartSemitones: Double = 0.0,
        var glideStartNanos: Long = 0L,
        var glideDurationNanos: Long = 1_000_000L,
        var task: ScheduledFuture<*>? = null,
        var lastSentBend: Int = -1
    )

    private val lock = Any()
    private val channels = Array(16) { ChannelState() }
    private val executor = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "Silveton-Smooth-Portamento").apply {
            isDaemon = true
            priority = (Thread.NORM_PRIORITY + 2).coerceAtMost(Thread.MAX_PRIORITY)
        }
    }

    @Volatile var enabled: Boolean = false
    @Volatile var durationMs: Double = 20.0
    @Volatile var bendRangeSemitones: Int = 12
    /** Allows a natural non-overlapped melody to glide if the next note arrives shortly after Note Off. */
    @Volatile var retriggerMemoryMs: Double = 220.0

    fun physicalPitchBend(channel: Int, value: Int) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val state = channels[ch]
            state.physicalBend = value.coerceIn(0, MAX_BEND)
            emitLocked(ch, state, force = true)
        }
    }

    fun noteOn(channel: Int, note: Int, nowNanos: Long = System.nanoTime()) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val n = note.coerceIn(0, 127)
            val state = channels[ch]
            updateGlideToNowLocked(ch, state, nowNanos, emit = false)

            val currentPitch = state.anchorNote?.let { it.toDouble() + state.glideSemitones }
            val priorHeld = state.held.peekLast()
            val recentReleased = state.lastNote?.takeIf {
                priorHeld == null && state.lastReleaseNanos != Long.MIN_VALUE &&
                    nowNanos - state.lastReleaseNanos <= (retriggerMemoryMs.coerceIn(0.0, 1000.0) * 1_000_000.0).roundToLong()
            }
            val previousNote = priorHeld ?: recentReleased

            state.held.remove(n)
            state.held.addLast(n)
            state.lastNote = n
            state.anchorNote = n

            if (!enabled || previousNote == null || previousNote == n) {
                cancelTaskLocked(state)
                state.glideSemitones = 0.0
                emitLocked(ch, state, force = false)
                return
            }

            // If another note arrives during an unfinished glide, begin from the
            // pitch that is actually sounding at this instant rather than snapping.
            val startPitch = currentPitch ?: previousNote.toDouble()
            val rawOffset = startPitch - n.toDouble()
            val range = bendRangeSemitones.coerceIn(1, 12).toDouble()
            state.glideSemitones = rawOffset.coerceIn(-range, range)
            startGlideLocked(ch, state, nowNanos)
        }
    }

    fun noteOff(channel: Int, note: Int, nowNanos: Long = System.nanoTime()) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val n = note.coerceIn(0, 127)
            val state = channels[ch]
            updateGlideToNowLocked(ch, state, nowNanos, emit = false)

            val wasAnchor = state.anchorNote == n
            val currentPitch = state.anchorNote?.let { it.toDouble() + state.glideSemitones }
            state.held.remove(n)
            state.lastReleaseNanos = nowNanos

            if (state.held.isEmpty()) {
                // Keep lastNote for a short retrigger-memory window, but stop any
                // running bend so a silent gap never leaves the channel detuned.
                cancelTaskLocked(state)
                state.anchorNote = null
                state.glideSemitones = 0.0
                emitLocked(ch, state, force = true)
                return
            }

            if (enabled && wasAnchor) {
                val resume = state.held.peekLast()
                state.anchorNote = resume
                val startPitch = currentPitch ?: n.toDouble()
                val range = bendRangeSemitones.coerceIn(1, 12).toDouble()
                state.glideSemitones = (startPitch - resume.toDouble()).coerceIn(-range, range)
                state.lastNote = resume
                startGlideLocked(ch, state, nowNanos)
            }
        }
    }

    fun resetChannel(channel: Int, emitCenter: Boolean = true) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val state = channels[ch]
            cancelTaskLocked(state)
            state.held.clear()
            state.anchorNote = null
            state.lastNote = null
            state.lastReleaseNanos = Long.MIN_VALUE
            state.glideSemitones = 0.0
            if (emitCenter) emitLocked(ch, state, force = true)
        }
    }

    fun reset(emitCurrentPhysicalBend: Boolean = false) {
        synchronized(lock) {
            channels.forEachIndexed { ch, state ->
                cancelTaskLocked(state)
                state.held.clear()
                state.anchorNote = null
                state.lastNote = null
                state.lastReleaseNanos = Long.MIN_VALUE
                state.glideSemitones = 0.0
                if (emitCurrentPhysicalBend) emitLocked(ch, state, force = true)
            }
        }
    }

    private fun startGlideLocked(channel: Int, state: ChannelState, nowNanos: Long) {
        cancelTaskLocked(state)
        if (abs(state.glideSemitones) < 1e-9) {
            emitLocked(channel, state, force = true)
            return
        }
        state.glideStartSemitones = state.glideSemitones
        state.glideStartNanos = nowNanos
        state.glideDurationNanos = (durationMs.coerceIn(1.0, 5000.0) * 1_000_000.0)
            .roundToLong().coerceAtLeast(1_000_000L)
        emitLocked(channel, state, force = true)
        state.task = executor.scheduleAtFixedRate({ tick(channel) }, TICK_MS, TICK_MS, TimeUnit.MILLISECONDS)
    }

    private fun tick(channel: Int) {
        synchronized(lock) {
            val state = channels[channel]
            if (state.task == null) return
            updateGlideToNowLocked(channel, state, System.nanoTime(), emit = true)
        }
    }

    private fun updateGlideToNowLocked(channel: Int, state: ChannelState, nowNanos: Long, emit: Boolean) {
        if (state.task == null) return
        val elapsed = (nowNanos - state.glideStartNanos).coerceAtLeast(0L)
        if (elapsed >= state.glideDurationNanos) {
            state.glideSemitones = 0.0
            cancelTaskLocked(state)
            if (emit) emitLocked(channel, state, force = true)
            return
        }

        val t = elapsed.toDouble() / state.glideDurationNanos.toDouble()
        // Smoothstep gives zero slope at both ends while preserving the exact total time.
        val progress = smoothStep(t)
        state.glideSemitones = state.glideStartSemitones * (1.0 - progress)
        if (emit) emitLocked(channel, state, force = false)
    }

    private fun cancelTaskLocked(state: ChannelState) {
        state.task?.cancel(false)
        state.task = null
    }

    private fun emitLocked(channel: Int, state: ChannelState, force: Boolean) {
        val range = bendRangeSemitones.coerceIn(1, 12).toDouble()
        val glideBend = semitonesToBendOffset(state.glideSemitones, range)
        val physicalOffset = state.physicalBend - CENTER
        val combined = (CENTER + physicalOffset + glideBend).coerceIn(0, MAX_BEND)
        if (!force && combined == state.lastSentBend) return
        state.lastSentBend = combined
        send(pitchBendMessage(channel, combined))
    }

    override fun close() {
        reset(emitCurrentPhysicalBend = false)
        executor.shutdownNow()
    }

    companion object {
        const val CENTER = 8192
        const val MAX_BEND = 16383
        private const val TICK_MS = 2L

        fun smoothStep(t: Double): Double {
            val x = t.coerceIn(0.0, 1.0)
            return x * x * (3.0 - 2.0 * x)
        }

        fun glideSemitonesAt(startSemitones: Double, elapsedMs: Double, durationMs: Double): Double {
            val d = durationMs.coerceAtLeast(1.0)
            if (elapsedMs <= 0.0) return startSemitones
            if (elapsedMs >= d) return 0.0
            return startSemitones * (1.0 - smoothStep(elapsedMs / d))
        }

        fun semitonesToBendOffset(semitones: Double, rangeSemitones: Double): Int {
            val r = rangeSemitones.coerceAtLeast(1.0)
            val normalized = (semitones / r).coerceIn(-1.0, 1.0)
            return if (normalized >= 0.0) {
                (normalized * (MAX_BEND - CENTER)).roundToInt()
            } else {
                (normalized * CENTER).roundToInt()
            }
        }

        fun pitchBendMessage(channel: Int, value: Int): ByteArray {
            val v = value.coerceIn(0, MAX_BEND)
            return byteArrayOf(
                (0xE0 or channel.coerceIn(0, 15)).toByte(),
                (v and 0x7F).toByte(),
                ((v ushr 7) and 0x7F).toByte()
            )
        }

        /** MIDI RPN 0,0 = Pitch Bend Sensitivity. Data Entry MSB is semitones. */
        fun pitchBendSensitivityMessages(channel: Int, semitones: Int): Array<ByteArray> {
            val ch = channel.coerceIn(0, 15)
            val st = (0xB0 or ch).toByte()
            val range = semitones.coerceIn(1, 12).toByte()
            return arrayOf(
                byteArrayOf(st, 101.toByte(), 0), // RPN MSB 0
                byteArrayOf(st, 100.toByte(), 0), // RPN LSB 0
                byteArrayOf(st, 6.toByte(), range), // Data Entry MSB = semitones
                byteArrayOf(st, 38.toByte(), 0), // Data Entry LSB = 0 cents
                byteArrayOf(st, 101.toByte(), 127.toByte()), // RPN null
                byteArrayOf(st, 100.toByte(), 127.toByte())
            )
        }
    }
}
