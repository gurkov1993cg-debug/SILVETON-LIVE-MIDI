package bg.silveton.live.midi

import kotlin.math.ln
import kotlin.math.roundToInt

/**
 * Clean KORG-native portamento controller.
 *
 * This class never emits Pitch Bend, RPN, transpose, octave, Program Change or notes.
 * It only emits the two standard messages used by the PA-series native portamento:
 * CC5 = Portamento Time and CC65 = Portamento Switch.
 *
 * Nothing is sent merely by constructing/configuring this object. The caller decides
 * exactly when the player has explicitly requested ON/OFF or a new time value.
 */
class KorgNativePortamento {
    fun switchMessage(channel: Int, enabled: Boolean): ByteArray = controlChange(channel, CC_SWITCH, if (enabled) 127 else 0)

    fun timeMessage(channel: Int, milliseconds: Double): ByteArray =
        controlChange(channel, CC_TIME, timeToCc(milliseconds))

    /**
     * UI milliseconds -> CC5 reference mapping. This is intentionally only an app-side
     * control scale; it does not claim that the keyboard's internal CC5 curve is linear
     * in real milliseconds. It is monotonic and never changes any keyboard state until
     * [timeMessage] is explicitly sent.
     */
    fun timeToCc(milliseconds: Double): Int {
        val ms = milliseconds.coerceIn(MIN_MS, MAX_MS)
        val normalized = ln(ms) / ln(MAX_MS)
        return (normalized * 127.0).roundToInt().coerceIn(0, 127)
    }

    private fun controlChange(channel: Int, cc: Int, value: Int): ByteArray = byteArrayOf(
        (0xB0 or channel.coerceIn(0, 15)).toByte(),
        cc.coerceIn(0, 127).toByte(),
        value.coerceIn(0, 127).toByte()
    )

    companion object {
        const val CC_TIME = 5
        const val CC_SWITCH = 65
        const val MIN_MS = 1.0
        const val MAX_MS = 5000.0
    }
}
