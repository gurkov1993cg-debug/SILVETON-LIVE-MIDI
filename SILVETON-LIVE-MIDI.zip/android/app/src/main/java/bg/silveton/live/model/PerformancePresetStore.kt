package bg.silveton.live.model

import android.content.Context
import bg.silveton.live.midi.*
import org.json.JSONArray
import org.json.JSONObject

data class PerformancePreset(
    val name: String,
    val modelId: String,
    val portamentoEnabled: Boolean,
    val portamentoMs: Double,
    val targetUpperMask: Int,
    val harmonyEnabled: Boolean,
    val harmonyTonic: Int,
    val harmonyScale: ScaleType,
    val tercaDegree: HarmonyDegree,
    val ribbonOutput: RibbonOutput,
    val ribbonRelease: RibbonRelease,
    val padBank: Int,
    val midiThru: Boolean,
    val performanceInputChannel: Int,
    val performanceInputOmni: Boolean,
    val upper1Channel: Int,
    val upper2Channel: Int,
    val upper3Channel: Int,
    val autoReconnect: Boolean,
    val padBanks: List<List<PadConfig>>
)

class PerformancePresetStore(context: Context) {
    companion object { const val SLOT_COUNT = 8 }
    private val prefs = context.getSharedPreferences("silveton_live_presets", Context.MODE_PRIVATE)

    fun names(): List<String?> = (0 until SLOT_COUNT).map { load(it)?.name }
    fun save(slot: Int, preset: PerformancePreset): Boolean {
        if (slot !in 0 until SLOT_COUNT) return false
        return runCatching { prefs.edit().putString(key(slot), encode(preset).toString()).commit() }.getOrDefault(false)
    }
    fun load(slot: Int): PerformancePreset? {
        if (slot !in 0 until SLOT_COUNT) return null
        val raw = prefs.getString(key(slot), null) ?: return null
        return runCatching { decode(JSONObject(raw)) }.getOrNull()
    }
    fun clear(slot: Int): Boolean = slot in 0 until SLOT_COUNT && prefs.edit().remove(key(slot)).commit()

    private fun encode(p: PerformancePreset) = JSONObject().apply {
        put("version", 2)
        put("name", p.name.trim().take(32).ifBlank { "Preset" })
        put("modelId", p.modelId)
        put("portamentoEnabled", p.portamentoEnabled)
        put("portamentoMs", p.portamentoMs)
        put("targetUpperMask", p.targetUpperMask)
        put("harmonyEnabled", p.harmonyEnabled)
        put("harmonyTonic", p.harmonyTonic)
        put("harmonyScale", p.harmonyScale.name)
        put("tercaDegree", p.tercaDegree.name)
        put("ribbonOutput", p.ribbonOutput.name)
        put("ribbonRelease", RibbonRelease.CENTER.name)
        put("padBank", p.padBank)
        put("midiThru", p.midiThru)
        put("performanceInputChannel", p.performanceInputChannel)
        put("performanceInputOmni", false)
        put("upper1Channel", p.upper1Channel)
        put("upper2Channel", p.upper2Channel)
        put("upper3Channel", p.upper3Channel)
        put("autoReconnect", p.autoReconnect)
        put("padBanks", JSONArray().apply {
            p.padBanks.take(3).forEach { bank -> put(JSONArray().apply { bank.take(16).forEach { put(encodePad(it)) } }) }
        })
    }

    private fun decode(o: JSONObject): PerformancePreset {
        val banksJson = o.optJSONArray("padBanks") ?: JSONArray()
        val banks = (0 until 3).map { bankIndex ->
            val bank = banksJson.optJSONArray(bankIndex)
            (0 until 16).map { padIndex -> bank?.optJSONObject(padIndex)?.let(::decodePad) ?: defaultPad(padIndex) }
        }
        return PerformancePreset(
            name = o.optString("name", "Preset").take(32).ifBlank { "Preset" },
            modelId = o.optString("modelId", "pa600"),
            portamentoEnabled = o.optBoolean("portamentoEnabled", false),
            portamentoMs = o.optDouble("portamentoMs", 20.0).coerceIn(1.0, 5000.0),
            targetUpperMask = o.optInt("targetUpperMask", 1).and(0x7).let { if (it == 0) 1 else it },
            harmonyEnabled = o.optBoolean("harmonyEnabled", false),
            harmonyTonic = o.optInt("harmonyTonic", 0).coerceIn(0, 11),
            harmonyScale = enumValueOr(o.optString("harmonyScale", null), ScaleType.MAJOR),
            tercaDegree = enumValueOr(o.optString("tercaDegree", null), HarmonyDegree.THIRD),
            ribbonOutput = enumValueOr(o.optString("ribbonOutput", null), RibbonOutput.PITCH_BEND),
            ribbonRelease = RibbonRelease.CENTER,
            padBank = o.optInt("padBank", 0).coerceIn(0, 2),
            midiThru = o.optBoolean("midiThru", false),
            performanceInputChannel = o.optInt("performanceInputChannel", 0).coerceIn(0, 15),
            performanceInputOmni = false,
            upper1Channel = o.optInt("upper1Channel", 0).coerceIn(0, 15),
            upper2Channel = o.optInt("upper2Channel", 1).coerceIn(0, 15),
            upper3Channel = o.optInt("upper3Channel", 2).coerceIn(0, 15),
            autoReconnect = o.optBoolean("autoReconnect", true),
            padBanks = banks
        )
    }

    private fun encodePad(p: PadConfig) = JSONObject().apply {
        put("label", p.label.take(24)); put("type", p.type.name); put("channel", p.channel.coerceIn(0, 15))
        put("number", p.number.coerceIn(0, 127)); put("onValue", p.onValue.coerceIn(0, 127)); put("offValue", p.offValue.coerceIn(0, 127)); put("momentary", p.momentary)
    }
    private fun decodePad(o: JSONObject) = PadConfig(
        label = o.optString("label", "PAD").trim().take(24).ifBlank { "PAD" },
        type = enumValueOr(o.optString("type", null), PadType.NOTE), channel = o.optInt("channel", 9).coerceIn(0, 15),
        number = o.optInt("number", 36).coerceIn(0, 127), onValue = o.optInt("onValue", 110).coerceIn(0, 127),
        offValue = o.optInt("offValue", 0).coerceIn(0, 127), momentary = o.optBoolean("momentary", true)
    )
    private fun defaultPad(index: Int) = PadConfig("PAD ${index + 1}", PadType.NOTE, 9, 36 + index.coerceIn(0, 15), 110, 0, true)
    private fun key(slot: Int) = "slot_$slot"
    private inline fun <reified T : Enum<T>> enumValueOr(name: String?, fallback: T): T =
        runCatching { if (name.isNullOrBlank()) fallback else enumValueOf<T>(name) }.getOrDefault(fallback)
}
