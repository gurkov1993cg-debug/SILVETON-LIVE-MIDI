package bg.silveton.live.midi

data class MidiIdentityInfo(
    val manufacturerName: String,
    val manufacturerIdHex: String,
    val familyCodeHex: String,
    val modelNumberHex: String,
    val versionHex: String
)

/** JNI facade for the remaining native modules: ribbon, pads, identity and panic. */
class NativeMidiCore : AutoCloseable {
    private val lock = Any()
    private var handle: Long = nativeCreate()

    init { require(handle != 0L) { "Native MIDI core initialization failed" } }

    private inline fun <T> withHandle(block: (Long) -> T): T = synchronized(lock) {
        check(handle != 0L) { "Native MIDI core is closed" }
        block(handle)
    }

    fun selectModel(modelId: String): Boolean = withHandle { nativeSelectModel(it, modelId) }

    fun configureRibbon(output: RibbonOutput, channel: Int, cc: Int = 16, smoothing: Double = 0.15, release: RibbonRelease = RibbonRelease.CENTER) =
        withHandle { nativeConfigureRibbon(it, output.nativeValue, channel, cc, smoothing, release.nativeValue) }

    fun ribbon(position: Double, timestampNanos: Long = 0L): ByteArray =
        withHandle { nativeRibbon(it, position, timestampNanos) }

    fun ribbonRelease(timestampNanos: Long = 0L): ByteArray =
        withHandle { nativeRibbonRelease(it, timestampNanos) }

    fun setPadBank(bank: Int) = withHandle { nativeSetPadBank(it, bank) }
    fun setPad(index: Int, type: PadType, channel: Int, number: Int, onValue: Int, offValue: Int, momentary: Boolean) =
        withHandle { nativeSetPad(it, index, type.nativeValue, channel, number, onValue, offValue, momentary) }
    fun pressPad(index: Int, timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativePressPad(it, index, timestampNanos) }
    fun releasePad(index: Int, timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativeReleasePad(it, index, timestampNanos) }
    fun flushPads(timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativeFlushPads(it, timestampNanos) }

    fun identityRequest(): ByteArray = withHandle { nativeIdentityRequest(it) }

    fun parseIdentityReply(bytes: ByteArray): MidiIdentityInfo? = withHandle { h ->
        val packed = nativeParseIdentityReply(h, bytes) ?: return@withHandle null
        val fields = packed.split('|')
        if (fields.size != 5) null else MidiIdentityInfo(fields[0], fields[1], fields[2], fields[3], fields[4])
    }

    fun panic(allChannels: Boolean = true, channel: Int = 0): Array<ByteArray> =
        withHandle { nativePanic(it, allChannels, channel) }

    override fun close() = synchronized(lock) {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    private external fun nativeCreate(): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeSelectModel(handle: Long, modelId: String): Boolean
    private external fun nativeConfigureRibbon(handle: Long, output: Int, channel: Int, cc: Int, smoothing: Double, releaseMode: Int)
    private external fun nativeRibbon(handle: Long, position: Double, timestampNanos: Long): ByteArray
    private external fun nativeRibbonRelease(handle: Long, timestampNanos: Long): ByteArray
    private external fun nativeSetPadBank(handle: Long, bank: Int)
    private external fun nativeSetPad(handle: Long, index: Int, type: Int, channel: Int, number: Int, onValue: Int, offValue: Int, momentary: Boolean)
    private external fun nativePressPad(handle: Long, index: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeReleasePad(handle: Long, index: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeFlushPads(handle: Long, timestampNanos: Long): Array<ByteArray>
    private external fun nativeIdentityRequest(handle: Long): ByteArray
    private external fun nativeParseIdentityReply(handle: Long, bytes: ByteArray): String?
    private external fun nativePanic(handle: Long, allChannels: Boolean, channel: Int): Array<ByteArray>

    companion object {
        init { System.loadLibrary("silveton_live_jni") }
    }
}
