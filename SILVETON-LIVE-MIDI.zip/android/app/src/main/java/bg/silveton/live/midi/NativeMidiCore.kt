package bg.silveton.live.midi

data class ScheduledMidi(val timestampNanos: Long, val bytes: ByteArray)

data class MidiIdentityInfo(
    val manufacturerName: String,
    val manufacturerIdHex: String,
    val familyCodeHex: String,
    val modelNumberHex: String,
    val versionHex: String
)

enum class PortaMode(val nativeValue: Int) { FIX(0), LIN(1), FIB(2), REAL(3), CUSTOM(4) }
enum class RibbonOutput(val nativeValue: Int) { PITCH_BEND(0), CONTROL_CHANGE(1) }
enum class RibbonRelease(val nativeValue: Int) { HOLD(0), CENTER(1), MINIMUM(2), MAXIMUM(3) }
enum class PadType(val nativeValue: Int) { NOTE(0), CONTROL_CHANGE(1), PROGRAM_CHANGE(2) }
enum class ScaleType(val nativeValue: Int) { MAJOR(0), NATURAL_MINOR(1), HARMONIC_MINOR(2), DORIAN(3), PHRYGIAN(4), LYDIAN(5), MIXOLYDIAN(6) }
enum class IntervalMode { SCALE, CHROMATIC }
enum class HarmonyDegree(val nativeValue: Int) { UNISON(0), SECOND(1), THIRD(2), FOURTH(3), FIFTH(4), SIXTH(5), SEVENTH(6), OCTAVE(7) }

/**
 * Serialized JNI facade around the mutable C++ live engine.
 * Android MIDI callbacks and UI gestures may arrive on different threads; the native
 * engines intentionally stay allocation-light rather than carrying their own locks.
 */
class NativeMidiCore : AutoCloseable {
    private val lock = Any()
    private var handle: Long = nativeCreate()

    init { require(handle != 0L) { "Native MIDI core initialization failed" } }

    private inline fun <T> withHandle(block: (Long) -> T): T = synchronized(lock) {
        check(handle != 0L) { "Native MIDI core is closed" }
        block(handle)
    }

    fun selectModel(modelId: String): Boolean = withHandle { nativeSelectModel(it, modelId) }

    fun configurePortamento(mode: PortaMode, durationMs: Double, depth: Double = 1.0, steps: Int = 48) =
        withHandle { nativeConfigurePortamento(it, mode.nativeValue, durationMs, depth, steps) }

    fun setPortamentoEngineEnabled(enabled: Boolean) =
        withHandle { nativeSetPortamentoEngineEnabled(it, enabled) }
    fun hardwarePortamentoSwitch(enabled: Boolean, channel: Int = 0): Array<ByteArray> =
        withHandle { nativeHardwarePortamentoSwitch(it, enabled, channel) }
    fun setPortamentoEnabled(enabled: Boolean, channel: Int = 0): Array<ByteArray> =
        withHandle { nativeSetPortamentoEnabled(it, enabled, channel) }

    fun applyPortamentoTime(channel: Int = 0): Array<ByteArray> =
        withHandle { nativeApplyPortamentoTime(it, channel) }

    fun setPortamentoCalibration(ccValues: IntArray, milliseconds: DoubleArray): Boolean =
        withHandle { nativeSetPortamentoCalibration(it, ccValues, milliseconds) }

    fun buildGlide(startNote: Int, endNote: Int, startTimeNanos: Long, channel: Int, bendRangeSemitones: Int): List<ScheduledMidi> =
        withHandle { h -> nativeBuildGlide(h, startNote, endNote, startTimeNanos, channel, bendRangeSemitones).mapNotNull(::decodeScheduled) }

    fun setPitchBendRange(channel: Int, semitones: Int): Array<ByteArray> =
        withHandle { nativeSetPitchBendRange(it, channel, semitones) }

    fun configureRibbon(output: RibbonOutput, channel: Int, cc: Int = 16, smoothing: Double = 0.15, release: RibbonRelease = RibbonRelease.CENTER) =
        withHandle { nativeConfigureRibbon(it, output.nativeValue, channel, cc, smoothing, release.nativeValue) }

    fun ribbon(position: Double, timestampNanos: Long = 0L): ByteArray =
        withHandle { nativeRibbon(it, position, timestampNanos) }
    fun ribbonRelease(timestampNanos: Long = 0L): ByteArray =
        withHandle { nativeRibbonRelease(it, timestampNanos) }

    fun setPadBank(bank: Int) = withHandle { nativeSetPadBank(it, bank) }
    fun setPad(index: Int, type: PadType, channel: Int, number: Int, onValue: Int, offValue: Int, momentary: Boolean) =
        withHandle { nativeSetPad(it, index, type.nativeValue, channel, number, onValue, offValue, momentary) }
    fun pressPad(index: Int, timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativePressPad(it, index, timestampNanos) }
    fun releasePad(index: Int, timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativeReleasePad(it, index, timestampNanos) }
    fun flushPads(timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativeFlushPads(it, timestampNanos) }

    fun setIntervalVoice(index: Int, enabled: Boolean, semitones: Int, velocityOffset: Int = 0, outputChannel: Int = -1) =
        withHandle { nativeSetIntervalVoice(it, index, enabled, semitones, velocityOffset, outputChannel) }
    fun intervalNoteOn(channel: Int, note: Int, velocity: Int, timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativeIntervalNoteOn(it, channel, note, velocity, timestampNanos) }
    fun intervalNoteOff(channel: Int, note: Int, velocity: Int = 0, timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativeIntervalNoteOff(it, channel, note, velocity, timestampNanos) }
    fun flushIntervals(timestampNanos: Long = 0L): List<ScheduledMidi> =
        withHandle { h -> nativeFlushIntervals(h, timestampNanos).mapNotNull(::decodeScheduled) }

    fun configureHarmony(tonic: Int, scale: ScaleType, quantizeNonScale: Boolean = true) =
        withHandle { nativeConfigureHarmony(it, tonic, scale.nativeValue, quantizeNonScale) }
    fun setHarmonyVoice(index: Int, enabled: Boolean, degree: HarmonyDegree, octaves: Int = 0, velocityOffset: Int = 0, outputChannel: Int = -1) =
        withHandle { nativeSetHarmonyVoice(it, index, enabled, degree.nativeValue, octaves, velocityOffset, outputChannel) }
    fun harmonyNoteOn(channel: Int, note: Int, velocity: Int, timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativeHarmonyNoteOn(it, channel, note, velocity, timestampNanos) }
    fun harmonyNoteOff(channel: Int, note: Int, velocity: Int = 0, timestampNanos: Long = 0L): Array<ByteArray> =
        withHandle { nativeHarmonyNoteOff(it, channel, note, velocity, timestampNanos) }
    fun flushHarmony(timestampNanos: Long = 0L): List<ScheduledMidi> =
        withHandle { h -> nativeFlushHarmony(h, timestampNanos).mapNotNull(::decodeScheduled) }

    fun portaBridgeNoteOn(outputChannel: Int, note: Int, velocity: Int, timestampNanos: Long, bendRangeSemitones: Int = 12): List<ScheduledMidi> =
        withHandle { h -> nativePortaBridgeNoteOn(h, outputChannel, note, velocity, timestampNanos, bendRangeSemitones).mapNotNull(::decodeScheduled) }
    fun portaBridgeNoteOff(outputChannel: Int, note: Int, velocity: Int, timestampNanos: Long): List<ScheduledMidi> =
        withHandle { h -> nativePortaBridgeNoteOff(h, outputChannel, note, velocity, timestampNanos).mapNotNull(::decodeScheduled) }
    fun resetPortaBridge(timestampNanos: Long = 0L): List<ScheduledMidi> =
        withHandle { h -> nativeResetPortaBridge(h, timestampNanos).mapNotNull(::decodeScheduled) }

    fun identityRequest(): ByteArray = withHandle { nativeIdentityRequest(it) }
    fun parseIdentityReply(bytes: ByteArray): MidiIdentityInfo? = withHandle { h ->
        val packed = nativeParseIdentityReply(h, bytes) ?: return@withHandle null
        val fields = packed.split('|')
        if (fields.size != 5) null else MidiIdentityInfo(fields[0], fields[1], fields[2], fields[3], fields[4])
    }
    fun panic(allChannels: Boolean = true, channel: Int = 0): Array<ByteArray> =
        withHandle { nativePanic(it, allChannels, channel) }

    override fun close() = synchronized(lock) {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    private fun decodeScheduled(frame: ByteArray): ScheduledMidi? {
        if (frame.size < 9) return null
        var t = 0L
        for (i in 0 until 8) t = (t shl 8) or (frame[i].toLong() and 0xFFL)
        return ScheduledMidi(t, frame.copyOfRange(8, frame.size))
    }

    private external fun nativeCreate(): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeSelectModel(handle: Long, modelId: String): Boolean
    private external fun nativeConfigurePortamento(handle: Long, mode: Int, durationMs: Double, depth: Double, steps: Int)
    private external fun nativeSetPortamentoEngineEnabled(handle: Long, enabled: Boolean)
    private external fun nativeHardwarePortamentoSwitch(handle: Long, enabled: Boolean, channel: Int): Array<ByteArray>
    private external fun nativeSetPortamentoEnabled(handle: Long, enabled: Boolean, channel: Int): Array<ByteArray>
    private external fun nativeApplyPortamentoTime(handle: Long, channel: Int): Array<ByteArray>
    private external fun nativeSetPortamentoCalibration(handle: Long, ccValues: IntArray, milliseconds: DoubleArray): Boolean
    private external fun nativeBuildGlide(handle: Long, startNote: Int, endNote: Int, startTimeNanos: Long, channel: Int, bendRangeSemitones: Int): Array<ByteArray>
    private external fun nativeSetPitchBendRange(handle: Long, channel: Int, semitones: Int): Array<ByteArray>
    private external fun nativeConfigureRibbon(handle: Long, output: Int, channel: Int, cc: Int, smoothing: Double, releaseMode: Int)
    private external fun nativeRibbon(handle: Long, position: Double, timestampNanos: Long): ByteArray
    private external fun nativeRibbonRelease(handle: Long, timestampNanos: Long): ByteArray
    private external fun nativeSetPadBank(handle: Long, bank: Int)
    private external fun nativeSetPad(handle: Long, index: Int, type: Int, channel: Int, number: Int, onValue: Int, offValue: Int, momentary: Boolean)
    private external fun nativePressPad(handle: Long, index: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeReleasePad(handle: Long, index: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeFlushPads(handle: Long, timestampNanos: Long): Array<ByteArray>
    private external fun nativeSetIntervalVoice(handle: Long, index: Int, enabled: Boolean, semitones: Int, velocityOffset: Int, outputChannel: Int)
    private external fun nativeIntervalNoteOn(handle: Long, channel: Int, note: Int, velocity: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeIntervalNoteOff(handle: Long, channel: Int, note: Int, velocity: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeFlushIntervals(handle: Long, timestampNanos: Long): Array<ByteArray>
    private external fun nativeConfigureHarmony(handle: Long, tonic: Int, scale: Int, quantize: Boolean)
    private external fun nativeSetHarmonyVoice(handle: Long, index: Int, enabled: Boolean, degree: Int, octaves: Int, velocityOffset: Int, outputChannel: Int)
    private external fun nativeHarmonyNoteOn(handle: Long, channel: Int, note: Int, velocity: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeHarmonyNoteOff(handle: Long, channel: Int, note: Int, velocity: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeFlushHarmony(handle: Long, timestampNanos: Long): Array<ByteArray>
    private external fun nativePortaBridgeNoteOn(handle: Long, outputChannel: Int, note: Int, velocity: Int, timestampNanos: Long, bendRangeSemitones: Int): Array<ByteArray>
    private external fun nativePortaBridgeNoteOff(handle: Long, outputChannel: Int, note: Int, velocity: Int, timestampNanos: Long): Array<ByteArray>
    private external fun nativeResetPortaBridge(handle: Long, timestampNanos: Long): Array<ByteArray>
    private external fun nativeIdentityRequest(handle: Long): ByteArray
    private external fun nativeParseIdentityReply(handle: Long, bytes: ByteArray): String?
    private external fun nativePanic(handle: Long, allChannels: Boolean, channel: Int): Array<ByteArray>

    companion object {
        init { System.loadLibrary("silveton_live_jni") }
    }
}
