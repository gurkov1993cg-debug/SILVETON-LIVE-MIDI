package bg.silveton.live.model

import android.content.Context

/** Persists measured CC5 -> milliseconds points separately for each PA model. */
class PortamentoCalibrationStore(context: Context) {
    data class Table(val cc: IntArray, val milliseconds: DoubleArray)

    private val prefs = context.getSharedPreferences("silveton_live_porta_calibration", Context.MODE_PRIVATE)

    fun load(modelId: String): Table? {
        val raw = prefs.getString(key(modelId), null) ?: return null
        val points = raw.split(';').mapNotNull { token ->
            val p = token.split(':')
            if (p.size != 2) null else {
                val cc = p[0].toIntOrNull()
                val ms = p[1].toDoubleOrNull()
                if (cc == null || ms == null || cc !in 0..127 || !ms.isFinite() || ms <= 0.0) null
                else cc to ms
            }
        }.sortedBy { it.first }
        if (points.size < 2) return null
        if (points.zipWithNext().any { (a, b) -> b.first <= a.first || b.second < a.second }) return null
        return Table(points.map { it.first }.toIntArray(), points.map { it.second }.toDoubleArray())
    }

    fun save(modelId: String, cc: IntArray, milliseconds: DoubleArray): Boolean {
        if (cc.size != milliseconds.size || cc.size < 2) return false
        val points = cc.indices.map { cc[it] to milliseconds[it] }.sortedBy { it.first }
        if (points.any { (v, ms) -> v !in 0..127 || !ms.isFinite() || ms <= 0.0 }) return false
        if (points.zipWithNext().any { (a, b) -> b.first <= a.first || b.second < a.second }) return false
        val raw = points.joinToString(";") { (v, ms) -> "$v:$ms" }
        prefs.edit().putString(key(modelId), raw).apply()
        return true
    }

    fun clear(modelId: String) {
        prefs.edit().remove(key(modelId)).apply()
    }

    private fun key(modelId: String) = "model_${modelId.lowercase()}"
}
