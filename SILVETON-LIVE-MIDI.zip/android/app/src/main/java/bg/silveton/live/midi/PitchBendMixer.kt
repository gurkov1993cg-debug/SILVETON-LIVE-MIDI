package bg.silveton.live.midi

/**
 * Combines the app-side portamento Pitch Bend trajectory with the live Ribbon Pitch Bend.
 *
 * MIDI exposes only one 14-bit Pitch Bend value per channel.  Without a single owner,
 * a portamento glide and a ribbon would overwrite each other.  This mixer keeps a
 * portamento base and a ribbon offset per MIDI channel, then emits their clamped sum.
 * Center is 8192, so either source behaves exactly as before when the other is centered.
 */
class PitchBendMixer {
    private val porta = IntArray(16) { CENTER }
    private val ribbon = IntArray(16) { CENTER }

    @Synchronized
    fun applyPortamento(message: ByteArray): ByteArray {
        val decoded = decode(message) ?: return message
        porta[decoded.first] = decoded.second
        return encode(decoded.first, combine(decoded.first))
    }

    @Synchronized
    fun applyRibbon(message: ByteArray): ByteArray {
        val decoded = decode(message) ?: return message
        ribbon[decoded.first] = decoded.second
        return encode(decoded.first, combine(decoded.first))
    }

    @Synchronized
    fun centerRibbon(channel: Int): ByteArray {
        val ch = channel.coerceIn(0, 15)
        ribbon[ch] = CENTER
        return encode(ch, combine(ch))
    }

    @Synchronized
    fun resetChannel(channel: Int) {
        val ch = channel.coerceIn(0, 15)
        porta[ch] = CENTER
        ribbon[ch] = CENTER
    }

    @Synchronized
    fun resetAll() {
        for (ch in 0 until 16) {
            porta[ch] = CENTER
            ribbon[ch] = CENTER
        }
    }

    private fun combine(channel: Int): Int =
        (CENTER + (porta[channel] - CENTER) + (ribbon[channel] - CENTER)).coerceIn(0, MAX)

    private fun decode(message: ByteArray): Pair<Int, Int>? {
        if (message.size < 3) return null
        val status = message[0].toInt() and 0xFF
        if (status and 0xF0 != 0xE0) return null
        val lsb = message[1].toInt() and 0x7F
        val msb = message[2].toInt() and 0x7F
        return (status and 0x0F) to (lsb or (msb shl 7))
    }

    private fun encode(channel: Int, value: Int): ByteArray {
        val v = value.coerceIn(0, MAX)
        return byteArrayOf(
            (0xE0 or channel.coerceIn(0, 15)).toByte(),
            (v and 0x7F).toByte(),
            ((v ushr 7) and 0x7F).toByte()
        )
    }

    private companion object {
        const val CENTER = 8192
        const val MAX = 16383
    }
}
