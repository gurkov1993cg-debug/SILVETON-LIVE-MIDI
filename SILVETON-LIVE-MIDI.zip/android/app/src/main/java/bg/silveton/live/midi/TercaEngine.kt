package bg.silveton.live.midi

/**
 * SILVETON smart-third engine.
 *
 * Own musical logic; no recovered interval/mask tables are used.
 * - SCAN recognizes a three-note major triad, minor triad, or Hijaz signature.
 * - The detected tonic + scale drive a diatonic third.
 * - A generated third is always the nearest +3/+4 or -3/-4 semitones, never +/-12.
 * - Output bookkeeping guarantees the matching Note Off is sent on UPPER 3.
 */
class TercaEngine {
    private var tonic = 0
    private var scale = ScaleType.MAJOR
    private var degree = HarmonyDegree.THIRD
    private val active = HashMap<Int, Int>()
    private val refs = IntArray(128)

    fun configure(tonic: Int, scale: ScaleType, degree: HarmonyDegree) {
        this.tonic = mod12(tonic)
        this.scale = scale
        this.degree = degree
    }

    fun noteOn(inputChannel: Int, note: Int, velocity: Int, outputChannel: Int): Array<ByteArray> {
        val n = note.coerceIn(0, 127)
        val key = (inputChannel.coerceIn(0, 15) shl 8) or n
        val out = ArrayList<ByteArray>()
        release(key, outputChannel, 0, out)

        val interval = thirdInterval(n, tonic, scale, degree)
        require(interval in intArrayOf(-4, -3, 3, 4))
        val generated = (n + interval).coerceIn(0, 127)
        active[key] = generated
        if (refs[generated]++ == 0) {
            out += noteMsg(true, outputChannel, generated, velocity.coerceIn(1, 127))
        }
        return out.toTypedArray()
    }

    fun noteOff(inputChannel: Int, note: Int, velocity: Int, outputChannel: Int): Array<ByteArray> {
        val out = ArrayList<ByteArray>()
        release((inputChannel.coerceIn(0, 15) shl 8) or note.coerceIn(0, 127), outputChannel, velocity, out)
        return out.toTypedArray()
    }

    fun flush(outputChannel: Int): Array<ByteArray> {
        val out = ArrayList<ByteArray>()
        for (note in 0..127) {
            if (refs[note] > 0) {
                out += noteMsg(false, outputChannel, note, 0)
                refs[note] = 0
            }
        }
        active.clear()
        return out.toTypedArray()
    }

    /**
     * Three-note scan, inversion aware.
     *
     * Recognized pitch-class signatures relative to the detected tonic:
     * - 0,4,7 : major triad -> MAJOR
     * - 0,3,7 : minor triad -> HARMONIC_MINOR
     * - 0,1,4 : Hijaz signature -> HIJAZ
     *
     * Root in the highest played voice selects THIRD_DOWN; otherwise THIRD_UP.
     * This gives an intuitive way to choose direction without adding another GUI control.
     */
    fun scan(notes: IntArray): TercaScanInfo? {
        if (notes.size != 3) return null
        val normalized = notes.map { it.coerceIn(0, 127) }
        if (normalized.map(::mod12).toSet().size != 3) return null
        val pcs = normalized.map(::mod12).toSet()

        val signatures = listOf(
            ScaleType.MAJOR to intArrayOf(0, 4, 7),
            ScaleType.HARMONIC_MINOR to intArrayOf(0, 3, 7),
            ScaleType.HIJAZ to intArrayOf(0, 1, 4)
        )

        for (root in 0..11) {
            for ((candidateScale, signature) in signatures) {
                val expected = signature.map { mod12(root + it) }.toSet()
                if (pcs != expected) continue

                val highest = normalized.maxOrNull() ?: return null
                val highestIsRoot = mod12(highest) == root
                val direction = if (highestIsRoot) HarmonyDegree.THIRD_DOWN else HarmonyDegree.THIRD
                configure(root, candidateScale, direction)
                return TercaScanInfo(root, candidateScale, direction)
            }
        }
        return null
    }

    fun currentTonic(): Int = tonic
    fun currentScale(): ScaleType = scale
    fun currentDegree(): HarmonyDegree = degree

    private fun release(key: Int, channel: Int, velocity: Int, out: MutableList<ByteArray>) {
        val generated = active.remove(key) ?: return
        if (refs[generated] > 0) refs[generated]--
        if (refs[generated] == 0) out += noteMsg(false, channel, generated, velocity.coerceIn(0, 127))
    }

    private fun noteMsg(on: Boolean, channel: Int, note: Int, velocity: Int) = byteArrayOf(
        ((if (on) 0x90 else 0x80) or channel.coerceIn(0, 15)).toByte(),
        note.coerceIn(0, 127).toByte(),
        velocity.coerceIn(0, 127).toByte()
    )

    companion object {
        private val SCALES: Map<ScaleType, IntArray> = mapOf(
            ScaleType.MAJOR to intArrayOf(0, 2, 4, 5, 7, 9, 11),
            ScaleType.NATURAL_MINOR to intArrayOf(0, 2, 3, 5, 7, 8, 10),
            ScaleType.HARMONIC_MINOR to intArrayOf(0, 2, 3, 5, 7, 8, 11),
            ScaleType.DORIAN to intArrayOf(0, 2, 3, 5, 7, 9, 10),
            ScaleType.PHRYGIAN to intArrayOf(0, 1, 3, 5, 7, 8, 10),
            ScaleType.LYDIAN to intArrayOf(0, 2, 4, 6, 7, 9, 11),
            ScaleType.MIXOLYDIAN to intArrayOf(0, 2, 4, 5, 7, 9, 10),
            // Common heptatonic Hijaz pitch collection: 1, b2, 3, 4, 5, b6, b7.
            ScaleType.HIJAZ to intArrayOf(0, 1, 4, 5, 7, 8, 10)
        )

        fun thirdInterval(note: Int, tonic: Int, scale: ScaleType, degree: HarmonyDegree): Int {
            val rel = mod12Static(note - tonic)
            val pcs = SCALES[scale] ?: SCALES.getValue(ScaleType.MAJOR)
            val index = pcs.indexOf(rel)

            if (index >= 0) {
                if (degree == HarmonyDegree.THIRD) {
                    val targetIndex = (index + 2) % pcs.size
                    var target = pcs[targetIndex]
                    if (target <= rel) target += 12
                    return (target - rel).coerceIn(3, 4)
                }

                val targetIndex = (index - 2 + pcs.size) % pcs.size
                var target = pcs[targetIndex]
                if (target >= rel) target -= 12
                return (target - rel).coerceIn(-4, -3)
            }

            // Chromatic passing notes: keep the harmony a true nearby third and prefer
            // the candidate whose destination belongs to the selected scale.
            return if (degree == HarmonyDegree.THIRD) {
                val plus3InScale = pcs.contains(mod12Static(rel + 3))
                val plus4InScale = pcs.contains(mod12Static(rel + 4))
                when {
                    plus3InScale && !plus4InScale -> 3
                    plus4InScale && !plus3InScale -> 4
                    else -> 3
                }
            } else {
                val minus3InScale = pcs.contains(mod12Static(rel - 3))
                val minus4InScale = pcs.contains(mod12Static(rel - 4))
                when {
                    minus3InScale && !minus4InScale -> -3
                    minus4InScale && !minus3InScale -> -4
                    else -> -3
                }
            }
        }

        private fun mod12Static(value: Int) = ((value % 12) + 12) % 12
    }

    private fun mod12(value: Int) = ((value % 12) + 12) % 12
}
