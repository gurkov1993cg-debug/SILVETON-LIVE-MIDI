package bg.silveton.live.midi

/**
 * Dedicated TERCA engine. It is deliberately note-only:
 * - never emits CC, Pitch Bend, RPN, transpose, octave or Program Change;
 * - every generated note is the nearest musical third (+3/+4 or -3/-4 semitones);
 * - NoteOff always releases the exact generated note remembered from NoteOn.
 */
class TercaEngine {
    private var tonic = 0
    private var scale = ScaleType.MAJOR
    private var degree = HarmonyDegree.THIRD
    private val active = HashMap<Int, Int>() // input key (channel<<8|note) -> generated note
    private val outputRefs = IntArray(128)

    fun configure(tonic: Int, scale: ScaleType, degree: HarmonyDegree) {
        this.tonic = floorMod12(tonic)
        this.scale = scale
        this.degree = degree
    }

    fun noteOn(inputChannel: Int, note: Int, velocity: Int, outputChannel: Int): Array<ByteArray> {
        val n = note.coerceIn(0, 127)
        val key = (inputChannel.coerceIn(0, 15) shl 8) or n
        val out = ArrayList<ByteArray>(2)
        releaseKey(key, outputChannel, 0, out)

        val generated = thirdFor(n)
        active[key] = generated
        if (outputRefs[generated]++ == 0) {
            out += noteMessage(true, outputChannel, generated, velocity.coerceIn(1, 127))
        }
        return out.toTypedArray()
    }

    fun noteOff(inputChannel: Int, note: Int, velocity: Int, outputChannel: Int): Array<ByteArray> {
        val key = (inputChannel.coerceIn(0, 15) shl 8) or note.coerceIn(0, 127)
        val out = ArrayList<ByteArray>(1)
        releaseKey(key, outputChannel, velocity.coerceIn(0, 127), out)
        return out.toTypedArray()
    }

    fun flush(outputChannel: Int): Array<ByteArray> {
        val out = ArrayList<ByteArray>()
        for (note in 0 until 128) {
            if (outputRefs[note] > 0) {
                out += noteMessage(false, outputChannel, note, 0)
                outputRefs[note] = 0
            }
        }
        active.clear()
        return out.toTypedArray()
    }

    fun scan(notes: IntArray): TercaScanInfo? {
        if (notes.size != 3) return null
        val pcs = notes.map(::floorMod12).distinct().sorted()
        if (pcs.size != 3) return null
        for (root in 0 until 12) {
            for (cell in scanCells) {
                val wanted = listOf(root, floorMod12(root + cell.i1), floorMod12(root + cell.i2)).sorted()
                if (pcs == wanted) return TercaScanInfo(root, cell.scale, cell.degree)
            }
        }
        return null
    }

    private fun thirdFor(note: Int): Int {
        val pc = floorMod12(note - tonic)
        val scalePcs = scaleIntervals(scale)
        val up3 = floorMod12(pc + 3)
        val up4 = floorMod12(pc + 4)
        val down3 = floorMod12(pc - 3)
        val down4 = floorMod12(pc - 4)

        val delta = when (degree) {
            HarmonyDegree.THIRD -> when {
                contains(scalePcs, up3) && !contains(scalePcs, up4) -> 3
                contains(scalePcs, up4) && !contains(scalePcs, up3) -> 4
                exactDiatonicThird(note, scalePcs) == 3 -> 3
                else -> 4
            }
            HarmonyDegree.THIRD_DOWN -> when {
                contains(scalePcs, down3) && !contains(scalePcs, down4) -> -3
                contains(scalePcs, down4) && !contains(scalePcs, down3) -> -4
                exactDiatonicThirdDown(note, scalePcs) == -3 -> -3
                else -> -4
            }
        }
        return (note + delta).coerceIn(0, 127)
    }

    private fun exactDiatonicThird(note: Int, intervals: IntArray): Int? {
        val pc = floorMod12(note - tonic)
        val i = intervals.indexOf(pc)
        if (i < 0) return null
        val target = intervals[(i + 2) % 7] + if (i + 2 >= 7) 12 else 0
        return target - intervals[i]
    }

    private fun exactDiatonicThirdDown(note: Int, intervals: IntArray): Int? {
        val pc = floorMod12(note - tonic)
        val i = intervals.indexOf(pc)
        if (i < 0) return null
        val j = (i + 5) % 7
        val target = intervals[j] - if (i < 2) 12 else 0
        return target - intervals[i]
    }

    private fun releaseKey(key: Int, outputChannel: Int, velocity: Int, out: MutableList<ByteArray>) {
        val generated = active.remove(key) ?: return
        if (outputRefs[generated] > 0) outputRefs[generated]--
        if (outputRefs[generated] == 0) out += noteMessage(false, outputChannel, generated, velocity)
    }

    private fun noteMessage(on: Boolean, channel: Int, note: Int, velocity: Int): ByteArray = byteArrayOf(
        ((if (on) 0x90 else 0x80) or channel.coerceIn(0, 15)).toByte(),
        note.coerceIn(0, 127).toByte(),
        velocity.coerceIn(0, 127).toByte()
    )

    private fun floorMod12(v: Int): Int = ((v % 12) + 12) % 12
    private fun contains(values: IntArray, value: Int): Boolean = values.any { it == value }

    private data class ScanCell(val i1: Int, val i2: Int, val scale: ScaleType, val degree: HarmonyDegree)

    private val scanCells = listOf(
        ScanCell(4, 7, ScaleType.MAJOR, HarmonyDegree.THIRD),
        ScanCell(2, 4, ScaleType.MAJOR, HarmonyDegree.THIRD_DOWN),
        ScanCell(3, 7, ScaleType.HARMONIC_MINOR, HarmonyDegree.THIRD),
        ScanCell(2, 3, ScaleType.HARMONIC_MINOR, HarmonyDegree.THIRD_DOWN),
        ScanCell(1, 3, ScaleType.PHRYGIAN, HarmonyDegree.THIRD),
        ScanCell(1, 4, ScaleType.HIJAZ, HarmonyDegree.THIRD)
    )

    private fun scaleIntervals(type: ScaleType): IntArray = when (type) {
        ScaleType.MAJOR -> intArrayOf(0, 2, 4, 5, 7, 9, 11)
        ScaleType.NATURAL_MINOR -> intArrayOf(0, 2, 3, 5, 7, 8, 10)
        ScaleType.HARMONIC_MINOR -> intArrayOf(0, 2, 3, 5, 7, 8, 11)
        ScaleType.DORIAN -> intArrayOf(0, 2, 3, 5, 7, 9, 10)
        ScaleType.PHRYGIAN -> intArrayOf(0, 1, 3, 5, 7, 8, 10)
        ScaleType.LYDIAN -> intArrayOf(0, 2, 4, 6, 7, 9, 11)
        ScaleType.MIXOLYDIAN -> intArrayOf(0, 2, 4, 5, 7, 9, 10)
        ScaleType.HIJAZ -> intArrayOf(0, 1, 4, 5, 7, 8, 10)
    }
}
