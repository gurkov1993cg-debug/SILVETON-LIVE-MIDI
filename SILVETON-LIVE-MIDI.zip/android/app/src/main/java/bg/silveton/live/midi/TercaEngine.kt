package bg.silveton.live.midi

/**
 * Clean-room TERCA engine using the exact interval/scan data recovered from
 * MasterKey 5.01 FREE.  It emits notes only; it never sends transpose/octave/RPN.
 */
class TercaEngine {
    private var root = 0
    private var mode = 0
    private var degree = HarmonyDegree.THIRD
    private val active = HashMap<Int, Int>()
    private val refs = IntArray(128)

    fun configure(tonic: Int, scale: ScaleType, degree: HarmonyDegree) {
        root = mod12(tonic)
        this.degree = degree
        mode = when {
            scale == ScaleType.HIJAZ -> 1
            scale == ScaleType.HARMONIC_MINOR && degree == HarmonyDegree.THIRD_DOWN -> 3
            scale == ScaleType.HARMONIC_MINOR -> 2
            else -> 0
        }
    }

    fun noteOn(inputChannel: Int, note: Int, velocity: Int, outputChannel: Int): Array<ByteArray> {
        val n = note.coerceIn(0, 127)
        val key = (inputChannel.coerceIn(0, 15) shl 8) or n
        val out = ArrayList<ByteArray>()
        release(key, outputChannel, 0, out)

        val rel = mod12(n - root)
        var interval = THIRD_TABLE[mode * 12 + rel]
        // MasterKey stores the low mode as pitch-class +8/+9.  For SILVETON the
        // musical equivalent -4/-3 is used deliberately, so no hidden +12 octave
        // displacement can ever be introduced.
        // The recovered table is pitch-class based.  Values above a tritone are
        // the wrapped representation of a DOWN interval (8 == -4, 9 == -3).
        // Always unwrap to the nearest signed interval so TERCA can never acquire
        // an accidental +12 octave displacement.
        if (interval > 6) interval -= 12

        val generated = (n + interval).coerceIn(0, 127)
        active[key] = generated
        if (refs[generated]++ == 0) {
            out += noteMsg(true, outputChannel, generated, velocity.coerceIn(1, 127))
        }
        return out.toTypedArray()
    }

    fun noteOff(inputChannel: Int, note: Int, velocity: Int, outputChannel: Int): Array<ByteArray> {
        val out = ArrayList<ByteArray>()
        release((inputChannel.coerceIn(0, 15) shl 8) or note.coerceIn(0, 127), outputChannel, velocity, out)
        return out.toTypedArray()
    }

    fun flush(outputChannel: Int): Array<ByteArray> {
        val out = ArrayList<ByteArray>()
        for (note in 0..127) {
            if (refs[note] > 0) {
                out += noteMsg(false, outputChannel, note, 0)
                refs[note] = 0
            }
        }
        active.clear()
        return out.toTypedArray()
    }

    fun scan(notes: IntArray): TercaScanInfo? {
        if (notes.size != 3) return null
        var mask = 0
        notes.forEach { mask = mask or (1 shl mod12(it)) }
        val index = SCAN_MASKS.indexOf(mask)
        if (index < 0) return null

        val packed = SCAN_RESULT[index]
        applyPackedScanResult(packed)
        val scale = when (mode) {
            0 -> ScaleType.MAJOR
            1 -> ScaleType.HIJAZ
            else -> ScaleType.HARMONIC_MINOR
        }
        degree = if (mode == 3) HarmonyDegree.THIRD_DOWN else HarmonyDegree.THIRD
        return TercaScanInfo(root, scale, degree)
    }

    /** Apply the binary scan result without translating it through UI scale names. */
    fun applyPackedScanResult(packed: Int) {
        root = (packed ushr 4) and 0x0F
        mode = packed and 0x0F
        require(root in 0..11 && mode in 0..3)
        degree = if (mode == 3) HarmonyDegree.THIRD_DOWN else HarmonyDegree.THIRD
    }

    fun currentPackedScanResult(): Int = (root shl 4) or mode

    private fun release(key: Int, channel: Int, velocity: Int, out: MutableList<ByteArray>) {
        val generated = active.remove(key) ?: return
        if (refs[generated] > 0) refs[generated]--
        if (refs[generated] == 0) out += noteMsg(false, channel, generated, velocity.coerceIn(0, 127))
    }

    private fun noteMsg(on: Boolean, channel: Int, note: Int, velocity: Int) = byteArrayOf(
        ((if (on) 0x90 else 0x80) or channel.coerceIn(0, 15)).toByte(),
        note.coerceIn(0, 127).toByte(),
        velocity.coerceIn(0, 127).toByte()
    )

    private fun mod12(value: Int) = ((value % 12) + 12) % 12

    companion object {
        // CONFIRMED: MasterKey.exe VA 0x4C866A, exact 48 bytes = 4 modes x 12 pitch classes.
        val THIRD_TABLE = intArrayOf(
            4,4,3,4,3,4,4,4,4,3,4,3,
            4,4,3,4,3,3,4,3,4,3,3,4,
            3,4,3,4,4,3,4,3,4,4,4,3,
            8,9,9,9,8,9,8,8,9,8,9,8
        )

        // CONFIRMED: MasterKey.exe VA 0x4C869C, exact 48 DWORD masks.
        val SCAN_MASKS = intArrayOf(
            0x811,0x023,0x046,0x08c,0x118,0x230,0x460,0x8c0,0x181,0x302,0x604,0xc08,
            0x411,0x822,0x045,0x08a,0x114,0x228,0x450,0x8a0,0x141,0x282,0x504,0xa08,
            0x809,0x013,0x026,0x04c,0x098,0x130,0x260,0x4c0,0x980,0x301,0x602,0xc04,
            0x409,0x812,0x025,0x04a,0x094,0x128,0x250,0x4a0,0x940,0x281,0x502,0xa04
        )

        // CONFIRMED: MasterKey.exe VA 0x4C875C, packed root(high nibble)/mode(low nibble).
        val SCAN_RESULT = intArrayOf(
            0x00,0x10,0x20,0x30,0x40,0x50,0x60,0x70,0x80,0x90,0xa0,0xb0,
            0x01,0x11,0x21,0x31,0x41,0x51,0x61,0x71,0x81,0x91,0xa1,0xb1,
            0x02,0x12,0x22,0x32,0x42,0x52,0x62,0x72,0x82,0x92,0xa2,0xb2,
            0x03,0x13,0x23,0x33,0x43,0x53,0x63,0x73,0x83,0x93,0xa3,0xb3
        )
    }
}
