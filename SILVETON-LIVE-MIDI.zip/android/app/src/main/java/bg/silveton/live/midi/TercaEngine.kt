package bg.silveton.live.midi

/** Clean-room TERCA engine derived from observed MasterKey 5.01 data tables.
 * The original table stores low-terca intervals as +8/+9 (pitch-class equivalent).
 * SILVETON deliberately renders those as -4/-3 so TERCA never adds an octave.
 */
class TercaEngine {
    private var root = 0
    private var mode = 0
    private var degree = HarmonyDegree.THIRD
    private val active = HashMap<Int, Int>()
    private val refs = IntArray(128)

    fun configure(tonic: Int, scale: ScaleType, degree: HarmonyDegree) {
        root = mod12(tonic); this.degree = degree
        mode = when (scale) {
            ScaleType.MAJOR -> if (degree == HarmonyDegree.THIRD) 0 else 2
            ScaleType.HIJAZ -> 1
            ScaleType.HARMONIC_MINOR -> if (degree == HarmonyDegree.THIRD) 2 else 3
            else -> if (degree == HarmonyDegree.THIRD) 0 else 2
        }
    }

    fun noteOn(inputChannel:Int,note:Int,velocity:Int,outputChannel:Int):Array<ByteArray>{
        val n=note.coerceIn(0,127); val key=(inputChannel.coerceIn(0,15) shl 8) or n
        val out=ArrayList<ByteArray>(); release(key,outputChannel,0,out)
        val rel=mod12(n-root); var d=THIRD_TABLE[mode*12+rel]
        // MasterKey's 8/9 are the same pitch classes as -4/-3. Use nearest lower third,
        // satisfying SILVETON's no-extra-octave requirement.
        if(d==8)d=-4 else if(d==9)d=-3
        val g=(n+d).coerceIn(0,127); active[key]=g
        if(refs[g]++==0) out+=noteMsg(true,outputChannel,g,velocity.coerceIn(1,127))
        return out.toTypedArray()
    }
    fun noteOff(inputChannel:Int,note:Int,velocity:Int,outputChannel:Int):Array<ByteArray>{
        val out=ArrayList<ByteArray>(); release((inputChannel.coerceIn(0,15) shl 8) or note.coerceIn(0,127),outputChannel,velocity,out); return out.toTypedArray()
    }
    fun flush(outputChannel:Int):Array<ByteArray>{ val out=ArrayList<ByteArray>(); for(n in 0..127) if(refs[n]>0){out+=noteMsg(false,outputChannel,n,0);refs[n]=0};active.clear();return out.toTypedArray() }

    fun scan(notes:IntArray):TercaScanInfo?{
        if(notes.size!=3)return null; var mask=0
        notes.forEach{mask=mask or (1 shl mod12(it))}
        val idx=SCAN_MASKS.indexOf(mask); if(idx<0)return null
        val packed=SCAN_RESULT[idx]; root=(packed ushr 4) and 0x0f; mode=packed and 0x0f
        val scale=when(mode){0->ScaleType.MAJOR;1->ScaleType.HIJAZ;else->ScaleType.HARMONIC_MINOR}
        val deg=if(mode<2) HarmonyDegree.THIRD else HarmonyDegree.THIRD_DOWN
        degree=deg; return TercaScanInfo(root,scale,deg)
    }

    private fun release(key:Int,ch:Int,vel:Int,out:MutableList<ByteArray>){ val g=active.remove(key)?:return; if(refs[g]>0)refs[g]--; if(refs[g]==0)out+=noteMsg(false,ch,g,vel.coerceIn(0,127)) }
    private fun noteMsg(on:Boolean,ch:Int,n:Int,v:Int)=byteArrayOf(((if(on)0x90 else 0x80) or ch.coerceIn(0,15)).toByte(),n.toByte(),v.toByte())
    private fun mod12(v:Int)=((v%12)+12)%12
    companion object {
        // VA 0x4C866A: four 12-note interval rows observed in MasterKey 5.01.
        val THIRD_TABLE=intArrayOf(3,4,4,3,4,3,4,4,4,3,4,3, 4,4,3,4,3,3,4,3,4,3,3,4, 3,4,3,4,4,3,4,4,4,3,8,9, 9,9,8,9,8,8,9,8,9,8,9,8)
        // VA 0x4C869C: 48 DWORD pitch-class masks; VA 0x4C875C: packed root/mode.
        val SCAN_MASKS=intArrayOf(
            0x00000011,0x00000008,0x00000023,0x00000046,0x0000008c,0x00000118,0x00000230,0x00000460,0x000008c0,0x00000181,0x00000302,0x00000604,
            0x00000c08,0x00000411,0x00000822,0x00000045,0x0000008a,0x00000114,0x00000228,0x00000450,0x000008a0,0x00000141,0x00000282,0x00000504,
            0x00000a08,0x00000809,0x00000013,0x00000026,0x0000004c,0x00000098,0x00000130,0x00000260,0x000004c0,0x00000980,0x00000301,0x00000602,
            0x00000c04,0x00000409,0x00000812,0x00000025,0x0000004a,0x00000094,0x00000128,0x00000250,0x000004a0,0x00000940,0x00000281,0x00000502)
        val SCAN_RESULT=intArrayOf(
            0x00,0x10,0x20,0x30,0x40,0x50,0x60,0x70,0x80,0x90,0xa0,0xb0,
            0x01,0x11,0x21,0x31,0x41,0x51,0x61,0x71,0x81,0x91,0xa1,0xb1,
            0x02,0x12,0x22,0x32,0x42,0x52,0x62,0x72,0x82,0x92,0xa2,0xb2,
            0x03,0x13,0x23,0x33,0x43,0x53,0x63,0x73,0x83,0x93,0xa3,0xb3)
    }
}
