package bg.silveton.live.midi

import java.io.Closeable
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLongArray

/**
 * App-side monotonic MIDI scheduler used for generated glides.
 *
 * Android's MidiInputPort can accept future timestamps, but once those events are handed
 * to the platform they cannot be withdrawn when the player hits another note. A live
 * portamento controller must be able to replace an in-flight glide immediately. This
 * dispatcher therefore keeps future events in the app until they are due and uses a
 * per-channel generation token to invalidate stale glide tails.
 */
class MidiEventDispatcher(
    private val sendNow: (ByteArray) -> Unit,
    private val transform: (ByteArray) -> ByteArray = { it },
    private val onError: (Throwable) -> Unit = {}
) : Closeable {
    private val executor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "SilvetonMidiScheduler").apply {
            isDaemon = true
            priority = Thread.MAX_PRIORITY
        }
    }
    private val generations = AtomicLongArray(16)
    @Volatile private var closed = false

    /** Invalidates every previously queued event for [channel]. */
    fun invalidateChannel(channel: Int): Long {
        val ch = channel.coerceIn(0, 15)
        return generations.incrementAndGet(ch)
    }

    fun invalidateAll() {
        for (ch in 0 until 16) generations.incrementAndGet(ch)
    }

    /**
     * Replaces any pending generated trajectory on [channel] and dispatches [events].
     * Events with timestamps at or before now are sent synchronously in list order.
     */
    fun replaceChannel(channel: Int, events: List<ScheduledMidi>) {
        if (closed || events.isEmpty()) return
        val ch = channel.coerceIn(0, 15)
        val generation = generations.incrementAndGet(ch)
        dispatch(events, ch, generation, checkGeneration = true)
    }

    /**
     * Schedules messages that are not part of a replaceable channel trajectory.
     * This is intended for short control/flush sequences rather than long glides.
     */
    fun dispatchUnscoped(events: List<ScheduledMidi>) {
        if (closed || events.isEmpty()) return
        dispatch(events, 0, 0L, checkGeneration = false)
    }

    private fun dispatch(events: List<ScheduledMidi>, channel: Int, generation: Long, checkGeneration: Boolean) {
        val now = System.nanoTime()
        // Native core emits deterministic ordering; preserve it for equal timestamps.
        for (event in events) {
            val due = if (event.timestampNanos > 0L) event.timestampNanos else now
            val task = Runnable {
                if (closed) return@Runnable
                if (checkGeneration && generations.get(channel) != generation) return@Runnable
                runCatching { sendNow(transform(event.bytes)) }.onFailure(onError)
            }
            val delay = due - System.nanoTime()
            if (delay <= 0L) task.run()
            else executor.schedule(task, delay, TimeUnit.NANOSECONDS)
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        invalidateAll()
        executor.shutdownNow()
    }
}
