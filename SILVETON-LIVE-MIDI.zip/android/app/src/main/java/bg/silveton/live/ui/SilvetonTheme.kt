package bg.silveton.live.ui

import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.widget.TextView

/** Visual system locked to the approved SILVETON LIVE MIDI reference. */
object SilvetonTheme {
    val bg = Color.rgb(2, 7, 13)
    val panel = Color.rgb(4, 13, 24)
    val panel2 = Color.rgb(7, 18, 31)
    val panel3 = Color.rgb(10, 24, 39)
    val border = Color.rgb(20, 92, 151)
    val borderSoft = Color.rgb(14, 48, 78)
    val text = Color.rgb(243, 248, 255)
    val muted = Color.rgb(162, 182, 204)
    val green = Color.rgb(0, 255, 153)
    val blue = Color.rgb(0, 126, 255)
    val cyan = Color.rgb(0, 232, 255)
    val purple = Color.rgb(206, 38, 255)
    val amber = Color.rgb(255, 116, 0)
    val red = Color.rgb(255, 56, 74)

    fun carbonBackground(): Drawable = object : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(canvas: Canvas) {
            val b = bounds
            canvas.drawColor(bg)
            paint.color = Color.rgb(5, 15, 25)
            paint.strokeWidth = 1f
            var x = -b.height()
            while (x < b.width()) {
                canvas.drawLine(x.toFloat(), b.bottom.toFloat(), (x + b.height()).toFloat(), b.top.toFloat(), paint)
                x += 22
            }
            paint.color = Color.argb(34, 18, 102, 168)
            x = -b.height() + 11
            while (x < b.width()) {
                canvas.drawLine(x.toFloat(), b.bottom.toFloat(), (x + b.height()).toFloat(), b.top.toFloat(), paint)
                x += 44
            }
        }
        override fun setAlpha(alpha: Int) = Unit
        override fun setColorFilter(colorFilter: ColorFilter?) = Unit
        @Deprecated("Deprecated in Java") override fun getOpacity(): Int = PixelFormat.OPAQUE
    }

    private fun gradient(top: Int, bottom: Int, radius: Float, stroke: Int, width: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = radius
            setStroke(width, stroke)
        }

    fun panelDrawable(radius: Float = 14f, strokeColor: Int = borderSoft): Drawable {
        val outer = gradient(Color.TRANSPARENT, Color.TRANSPARENT, radius + 2f, Color.argb(120, Color.red(strokeColor), Color.green(strokeColor), Color.blue(strokeColor)), 2)
        val inner = gradient(Color.rgb(7, 19, 32), Color.rgb(2, 10, 20), radius, strokeColor, 1)
        return LayerDrawable(arrayOf(outer, inner)).apply { setLayerInset(1, 2, 2, 2, 2) }
    }

    fun neonPanelDrawable(accent: Int, radius: Float = 14f): Drawable {
        val glow = gradient(Color.TRANSPARENT, Color.TRANSPARENT, radius + 3f, withAlpha(accent, 120), 3)
        val body = gradient(blend(panel3, accent, 0.06f), panel, radius, withAlpha(accent, 225), 2)
        return LayerDrawable(arrayOf(glow, body)).apply { setLayerInset(1, 2, 2, 2, 2) }
    }

    fun insetPanelDrawable(radius: Float = 14f): Drawable =
        gradient(Color.rgb(3, 9, 16), Color.rgb(8, 17, 28), radius, Color.rgb(23, 55, 84), 1)

    private fun buttonDrawable(fillTop: Int, fillBottom: Int, stroke: Int, radius: Float = 14f, strokeWidth: Int = 1): GradientDrawable =
        gradient(fillTop, fillBottom, radius, stroke, strokeWidth)

    fun selectableBackground(accent: Int, radius: Float = 14f): StateListDrawable {
        val active = buttonDrawable(blend(accent, Color.WHITE, 0.12f), blend(accent, Color.BLACK, 0.24f), Color.WHITE, radius, 2)
        val pressed = buttonDrawable(blend(panel3, accent, 0.30f), blend(panel, accent, 0.18f), accent, radius, 2)
        val normal = buttonDrawable(Color.rgb(9, 20, 33), Color.rgb(4, 12, 22), Color.rgb(28, 66, 99), radius, 1)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_checked), active)
            addState(intArrayOf(android.R.attr.state_selected), active)
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    fun dangerBackground(radius: Float = 14f): StateListDrawable {
        val normal = buttonDrawable(Color.rgb(36, 12, 18), Color.rgb(18, 7, 12), Color.rgb(130, 35, 49), radius, 1)
        val pressed = buttonDrawable(Color.rgb(103, 20, 32), Color.rgb(50, 12, 20), red, radius, 2)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    fun textColors(active: Int, inactive: Int = text): ColorStateList = ColorStateList(
        arrayOf(
            intArrayOf(android.R.attr.state_checked),
            intArrayOf(android.R.attr.state_selected),
            intArrayOf(android.R.attr.state_pressed),
            intArrayOf()
        ),
        intArrayOf(Color.WHITE, Color.WHITE, Color.WHITE, inactive)
    )

    fun styleControl(view: TextView, accent: Int, sizeSp: Float = 15f, radius: Float = 14f) {
        view.background = selectableBackground(accent, radius)
        view.setTextColor(textColors(accent))
        view.textSize = sizeSp
        view.gravity = Gravity.CENTER
        view.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        view.setPadding(8, 2, 8, 2)
        view.includeFontPadding = false
        view.minHeight = 0
        view.minWidth = 0
        if (view is android.widget.Button) view.setAllCaps(false)
    }

    fun styleDanger(view: TextView, sizeSp: Float = 15f) {
        view.background = dangerBackground()
        view.setTextColor(red)
        view.textSize = sizeSp
        view.gravity = Gravity.CENTER
        view.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        view.setPadding(8, 2, 8, 2)
        view.includeFontPadding = false
        view.minHeight = 0
        view.minWidth = 0
        if (view is android.widget.Button) view.setAllCaps(false)
    }

    fun titleTypeface(): Typeface = Typeface.create("sans-serif", Typeface.BOLD_ITALIC)
    fun condensedBold(): Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    fun monoBold(): Typeface = Typeface.create("monospace", Typeface.BOLD)

    fun textOn(color: Int): Int = Color.WHITE

    fun blend(a: Int, b: Int, t: Float): Int {
        val c = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) * (1f - c) + Color.red(b) * c).toInt(),
            (Color.green(a) * (1f - c) + Color.green(b) * c).toInt(),
            (Color.blue(a) * (1f - c) + Color.blue(b) * c).toInt()
        )
    }

    fun withAlpha(color: Int, alpha: Int): Int = Color.argb(alpha.coerceIn(0,255), Color.red(color), Color.green(color), Color.blue(color))
}
