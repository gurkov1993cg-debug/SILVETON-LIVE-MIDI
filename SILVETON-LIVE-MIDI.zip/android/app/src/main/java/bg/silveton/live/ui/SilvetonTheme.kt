package bg.silveton.live.ui

import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.widget.TextView

object SilvetonTheme {
    val bg = Color.rgb(6, 9, 13)
    val panel = Color.rgb(13, 18, 25)
    val panel2 = Color.rgb(18, 24, 33)
    val panel3 = Color.rgb(24, 31, 42)
    val border = Color.rgb(54, 68, 88)
    val borderSoft = Color.rgb(38, 48, 63)
    val text = Color.rgb(246, 248, 252)
    val muted = Color.rgb(125, 139, 160)
    val green = Color.rgb(0, 241, 119)
    val blue = Color.rgb(28, 113, 255)
    val cyan = Color.rgb(0, 218, 244)
    val purple = Color.rgb(167, 56, 255)
    val amber = Color.rgb(255, 181, 24)
    val red = Color.rgb(255, 62, 75)


    fun carbonBackground(): Drawable = object : Drawable() {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun draw(canvas: Canvas) {
            val b = bounds
            canvas.drawColor(bg)
            paint.color = Color.rgb(10, 14, 19)
            paint.strokeWidth = 1f
            val span = (b.width() + b.height()).coerceAtLeast(1)
            var x = -b.height()
            while (x < b.width()) {
                canvas.drawLine(x.toFloat(), b.bottom.toFloat(), (x + b.height()).toFloat(), b.top.toFloat(), paint)
                x += 18
            }
            paint.color = Color.argb(55, 255, 255, 255)
            paint.strokeWidth = 0.6f
            x = -b.height() + 9
            while (x < b.width()) {
                canvas.drawLine(x.toFloat(), b.bottom.toFloat(), (x + b.height()).toFloat(), b.top.toFloat(), paint)
                x += 36
            }
        }
        override fun setAlpha(alpha: Int) = Unit
        override fun setColorFilter(colorFilter: ColorFilter?) = Unit
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.OPAQUE
    }

    fun panelDrawable(radius: Float = 14f, strokeColor: Int = borderSoft): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(panel3, panel)).apply {
            cornerRadius = radius
            setStroke(1, strokeColor)
        }

    fun insetPanelDrawable(radius: Float = 14f): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(8, 11, 16), Color.rgb(15, 19, 26))).apply {
            cornerRadius = radius
            setStroke(1, border)
        }

    private fun buttonDrawable(fillTop: Int, fillBottom: Int, stroke: Int, radius: Float = 14f, strokeWidth: Int = 1): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(fillTop, fillBottom)).apply {
            cornerRadius = radius
            setStroke(strokeWidth, stroke)
        }

    fun selectableBackground(accent: Int, radius: Float = 14f): StateListDrawable {
        val activeTop = blend(accent, Color.WHITE, 0.18f)
        val activeBottom = blend(accent, Color.BLACK, 0.18f)
        val active = buttonDrawable(activeTop, activeBottom, blend(accent, Color.WHITE, 0.35f), radius, 2)
        val pressed = buttonDrawable(blend(panel3, accent, 0.24f), blend(panel, accent, 0.18f), accent, radius, 2)
        val normal = buttonDrawable(panel3, panel, border, radius, 1)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_checked), active)
            addState(intArrayOf(android.R.attr.state_selected), active)
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    fun dangerBackground(radius: Float = 14f): StateListDrawable {
        val normal = buttonDrawable(Color.rgb(37, 20, 25), Color.rgb(22, 14, 18), Color.rgb(134, 41, 49), radius, 1)
        val pressed = buttonDrawable(Color.rgb(105, 23, 31), Color.rgb(54, 16, 22), red, radius, 2)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), pressed)
            addState(intArrayOf(), normal)
        }
    }

    fun textColors(active: Int, inactive: Int = text): ColorStateList = ColorStateList(
        arrayOf(
            intArrayOf(android.R.attr.state_checked),
            intArrayOf(android.R.attr.state_selected),
            intArrayOf(android.R.attr.state_pressed),
            intArrayOf()
        ),
        intArrayOf(textOn(active), textOn(active), text, inactive)
    )

    fun styleControl(view: TextView, accent: Int, sizeSp: Float = 15f, radius: Float = 14f) {
        view.background = selectableBackground(accent, radius)
        view.setTextColor(textColors(accent))
        view.textSize = sizeSp
        view.gravity = Gravity.CENTER
        view.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        view.setPadding(8, 2, 8, 2)
        view.includeFontPadding = false
        view.minHeight = 0
        view.minWidth = 0
        if (view is android.widget.Button) view.setAllCaps(false)
    }

    fun styleDanger(view: TextView, sizeSp: Float = 15f) {
        view.background = dangerBackground()
        view.setTextColor(red)
        view.textSize = sizeSp
        view.gravity = Gravity.CENTER
        view.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        view.setPadding(8, 2, 8, 2)
        view.includeFontPadding = false
        view.minHeight = 0
        view.minWidth = 0
        if (view is android.widget.Button) view.setAllCaps(false)
    }

    fun titleTypeface(): Typeface = Typeface.create("sans-serif", Typeface.BOLD)
    fun condensedBold(): Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    fun monoBold(): Typeface = Typeface.create("monospace", Typeface.BOLD)

    fun textOn(color: Int): Int {
        val r = Color.red(color) / 255.0
        val g = Color.green(color) / 255.0
        val b = Color.blue(color) / 255.0
        val luma = 0.299 * r + 0.587 * g + 0.114 * b
        return if (luma > 0.62) Color.rgb(5, 8, 11) else Color.WHITE
    }

    fun blend(a: Int, b: Int, t: Float): Int {
        val clamped = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) * (1f - clamped) + Color.red(b) * clamped).toInt(),
            (Color.green(a) * (1f - clamped) + Color.green(b) * clamped).toInt(),
            (Color.blue(a) * (1f - clamped) + Color.blue(b) * clamped).toInt()
        )
    }
}
