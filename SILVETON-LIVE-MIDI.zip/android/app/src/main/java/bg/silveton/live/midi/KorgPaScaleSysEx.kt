package bg.silveton.live.midi

/**
 * Encoder for the Pa-series proprietary Quarter-Tone/User-Scale SysEx packet.
 *
 * The packet layout is derived from real Pa-series MIDI captures and matches
 * the 12-note signed-cent packing used by the keyboards.  The two 7-bit mask
 * bytes carry the MSB/sign bit for the twelve 8-bit signed cent values, while
 * the remaining data bytes carry the low seven bits.  This lets the message
 * represent the documented -99..+99 cent range without violating MIDI's
 * 7-bit SysEx data-byte rule.
 */
object KorgPaScaleSysEx {
    private val header = byteArrayOf(
        0xF0.toByte(), 0x42, 0x7F, 0x60, 0x01, 0x01
    )

    fun neutral(): ByteArray = encode(IntArray(12))

    fun encode(centsByPitchClass: IntArray): ByteArray {
        require(centsByPitchClass.size == 12) { "Exactly 12 pitch-class values are required" }

        val cents = IntArray(12) { centsByPitchClass[it].coerceIn(-99, 99) }
        var firstMsbMask = 0
        var secondMsbMask = 0
        val low = IntArray(12)

        for (note in 0 until 12) {
            val value = cents[note]
            val unsigned8 = if (value < 0) 256 + value else value
            low[note] = unsigned8 and 0x7F
            val msb = (unsigned8 ushr 7) and 0x01
            if (msb != 0) {
                if (note <= 4) {
                    firstMsbMask = firstMsbMask or (1 shl (4 - note))
                } else {
                    secondMsbMask = secondMsbMask or (1 shl (11 - note))
                }
            }
        }

        return byteArrayOf(
            header[0], header[1], header[2], header[3], header[4], header[5],
            firstMsbMask.toByte(),
            0x7D,
            0x00,
            low[0].toByte(), low[1].toByte(), low[2].toByte(), low[3].toByte(), low[4].toByte(),
            secondMsbMask.toByte(),
            low[5].toByte(), low[6].toByte(), low[7].toByte(), low[8].toByte(), low[9].toByte(), low[10].toByte(), low[11].toByte(),
            0xF7.toByte()
        )
    }
}
