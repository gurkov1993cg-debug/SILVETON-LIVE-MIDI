package bg.silveton.live.midi

/** Live scale-tuning modes exposed by the performance UI. */
enum class ScaleTuningMode {
    ARABIC,
    TURKISH,
    USER
}

/**
 * Nominal Turkish makam pitch-class templates in cents from the tonic.
 *
 * These values follow the theoretical templates used in the Tarsos Turkish-makam
 * recognition reference set (Arel-Ezgi-Uzdilek/Holdrian-comma tradition).  They
 * are intentionally treated as presets, not as a claim that every performance
 * uses one immutable intonation.
 */
enum class TurkishMakam(val displayName: String, val degreeCents: IntArray) {
    RAST("Rast", intArrayOf(0, 203, 384, 498, 701, 905, 1086)),
    HICAZ("Hicaz", intArrayOf(0, 113, 384, 498, 701, 792, 996)),
    HUSEYNI("Hüseyni", intArrayOf(0, 181, 294, 498, 701, 883, 996)),
    USSAK("Uşşak", intArrayOf(0, 181, 294, 498, 701, 792, 996)),
    NIHAVEND("Nihavend", intArrayOf(0, 203, 294, 498, 701, 792, 996)),
    KURDILI_HICAZAR("Kürdili Hicazkâr", intArrayOf(0, 90, 294, 498, 701, 792, 996)),
    SABA("Saba", intArrayOf(0, 181, 294, 407, 701, 792, 996)),
    SEGAH("Segâh", intArrayOf(0, 113, 316, 498, 701, 815, 1109)),
    HUZZAM("Hüzzam", intArrayOf(0, 113, 316, 430, 701, 812, 1109));

    /**
     * Converts the makam template into KORG-style per-pitch-class detuning.
     * The nearest 12-TET pitch class is used as the carrier and the remainder
     * (clamped to the Pa-series User/Quarter-Tone range) is sent as cents.
     */
    fun offsetsForRoot(rootPitchClass: Int): IntArray {
        val root = ((rootPitchClass % 12) + 12) % 12
        val result = IntArray(12)
        degreeCents.forEach { cents ->
            val wrapped = ((cents % 1200) + 1200) % 1200
            val nearestSemitone = ((wrapped + 50) / 100) % 12
            val detune = (wrapped - nearestSemitone * 100).coerceIn(-99, 99)
            val pitchClass = (root + nearestSemitone) % 12
            result[pitchClass] = detune
        }
        return result
    }
}
