package bg.silveton.live.midi

/** Stateful MIDI 1.0 stream decoder used by the Android control layer. */
class MidiStreamDecoder {
    private var runningStatus = 0
    private var currentStatus = 0
    private var expectedData = 0
    private val current = ArrayList<Byte>(3)
    private var inSysEx = false
    private val sysex = ArrayList<Byte>(256)

    fun reset() {
        runningStatus = 0
        currentStatus = 0
        expectedData = 0
        current.clear()
        inSysEx = false
        sysex.clear()
    }

    fun push(data: ByteArray): List<ByteArray> {
        val out = ArrayList<ByteArray>()
        var i = 0
        while (i < data.size) {
            val value = data[i].toInt() and 0xFF

            if (value >= 0xF8) {
                out += byteArrayOf(value.toByte())
                i++
                continue
            }

            if (inSysEx) {
                sysex += value.toByte()
                if (value == 0xF7) {
                    out += sysex.toByteArray()
                    sysex.clear()
                    inSysEx = false
                    i++
                } else if (value and 0x80 != 0) {
                    sysex.clear()
                    inSysEx = false
                    // Re-process unexpected status.
                } else i++
                continue
            }

            if (value and 0x80 != 0) {
                current.clear()
                expectedData = 0
                currentStatus = 0
                if (value == 0xF0) {
                    inSysEx = true
                    sysex.clear()
                    sysex += value.toByte()
                    runningStatus = 0
                    i++
                    continue
                }
                currentStatus = value
                current += value.toByte()
                expectedData = dataBytesForStatus(value)
                if (value < 0xF0) runningStatus = value else runningStatus = 0
                if (expectedData == 0) {
                    out += current.toByteArray()
                    current.clear()
                    currentStatus = 0
                }
                i++
                continue
            }

            if (currentStatus == 0) {
                if (runningStatus == 0) { i++; continue }
                currentStatus = runningStatus
                current.clear()
                current += runningStatus.toByte()
                expectedData = dataBytesForStatus(runningStatus)
            }
            current += (value and 0x7F).toByte()
            if (current.size == expectedData + 1) {
                out += current.toByteArray()
                current.clear()
                currentStatus = 0
                expectedData = 0
            }
            i++
        }
        return out
    }

    private fun dataBytesForStatus(status: Int): Int {
        if (status < 0xF0) return if ((status and 0xF0) == 0xC0 || (status and 0xF0) == 0xD0) 1 else 2
        return when (status) {
            0xF1, 0xF3 -> 1
            0xF2 -> 2
            else -> 0
        }
    }
}
