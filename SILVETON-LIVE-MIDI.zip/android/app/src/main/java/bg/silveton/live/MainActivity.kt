package bg.silveton.live

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.text.InputType
import android.widget.*
import bg.silveton.live.controller.LiveMidiController
import bg.silveton.live.midi.*
import bg.silveton.live.ui.LiveControlView
import bg.silveton.live.model.PadConfig
import bg.silveton.live.model.MidiRuntimeSettings

class MainActivity : Activity(), LiveMidiController.Listener, LiveControlView.Actions {
    private lateinit var controller: LiveMidiController
    private lateinit var controls: LiveControlView
    private var devices: List<AndroidMidiTransport.Device> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        controller = LiveMidiController(this)
        controls = LiveControlView(this).also { it.actions = this }
        setContentView(controls)
        controller.addListener(this)
    }

    override fun onStateChanged(state: LiveMidiController.State) {
        runOnUiThread { controls.updateState(state) }
    }

    override fun onDevicesChanged(devices: List<AndroidMidiTransport.Device>) {
        this.devices = devices
    }

    override fun onMonitorLine(line: String) {
        runOnUiThread { controls.appendMonitor(line) }
    }

    override fun onError(message: String) {
        runOnUiThread { controls.showError(message) }
    }

    override fun onModel(id: String) = controller.selectModel(id)
    override fun onDisconnect() = controller.disconnect()
    override fun onSettings() = showMidiSettings()
    override fun onPresets() = showPresetManager()
    override fun onMonitor(enabled: Boolean) = controller.setMonitorEnabled(enabled)
    override fun onPanic() = controller.panic()
    override fun onTargetUpper(index: Int, enabled: Boolean) = controller.setTargetUpper(index, enabled)
    override fun onPortamentoEnabled(enabled: Boolean) = controller.setPortamentoEnabled(enabled)
    override fun onPortamentoTime(ms: Double) = controller.setPortamentoTime(ms)
    override fun onPortamentoCustomTime(ms: Double) = controller.setCustomPortamentoTime(ms)
    override fun onHarmonyEnabled(enabled: Boolean) = controller.setHarmonyEnabled(enabled)
    override fun onTercaScan() = controller.toggleTercaScan()
    override fun onPadBank(bank: Int) = controller.selectPadBank(bank)
    override fun onPadPress(index: Int) = controller.pressPad(index)
    override fun onPadRelease(index: Int) = controller.releasePad(index)
    override fun onPadEdit(index: Int, config: PadConfig) = showPadEditor(index, config)
    override fun onRibbonConfig(output: RibbonOutput, release: RibbonRelease) = controller.configureRibbon(output, release)
    override fun onRibbon(position: Double) = controller.ribbon(position)
    override fun onRibbonRelease() = controller.ribbonRelease()

    override fun onConnect() {
        if (devices.isEmpty()) {
            controls.showError("No Android MIDI device is currently available")
            return
        }
        val labels = devices.map { d ->
            val inCount = d.inputPorts.size
            val outCount = d.outputPorts.size
            "${d.label}  (IN:$inCount OUT:$outCount)"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select KORG / MIDI device")
            .setItems(labels) { _, which -> choosePorts(devices[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun choosePorts(device: AndroidMidiTransport.Device) {
        if (device.inputPorts.isEmpty()) {
            controls.showError("Selected device exposes no MIDI input port for app → keyboard data")
            return
        }
        val txPorts = device.inputPorts
        val rxPorts = device.outputPorts.ifEmpty {
            listOf(AndroidMidiTransport.Port(-1, android.media.midi.MidiDeviceInfo.PortInfo.TYPE_OUTPUT, "No receive port"))
        }
        val pairs = buildList {
            txPorts.forEach { tx ->
                rxPorts.forEach { rx -> add(tx to rx) }
            }
        }
        if (pairs.size == 1) {
            val (tx, rx) = pairs.first()
            controller.connect(device.info, tx.number, rx.number)
            return
        }
        val labels = pairs.map { (tx, rx) ->
            "To KORG: ${tx.name} (#${tx.number})   From KORG: ${rx.name} (#${rx.number})"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select MIDI ports")
            .setItems(labels) { _, which ->
                val (tx, rx) = pairs[which]
                controller.connect(device.info, tx.number, rx.number)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


    private fun showMidiSettings() {
        val current = controller.runtimeSettings()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }

        fun channelSpinner(label: String, channel: Int): Pair<TextView, Spinner> {
            val title = TextView(this).apply { text = label }
            val spinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                    (1..16).map { "MIDI CH $it" })
                setSelection(channel.coerceIn(0, 15))
            }
            return title to spinner
        }

        root.addView(TextView(this).apply {
            text = "HARD SPLIT: B3 (MIDI 59) and below are CHORD/LEFT HAND only. PORTA + TERCA process C4 (MIDI 60) and above on the RIGHT HAND / UPPER MIDI channel."
        })
        val (_, inputChannel) = channelSpinner("Right hand / Upper input channel", current.performanceInputChannel)
        root.addView(TextView(this).apply { text = "Right hand / Upper input channel" }); root.addView(inputChannel)
        root.addView(TextView(this).apply {
            text = "KORG PA: set GLOBAL > MIDI > MIDI In Controls > Track Mute Active = ON. This keeps muted UPPER tracks muted even when PORTA is armed or TERCA sends its U3 harmony note."
            setPadding(0, 8, 0, 12)
        })
        val (_, u1) = channelSpinner("Upper 1", current.upper1Channel)
        val (_, u2) = channelSpinner("Upper 2", current.upper2Channel)
        val (_, u3) = channelSpinner("Upper 3", current.upper3Channel)
        root.addView(TextView(this).apply { text = "Upper 1 output channel" }); root.addView(u1)
        root.addView(TextView(this).apply { text = "Upper 2 output channel" }); root.addView(u2)
        root.addView(TextView(this).apply { text = "Upper 3 output channel" }); root.addView(u3)

        val bendRef = EditText(this).apply {
            hint = "PORTA PB range reference 1–12 (LOCAL ONLY)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(current.portamentoBendRangeReference.toString())
            setSingleLine(true)
        }
        root.addView(TextView(this).apply {
            text = "PORTA Pitch Bend range reference (LOCAL ONLY — never sent to KORG). Set it to the current Sound's own PB range."
        })
        root.addView(bendRef)

        val thru = CheckBox(this).apply { text = "MIDI THRU"; isChecked = current.midiThru }
        val reconnect = CheckBox(this).apply { text = "Auto reconnect"; isChecked = current.autoReconnect }
        root.addView(thru); root.addView(reconnect)



        AlertDialog.Builder(this)
            .setTitle("MIDI / Routing Settings")
            .setView(root)
            .setPositiveButton("Apply") { _, _ ->
                controller.applyRuntimeSettings(MidiRuntimeSettings(
                    performanceInputChannel = inputChannel.selectedItemPosition.coerceIn(0, 15),
                    performanceInputOmni = false,
                    upper1Channel = u1.selectedItemPosition.coerceIn(0, 15),
                    upper2Channel = u2.selectedItemPosition.coerceIn(0, 15),
                    upper3Channel = u3.selectedItemPosition.coerceIn(0, 15),
                    portamentoBendRangeReference = (bendRef.text.toString().toIntOrNull() ?: current.portamentoBendRangeReference).coerceIn(1, 12),
                    midiThru = thru.isChecked,
                    autoReconnect = reconnect.isChecked
                ))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPresetManager() {
        val names = controller.presetNames()
        val labels = (0 until 8).map { slot ->
            "${slot + 1}. ${names.getOrNull(slot) ?: "<empty>"}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Performance Presets")
            .setItems(labels) { _, slot -> showPresetSlot(slot, names.getOrNull(slot)) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showPresetSlot(slot: Int, existingName: String?) {
        val actions = if (existingName == null) arrayOf("SAVE CURRENT") else arrayOf("LOAD", "OVERWRITE", "DELETE")
        AlertDialog.Builder(this)
            .setTitle("Preset ${slot + 1}${existingName?.let { ": $it" } ?: ""}")
            .setItems(actions) { _, which ->
                if (existingName == null) {
                    promptPresetName(slot, null)
                } else when (which) {
                    0 -> if (!controller.loadPreset(slot)) controls.showError("Preset could not be loaded")
                    1 -> promptPresetName(slot, existingName)
                    2 -> AlertDialog.Builder(this)
                        .setTitle("Delete preset?")
                        .setMessage(existingName)
                        .setPositiveButton("Delete") { _, _ -> controller.clearPreset(slot) }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptPresetName(slot: Int, existingName: String?) {
        val field = EditText(this).apply {
            hint = "Preset name"
            setText(existingName ?: "Preset ${slot + 1}")
            setSingleLine(true)
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Save preset ${slot + 1}")
            .setView(field)
            .setPositiveButton("Save") { _, _ ->
                if (!controller.savePreset(slot, field.text.toString())) controls.showError("Preset could not be saved")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPadEditor(index: Int, config: PadConfig) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }

        val label = EditText(this).apply {
            hint = "Label"
            setText(config.label)
            setSingleLine(true)
        }
        root.addView(label)

        val type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("NOTE", "CONTROL CHANGE", "PROGRAM CHANGE"))
            setSelection(config.type.ordinal)
        }
        root.addView(type)

        fun numberField(title: String, value: Int, max: Int): EditText = EditText(this).apply {
            hint = title
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(value.toString())
            setSingleLine(true)
            tag = max
        }
        val channel = numberField("MIDI channel 1-16", config.channel + 1, 16)
        val number = numberField("Note / CC / Program 0-127", config.number, 127)
        val onValue = numberField("ON value 0-127", config.onValue, 127)
        val offValue = numberField("OFF value 0-127", config.offValue, 127)
        root.addView(channel); root.addView(number); root.addView(onValue); root.addView(offValue)

        val momentary = CheckBox(this).apply {
            text = "Momentary (release sends OFF)"
            isChecked = config.momentary
        }
        root.addView(momentary)

        AlertDialog.Builder(this)
            .setTitle("Pad ${index + 1}")
            .setView(root)
            .setPositiveButton("Save") { _, _ ->
                val cfg = PadConfig(
                    label = label.text.toString(),
                    type = PadType.values()[type.selectedItemPosition.coerceIn(0, PadType.values().lastIndex)],
                    channel = ((channel.text.toString().toIntOrNull() ?: 1) - 1).coerceIn(0, 15),
                    number = (number.text.toString().toIntOrNull() ?: config.number).coerceIn(0, 127),
                    onValue = (onValue.text.toString().toIntOrNull() ?: config.onValue).coerceIn(0, 127),
                    offValue = (offValue.text.toString().toIntOrNull() ?: config.offValue).coerceIn(0, 127),
                    momentary = momentary.isChecked
                )
                controller.configurePad(index, cfg)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        controller.removeListener(this)
        controller.close()
        super.onDestroy()
    }
}
