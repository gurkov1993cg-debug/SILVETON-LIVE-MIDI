package bg.silveton.live

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.text.InputType
import android.widget.*
import bg.silveton.live.controller.LiveMidiController
import bg.silveton.live.midi.*
import bg.silveton.live.ui.LiveControlView
import bg.silveton.live.model.PadConfig
import bg.silveton.live.model.MidiRuntimeSettings

class MainActivity : Activity(), LiveMidiController.Listener, LiveControlView.Actions {
    private lateinit var controller: LiveMidiController
    private lateinit var controls: LiveControlView
    private var devices: List<AndroidMidiTransport.Device> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        controller = LiveMidiController(this)
        controls = LiveControlView(this).also { it.actions = this }
        setContentView(controls)
        controller.addListener(this)
    }

    override fun onStateChanged(state: LiveMidiController.State) {
        runOnUiThread { controls.updateState(state) }
    }

    override fun onDevicesChanged(devices: List<AndroidMidiTransport.Device>) {
        this.devices = devices
    }

    override fun onMonitorLine(line: String) {
        runOnUiThread { controls.appendMonitor(line) }
    }

    override fun onError(message: String) {
        runOnUiThread { controls.showError(message) }
    }

    override fun onModel(id: String) = controller.selectModel(id)
    override fun onDisconnect() = controller.disconnect()
    override fun onSettings() = showMidiSettings()
    override fun onPresets() = showPresetManager()
    override fun onMonitor(enabled: Boolean) = controller.setMonitorEnabled(enabled)
    override fun onPanic() = controller.panic()
    override fun onTargetUpper(index: Int, enabled: Boolean) = controller.setTargetUpper(index, enabled)
    override fun onPortamentoEnabled(enabled: Boolean) = controller.setPortamentoEnabled(enabled)
    override fun onAppSidePortamento(enabled: Boolean) = controller.setAppSidePortamento(enabled)
    override fun onPortamentoMode(mode: PortaMode) = controller.setPortamentoMode(mode)
    override fun onPortamentoTime(ms: Double) = controller.setPortamentoTime(ms)
    override fun onPortamentoDepth(depth: Double) = controller.setPortamentoDepth(depth)
    override fun onHarmonyEnabled(enabled: Boolean) = controller.setHarmonyEnabled(enabled)
    override fun onTercaScan() = controller.toggleTercaScan()
    override fun onPadBank(bank: Int) = controller.selectPadBank(bank)
    override fun onPadPress(index: Int) = controller.pressPad(index)
    override fun onPadRelease(index: Int) = controller.releasePad(index)
    override fun onPadEdit(index: Int, config: PadConfig) = showPadEditor(index, config)
    override fun onRibbonConfig(output: RibbonOutput, release: RibbonRelease) = controller.configureRibbon(output, release)
    override fun onRibbon(position: Double) = controller.ribbon(position)
    override fun onRibbonRelease() = controller.ribbonRelease()

    override fun onConnect() {
        if (devices.isEmpty()) {
            controls.showError("No Android MIDI device is currently available")
            return
        }
        val labels = devices.map { d ->
            val inCount = d.inputPorts.size
            val outCount = d.outputPorts.size
            "${d.label}  (IN:$inCount OUT:$outCount)"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select KORG / MIDI device")
            .setItems(labels) { _, which -> choosePorts(devices[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun choosePorts(device: AndroidMidiTransport.Device) {
        if (device.inputPorts.isEmpty()) {
            controls.showError("Selected device exposes no MIDI input port for app → keyboard data")
            return
        }
        val txPorts = device.inputPorts
        val rxPorts = device.outputPorts.ifEmpty {
            listOf(AndroidMidiTransport.Port(-1, android.media.midi.MidiDeviceInfo.PortInfo.TYPE_OUTPUT, "No receive port"))
        }
        val pairs = buildList {
            txPorts.forEach { tx ->
                rxPorts.forEach { rx -> add(tx to rx) }
            }
        }
        if (pairs.size == 1) {
            val (tx, rx) = pairs.first()
            controller.connect(device.info, tx.number, rx.number)
            return
        }
        val labels = pairs.map { (tx, rx) ->
            "To KORG: ${tx.name} (#${tx.number})   From KORG: ${rx.name} (#${rx.number})"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select MIDI ports")
            .setItems(labels) { _, which ->
                val (tx, rx) = pairs[which]
                controller.connect(device.info, tx.number, rx.number)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


    private fun showMidiSettings() {
        val current = controller.runtimeSettings()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }

        fun channelSpinner(label: String, channel: Int): Pair<TextView, Spinner> {
            val title = TextView(this).apply { text = label }
            val spinner = Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                    (1..16).map { "MIDI CH $it" })
                setSelection(channel.coerceIn(0, 15))
            }
            return title to spinner
        }

        val omni = CheckBox(this).apply { text = "Performance input: OMNI"; isChecked = current.performanceInputOmni }
        root.addView(omni)
        val (_, inputChannel) = channelSpinner("Performance input channel", current.performanceInputChannel)
        root.addView(TextView(this).apply { text = "Performance input channel" }); root.addView(inputChannel)
        val (_, u1) = channelSpinner("Upper 1", current.upper1Channel)
        val (_, u2) = channelSpinner("Upper 2", current.upper2Channel)
        val (_, u3) = channelSpinner("Upper 3", current.upper3Channel)
        root.addView(TextView(this).apply { text = "Upper 1 output channel" }); root.addView(u1)
        root.addView(TextView(this).apply { text = "Upper 2 output channel" }); root.addView(u2)
        root.addView(TextView(this).apply { text = "Upper 3 output channel" }); root.addView(u3)

        val thru = CheckBox(this).apply { text = "MIDI THRU"; isChecked = current.midiThru }
        val reconnect = CheckBox(this).apply { text = "Auto reconnect"; isChecked = current.autoReconnect }
        root.addView(thru); root.addView(reconnect)

        val bend = EditText(this).apply {
            hint = "Pitch bend range (PA600: use 12 semitones)"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(current.pitchBendRangeSemitones.toString())
            setSingleLine(true)
        }
        root.addView(bend)

        val calibration = Button(this).apply {
            text = "PORTAMENTO CALIBRATION (${controller.state().selectedModelId.uppercase()})"
            setOnClickListener { showPortamentoCalibration() }
        }
        root.addView(calibration)

        AlertDialog.Builder(this)
            .setTitle("MIDI / Routing Settings")
            .setView(root)
            .setPositiveButton("Apply") { _, _ ->
                controller.applyRuntimeSettings(MidiRuntimeSettings(
                    performanceInputChannel = inputChannel.selectedItemPosition.coerceIn(0, 15),
                    performanceInputOmni = omni.isChecked,
                    upper1Channel = u1.selectedItemPosition.coerceIn(0, 15),
                    upper2Channel = u2.selectedItemPosition.coerceIn(0, 15),
                    upper3Channel = u3.selectedItemPosition.coerceIn(0, 15),
                    midiThru = thru.isChecked,
                    pitchBendRangeSemitones = (bend.text.toString().toIntOrNull() ?: current.pitchBendRangeSemitones).coerceIn(1, 96),
                    autoReconnect = reconnect.isChecked
                ))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPortamentoCalibration() {
        val model = controller.state().selectedModelId.uppercase()
        val current = controller.portamentoCalibration()
        val field = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 8
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            hint = "One measured point per line: CC=milliseconds\nExample:\n0=5\n32=20\n64=80\n96=320\n127=1200"
            setText(current?.let { table ->
                table.cc.indices.joinToString("\n") { i -> "${table.cc[i]}=${table.milliseconds[i]}" }
            } ?: "")
        }

        fun applyCalibration(): Boolean {
            val points = field.text.toString().lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .mapNotNull { line ->
                    val parts = line.split('=', ':', limit = 2)
                    if (parts.size != 2) null else {
                        val cc = parts[0].trim().toIntOrNull()
                        val ms = parts[1].trim().replace(',', '.').toDoubleOrNull()
                        if (cc == null || ms == null) null else cc to ms
                    }
                }
                .sortedBy { it.first }
                .toList()
            if (points.size < 2) {
                controls.showError("Calibration needs at least two valid CC=ms points")
                return false
            }
            val ok = controller.setPortamentoCalibration(
                points.map { it.first }.toIntArray(),
                points.map { it.second }.toDoubleArray()
            )
            if (!ok) controls.showError("Invalid calibration: CC must increase 0..127 and measured time must not decrease")
            return ok
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("$model Portamento Calibration")
            .setMessage("Enter measured CC5 values and the real glide time in milliseconds. This table is stored only for $model.")
            .setView(field)
            .setPositiveButton("Save", null)
            .setNeutralButton("Clear", null)
            .setNegativeButton("Cancel", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (applyCalibration()) dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                controller.clearPortamentoCalibration()
                field.setText("")
                controls.showError("$model calibration cleared")
            }
        }
        dialog.show()
    }

    private fun showPresetManager() {
        val names = controller.presetNames()
        val labels = (0 until 8).map { slot ->
            "${slot + 1}. ${names.getOrNull(slot) ?: "<empty>"}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Performance Presets")
            .setItems(labels) { _, slot -> showPresetSlot(slot, names.getOrNull(slot)) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showPresetSlot(slot: Int, existingName: String?) {
        val actions = if (existingName == null) arrayOf("SAVE CURRENT") else arrayOf("LOAD", "OVERWRITE", "DELETE")
        AlertDialog.Builder(this)
            .setTitle("Preset ${slot + 1}${existingName?.let { ": $it" } ?: ""}")
            .setItems(actions) { _, which ->
                if (existingName == null) {
                    promptPresetName(slot, null)
                } else when (which) {
                    0 -> if (!controller.loadPreset(slot)) controls.showError("Preset could not be loaded")
                    1 -> promptPresetName(slot, existingName)
                    2 -> AlertDialog.Builder(this)
                        .setTitle("Delete preset?")
                        .setMessage(existingName)
                        .setPositiveButton("Delete") { _, _ -> controller.clearPreset(slot) }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptPresetName(slot: Int, existingName: String?) {
        val field = EditText(this).apply {
            hint = "Preset name"
            setText(existingName ?: "Preset ${slot + 1}")
            setSingleLine(true)
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Save preset ${slot + 1}")
            .setView(field)
            .setPositiveButton("Save") { _, _ ->
                if (!controller.savePreset(slot, field.text.toString())) controls.showError("Preset could not be saved")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPadEditor(index: Int, config: PadConfig) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, 0)
        }

        val label = EditText(this).apply {
            hint = "Label"
            setText(config.label)
            setSingleLine(true)
        }
        root.addView(label)

        val type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("NOTE", "CONTROL CHANGE", "PROGRAM CHANGE"))
            setSelection(config.type.ordinal)
        }
        root.addView(type)

        fun numberField(title: String, value: Int, max: Int): EditText = EditText(this).apply {
            hint = title
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(value.toString())
            setSingleLine(true)
            tag = max
        }
        val channel = numberField("MIDI channel 1-16", config.channel + 1, 16)
        val number = numberField("Note / CC / Program 0-127", config.number, 127)
        val onValue = numberField("ON value 0-127", config.onValue, 127)
        val offValue = numberField("OFF value 0-127", config.offValue, 127)
        root.addView(channel); root.addView(number); root.addView(onValue); root.addView(offValue)

        val momentary = CheckBox(this).apply {
            text = "Momentary (release sends OFF)"
            isChecked = config.momentary
        }
        root.addView(momentary)

        AlertDialog.Builder(this)
            .setTitle("Pad ${index + 1}")
            .setView(root)
            .setPositiveButton("Save") { _, _ ->
                val cfg = PadConfig(
                    label = label.text.toString(),
                    type = PadType.values()[type.selectedItemPosition.coerceIn(0, PadType.values().lastIndex)],
                    channel = ((channel.text.toString().toIntOrNull() ?: 1) - 1).coerceIn(0, 15),
                    number = (number.text.toString().toIntOrNull() ?: config.number).coerceIn(0, 127),
                    onValue = (onValue.text.toString().toIntOrNull() ?: config.onValue).coerceIn(0, 127),
                    offValue = (offValue.text.toString().toIntOrNull() ?: config.offValue).coerceIn(0, 127),
                    momentary = momentary.isChecked
                )
                controller.configurePad(index, cfg)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        controller.removeListener(this)
        controller.close()
        super.onDestroy()
    }
}
