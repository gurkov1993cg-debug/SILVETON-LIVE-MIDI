package bg.silveton.live.midi

import java.io.Closeable
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.roundToInt

/** Clean-room glide using the observed MasterKey rule: step = abs(target-current)/speed.
 * SILVETON exposes TIME in ms, so speed = number of 1-ms ticks. No RPN/range/transpose/
 * octave/CC5/CC65 is ever sent. Incoming physical Pitch Bend is retained as the base.
 */
class MasterKeyPortamento(private val send:(ByteArray)->Unit):Closeable {
    private data class Ch(var lastNote:Int?=null,var held:Int=0,var physical:Int=8192,var glide:Int=8192,var target:Int=8192,var step:Int=0,var up:Boolean=true,var task:ScheduledFuture<*>?=null)
    private val s=Array(16){Ch()}; private val exec=Executors.newSingleThreadScheduledExecutor{r->Thread(r,"Silveton-Porta").apply{isDaemon=true}}
    @Volatile var enabled=false; @Volatile var durationMs=20.0
    // Local mathematical reference only; never transmitted to the keyboard.
    @Volatile var bendRangeSemitones=12

    fun physicalPitchBend(ch:Int,value:Int){ val c=s[ch.coerceIn(0,15)]; c.physical=value.coerceIn(0,16383); emit(ch,c) }
    fun noteOn(ch:Int,note:Int){ val c=s[ch.coerceIn(0,15)]; val old=c.lastNote; c.held++
        if(!enabled || old==null || c.held<2){ c.lastNote=note; c.glide=8192;c.target=8192;c.task?.cancel(false);return }
        val semis=(old-note).coerceIn(-bendRangeSemitones,bendRangeSemitones)
        c.glide=(8192.0 + semis*8192.0/bendRangeSemitones).roundToInt().coerceIn(0,16383); c.target=8192;c.lastNote=note
        start(ch,c)
    }
    fun noteOff(ch:Int,note:Int){ val c=s[ch.coerceIn(0,15)]; if(c.held>0)c.held--; if(c.held==0){c.lastNote=null;c.task?.cancel(false);c.glide=8192;emit(ch,c)} }
    fun reset(){ s.forEachIndexed{i,c->c.task?.cancel(false);c.lastNote=null;c.held=0;c.glide=8192;c.target=8192} }
    private fun start(ch:Int,c:Ch){ c.task?.cancel(false); val ticks=durationMs.roundToInt().coerceIn(1,5000); val delta=abs(c.target-c.glide); c.step=(delta/ticks).coerceAtLeast(1); c.up=c.target>=c.glide; emit(ch,c)
        c.task=exec.scheduleAtFixedRate({ if(c.glide==c.target){c.task?.cancel(false);return@scheduleAtFixedRate}; c.glide=if(c.up)(c.glide+c.step).coerceAtMost(c.target) else (c.glide-c.step).coerceAtLeast(c.target); emit(ch,c)},1,1,TimeUnit.MILLISECONDS)
    }
    private fun emit(ch:Int,c:Ch){ val combined=(c.physical + (c.glide-8192)).coerceIn(0,16383); send(byteArrayOf((0xE0 or ch.coerceIn(0,15)).toByte(),(combined and 0x7f).toByte(),((combined ushr 7) and 0x7f).toByte())) }
    override fun close(){reset();exec.shutdownNow()}
}
