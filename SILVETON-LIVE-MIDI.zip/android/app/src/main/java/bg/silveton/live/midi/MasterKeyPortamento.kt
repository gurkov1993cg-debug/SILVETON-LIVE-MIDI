package bg.silveton.live.midi

import java.io.Closeable
import java.util.ArrayDeque
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Clean-room PORTAMENTO engine following the behavior recovered from MasterKey 5.01:
 * a per-channel 14-bit Pitch Bend glide updated by a high-resolution timer, with
 * transition duration independent of the played interval.
 *
 * Important safety rule for SILVETON / KORG PA600:
 * - bendRangeSemitones is a LOCAL mathematical reference only;
 * - this class NEVER sends RPN, CC5, CC65, transpose or octave messages;
 * - physical joystick Pitch Bend is retained as a separate base component and the
 *   temporary portamento offset is added to it.
 */
class MasterKeyPortamento(private val send: (ByteArray) -> Unit) : Closeable {
    private data class ChannelState(
        val held: ArrayDeque<Int> = ArrayDeque(),
        var physicalBend: Int = CENTER,
        var glideOffset: Double = 0.0,
        var glideStartOffset: Double = 0.0,
        var glideStartNanos: Long = 0L,
        var glideDurationNanos: Long = 1_000_000L,
        var task: ScheduledFuture<*>? = null
    )

    private val lock = Any()
    private val channels = Array(16) { ChannelState() }
    private val executor = Executors.newSingleThreadScheduledExecutor { runnable ->
        Thread(runnable, "Silveton-MasterKey-Porta").apply { isDaemon = true }
    }

    @Volatile var enabled: Boolean = false
    @Volatile var durationMs: Double = 20.0
    /** Local reference only. It must match the current Sound's PB range. Never transmitted. */
    @Volatile var bendRangeSemitones: Int = 12

    fun physicalPitchBend(channel: Int, value: Int) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val state = channels[ch]
            state.physicalBend = value.coerceIn(0, MAX_BEND)
            emitLocked(ch, state)
        }
    }

    /**
     * Feed the note that is ACTUALLY sounding on this output channel.  Calling this
     * before forwarding its Note On gives PB -> Note On ordering when MIDI THRU/local-off is used.
     */
    fun noteOn(channel: Int, note: Int) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val n = note.coerceIn(0, 127)
            val state = channels[ch]
            updateGlideToNowLocked(ch, state, emit = false)

            val previous = state.held.peekLast()
            // Re-triggering an already-held note makes it the last-note-priority note.
            state.held.remove(n)
            state.held.addLast(n)

            if (previous == n) return
            if (!enabled || previous == null) {
                cancelTaskLocked(state)
                state.glideOffset = 0.0
                return
            }

            // If a new legato note arrives during an unfinished glide, preserve the
            // current sounding pitch: previous-note interval + current temporary offset.
            val range = bendRangeSemitones.coerceIn(1, 12)
            val intervalOffset = (previous - n).toDouble() * CENTER.toDouble() / range.toDouble()
            state.glideOffset = (intervalOffset + state.glideOffset).coerceIn(-CENTER.toDouble(), (CENTER - 1).toDouble())
            startGlideLocked(ch, state)
        }
    }

    /** Last-note priority: releasing the active note can return to the previous held note. */
    fun noteOff(channel: Int, note: Int) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val n = note.coerceIn(0, 127)
            val state = channels[ch]
            updateGlideToNowLocked(ch, state, emit = false)
            val wasActive = state.held.peekLast() == n
            state.held.remove(n)

            if (state.held.isEmpty()) {
                cancelTaskLocked(state)
                state.glideOffset = 0.0
                emitLocked(ch, state)
                return
            }

            if (enabled && wasActive) {
                // The keyboard's last-note-priority voice returns to the previous held
                // note. Start from the current sounding pitch and glide to that note.
                val resume = state.held.peekLast()
                val range = bendRangeSemitones.coerceIn(1, 12)
                val intervalOffset = (n - resume).toDouble() * CENTER.toDouble() / range.toDouble()
                state.glideOffset = (intervalOffset + state.glideOffset).coerceIn(-CENTER.toDouble(), (CENTER - 1).toDouble())
                startGlideLocked(ch, state)
            }
        }
    }

    fun resetChannel(channel: Int, emitCenter: Boolean = true) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val state = channels[ch]
            cancelTaskLocked(state)
            state.held.clear()
            state.glideOffset = 0.0
            if (emitCenter) emitLocked(ch, state)
        }
    }

    /** Local-only reset. By default it sends nothing, so app close/start does not alter PA state. */
    fun reset(emitCurrentPhysicalBend: Boolean = false) {
        synchronized(lock) {
            channels.forEachIndexed { ch, state ->
                cancelTaskLocked(state)
                state.held.clear()
                state.glideOffset = 0.0
                if (emitCurrentPhysicalBend) emitLocked(ch, state)
            }
        }
    }

    private fun startGlideLocked(channel: Int, state: ChannelState) {
        cancelTaskLocked(state)
        state.glideStartOffset = state.glideOffset
        state.glideStartNanos = System.nanoTime()
        state.glideDurationNanos = (durationMs.coerceIn(1.0, 5000.0) * 1_000_000.0).roundToLong().coerceAtLeast(1_000_000L)
        emitLocked(channel, state) // initial PB must precede forwarded Note On where possible
        state.task = executor.scheduleAtFixedRate({ tick(channel) }, 1L, 1L, TimeUnit.MILLISECONDS)
    }

    private fun tick(channel: Int) {
        synchronized(lock) {
            val ch = channel.coerceIn(0, 15)
            val state = channels[ch]
            if (state.task == null) return
            updateGlideToNowLocked(ch, state, emit = true)
        }
    }

    /** Time-domain equivalent of MasterKey's delta/speed rule: same finish time for every interval. */
    private fun updateGlideToNowLocked(channel: Int, state: ChannelState, emit: Boolean) {
        if (state.task == null) return
        val elapsed = (System.nanoTime() - state.glideStartNanos).coerceAtLeast(0L)
        if (elapsed >= state.glideDurationNanos) {
            state.glideOffset = 0.0
            cancelTaskLocked(state)
            if (emit) emitLocked(channel, state)
            return
        }
        val remaining = 1.0 - elapsed.toDouble() / state.glideDurationNanos.toDouble()
        state.glideOffset = state.glideStartOffset * remaining
        if (emit) emitLocked(channel, state)
    }

    private fun cancelTaskLocked(state: ChannelState) {
        state.task?.cancel(false)
        state.task = null
    }

    private fun emitLocked(channel: Int, state: ChannelState) {
        val combined = (state.physicalBend.toDouble() + state.glideOffset)
            .roundToInt().coerceIn(0, MAX_BEND)
        send(
            byteArrayOf(
                (0xE0 or channel.coerceIn(0, 15)).toByte(),
                (combined and 0x7F).toByte(),
                ((combined ushr 7) and 0x7F).toByte()
            )
        )
    }

    override fun close() {
        reset(emitCurrentPhysicalBend = false)
        executor.shutdownNow()
    }

    companion object {
        const val CENTER = 8192
        const val MAX_BEND = 16383

        /** Pure helper used by regression tests: exact equal-time linear decay. */
        fun glideOffsetAt(startOffset: Double, elapsedMs: Double, durationMs: Double): Double {
            val d = durationMs.coerceAtLeast(1.0)
            if (elapsedMs <= 0.0) return startOffset
            if (elapsedMs >= d) return 0.0
            return startOffset * (1.0 - elapsedMs / d)
        }
    }
}
