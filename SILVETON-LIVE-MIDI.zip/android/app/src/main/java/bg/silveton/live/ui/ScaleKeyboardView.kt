package bg.silveton.live.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** One-octave selector drawn to match the approved SILVETON keyboard geometry. */
class ScaleKeyboardView(context: Context) : View(context) {
    interface Listener { fun onNoteSelected(note: Int) }
    var listener: Listener? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var selected = 0
    private var tuningCents = IntArray(12)
    private val naturals = intArrayOf(0,2,4,5,7,9,11)
    private val sharps = intArrayOf(1,3,6,8,10)
    private val sharpAfter = intArrayOf(0,1,3,4,5)
    private val names = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")

    init {
        minimumHeight = 0
        isClickable = true
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setSelectedNote(note: Int) { selected = note.coerceIn(0,11); invalidate() }

    fun setTuningState(selectedNote: Int, centsByPitchClass: IntArray) {
        selected = selectedNote.coerceIn(0, 11)
        tuningCents = IntArray(12) { i -> centsByPitchClass.getOrElse(i) { 0 }.coerceIn(-99, 99) }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val left = dpF(4)
        val top = dpF(4)
        val right = width - dpF(4)
        val bottom = height - dpF(4)
        val w = (right - left) / 7f
        val radius = dpF(7)

        naturals.forEachIndexed { i, note ->
            val r = RectF(left + i*w + dpF(1), top, left + (i+1)*w - dpF(1), bottom)
            paint.style = Paint.Style.FILL
            paint.clearShadowLayer()
            paint.color = if (note == selected) Color.rgb(43, 192, 245) else Color.rgb(235, 241, 247)
            if (note == selected) paint.setShadowLayer(dpF(11), 0f, 0f, SilvetonTheme.cyan)
            canvas.drawRoundRect(r, radius, radius, paint)
            paint.clearShadowLayer()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (note == selected) dpF(2.2f) else dpF(1.2f)
            paint.color = if (note == selected) Color.WHITE else Color.rgb(128, 150, 171)
            canvas.drawRoundRect(r, radius, radius, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(25, 34, 70)
            paint.textSize = dpF(18f)
            paint.textAlign = Paint.Align.CENTER
            paint.isFakeBoldText = true
            canvas.drawText(names[note], r.centerX(), bottom - dpF(13f), paint)
            if (tuningCents[note] != 0) {
                paint.color = SilvetonTheme.cyan
                canvas.drawCircle(r.centerX(), top + dpF(14f), dpF(4f), paint)
            }
        }

        val blackBottom = top + (bottom-top) * 0.66f
        sharps.forEachIndexed { i, note ->
            val x = left + (sharpAfter[i] + 1) * w
            val r = RectF(x - w*0.245f, top, x + w*0.245f, blackBottom)
            paint.style = Paint.Style.FILL
            paint.clearShadowLayer()
            paint.color = if (note == selected) Color.rgb(8, 136, 218) else Color.rgb(5, 10, 16)
            if (note == selected) paint.setShadowLayer(dpF(10), 0f, 0f, SilvetonTheme.cyan)
            canvas.drawRoundRect(r, dpF(5), dpF(5), paint)
            paint.clearShadowLayer()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = if (note == selected) dpF(2.2f) else dpF(1.2f)
            paint.color = if (note == selected) SilvetonTheme.cyan else Color.rgb(71, 112, 148)
            canvas.drawRoundRect(r, dpF(5), dpF(5), paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(210, 215, 220)
            paint.textSize = dpF(13f)
            paint.textAlign = Paint.Align.CENTER
            paint.isFakeBoldText = true
            canvas.drawText(names[note], r.centerX(), blackBottom - dpF(12f), paint)
            if (tuningCents[note] != 0) {
                paint.color = SilvetonTheme.cyan
                canvas.drawCircle(r.centerX(), top + dpF(12f), dpF(3.5f), paint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_DOWN) return true
        val left = dpF(4)
        val usable = (width - dpF(8)).coerceAtLeast(1f)
        val w = usable / 7f
        val blackBottom = dpF(4) + (height - dpF(8)) * 0.66f
        if (event.y <= blackBottom) {
            sharps.forEachIndexed { i, note ->
                val x = left + (sharpAfter[i] + 1) * w
                if (event.x in (x-w*0.27f)..(x+w*0.27f)) { choose(note); return true }
            }
        }
        choose(naturals[((event.x-left)/w).toInt().coerceIn(0,6)])
        return true
    }

    private fun choose(note:Int) { selected=note; invalidate(); listener?.onNoteSelected(note); performClick() }
    override fun performClick(): Boolean { super.performClick(); return true }
    private fun dpF(v:Int)=v*resources.displayMetrics.density
    private fun dpF(v:Float)=v*resources.displayMetrics.density
}
