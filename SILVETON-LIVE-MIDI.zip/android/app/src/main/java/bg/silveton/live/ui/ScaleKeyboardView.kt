package bg.silveton.live.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** One-octave scale selector used by the approved HOME layout. */
class ScaleKeyboardView(context: Context) : View(context) {
    interface Listener { fun onNoteSelected(note: Int) }
    var listener: Listener? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var selected = 0
    private val naturals = intArrayOf(0,2,4,5,7,9,11)
    private val sharps = intArrayOf(1,3,6,8,10)
    private val sharpAfter = intArrayOf(0,1,3,4,5)
    private val names = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")

    init { minimumHeight = dp(150); isClickable = true }

    fun setSelectedNote(note: Int) { selected = note.coerceIn(0,11); invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width / 7f
        val h = height.toFloat()
        naturals.forEachIndexed { i, note ->
            val r=RectF(i*w+2,2,(i+1)*w-2,h-2)
            paint.style=Paint.Style.FILL
            paint.color=if (note==selected) SilvetonTheme.cyan else Color.rgb(232,238,245)
            canvas.drawRoundRect(r, dpF(5), dpF(5), paint)
            paint.style=Paint.Style.STROKE; paint.strokeWidth=if(note==selected) dpF(3) else dpF(1); paint.color=if(note==selected) Color.WHITE else Color.rgb(105,122,145)
            canvas.drawRoundRect(r, dpF(5), dpF(5), paint)
            paint.style=Paint.Style.FILL; paint.color=Color.rgb(24,30,55); paint.textSize=dpF(18); paint.textAlign=Paint.Align.CENTER; paint.isFakeBoldText=true
            canvas.drawText(names[note], r.centerX(), h-dpF(16), paint)
        }
        val bh=h*0.62f
        sharps.forEachIndexed { i,note ->
            val x=(sharpAfter[i]+1)*w
            val r=RectF(x-w*0.28f,2,x+w*0.28f,bh)
            paint.style=Paint.Style.FILL; paint.color=if(note==selected) Color.rgb(22,181,232) else Color.rgb(12,16,21)
            canvas.drawRoundRect(r,dpF(4),dpF(4),paint)
            paint.style=Paint.Style.STROKE; paint.strokeWidth=if(note==selected) dpF(3) else dpF(1); paint.color=if(note==selected) SilvetonTheme.cyan else Color.rgb(84,112,145)
            canvas.drawRoundRect(r,dpF(4),dpF(4),paint)
            paint.style=Paint.Style.FILL; paint.color=Color.LTGRAY; paint.textSize=dpF(13); paint.textAlign=Paint.Align.CENTER; paint.isFakeBoldText=true
            canvas.drawText(names[note],r.centerX(),bh-dpF(10),paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_DOWN) return true
        val w=width/7f; val h=height.toFloat(); val bh=h*0.62f
        if(event.y<=bh){
            sharps.forEachIndexed { i,note ->
                val x=(sharpAfter[i]+1)*w
                if(event.x in (x-w*0.30f)..(x+w*0.30f)){ choose(note); return true }
            }
        }
        choose(naturals[(event.x/w).toInt().coerceIn(0,6)])
        return true
    }
    private fun choose(note:Int){ selected=note; invalidate(); listener?.onNoteSelected(note); performClick() }
    override fun performClick(): Boolean { super.performClick(); return true }
    private fun dp(v:Int)= (v*resources.displayMetrics.density+0.5f).toInt()
    private fun dpF(v:Int)= v*resources.displayMetrics.density
}
