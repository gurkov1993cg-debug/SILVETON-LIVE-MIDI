package bg.silveton.live.midi

enum class RibbonOutput(val nativeValue: Int) { PITCH_BEND(0), CONTROL_CHANGE(1) }
enum class RibbonRelease(val nativeValue: Int) { HOLD(0), CENTER(1), MINIMUM(2), MAXIMUM(3) }
enum class PadType(val nativeValue: Int) { NOTE(0), CONTROL_CHANGE(1), PROGRAM_CHANGE(2) }

enum class ScaleType {
    MAJOR,
    NATURAL_MINOR,
    HARMONIC_MINOR,
    DORIAN,
    PHRYGIAN,
    LYDIAN,
    MIXOLYDIAN,
    HIJAZ
}

enum class HarmonyDegree { THIRD_DOWN, THIRD }

data class TercaScanInfo(val tonic: Int, val scale: ScaleType, val degree: HarmonyDegree)
