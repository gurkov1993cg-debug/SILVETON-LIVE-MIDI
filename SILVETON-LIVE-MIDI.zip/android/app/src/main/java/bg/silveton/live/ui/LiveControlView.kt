package bg.silveton.live.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import bg.silveton.live.controller.LiveMidiController
import bg.silveton.live.midi.*
import bg.silveton.live.model.KorgModels
import bg.silveton.live.model.PadConfig
import bg.silveton.live.midi.PadType
import kotlin.math.abs

/**
 * Main live surface.  The visual language deliberately mirrors a hardware live controller:
 * large hit targets, high-contrast state, no decorative controls, and every visible button
 * maps to a real controller action.
 */
class LiveControlView(context: Context) : LinearLayout(context) {
    interface Actions {
        fun onModel(id: String)
        fun onConnect()
        fun onDisconnect()
        fun onSettings()
        fun onPresets()
        fun onMonitor(enabled: Boolean)
        fun onPanic()
        fun onTargetUpper(index: Int, enabled: Boolean)
        fun onPortamentoEnabled(enabled: Boolean)
        fun onPortamentoTime(ms: Double)
        fun onPortamentoCustomTime(ms: Double)
        fun onHarmonyEnabled(enabled: Boolean)
        fun onTercaScan()
        fun onPadBank(bank: Int)
        fun onPadPress(index: Int)
        fun onPadRelease(index: Int)
        fun onPadEdit(index: Int, config: PadConfig)
        fun onRibbonConfig(output: RibbonOutput, release: RibbonRelease)
        fun onRibbon(position: Double)
        fun onRibbonRelease()
    }

    var actions: Actions? = null
    private var syncing = false
    private var currentPage = 1

    private val statusText = TextView(context)
    private val modelSpinner = Spinner(context)
    private val connectButton = Button(context)
    private val presetsButton = Button(context)
    private val monitorButton = ToggleButton(context)
    private val monitorText = TextView(context)
    private val pages = arrayOfNulls<View>(4)
    private val pageButtons = arrayOfNulls<Button>(5)

    private val portaOn = ToggleButton(context)
    private val nativePortaLabel = TextView(context)
    private val targetButtons = Array(3) { ToggleButton(context) }
    private val timeButtons = LinkedHashMap<Double, Button>()
    private val portamentoTimeInput = EditText(context)

    private val harmonyOn = ToggleButton(context)
    private val tercaScanButton = Button(context)
    private val tercaStatusText = TextView(context)
    private var tercaBlinking = false
    private var tercaBlinkOn = true
    private val tercaBlinkRunnable = object : Runnable {
        override fun run() {
            if (!tercaBlinking) return
            tercaBlinkOn = !tercaBlinkOn
            tercaScanButton.alpha = if (tercaBlinkOn) 1f else 0.35f
            tercaScanButton.postDelayed(this, 320L)
        }
    }

    private val ribbon = RibbonView(context)
    private val ribbonOutputSpinner = Spinner(context)

    private val bankButtons = Array(3) { Button(context) }
    private val padButtons = Array(16) { Button(context) }

    init {
        orientation = VERTICAL
        background = SilvetonTheme.carbonBackground()
        setPadding(dp(8), dp(6), dp(8), dp(6))

        addView(buildHeader(), LayoutParams(LayoutParams.MATCH_PARENT, dp(72)))
        addView(space(dp(5)))
        addView(buildNav(), LayoutParams(LayoutParams.MATCH_PARENT, dp(66)))
        addView(space(dp(6)))

        val frame = FrameLayout(context).apply {
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
        }
        pages[0] = buildPadsPage()
        pages[1] = buildPortaPage()
        pages[2] = buildIntervalsPage()
        pages[3] = buildRibbonPage()
        pages.forEachIndexed { i, v ->
            frame.addView(v, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            v?.visibility = if (i == currentPage) View.VISIBLE else View.GONE
        }
        addView(frame, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        monitorText.apply {
            setTextColor(Color.rgb(202, 213, 226))
            background = SilvetonTheme.panelDrawable(dpF(9), SilvetonTheme.borderSoft)
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(5), dp(10), dp(5))
            visibility = View.GONE
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.START
        }
        addView(monitorText, LayoutParams(LayoutParams.MATCH_PARENT, dp(68)))
        selectPage(currentPage)
    }

    private fun buildHeader(): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(7), dp(10), dp(7))
            background = SilvetonTheme.panelDrawable(dpF(16), SilvetonTheme.borderSoft)
        }

        val brand = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(TextView(context).apply {
            text = "SILVETON"
            setTextColor(SilvetonTheme.text)
            textSize = 25f
            typeface = SilvetonTheme.titleTypeface()
            letterSpacing = 0.05f
            includeFontPadding = false
        })
        titleRow.addView(TextView(context).apply {
            text = "  LIVE MIDI"
            setTextColor(SilvetonTheme.blue)
            textSize = 22f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            letterSpacing = 0.08f
            includeFontPadding = false
        })
        brand.addView(titleRow, LayoutParams(LayoutParams.WRAP_CONTENT, dp(37)))

        statusText.apply {
            text = "DISCONNECTED  ·  ANDROID LIVE MIDI INTERFACE"
            setTextColor(SilvetonTheme.muted)
            textSize = 9.5f
            typeface = SilvetonTheme.condensedBold()
            letterSpacing = 0.10f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            includeFontPadding = false
        }
        brand.addView(statusText, LayoutParams(LayoutParams.MATCH_PARENT, dp(20)))
        row.addView(brand, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        styleSpinner(modelSpinner, KorgModels.supportedTargets.map { it.displayName }, SilvetonTheme.amber)
        modelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onModel(KorgModels.supportedTargets[position].id)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        row.addView(modelSpinner, marginParams(dp(155), LayoutParams.MATCH_PARENT, 4, 0))

        SilvetonTheme.styleControl(connectButton, SilvetonTheme.green, 13f)
        connectButton.text = "CONNECT"
        connectButton.setOnClickListener {
            val connected = connectButton.tag as? Boolean ?: false
            if (connected) actions?.onDisconnect() else actions?.onConnect()
        }
        row.addView(connectButton, marginParams(dp(116), LayoutParams.MATCH_PARENT, 4, 0))

        monitorButton.textOn = "MON ON"
        monitorButton.textOff = "MON"
        SilvetonTheme.styleControl(monitorButton, SilvetonTheme.blue, 13f)
        monitorButton.setOnCheckedChangeListener { _, checked ->
            if (!syncing) {
                monitorText.visibility = if (checked) View.VISIBLE else View.GONE
                actions?.onMonitor(checked)
            }
        }
        row.addView(monitorButton, marginParams(dp(82), LayoutParams.MATCH_PARENT, 4, 0))

        SilvetonTheme.styleControl(presetsButton, SilvetonTheme.purple, 12f)
        presetsButton.text = "PRESET"
        presetsButton.setOnClickListener { actions?.onPresets() }
        row.addView(presetsButton, marginParams(dp(88), LayoutParams.MATCH_PARENT, 4, 0))

        val panic = Button(context).apply {
            text = "PANIC"
            SilvetonTheme.styleDanger(this, 14f)
            setOnClickListener { actions?.onPanic() }
        }
        row.addView(panic, marginParams(dp(92), LayoutParams.MATCH_PARENT, 4, 0))
        return row
    }

    private fun buildNav(): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val labels = listOf("●●●  PADS", "〰  PORTA", "▮▮  TERCA", "≋  RIBBON", "⚙  SETTINGS")
        val accents = intArrayOf(SilvetonTheme.amber, SilvetonTheme.purple, SilvetonTheme.cyan, SilvetonTheme.blue, SilvetonTheme.muted)
        labels.forEachIndexed { i, label ->
            val b = Button(context).apply {
                text = label
                SilvetonTheme.styleControl(this, accents[i], 15f, dpF(10))
                if (i < 4) setOnClickListener { selectPage(i) } else setOnClickListener { actions?.onSettings() }
            }
            pageButtons[i] = b
            row.addView(b, marginParams(0, LayoutParams.MATCH_PARENT, if (i == 0) 0 else 3, 0, 1f))
        }
        return row
    }

    private fun buildPortaPage(): View {
        val root = LinearLayout(context).apply {
            orientation = HORIZONTAL
            setPadding(dp(12), dp(14), dp(12), dp(12))
        }
        val main = LinearLayout(context).apply { orientation = VERTICAL }
        val top = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

        portaOn.textOn = "ON"; portaOn.textOff = "OFF"
        SilvetonTheme.styleControl(portaOn, SilvetonTheme.green, 16f)
        portaOn.setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onPortamentoEnabled(checked) }
        top.addView(portaOn, weightedControlParams(1.15f, 0))

        targetButtons.forEachIndexed { i, b ->
            b.textOn = "U${i + 1}\n${i + 1}"; b.textOff = "U${i + 1}\n${i + 1}"
            SilvetonTheme.styleControl(b, SilvetonTheme.green, 15f)
            b.setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onTargetUpper(i, checked) }
            top.addView(b, weightedControlParams(0.9f, 5))
        }

        top.addView(Space(context), LayoutParams(dp(8), 1))
        nativePortaLabel.apply {
            text = "MASTERKEY\nGLIDE"
            gravity = Gravity.CENTER
            setTextColor(SilvetonTheme.purple)
            textSize = 11f
            typeface = SilvetonTheme.condensedBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
        }
        top.addView(nativePortaLabel, weightedControlParams(1.15f, 0))
        main.addView(top, LayoutParams(LayoutParams.MATCH_PARENT, dp(82)))
        main.addView(space(dp(12)))

        val cardsRow = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val presets = listOf(
            10.0 to "≫\nVERY\nFAST\n10 ms",
            20.0 to "›\nFAST\n20 ms",
            35.0 to "≫\nMODERATE\n35 ms",
            60.0 to "≫›\nSLOW\n60 ms",
            100.0 to "≫≫\nVERY\nSLOW\n100 ms"
        )
        presets.forEachIndexed { index, (ms, label) ->
            val b = Button(context).apply {
                text = label
                SilvetonTheme.styleControl(this, SilvetonTheme.amber, if (index == 2) 13f else 14f, dpF(16))
                setOnClickListener { actions?.onPortamentoTime(ms) }
            }
            timeButtons[ms] = b
            cardsRow.addView(b, marginParams(0, LayoutParams.MATCH_PARENT, if (index == 0) 0 else 6, 0, 1f))
        }
        main.addView(cardsRow, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(main, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        val customTimePanel = LinearLayout(context).apply {
            orientation = VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = SilvetonTheme.panelDrawable(dpF(18), SilvetonTheme.border)
        }
        customTimePanel.addView(TextView(context).apply {
            text = "PORTAMENTO TIME · MS"; setTextColor(SilvetonTheme.muted); textSize = 12f
            gravity = Gravity.CENTER; typeface = SilvetonTheme.condensedBold(); letterSpacing = 0.12f
        }, LayoutParams(LayoutParams.MATCH_PARENT, dp(34)))

        portamentoTimeInput.apply {
            inputType = InputType.TYPE_CLASS_NUMBER; imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine(true); setSelectAllOnFocus(true); gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 247, 221)); setHintTextColor(SilvetonTheme.muted); hint = "1–5000"
            textSize = 31f; typeface = SilvetonTheme.monoBold(); background = SilvetonTheme.insetPanelDrawable(dpF(13))
            includeFontPadding = false; setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener {
                requestFocus(); selectAll()
                (context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                    ?.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
            }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    clearFocus()
                    (context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
                        ?.hideSoftInputFromWindow(windowToken, 0)
                    true
                } else false
            }
            setOnFocusChangeListener { _, hasFocus -> if (!hasFocus && !syncing) commitPortamentoTimeInput() }
        }
        customTimePanel.addView(portamentoTimeInput, LayoutParams(LayoutParams.MATCH_PARENT, dp(72)))
        customTimePanel.addView(TextView(context).apply {
            text = "TAP NUMBER · TYPE TIME · DONE"; setTextColor(SilvetonTheme.muted); textSize = 9.5f
            gravity = Gravity.CENTER; typeface = SilvetonTheme.condensedBold()
        }, marginParams(LayoutParams.MATCH_PARENT, dp(34), 0, 8))
        root.addView(customTimePanel, marginParams(dp(255), LayoutParams.MATCH_PARENT, 12, 0))
        return root
    }

    private fun buildPadsPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val bankRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        bankButtons.forEachIndexed { i, b ->
            b.text = "BANK ${('A'.code + i).toChar()}"
            SilvetonTheme.styleControl(b, SilvetonTheme.amber, 14f)
            b.setOnClickListener {
                actions?.onPadBank(i)
                bankButtons.forEachIndexed { j, x -> x.isSelected = i == j }
            }
            bankRow.addView(b, marginParams(0, dp(56), if (i == 0) 0 else 6, 0, 1f))
        }
        root.addView(bankRow)
        root.addView(space(dp(10)))

        val grid = GridLayout(context).apply {
            columnCount = 4
            rowCount = 4
        }
        for (i in 0 until 16) {
            val b = padButtons[i].apply {
                text = "PAD ${i + 1}"
                SilvetonTheme.styleControl(this, SilvetonTheme.purple, 15f, dpF(15))
                setOnLongClickListener {
                    val cfg = (tag as? PadConfig) ?: return@setOnLongClickListener false
                    // A non-momentary NOTE/CC pad toggles on at ACTION_DOWN. Undo that
                    // latch before opening the editor so a long-press cannot leave MIDI on.
                    if (!cfg.momentary && cfg.type != PadType.PROGRAM_CHANGE) actions?.onPadPress(i)
                    actions?.onPadEdit(i, cfg)
                    true
                }
                setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            actions?.onPadPress(i)
                            false // keep Button's own touch handling alive so long-click works
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            actions?.onPadRelease(i)
                            false
                        }
                        else -> false
                    }
                }
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            })
        }
        root.addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun buildIntervalsPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        val title = sectionLabel("TERCA · UPPER 3", SilvetonTheme.cyan).apply {
            gravity = Gravity.CENTER
            textSize = 18f
        }
        root.addView(title, LayoutParams(LayoutParams.MATCH_PARENT, dp(54)))
        root.addView(space(dp(12)))

        val buttons = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        harmonyOn.textOn = "TERCA\nON"
        harmonyOn.textOff = "TERCA\nOFF"
        SilvetonTheme.styleControl(harmonyOn, SilvetonTheme.green, 18f, dpF(18))
        harmonyOn.setOnCheckedChangeListener { _, checked ->
            if (!syncing) actions?.onHarmonyEnabled(checked)
        }
        buttons.addView(harmonyOn, LayoutParams(0, dp(112), 1f))

        tercaScanButton.text = "SCAN\n3 NOTES"
        SilvetonTheme.styleControl(tercaScanButton, SilvetonTheme.cyan, 18f, dpF(18))
        tercaScanButton.setOnClickListener { if (!syncing) actions?.onTercaScan() }
        buttons.addView(tercaScanButton, marginParams(0, dp(112), 14, 0, 1f))
        root.addView(buttons, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        tercaStatusText.apply {
            text = "Press SCAN and hold the 3 notes that define the terca FROM C4 UP. Notes below C4 are reserved for the chord section. SCAN works in all 12 tonalities and TERCA always plays on UPPER 3."
            setTextColor(SilvetonTheme.muted)
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = SilvetonTheme.condensedBold()
            setPadding(dp(12), dp(18), dp(12), dp(8))
        }
        root.addView(tercaStatusText, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun buildRibbonPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val options = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        options.addView(sectionLabel("RIBBON OUTPUT", SilvetonTheme.blue), LayoutParams(0, dp(62), 1f))
        styleSpinner(ribbonOutputSpinner, listOf("PITCH BEND", "CC16 RIBBON"), SilvetonTheme.blue)
        ribbonOutputSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onRibbonConfig(
                    if (ribbonOutputSpinner.selectedItemPosition == 0) RibbonOutput.PITCH_BEND else RibbonOutput.CONTROL_CHANGE,
                    RibbonRelease.CENTER
                )
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        options.addView(ribbonOutputSpinner, marginParams(dp(230), dp(62), 8, 0))
        val autoCenter = TextView(context).apply {
            text = "AUTO CENTER"
            gravity = Gravity.CENTER
            setTextColor(SilvetonTheme.cyan)
            textSize = 14f
            typeface = SilvetonTheme.condensedBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(14))
        }
        options.addView(autoCenter, marginParams(dp(180), dp(62), 8, 0))
        root.addView(options)
        root.addView(space(dp(12)))

        ribbon.listener = object : RibbonView.Listener {
            override fun onPosition(position: Double) { actions?.onRibbon(position) }
            override fun onRelease() { actions?.onRibbonRelease() }
        }
        root.addView(ribbon, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    fun updateState(state: LiveMidiController.State) {
        syncing = true
        val modelIndex = KorgModels.supportedTargets.indexOfFirst { it.id == state.selectedModelId }.coerceAtLeast(0)
        modelSpinner.setSelection(modelIndex)

        val baseStatus = if (state.connected) "CONNECTED · ${state.connectionLabel ?: "MIDI"}" else "DISCONNECTED"
        val withIdentity = state.identityLabel?.let { "$baseStatus · $it" } ?: baseStatus
        statusText.text = state.activePresetName?.let { "$withIdentity · $it" } ?: "$withIdentity · SUPPORTS PA600–PA5X"
        statusText.setTextColor(if (state.connected) SilvetonTheme.green else SilvetonTheme.muted)

        connectButton.text = if (state.connected) "DISCONNECT" else "CONNECT"
        connectButton.tag = state.connected
        connectButton.isSelected = state.connected
        monitorButton.isChecked = state.monitorEnabled
        monitorText.visibility = if (state.monitorEnabled) View.VISIBLE else View.GONE

        portaOn.isChecked = state.portamentoEnabled
        targetButtons.forEachIndexed { i, b -> b.isChecked = state.targetUpperMask and (1 shl i) != 0 }
        if (!portamentoTimeInput.hasFocus()) {
            val text = state.portamentoMs.toInt().coerceIn(1, 5000).toString()
            if (portamentoTimeInput.text.toString() != text) {
                portamentoTimeInput.setText(text)
                portamentoTimeInput.setSelection(text.length)
            }
        }


        harmonyOn.isChecked = state.harmonyEnabled
        tercaScanButton.isSelected = state.tercaScanActive
        tercaScanButton.text = if (state.tercaScanActive) "SCANNING…\nHOLD 3 NOTES" else "SCAN\n3 NOTES"
        if (state.tercaScanActive && !tercaBlinking) {
            tercaBlinking = true
            tercaBlinkOn = true
            tercaScanButton.removeCallbacks(tercaBlinkRunnable)
            tercaScanButton.post(tercaBlinkRunnable)
        } else if (!state.tercaScanActive && tercaBlinking) {
            tercaBlinking = false
            tercaScanButton.removeCallbacks(tercaBlinkRunnable)
            tercaScanButton.alpha = 1f
        }
        val tercaDir = if (state.tercaDegree == HarmonyDegree.THIRD_DOWN) "DOWN" else "UP"
        val noteNames = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")
        tercaStatusText.text = if (state.tercaScanActive) {
            "SCAN ARMED · hold the 3 control notes together FROM C4 UP. Notes below C4 are ignored as chord-zone keys."
        } else {
            "${if (state.harmonyEnabled) "TERCA ON" else "TERCA OFF"} · $tercaDir · ${noteNames[state.harmonyTonic.coerceIn(0, 11)]} · ${state.harmonyScale.name.replace('_', ' ')} · UPPER 3"
        }

        ribbonOutputSpinner.setSelection(if (state.ribbonOutput == RibbonOutput.PITCH_BEND) 0 else 1)

        bankButtons.forEachIndexed { i, b -> b.isSelected = i == state.padBank }
        padButtons.forEachIndexed { i, b ->
            val cfg = state.padConfigs.getOrNull(i)
            if (cfg != null) {
                b.text = cfg.label
                b.tag = cfg
            }
        }

        val nearest = timeButtons.keys.minByOrNull { abs(it - state.portamentoMs) }
        timeButtons.values.forEach { it.isSelected = false }
        if (nearest != null && abs(nearest - state.portamentoMs) < 0.01) timeButtons[nearest]?.isSelected = true
        syncing = false
    }

    fun appendMonitor(line: String) {
        if (!monitorButton.isChecked) return
        val lines = (monitorText.text.toString().lineSequence().filter { it.isNotBlank() }.toList() + line).takeLast(4)
        monitorText.text = lines.joinToString("\n")
    }

    private fun commitPortamentoTimeInput() {
        val value = portamentoTimeInput.text.toString().trim().toIntOrNull()
        if (value == null) {
            val fallback = "20"
            portamentoTimeInput.setText(fallback)
            portamentoTimeInput.setSelection(fallback.length)
            return
        }
        val clamped = value.coerceIn(1, 5000)
        val normalized = clamped.toString()
        if (portamentoTimeInput.text.toString() != normalized) {
            portamentoTimeInput.setText(normalized)
            portamentoTimeInput.setSelection(normalized.length)
        }
        actions?.onPortamentoCustomTime(clamped.toDouble())
    }

    fun showError(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDetachedFromWindow() {
        tercaBlinking = false
        tercaScanButton.removeCallbacks(tercaBlinkRunnable)
        super.onDetachedFromWindow()
    }

    private fun selectPage(index: Int) {
        currentPage = index.coerceIn(0, 3)
        pages.forEachIndexed { i, v -> v?.visibility = if (i == currentPage) View.VISIBLE else View.GONE }
        pageButtons.forEachIndexed { i, b -> b?.isSelected = i == currentPage && i < 4 }
    }

    private fun sectionLabel(text: String, accent: Int = SilvetonTheme.text) = TextView(context).apply {
        this.text = text
        setTextColor(accent)
        typeface = SilvetonTheme.condensedBold()
        gravity = Gravity.CENTER
        textSize = 13f
        letterSpacing = 0.08f
        includeFontPadding = false
    }

    private fun styleSpinner(spinner: Spinner, values: List<String>, accent: Int) {
        val adapter = object : ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, values) {
            private fun style(v: View, dropdown: Boolean): View {
                val tv = v as TextView
                tv.setTextColor(SilvetonTheme.text)
                tv.setBackgroundColor(if (dropdown) SilvetonTheme.panel2 else Color.TRANSPARENT)
                tv.typeface = SilvetonTheme.condensedBold()
                tv.textSize = if (dropdown) 15f else 14f
                tv.gravity = Gravity.CENTER_VERTICAL
                tv.setPadding(dp(12), 0, dp(10), 0)
                return tv
            }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getView(position, convertView, parent), false)
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getDropDownView(position, convertView, parent), true)
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.background = SilvetonTheme.selectableBackground(accent, dpF(13))
        spinner.setPadding(dp(4), 0, dp(4), 0)
        spinner.setPopupBackgroundDrawable(SilvetonTheme.panelDrawable(dpF(8), SilvetonTheme.border))
    }

    private fun weightedControlParams(weight: Float, leftMarginDp: Int): LayoutParams =
        marginParams(0, LayoutParams.MATCH_PARENT, leftMarginDp, 0, weight)

    private fun marginParams(width: Int, height: Int, leftDp: Int, topDp: Int, weight: Float = 0f): LayoutParams =
        LayoutParams(width, height, weight).apply {
            leftMargin = dp(leftDp)
            topMargin = dp(topDp)
        }

    private fun space(height: Int): View = Space(context).apply {
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, height)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpF(v: Int): Float = v * resources.displayMetrics.density
}
