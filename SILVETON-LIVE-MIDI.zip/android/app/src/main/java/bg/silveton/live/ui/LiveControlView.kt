package bg.silveton.live.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import bg.silveton.live.controller.LiveMidiController
import bg.silveton.live.midi.*
import bg.silveton.live.model.KorgModels
import bg.silveton.live.model.PadConfig
import kotlin.math.abs

/**
 * Main live surface.  The visual language deliberately mirrors a hardware live controller:
 * large hit targets, high-contrast state, no decorative controls, and every visible button
 * maps to a real controller action.
 */
class LiveControlView(context: Context) : LinearLayout(context) {
    interface Actions {
        fun onModel(id: String)
        fun onConnect()
        fun onDisconnect()
        fun onSettings()
        fun onPresets()
        fun onMonitor(enabled: Boolean)
        fun onPanic()
        fun onTargetUpper(index: Int, enabled: Boolean)
        fun onPortamentoEnabled(enabled: Boolean)
        fun onAppSidePortamento(enabled: Boolean)
        fun onPortamentoMode(mode: PortaMode)
        fun onPortamentoTime(ms: Double)
        fun onPortamentoDepth(depth: Double)
        fun onHarmonyEnabled(enabled: Boolean)
        fun onIntervalMode(mode: IntervalMode)
        fun onHarmonyKey(tonic: Int, scale: ScaleType)
        fun onHarmonyVoice(index: Int, enabled: Boolean, degree: HarmonyDegree, octaves: Int)
        fun onPadBank(bank: Int)
        fun onPadPress(index: Int)
        fun onPadRelease(index: Int)
        fun onPadEdit(index: Int, config: PadConfig)
        fun onRibbonConfig(output: RibbonOutput, release: RibbonRelease)
        fun onRibbon(position: Double)
        fun onRibbonRelease()
    }

    var actions: Actions? = null
    private var syncing = false
    private var currentPage = 1

    private val statusText = TextView(context)
    private val modelSpinner = Spinner(context)
    private val connectButton = Button(context)
    private val presetsButton = Button(context)
    private val monitorButton = ToggleButton(context)
    private val monitorText = TextView(context)
    private val pages = arrayOfNulls<View>(4)
    private val pageButtons = arrayOfNulls<Button>(5)

    private val portaOn = ToggleButton(context)
    private val timingEngine = ToggleButton(context)
    private val targetButtons = Array(3) { ToggleButton(context) }
    private val modeButtons = LinkedHashMap<PortaMode, Button>()
    private val timeButtons = LinkedHashMap<Double, Button>()
    private val numericKeypad = NumericKeypadView(context)
    private val depthText = TextView(context)
    private var depth = 1.0

    private val harmonyOn = ToggleButton(context)
    private val intervalModeSpinner = Spinner(context)
    private val keySpinner = Spinner(context)
    private val scaleSpinner = Spinner(context)
    private val harmonyVoiceButtons = Array(4) { ToggleButton(context) }

    private val ribbon = RibbonView(context)
    private val ribbonOutputSpinner = Spinner(context)
    private val ribbonReleaseSpinner = Spinner(context)

    private val bankButtons = Array(3) { Button(context) }
    private val padButtons = Array(16) { Button(context) }

    init {
        orientation = VERTICAL
        background = SilvetonTheme.carbonBackground()
        setPadding(dp(8), dp(6), dp(8), dp(6))

        addView(buildHeader(), LayoutParams(LayoutParams.MATCH_PARENT, dp(72)))
        addView(space(dp(5)))
        addView(buildNav(), LayoutParams(LayoutParams.MATCH_PARENT, dp(66)))
        addView(space(dp(6)))

        val frame = FrameLayout(context).apply {
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
        }
        pages[0] = buildPadsPage()
        pages[1] = buildPortaPage()
        pages[2] = buildIntervalsPage()
        pages[3] = buildRibbonPage()
        pages.forEachIndexed { i, v ->
            frame.addView(v, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            v?.visibility = if (i == currentPage) View.VISIBLE else View.GONE
        }
        addView(frame, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        monitorText.apply {
            setTextColor(Color.rgb(202, 213, 226))
            background = SilvetonTheme.panelDrawable(dpF(9), SilvetonTheme.borderSoft)
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(5), dp(10), dp(5))
            visibility = View.GONE
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.START
        }
        addView(monitorText, LayoutParams(LayoutParams.MATCH_PARENT, dp(68)))
        selectPage(currentPage)
    }

    private fun buildHeader(): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(7), dp(10), dp(7))
            background = SilvetonTheme.panelDrawable(dpF(16), SilvetonTheme.borderSoft)
        }

        val brand = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleRow.addView(TextView(context).apply {
            text = "SILVETON"
            setTextColor(SilvetonTheme.text)
            textSize = 25f
            typeface = SilvetonTheme.titleTypeface()
            letterSpacing = 0.05f
            includeFontPadding = false
        })
        titleRow.addView(TextView(context).apply {
            text = "  LIVE MIDI"
            setTextColor(SilvetonTheme.blue)
            textSize = 22f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            letterSpacing = 0.08f
            includeFontPadding = false
        })
        brand.addView(titleRow, LayoutParams(LayoutParams.WRAP_CONTENT, dp(37)))

        statusText.apply {
            text = "DISCONNECTED  ·  ANDROID LIVE MIDI INTERFACE"
            setTextColor(SilvetonTheme.muted)
            textSize = 9.5f
            typeface = SilvetonTheme.condensedBold()
            letterSpacing = 0.10f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            includeFontPadding = false
        }
        brand.addView(statusText, LayoutParams(LayoutParams.MATCH_PARENT, dp(20)))
        row.addView(brand, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        styleSpinner(modelSpinner, KorgModels.supportedTargets.map { it.displayName }, SilvetonTheme.amber)
        modelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onModel(KorgModels.supportedTargets[position].id)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        row.addView(modelSpinner, marginParams(dp(155), LayoutParams.MATCH_PARENT, 4, 0))

        SilvetonTheme.styleControl(connectButton, SilvetonTheme.green, 13f)
        connectButton.text = "CONNECT"
        connectButton.setOnClickListener {
            val connected = connectButton.tag as? Boolean ?: false
            if (connected) actions?.onDisconnect() else actions?.onConnect()
        }
        row.addView(connectButton, marginParams(dp(116), LayoutParams.MATCH_PARENT, 4, 0))

        monitorButton.textOn = "MON ON"
        monitorButton.textOff = "MON"
        SilvetonTheme.styleControl(monitorButton, SilvetonTheme.blue, 13f)
        monitorButton.setOnCheckedChangeListener { _, checked ->
            if (!syncing) {
                monitorText.visibility = if (checked) View.VISIBLE else View.GONE
                actions?.onMonitor(checked)
            }
        }
        row.addView(monitorButton, marginParams(dp(82), LayoutParams.MATCH_PARENT, 4, 0))

        SilvetonTheme.styleControl(presetsButton, SilvetonTheme.purple, 12f)
        presetsButton.text = "PRESET"
        presetsButton.setOnClickListener { actions?.onPresets() }
        row.addView(presetsButton, marginParams(dp(88), LayoutParams.MATCH_PARENT, 4, 0))

        val panic = Button(context).apply {
            text = "PANIC"
            SilvetonTheme.styleDanger(this, 14f)
            setOnClickListener { actions?.onPanic() }
        }
        row.addView(panic, marginParams(dp(92), LayoutParams.MATCH_PARENT, 4, 0))
        return row
    }

    private fun buildNav(): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val labels = listOf("●●●  PADS", "〰  PORTA", "▮▮  INTERVAL", "≋  RIBBON", "⚙  SETTINGS")
        val accents = intArrayOf(SilvetonTheme.amber, SilvetonTheme.purple, SilvetonTheme.cyan, SilvetonTheme.blue, SilvetonTheme.muted)
        labels.forEachIndexed { i, label ->
            val b = Button(context).apply {
                text = label
                SilvetonTheme.styleControl(this, accents[i], 15f, dpF(10))
                if (i < 4) setOnClickListener { selectPage(i) } else setOnClickListener { actions?.onSettings() }
            }
            pageButtons[i] = b
            row.addView(b, marginParams(0, LayoutParams.MATCH_PARENT, if (i == 0) 0 else 3, 0, 1f))
        }
        return row
    }

    private fun buildPortaPage(): View {
        val root = LinearLayout(context).apply {
            orientation = HORIZONTAL
            setPadding(dp(12), dp(14), dp(12), dp(12))
        }

        val main = LinearLayout(context).apply {
            orientation = VERTICAL
        }
        val top = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        portaOn.textOn = "ON"
        portaOn.textOff = "OFF"
        SilvetonTheme.styleControl(portaOn, SilvetonTheme.green, 16f)
        portaOn.setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onPortamentoEnabled(checked) }
        top.addView(portaOn, weightedControlParams(1.15f, 0))

        targetButtons.forEachIndexed { i, b ->
            b.textOn = "U${i + 1}\n${i + 1}"
            b.textOff = "U${i + 1}\n${i + 1}"
            SilvetonTheme.styleControl(b, SilvetonTheme.green, 15f)
            b.setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onTargetUpper(i, checked) }
            top.addView(b, weightedControlParams(0.9f, 5))
        }

        top.addView(Space(context), LayoutParams(dp(8), 1))
        timingEngine.textOn = "◷\nTIMES"
        timingEngine.textOff = "◷\nTIMES"
        SilvetonTheme.styleControl(timingEngine, SilvetonTheme.purple, 12f)
        timingEngine.setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onAppSidePortamento(checked) }
        top.addView(timingEngine, weightedControlParams(1.15f, 0))

        listOf(PortaMode.FIX, PortaMode.LIN, PortaMode.FIB, PortaMode.REAL).forEach { mode ->
            val b = Button(context).apply {
                text = when (mode) {
                    PortaMode.FIX -> "◎\nFIX"
                    PortaMode.LIN -> "╱\nLIN"
                    PortaMode.FIB -> "∿\nFIB"
                    PortaMode.REAL -> "⌁\nREAL"
                    else -> mode.name
                }
                SilvetonTheme.styleControl(this, SilvetonTheme.blue, 13f)
                setOnClickListener { actions?.onPortamentoMode(mode) }
            }
            modeButtons[mode] = b
            top.addView(b, weightedControlParams(1f, 5))
        }
        main.addView(top, LayoutParams(LayoutParams.MATCH_PARENT, dp(82)))
        main.addView(space(dp(12)))

        val cardsRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val presets = listOf(
            10.0 to "≫\nVERY\nFAST\n10 ms",
            20.0 to "›\nFAST\n20 ms",
            35.0 to "≫\nMODERATE\n35 ms",
            60.0 to "≫›\nSLOW\n60 ms",
            100.0 to "≫≫\nVERY\nSLOW\n100 ms"
        )
        presets.forEachIndexed { index, (ms, label) ->
            val b = Button(context).apply {
                text = label
                SilvetonTheme.styleControl(this, SilvetonTheme.amber, if (index == 2) 13f else 14f, dpF(16))
                setOnClickListener { actions?.onPortamentoTime(ms) }
            }
            timeButtons[ms] = b
            cardsRow.addView(b, marginParams(0, LayoutParams.MATCH_PARENT, if (index == 0) 0 else 6, 0, 1f))
        }

        val depthPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = SilvetonTheme.panelDrawable(dpF(16), SilvetonTheme.border)
        }
        depthPanel.addView(TextView(context).apply {
            text = "DEPTH · FIX"
            setTextColor(SilvetonTheme.muted)
            typeface = SilvetonTheme.condensedBold()
            textSize = 10f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
        }, LayoutParams(LayoutParams.MATCH_PARENT, dp(28)))

        val plus = Button(context).apply {
            text = "+"
            SilvetonTheme.styleControl(this, SilvetonTheme.amber, 26f, dpF(12))
            setOnClickListener { actions?.onPortamentoDepth((depth + 0.05).coerceAtMost(8.0)) }
        }
        depthPanel.addView(plus, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        depthText.apply {
            setTextColor(SilvetonTheme.amber)
            textSize = 28f
            gravity = Gravity.CENTER
            typeface = SilvetonTheme.monoBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
            includeFontPadding = false
            text = "1.00"
        }
        depthPanel.addView(depthText, marginParams(LayoutParams.MATCH_PARENT, dp(58), 0, 6))

        val minus = Button(context).apply {
            text = "−"
            SilvetonTheme.styleControl(this, SilvetonTheme.amber, 26f, dpF(12))
            setOnClickListener { actions?.onPortamentoDepth((depth - 0.05).coerceAtLeast(0.05)) }
        }
        depthPanel.addView(minus, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        cardsRow.addView(depthPanel, marginParams(dp(142), LayoutParams.MATCH_PARENT, 8, 0))

        main.addView(cardsRow, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(main, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        numericKeypad.listener = object : NumericKeypadView.Listener {
            override fun onAccepted(value: Double) { actions?.onPortamentoTime(value) }
        }
        root.addView(numericKeypad, marginParams(dp(255), LayoutParams.MATCH_PARENT, 12, 0))
        return root
    }

    private fun buildPadsPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val bankRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        bankButtons.forEachIndexed { i, b ->
            b.text = "BANK ${('A'.code + i).toChar()}"
            SilvetonTheme.styleControl(b, SilvetonTheme.amber, 14f)
            b.setOnClickListener {
                actions?.onPadBank(i)
                bankButtons.forEachIndexed { j, x -> x.isSelected = i == j }
            }
            bankRow.addView(b, marginParams(0, dp(56), if (i == 0) 0 else 6, 0, 1f))
        }
        root.addView(bankRow)
        root.addView(space(dp(10)))

        val grid = GridLayout(context).apply {
            columnCount = 4
            rowCount = 4
        }
        for (i in 0 until 16) {
            val b = padButtons[i].apply {
                text = "PAD ${i + 1}"
                SilvetonTheme.styleControl(this, SilvetonTheme.purple, 15f, dpF(15))
                setOnLongClickListener {
                    val cfg = (tag as? PadConfig) ?: return@setOnLongClickListener false
                    actions?.onPadEdit(i, cfg)
                    true
                }
                setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            isPressed = true
                            actions?.onPadPress(i)
                            true
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            isPressed = false
                            actions?.onPadRelease(i)
                            performClick()
                            true
                        }
                        else -> true
                    }
                }
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            })
        }
        root.addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun buildIntervalsPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val top = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        harmonyOn.textOn = "HARMONY\nON"
        harmonyOn.textOff = "HARMONY\nOFF"
        SilvetonTheme.styleControl(harmonyOn, SilvetonTheme.green, 13f)
        harmonyOn.setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onHarmonyEnabled(checked) }
        top.addView(harmonyOn, LayoutParams(0, dp(68), 1f))

        styleSpinner(intervalModeSpinner, listOf("SCALE", "CHROMATIC"), SilvetonTheme.cyan)
        intervalModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onIntervalMode(if (position == 0) IntervalMode.SCALE else IntervalMode.CHROMATIC)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        top.addView(intervalModeSpinner, marginParams(dp(145), dp(68), 8, 0))

        styleSpinner(keySpinner, listOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B"), SilvetonTheme.cyan)
        styleSpinner(scaleSpinner, listOf("Major","Natural Minor","Harmonic Minor","Dorian","Phrygian","Lydian","Mixolydian"), SilvetonTheme.cyan)
        val keyListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onHarmonyKey(keySpinner.selectedItemPosition, ScaleType.values()[scaleSpinner.selectedItemPosition])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        keySpinner.onItemSelectedListener = keyListener
        scaleSpinner.onItemSelectedListener = keyListener
        top.addView(keySpinner, marginParams(dp(100), dp(68), 8, 0))
        top.addView(scaleSpinner, marginParams(dp(190), dp(68), 8, 0))
        root.addView(top)

        root.addView(sectionLabel("INTERVAL VOICES", SilvetonTheme.cyan), LayoutParams(LayoutParams.MATCH_PARENT, dp(54)))
        val voices = listOf(
            Triple("TERCA\n3rd", HarmonyDegree.THIRD, 0),
            Triple("KVINTA\n5th", HarmonyDegree.FIFTH, 0),
            Triple("SEKSTA\n6th", HarmonyDegree.SIXTH, 0),
            Triple("OCTAVE\n8va", HarmonyDegree.OCTAVE, 0)
        )
        val row = LinearLayout(context).apply { orientation = HORIZONTAL }
        voices.forEachIndexed { i, spec ->
            val b = harmonyVoiceButtons[i]
            b.textOn = "${spec.first}\nON"
            b.textOff = spec.first
            SilvetonTheme.styleControl(b, SilvetonTheme.cyan, 17f, dpF(18))
            b.setOnCheckedChangeListener { _, checked ->
                if (!syncing) actions?.onHarmonyVoice(i, checked, spec.second, spec.third)
            }
            row.addView(b, marginParams(0, dp(118), if (i == 0) 0 else 8, 0, 1f))
        }
        root.addView(row)

        val note = TextView(context).apply {
            text = "SCALE follows the selected key and scale.  CHROMATIC uses fixed +4 / +7 / +9 / +12 semitone intervals."
            setTextColor(SilvetonTheme.muted)
            gravity = Gravity.CENTER
            textSize = 12f
            typeface = SilvetonTheme.condensedBold()
        }
        root.addView(note, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun buildRibbonPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val options = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        options.addView(sectionLabel("RIBBON OUTPUT", SilvetonTheme.blue), LayoutParams(0, dp(62), 1f))
        styleSpinner(ribbonOutputSpinner, listOf("PITCH BEND", "CC16 RIBBON"), SilvetonTheme.blue)
        styleSpinner(ribbonReleaseSpinner, listOf("HOLD", "CENTER", "MINIMUM", "MAXIMUM"), SilvetonTheme.blue)
        val change = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onRibbonConfig(
                    if (ribbonOutputSpinner.selectedItemPosition == 0) RibbonOutput.PITCH_BEND else RibbonOutput.CONTROL_CHANGE,
                    RibbonRelease.values()[ribbonReleaseSpinner.selectedItemPosition]
                )
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        ribbonOutputSpinner.onItemSelectedListener = change
        ribbonReleaseSpinner.onItemSelectedListener = change
        options.addView(ribbonOutputSpinner, marginParams(dp(210), dp(62), 8, 0))
        options.addView(ribbonReleaseSpinner, marginParams(dp(180), dp(62), 8, 0))
        root.addView(options)
        root.addView(space(dp(12)))

        ribbon.listener = object : RibbonView.Listener {
            override fun onPosition(position: Double) { actions?.onRibbon(position) }
            override fun onRelease() { actions?.onRibbonRelease() }
        }
        root.addView(ribbon, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    fun updateState(state: LiveMidiController.State) {
        syncing = true
        val modelIndex = KorgModels.supportedTargets.indexOfFirst { it.id == state.selectedModelId }.coerceAtLeast(0)
        modelSpinner.setSelection(modelIndex)

        val baseStatus = if (state.connected) "CONNECTED · ${state.connectionLabel ?: "MIDI"}" else "DISCONNECTED"
        val withIdentity = state.identityLabel?.let { "$baseStatus · $it" } ?: baseStatus
        statusText.text = state.activePresetName?.let { "$withIdentity · $it" } ?: "$withIdentity · SUPPORTS PA600–PA5X"
        statusText.setTextColor(if (state.connected) SilvetonTheme.green else SilvetonTheme.muted)

        connectButton.text = if (state.connected) "DISCONNECT" else "CONNECT"
        connectButton.tag = state.connected
        connectButton.isSelected = state.connected
        monitorButton.isChecked = state.monitorEnabled
        monitorText.visibility = if (state.monitorEnabled) View.VISIBLE else View.GONE

        portaOn.isChecked = state.portamentoEnabled
        timingEngine.isChecked = state.appSidePortamento
        targetButtons.forEachIndexed { i, b -> b.isChecked = state.targetUpperMask and (1 shl i) != 0 }
        depth = state.portamentoDepth
        depthText.text = "%.2f".format(depth).trimEnd('0').trimEnd('.')
        numericKeypad.setValue(state.portamentoMs)

        harmonyOn.isChecked = state.harmonyEnabled
        intervalModeSpinner.setSelection(if (state.intervalMode == IntervalMode.SCALE) 0 else 1)
        keySpinner.isEnabled = state.intervalMode == IntervalMode.SCALE
        scaleSpinner.isEnabled = state.intervalMode == IntervalMode.SCALE
        keySpinner.alpha = if (keySpinner.isEnabled) 1f else 0.45f
        scaleSpinner.alpha = if (scaleSpinner.isEnabled) 1f else 0.45f
        keySpinner.setSelection(state.harmonyTonic.coerceIn(0, 11))
        scaleSpinner.setSelection(state.harmonyScale.ordinal.coerceIn(0, ScaleType.values().lastIndex))
        harmonyVoiceButtons.forEachIndexed { i, b -> b.isChecked = state.harmonyVoiceMask and (1 shl i) != 0 }

        ribbonOutputSpinner.setSelection(if (state.ribbonOutput == RibbonOutput.PITCH_BEND) 0 else 1)
        ribbonReleaseSpinner.setSelection(state.ribbonRelease.ordinal.coerceIn(0, RibbonRelease.values().lastIndex))

        bankButtons.forEachIndexed { i, b -> b.isSelected = i == state.padBank }
        padButtons.forEachIndexed { i, b ->
            val cfg = state.padConfigs.getOrNull(i)
            if (cfg != null) {
                b.text = cfg.label
                b.tag = cfg
            }
        }

        modeButtons.values.forEach { it.isSelected = false }
        modeButtons[state.portamentoMode]?.isSelected = true
        val nearest = timeButtons.keys.minByOrNull { abs(it - state.portamentoMs) }
        timeButtons.values.forEach { it.isSelected = false }
        if (nearest != null && abs(nearest - state.portamentoMs) < 0.01) timeButtons[nearest]?.isSelected = true
        syncing = false
    }

    fun appendMonitor(line: String) {
        if (!monitorButton.isChecked) return
        val lines = (monitorText.text.toString().lineSequence().filter { it.isNotBlank() }.toList() + line).takeLast(4)
        monitorText.text = lines.joinToString("\n")
    }

    fun showError(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun selectPage(index: Int) {
        currentPage = index.coerceIn(0, 3)
        pages.forEachIndexed { i, v -> v?.visibility = if (i == currentPage) View.VISIBLE else View.GONE }
        pageButtons.forEachIndexed { i, b -> b?.isSelected = i == currentPage && i < 4 }
    }

    private fun sectionLabel(text: String, accent: Int = SilvetonTheme.text) = TextView(context).apply {
        this.text = text
        setTextColor(accent)
        typeface = SilvetonTheme.condensedBold()
        gravity = Gravity.CENTER
        textSize = 13f
        letterSpacing = 0.08f
        includeFontPadding = false
    }

    private fun styleSpinner(spinner: Spinner, values: List<String>, accent: Int) {
        val adapter = object : ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, values) {
            private fun style(v: View, dropdown: Boolean): View {
                val tv = v as TextView
                tv.setTextColor(SilvetonTheme.text)
                tv.setBackgroundColor(if (dropdown) SilvetonTheme.panel2 else Color.TRANSPARENT)
                tv.typeface = SilvetonTheme.condensedBold()
                tv.textSize = if (dropdown) 15f else 14f
                tv.gravity = Gravity.CENTER_VERTICAL
                tv.setPadding(dp(12), 0, dp(10), 0)
                return tv
            }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getView(position, convertView, parent), false)
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getDropDownView(position, convertView, parent), true)
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.background = SilvetonTheme.selectableBackground(accent, dpF(13))
        spinner.setPadding(dp(4), 0, dp(4), 0)
        spinner.popupBackgroundDrawable = SilvetonTheme.panelDrawable(dpF(8), SilvetonTheme.border)
    }

    private fun weightedControlParams(weight: Float, leftMarginDp: Int): LayoutParams =
        marginParams(0, LayoutParams.MATCH_PARENT, leftMarginDp, 0, weight)

    private fun marginParams(width: Int, height: Int, leftDp: Int, topDp: Int, weight: Float = 0f): LayoutParams =
        LayoutParams(width, height, weight).apply {
            leftMargin = dp(leftDp)
            topMargin = dp(topDp)
        }

    private fun space(height: Int): View = Space(context).apply {
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, height)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpF(v: Int): Float = v * resources.displayMetrics.density
}
