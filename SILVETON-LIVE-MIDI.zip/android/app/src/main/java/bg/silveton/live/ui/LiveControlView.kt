package bg.silveton.live.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable
import bg.silveton.live.controller.LiveMidiController
import bg.silveton.live.midi.*
import bg.silveton.live.model.KorgModels
import bg.silveton.live.model.PadConfig
import bg.silveton.live.midi.PadType
import kotlin.math.abs

/**
 * Main live surface.  The visual language deliberately mirrors a hardware live controller:
 * large hit targets, high-contrast state, no decorative controls, and every visible button
 * maps to a real controller action.
 */
class LiveControlView(context: Context) : LinearLayout(context) {
    interface Actions {
        fun onModel(id: String)
        fun onConnect()
        fun onDisconnect()
        fun onSettings()
        fun onPresets()
        fun onMonitor(enabled: Boolean)
        fun onPanic()
        fun onPortamentoEnabled(enabled: Boolean)
        fun onAppSidePortamento(enabled: Boolean)
        fun onPortamentoMode(mode: PortaMode)
        fun onPortamentoTime(ms: Double)
        fun onPortamentoCustomTime(ms: Double)
        fun onPortamentoDepth(depth: Double)
        fun onHarmonyEnabled(enabled: Boolean)
        fun onScaleEnabled(enabled: Boolean)
        fun onScaleMode(mode: ScaleTuningMode)
        fun onScaleNote(note: Int)
        fun onTurkishMakam(makam: TurkishMakam)
        fun onUserScaleCent(cents: Int)
        fun onTercaScan()
        fun onPadBank(bank: Int)
        fun onPadPress(index: Int)
        fun onPadRelease(index: Int)
        fun onPadEdit(index: Int, config: PadConfig)
        fun onRibbonConfig(output: RibbonOutput, release: RibbonRelease)
        fun onRibbon(position: Double)
        fun onRibbonRelease()
    }

    var actions: Actions? = null
    private var syncing = false
    private var currentPage = 0

    private val statusText = TextView(context)
    private val modelSpinner = Spinner(context)
    private val connectButton = Button(context)
    private val presetsButton = Button(context)
    private val monitorButton = ToggleButton(context)
    private val monitorText = TextView(context)
    private val pages = arrayOfNulls<View>(3)
    private val pageButtons = arrayOfNulls<Button>(5)
    private val settingsButton = Button(context)

    private val portaOn = ToggleButton(context)
    private val timingEngine = ToggleButton(context)
    private val modeButtons = LinkedHashMap<PortaMode, Button>()
    private val timeButtons = LinkedHashMap<Double, Button>()
    private val numericKeypad = NumericKeypadView(context)
    private val depthText = TextView(context)
    private val depthPlus = Button(context)
    private val depthMinus = Button(context)
    private var depth = 1.0

    private val harmonyOn = ToggleButton(context)
    private val tercaScanButton = Button(context)
    private val tercaStatusText = TextView(context)

    private val ribbon = RibbonView(context)
    private val ribbonOutputSpinner = Spinner(context)

    private val bankButtons = Array(3) { Button(context) }
    private val padButtons = Array(16) { Button(context) }

    private val scaleKeyboard = ScaleKeyboardView(context)
    private val scaleOn = ToggleButton(context)
    private val scaleModeSpinner = Spinner(context)
    private val turkishMakamSpinner = Spinner(context)
    private val selectedNoteText = TextView(context)
    private val scaleTuning = SeekBar(context)
    private val scaleTuningText = TextView(context)
    private val scaleMinus = Button(context)
    private val scalePlus = Button(context)
    private var turkishMakamField: View? = null
    private var tuningField: View? = null
    private var scaleTuningValue: Int = 0
    private val portaModeSpinner = Spinner(context)
    private val portaTime = SeekBar(context)
    private val portaTimeText = TextView(context)

    init {
        orientation = VERTICAL
        background = SilvetonTheme.carbonBackground()
        setPadding(dp(6), dp(4), dp(6), dp(5))

        addView(buildHeader(), LayoutParams(LayoutParams.MATCH_PARENT, dp(86)))
        addView(space(dp(4)))

        // The approved live surface is a single working screen.  Do not waste
        // space on navigation buttons for hidden/unfinished pages.
        addView(buildHomePage(), LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        monitorText.apply {
            setTextColor(Color.rgb(202, 213, 226))
            background = SilvetonTheme.panelDrawable(dpF(9), SilvetonTheme.borderSoft)
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(5), dp(10), dp(5))
            visibility = View.GONE
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.START
        }
        addView(monitorText, LayoutParams(LayoutParams.MATCH_PARENT, dp(68)))
    }

    private fun buildHeader(): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(5), dp(10), dp(5))
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.blue, dpF(15))
        }

        val brand = LinearLayout(context).apply { orientation = VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        brand.addView(TextView(context).apply {
            text = "SILVETON"
            setTextColor(SilvetonTheme.text)
            textSize = 27f
            typeface = SilvetonTheme.titleTypeface()
            letterSpacing = 0.08f
            includeFontPadding = false
        }, LayoutParams(LayoutParams.WRAP_CONTENT, dp(34)))
        brand.addView(TextView(context).apply {
            text = "L I V E   M I D I"
            setTextColor(SilvetonTheme.cyan)
            textSize = 11f
            typeface = SilvetonTheme.condensedBold()
            letterSpacing = 0.16f
            includeFontPadding = false
        }, LayoutParams(LayoutParams.WRAP_CONTENT, dp(20)))
        row.addView(brand, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        val connectionBox = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(3), dp(6), dp(3))
            background = SilvetonTheme.insetPanelDrawable(dpF(12))
        }

        styleSpinner(modelSpinner, KorgModels.supportedTargets.map { it.displayName }, SilvetonTheme.cyan)
        modelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onModel(KorgModels.supportedTargets[position].id)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        connectionBox.addView(modelSpinner, LayoutParams(dp(190), dp(42)))

        statusText.apply {
            text = "● DISCONNECTED"
            setTextColor(SilvetonTheme.red)
            textSize = 11f
            typeface = SilvetonTheme.condensedBold()
            gravity = Gravity.CENTER
            includeFontPadding = false
            background = SilvetonTheme.selectableBackground(SilvetonTheme.red, dpF(11))
            setOnClickListener {
                val connected = connectButton.tag as? Boolean ?: false
                if (connected) actions?.onDisconnect() else actions?.onConnect()
            }
        }
        connectionBox.addView(statusText, marginParams(dp(170), dp(42), 6, 0))

        settingsButton.apply {
            text = "⚙"
            contentDescription = "MIDI settings"
            SilvetonTheme.styleControl(this, SilvetonTheme.cyan, 18f, dpF(11))
            setOnClickListener { actions?.onSettings() }
        }
        connectionBox.addView(settingsButton, marginParams(dp(52), dp(42), 6, 0))
        row.addView(connectionBox, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT))

        // Legacy controls are kept only as internal state holders for compatibility;
        // they are never rendered as dead GUI controls.
        connectButton.visibility = View.GONE
        monitorButton.visibility = View.GONE
        presetsButton.visibility = View.GONE
        return row
    }

    private fun buildHomePage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        val keyboardPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.blue, dpF(12))
            setPadding(dp(10), dp(5), dp(10), dp(7))
        }
        keyboardPanel.addView(sectionLabel("SCALE KEYBOARD  ·  1 OCTAVE", SilvetonTheme.text).apply {
            gravity = Gravity.CENTER_VERTICAL
        }, LayoutParams(LayoutParams.MATCH_PARENT, dp(28)))
        scaleKeyboard.listener = object : ScaleKeyboardView.Listener {
            override fun onNoteSelected(note: Int) {
                actions?.onScaleNote(note)
            }
        }
        keyboardPanel.addView(scaleKeyboard, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(keyboardPanel, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1.55f))
        root.addView(space(dp(6)))

        // SCALE is independent from TERCA harmony. Every visible control sends a real
        // Pa-series Quarter-Tone/User-Scale SysEx update through the controller.
        val scalePanel = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.blue, dpF(12))
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }

        fun field(label: String, view: View, weight: Float): View = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(5), 0, dp(5), 0)
            addView(sectionLabel(label, SilvetonTheme.muted).apply {
                textSize = 9f
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
            }, LayoutParams(LayoutParams.MATCH_PARENT, dp(20)))
            addView(view, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
            layoutParams = LayoutParams(0, LayoutParams.MATCH_PARENT, weight)
        }

        val scaleTitle = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(sectionLabel("SCALE", SilvetonTheme.cyan).apply {
                gravity = Gravity.CENTER_VERTICAL
            }, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
            scaleOn.apply {
                textOn = "ON"
                textOff = "OFF"
                SilvetonTheme.styleControl(this, SilvetonTheme.cyan, 11f, dpF(18))
                setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onScaleEnabled(checked) }
            }
            addView(scaleOn, LayoutParams(dp(82), dp(40)))
        }
        scalePanel.addView(scaleTitle, LayoutParams(dp(190), LayoutParams.MATCH_PARENT))

        styleSpinner(scaleModeSpinner, listOf("ARABIC", "TURKISH", "USER"), SilvetonTheme.cyan)
        scaleModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onScaleMode(arrayOf(ScaleTuningMode.ARABIC, ScaleTuningMode.TURKISH, ScaleTuningMode.USER)[position.coerceIn(0, 2)])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        scalePanel.addView(field("MODE", scaleModeSpinner, .85f))

        styleSpinner(turkishMakamSpinner, TurkishMakam.values().map { it.displayName }, SilvetonTheme.cyan)
        turkishMakamSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onTurkishMakam(TurkishMakam.values()[position.coerceIn(0, TurkishMakam.values().lastIndex)])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        turkishMakamField = field("MAKAM", turkishMakamSpinner, 1.2f).also { scalePanel.addView(it) }

        selectedNoteText.apply {
            text = "C"
            gravity = Gravity.CENTER
            textSize = 23f
            typeface = SilvetonTheme.monoBold()
            setTextColor(SilvetonTheme.text)
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
        }
        scalePanel.addView(field("NOTE / ROOT", selectedNoteText, .62f))

        val tuningBox = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            scaleMinus.apply {
                text = "−"
                SilvetonTheme.styleControl(this, SilvetonTheme.cyan, 18f, dpF(10))
                setOnClickListener { if (!syncing) actions?.onUserScaleCent((scaleTuningValue - 1).coerceIn(-99, 99)) }
            }
            addView(scaleMinus, LayoutParams(dp(42), LayoutParams.MATCH_PARENT))
            scaleTuning.max = 198
            scaleTuning.progress = 99
            scaleTuning.progressTintList = android.content.res.ColorStateList.valueOf(SilvetonTheme.cyan)
            scaleTuning.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            scaleTuning.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val cents = progress - 99
                    scaleTuningValue = cents
                    scaleTuningText.text = if (cents > 0) "+$cents" else cents.toString()
                    if (fromUser && !syncing) actions?.onUserScaleCent(cents)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
            addView(scaleTuning, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
            scalePlus.apply {
                text = "+"
                SilvetonTheme.styleControl(this, SilvetonTheme.cyan, 18f, dpF(10))
                setOnClickListener { if (!syncing) actions?.onUserScaleCent((scaleTuningValue + 1).coerceIn(-99, 99)) }
            }
            addView(scalePlus, LayoutParams(dp(42), LayoutParams.MATCH_PARENT))
            scaleTuningText.apply {
                gravity = Gravity.CENTER
                setTextColor(SilvetonTheme.text)
                textSize = 15f
                typeface = SilvetonTheme.monoBold()
                background = SilvetonTheme.insetPanelDrawable(dpF(8))
            }
            addView(scaleTuningText, marginParams(dp(64), LayoutParams.MATCH_PARENT, 5, 0))
        }
        tuningField = field("TUNING (CENT)", tuningBox, 1.75f).also { scalePanel.addView(it) }

        root.addView(scalePanel, LayoutParams(LayoutParams.MATCH_PARENT, 0, .70f))
        root.addView(space(dp(6)))

        val middle = LinearLayout(context).apply { orientation = HORIZONTAL }

        val portaPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.purple, dpF(12))
            setPadding(dp(10), dp(6), dp(10), dp(7))
        }
        val portaHead = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        portaHead.addView(sectionLabel("GLOBAL PORTAMENTO  ·  ALL UPPERS", SilvetonTheme.text).apply {
            gravity = Gravity.CENTER_VERTICAL
        }, LayoutParams(0, dp(38), 1f))
        portaOn.apply {
            textOn = "ON"
            textOff = "OFF"
            SilvetonTheme.styleControl(this, SilvetonTheme.purple, 12f, dpF(18))
            setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onPortamentoEnabled(checked) }
        }
        portaHead.addView(portaOn, LayoutParams(dp(96), dp(38)))
        portaPanel.addView(portaHead)

        val portaControls = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        styleSpinner(portaModeSpinner, listOf("Fixed", "Linear", "Fibonacci", "Real"), SilvetonTheme.purple)
        portaModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onPortamentoMode(arrayOf(PortaMode.FIX, PortaMode.LIN, PortaMode.FIB, PortaMode.REAL)[position.coerceIn(0, 3)])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        portaControls.addView(field("MODE", portaModeSpinner, .8f))

        portaTime.max = 4999
        portaTime.progressTintList = android.content.res.ColorStateList.valueOf(SilvetonTheme.purple)
        portaTime.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        portaTime.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val ms = progress + 1
                portaTimeText.text = "$ms ms"
                if (fromUser && !syncing) actions?.onPortamentoTime(ms.toDouble())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        portaControls.addView(field("TIME", portaTime, 1.35f))
        portaTimeText.apply {
            gravity = Gravity.CENTER
            setTextColor(SilvetonTheme.text)
            textSize = 15f
            typeface = SilvetonTheme.monoBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
        }
        portaControls.addView(field("VALUE", portaTimeText, .55f))
        portaPanel.addView(portaControls, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        middle.addView(portaPanel, LayoutParams(0, LayoutParams.MATCH_PARENT, 1.35f))

        val tercaPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.amber, dpF(12))
            setPadding(dp(10), dp(6), dp(10), dp(7))
        }
        val tercaHead = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tercaHead.addView(sectionLabel("TERCA", SilvetonTheme.text).apply { gravity = Gravity.CENTER_VERTICAL }, LayoutParams(0, dp(38), 1f))
        harmonyOn.apply {
            textOn = "ON"
            textOff = "OFF"
            SilvetonTheme.styleControl(this, SilvetonTheme.amber, 12f, dpF(18))
            setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onHarmonyEnabled(checked) }
        }
        tercaHead.addView(harmonyOn, LayoutParams(dp(92), dp(38)))
        tercaPanel.addView(tercaHead)

        tercaScanButton.apply {
            text = "SCAN TERCA"
            SilvetonTheme.styleControl(this, SilvetonTheme.amber, 12f, dpF(12))
            setOnClickListener { actions?.onTercaScan() }
        }
        tercaPanel.addView(tercaScanButton, LayoutParams(LayoutParams.MATCH_PARENT, dp(48)))
        tercaStatusText.apply {
            gravity = Gravity.CENTER
            setTextColor(SilvetonTheme.muted)
            textSize = 10f
            typeface = SilvetonTheme.condensedBold()
            maxLines = 2
        }
        tercaPanel.addView(tercaStatusText, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        middle.addView(tercaPanel, marginParams(0, LayoutParams.MATCH_PARENT, 6, 0, .85f))
        root.addView(middle, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1.00f))
        root.addView(space(dp(6)))

        val ribbonPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.cyan, dpF(12))
            setPadding(dp(10), dp(5), dp(10), dp(7))
        }
        val ribbonHead = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        ribbonHead.addView(sectionLabel("RIBBON  ·  GLOBAL", SilvetonTheme.text).apply { gravity = Gravity.CENTER_VERTICAL }, LayoutParams(0, dp(34), 1f))
        styleSpinner(ribbonOutputSpinner, listOf("PITCH BEND", "CC16"), SilvetonTheme.cyan)
        ribbonOutputSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onRibbonConfig(
                    if (position == 0) RibbonOutput.PITCH_BEND else RibbonOutput.CONTROL_CHANGE,
                    RibbonRelease.CENTER
                )
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        ribbonHead.addView(ribbonOutputSpinner, LayoutParams(dp(180), dp(34)))
        ribbonPanel.addView(ribbonHead)
        ribbon.listener = object : RibbonView.Listener {
            override fun onPosition(position: Double) { actions?.onRibbon(position) }
            override fun onRelease() { actions?.onRibbonRelease() }
        }
        ribbonPanel.addView(ribbon, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(ribbonPanel, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1.0f))

        return root
    }

    private fun buildEffectsPage(): View {
        return LinearLayout(context).apply {
            orientation = VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(24)); background = SilvetonTheme.insetPanelDrawable(dpF(12))
            addView(sectionLabel("EFFECTS", SilvetonTheme.cyan).apply { textSize=22f }, LayoutParams(LayoutParams.MATCH_PARENT, dp(60)))
            addView(TextView(context).apply { text="PORTAMENTO, TERCA and RIBBON are live on HOME for one-screen performance control."; setTextColor(SilvetonTheme.muted); gravity=Gravity.CENTER; textSize=15f }, LayoutParams(LayoutParams.MATCH_PARENT, dp(80)))
            val home=Button(context).apply { text="RETURN TO HOME"; SilvetonTheme.styleControl(this, SilvetonTheme.blue, 15f); setOnClickListener { selectPage(0) } }
            addView(home, LayoutParams(dp(260), dp(64)))
        }
    }

    private fun buildPortaPage(): View {
        val root = LinearLayout(context).apply {
            orientation = HORIZONTAL
            setPadding(dp(12), dp(14), dp(12), dp(12))
        }

        val main = LinearLayout(context).apply {
            orientation = VERTICAL
        }
        val top = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        portaOn.textOn = "ON"
        portaOn.textOff = "OFF"
        SilvetonTheme.styleControl(portaOn, SilvetonTheme.green, 16f)
        portaOn.setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onPortamentoEnabled(checked) }
        top.addView(portaOn, weightedControlParams(1.15f, 0))

        top.addView(Space(context), LayoutParams(dp(8), 1))
        timingEngine.textOn = "◷\nTIMES"
        timingEngine.textOff = "◷\nTIMES"
        SilvetonTheme.styleControl(timingEngine, SilvetonTheme.purple, 12f)
        timingEngine.setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onAppSidePortamento(checked) }
        top.addView(timingEngine, weightedControlParams(1.15f, 0))

        listOf(PortaMode.FIX, PortaMode.LIN, PortaMode.FIB, PortaMode.REAL).forEach { mode ->
            val b = Button(context).apply {
                text = when (mode) {
                    PortaMode.FIX -> "◎\nFIX"
                    PortaMode.LIN -> "╱\nLIN"
                    PortaMode.FIB -> "∿\nFIB"
                    PortaMode.REAL -> "⌁\nREAL"
                    else -> mode.name
                }
                SilvetonTheme.styleControl(this, SilvetonTheme.blue, 13f)
                setOnClickListener { actions?.onPortamentoMode(mode) }
            }
            modeButtons[mode] = b
            top.addView(b, weightedControlParams(1f, 5))
        }
        main.addView(top, LayoutParams(LayoutParams.MATCH_PARENT, dp(82)))
        main.addView(space(dp(12)))

        val cardsRow = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val presets = listOf(
            10.0 to "≫\nVERY\nFAST\n10 ms",
            20.0 to "›\nFAST\n20 ms",
            35.0 to "≫\nMODERATE\n35 ms",
            60.0 to "≫›\nSLOW\n60 ms",
            100.0 to "≫≫\nVERY\nSLOW\n100 ms"
        )
        presets.forEachIndexed { index, (ms, label) ->
            val b = Button(context).apply {
                text = label
                SilvetonTheme.styleControl(this, SilvetonTheme.amber, if (index == 2) 13f else 14f, dpF(16))
                setOnClickListener { actions?.onPortamentoTime(ms) }
            }
            timeButtons[ms] = b
            cardsRow.addView(b, marginParams(0, LayoutParams.MATCH_PARENT, if (index == 0) 0 else 6, 0, 1f))
        }

        val depthPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = SilvetonTheme.panelDrawable(dpF(16), SilvetonTheme.border)
        }
        depthPanel.addView(TextView(context).apply {
            text = "DEPTH · FIX"
            setTextColor(SilvetonTheme.muted)
            typeface = SilvetonTheme.condensedBold()
            textSize = 10f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
        }, LayoutParams(LayoutParams.MATCH_PARENT, dp(28)))

        depthPlus.apply {
            text = "+"
            SilvetonTheme.styleControl(this, SilvetonTheme.amber, 26f, dpF(12))
            setOnClickListener { actions?.onPortamentoDepth((depth + 0.05).coerceAtMost(8.0)) }
        }
        depthPanel.addView(depthPlus, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        depthText.apply {
            setTextColor(SilvetonTheme.amber)
            textSize = 28f
            gravity = Gravity.CENTER
            typeface = SilvetonTheme.monoBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
            includeFontPadding = false
            text = "1.00"
        }
        depthPanel.addView(depthText, marginParams(LayoutParams.MATCH_PARENT, dp(58), 0, 6))

        depthMinus.apply {
            text = "−"
            SilvetonTheme.styleControl(this, SilvetonTheme.amber, 26f, dpF(12))
            setOnClickListener { actions?.onPortamentoDepth((depth - 0.05).coerceAtLeast(0.05)) }
        }
        depthPanel.addView(depthMinus, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        cardsRow.addView(depthPanel, marginParams(dp(142), LayoutParams.MATCH_PARENT, 8, 0))

        main.addView(cardsRow, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(main, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        numericKeypad.listener = object : NumericKeypadView.Listener {
            override fun onAccepted(value: Double) { actions?.onPortamentoCustomTime(value) }
        }
        root.addView(numericKeypad, marginParams(dp(255), LayoutParams.MATCH_PARENT, 12, 0))
        return root
    }

    private fun buildPadsPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val bankRow = LinearLayout(context).apply { orientation = HORIZONTAL }
        bankButtons.forEachIndexed { i, b ->
            b.text = "BANK ${('A'.code + i).toChar()}"
            SilvetonTheme.styleControl(b, SilvetonTheme.amber, 14f)
            b.setOnClickListener {
                actions?.onPadBank(i)
                bankButtons.forEachIndexed { j, x -> x.isSelected = i == j }
            }
            bankRow.addView(b, marginParams(0, dp(56), if (i == 0) 0 else 6, 0, 1f))
        }
        root.addView(bankRow)
        root.addView(space(dp(10)))

        val grid = GridLayout(context).apply {
            columnCount = 4
            rowCount = 4
        }
        for (i in 0 until 16) {
            val b = padButtons[i].apply {
                text = "PAD ${i + 1}"
                SilvetonTheme.styleControl(this, SilvetonTheme.purple, 15f, dpF(15))
                setOnLongClickListener {
                    val cfg = (tag as? PadConfig) ?: return@setOnLongClickListener false
                    // A non-momentary NOTE/CC pad toggles on at ACTION_DOWN. Undo that
                    // latch before opening the editor so a long-press cannot leave MIDI on.
                    if (!cfg.momentary && cfg.type != PadType.PROGRAM_CHANGE) actions?.onPadPress(i)
                    actions?.onPadEdit(i, cfg)
                    true
                }
                setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            actions?.onPadPress(i)
                            false // keep Button's own touch handling alive so long-click works
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            actions?.onPadRelease(i)
                            false
                        }
                        else -> false
                    }
                }
            }
            grid.addView(b, GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            })
        }
        root.addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun buildIntervalsPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        val title = sectionLabel("TERCA · UPPER 3", SilvetonTheme.cyan).apply {
            gravity = Gravity.CENTER
            textSize = 18f
        }
        root.addView(title, LayoutParams(LayoutParams.MATCH_PARENT, dp(54)))
        root.addView(space(dp(12)))

        val buttons = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
        }

        harmonyOn.textOn = "TERCA\nON"
        harmonyOn.textOff = "TERCA\nOFF"
        SilvetonTheme.styleControl(harmonyOn, SilvetonTheme.green, 18f, dpF(18))
        harmonyOn.setOnCheckedChangeListener { _, checked ->
            if (!syncing) actions?.onHarmonyEnabled(checked)
        }
        buttons.addView(harmonyOn, LayoutParams(0, dp(112), 1f))

        tercaScanButton.text = "SCAN\n3 NOTES"
        SilvetonTheme.styleControl(tercaScanButton, SilvetonTheme.cyan, 18f, dpF(18))
        tercaScanButton.setOnClickListener { if (!syncing) actions?.onTercaScan() }
        buttons.addView(tercaScanButton, marginParams(0, dp(112), 14, 0, 1f))
        root.addView(buttons, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        tercaStatusText.apply {
            text = "Press SCAN and hold the 3 notes that define the terca ABOVE C4. C4 and below are reserved for the chord section. SCAN works in all 12 tonalities and TERCA always plays on UPPER 3."
            setTextColor(SilvetonTheme.muted)
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = SilvetonTheme.condensedBold()
            setPadding(dp(12), dp(18), dp(12), dp(8))
        }
        root.addView(tercaStatusText, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun buildRibbonPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        val options = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        options.addView(sectionLabel("RIBBON OUTPUT", SilvetonTheme.blue), LayoutParams(0, dp(62), 1f))
        styleSpinner(ribbonOutputSpinner, listOf("PITCH BEND", "CC16 RIBBON"), SilvetonTheme.blue)
        ribbonOutputSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onRibbonConfig(
                    if (ribbonOutputSpinner.selectedItemPosition == 0) RibbonOutput.PITCH_BEND else RibbonOutput.CONTROL_CHANGE,
                    RibbonRelease.CENTER
                )
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        options.addView(ribbonOutputSpinner, marginParams(dp(230), dp(62), 8, 0))
        val autoCenter = TextView(context).apply {
            text = "AUTO CENTER"
            gravity = Gravity.CENTER
            setTextColor(SilvetonTheme.cyan)
            textSize = 14f
            typeface = SilvetonTheme.condensedBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(14))
        }
        options.addView(autoCenter, marginParams(dp(180), dp(62), 8, 0))
        root.addView(options)
        root.addView(space(dp(12)))

        ribbon.listener = object : RibbonView.Listener {
            override fun onPosition(position: Double) { actions?.onRibbon(position) }
            override fun onRelease() { actions?.onRibbonRelease() }
        }
        root.addView(ribbon, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    fun updateState(state: LiveMidiController.State) {
        syncing = true
        val modelIndex = KorgModels.supportedTargets.indexOfFirst { it.id == state.selectedModelId }.coerceAtLeast(0)
        modelSpinner.setSelection(modelIndex)

        val baseStatus = if (state.connected) {
            "● CONNECTED · ${state.connectionLabel ?: "MIDI"}"
        } else {
            "● DISCONNECTED · NO MIDI CONNECTION"
        }
        val withIdentity = if (state.connected) {
            state.identityLabel?.let { "$baseStatus · $it" } ?: baseStatus
        } else {
            baseStatus
        }
        statusText.text = if (state.connected) "● MIDI Connected" else "● MIDI Disconnected"
        // Connection indication is deliberately binary and driven only by the
        // real Android MIDI transport state: green = an output port to the KORG
        // is open, red = no usable MIDI connection.
        statusText.setTextColor(if (state.connected) SilvetonTheme.green else SilvetonTheme.red)

        connectButton.text = if (state.connected) "DISCONNECT" else "CONNECT"
        connectButton.tag = state.connected
        connectButton.isSelected = state.connected
        monitorButton.isChecked = state.monitorEnabled
        monitorText.visibility = if (state.monitorEnabled) View.VISIBLE else View.GONE

        portaOn.isChecked = state.portamentoEnabled
        timingEngine.isChecked = state.appSidePortamento
        depth = state.portamentoDepth
        depthText.text = "%.2f".format(depth).trimEnd('0').trimEnd('.')
        numericKeypad.setValue(state.portamentoMs)

        // Mode buttons are always live. Selecting FIX/LIN/FIB/REAL while TIMES is
        // off automatically enables the app-side timing engine in the controller.
        modeButtons.forEach { (mode, button) ->
            button.isEnabled = true
            button.alpha = 1f
            button.isSelected = state.portamentoMode == mode
        }
        timeButtons.forEach { (ms, button) ->
            button.isSelected = kotlin.math.abs(state.portamentoMs - ms) < 0.001
        }
        val depthActive = state.appSidePortamento && state.portamentoMode == PortaMode.FIX
        depthPlus.isEnabled = depthActive
        depthMinus.isEnabled = depthActive
        depthText.alpha = if (depthActive) 1f else 0.42f
        depthPlus.alpha = if (depthActive) 1f else 0.42f
        depthMinus.alpha = if (depthActive) 1f else 0.42f

        harmonyOn.isChecked = state.harmonyEnabled

        scaleOn.isChecked = state.scaleTuningEnabled
        scaleModeSpinner.setSelection(when (state.scaleTuningMode) {
            ScaleTuningMode.ARABIC -> 0
            ScaleTuningMode.TURKISH -> 1
            ScaleTuningMode.USER -> 2
        })
        turkishMakamSpinner.setSelection(TurkishMakam.values().indexOf(state.turkishMakam).coerceAtLeast(0))
        turkishMakamField?.visibility = if (state.scaleTuningMode == ScaleTuningMode.TURKISH) View.VISIBLE else View.GONE
        tuningField?.visibility = if (state.scaleTuningMode == ScaleTuningMode.USER) View.VISIBLE else View.GONE
        val scaleNote = if (state.scaleTuningMode == ScaleTuningMode.TURKISH) state.turkishScaleRoot else state.scaleSelectedNote
        val noteNames = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")
        selectedNoteText.text = noteNames[scaleNote.coerceIn(0, 11)]
        scaleKeyboard.setTuningState(scaleNote, state.scaleCents.toIntArray())
        scaleTuningValue = state.scaleCents.getOrElse(state.scaleSelectedNote.coerceIn(0, 11)) { 0 }.coerceIn(-99, 99)
        scaleTuning.progress = scaleTuningValue + 99
        scaleTuningText.text = if (scaleTuningValue > 0) "+$scaleTuningValue" else scaleTuningValue.toString()

        portaModeSpinner.setSelection(when (state.portamentoMode) { PortaMode.FIX -> 0; PortaMode.LIN -> 1; PortaMode.FIB -> 2; PortaMode.REAL -> 3; else -> 1 })
        portaTime.progress = (state.portamentoMs.toInt().coerceIn(1,5000) - 1)
        portaTimeText.text = "${state.portamentoMs.toInt()} ms"
        tercaScanButton.isSelected = state.tercaScanActive
        tercaScanButton.text = if (state.tercaScanActive) "SCANNING…\nHOLD 3 NOTES" else "⌕  SCAN TERCA"
        val tercaDir = if (state.tercaDegree == HarmonyDegree.THIRD_DOWN) "DOWN" else "UP"
        val tercaNoteNames = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")
        tercaStatusText.text = if (state.tercaScanActive) {
            "SCAN ARMED · hold the 3 control notes together ABOVE C4. C4 and below are ignored as chord-zone keys."
        } else {
            "${if (state.harmonyEnabled) "TERCA ON" else "TERCA OFF"} · $tercaDir · ${tercaNoteNames[state.harmonyTonic.coerceIn(0, 11)]} · ${state.harmonyScale.name.replace('_', ' ')} · UPPER 3"
        }

        ribbonOutputSpinner.setSelection(if (state.ribbonOutput == RibbonOutput.PITCH_BEND) 0 else 1)

        bankButtons.forEachIndexed { i, b -> b.isSelected = i == state.padBank }
        padButtons.forEachIndexed { i, b ->
            val cfg = state.padConfigs.getOrNull(i)
            if (cfg != null) {
                b.text = cfg.label
                b.tag = cfg
            }
        }

        modeButtons.values.forEach { it.isSelected = false }
        modeButtons[state.portamentoMode]?.isSelected = true
        val nearest = timeButtons.keys.minByOrNull { abs(it - state.portamentoMs) }
        timeButtons.values.forEach { it.isSelected = false }
        if (nearest != null && abs(nearest - state.portamentoMs) < 0.01) timeButtons[nearest]?.isSelected = true
        syncing = false
    }

    fun appendMonitor(line: String) {
        if (!monitorButton.isChecked) return
        val lines = (monitorText.text.toString().lineSequence().filter { it.isNotBlank() }.toList() + line).takeLast(4)
        monitorText.text = lines.joinToString("\n")
    }

    fun showError(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun selectPage(index: Int) {
        currentPage = index.coerceIn(0, 2)
        pages.forEachIndexed { i, v -> v?.visibility = if (i == currentPage) View.VISIBLE else View.GONE }
        pageButtons.forEachIndexed { i, b -> b?.isSelected = i == currentPage }
    }

    private fun sectionLabel(text: String, accent: Int = SilvetonTheme.text) = TextView(context).apply {
        this.text = text
        setTextColor(accent)
        typeface = SilvetonTheme.condensedBold()
        gravity = Gravity.CENTER
        textSize = 14f
        letterSpacing = 0.08f
        includeFontPadding = false
    }

    private fun styleSpinner(spinner: Spinner, values: List<String>, accent: Int) {
        val adapter = object : ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, values) {
            private fun style(v: View, dropdown: Boolean): View {
                val tv = v as TextView
                tv.setTextColor(SilvetonTheme.text)
                tv.setBackgroundColor(if (dropdown) SilvetonTheme.panel2 else Color.TRANSPARENT)
                tv.typeface = SilvetonTheme.condensedBold()
                tv.textSize = if (dropdown) 15f else 14f
                tv.gravity = Gravity.CENTER_VERTICAL
                tv.setPadding(dp(12), 0, dp(10), 0)
                return tv
            }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getView(position, convertView, parent), false)
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getDropDownView(position, convertView, parent), true)
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.background = SilvetonTheme.selectableBackground(accent, dpF(13))
        spinner.setPadding(dp(4), 0, dp(4), 0)
        spinner.setPopupBackgroundDrawable(SilvetonTheme.panelDrawable(dpF(8), SilvetonTheme.border))
    }

    private fun weightedControlParams(weight: Float, leftMarginDp: Int): LayoutParams =
        marginParams(0, LayoutParams.MATCH_PARENT, leftMarginDp, 0, weight)

    private fun marginParams(width: Int, height: Int, leftDp: Int, topDp: Int, weight: Float = 0f): LayoutParams =
        LayoutParams(width, height, weight).apply {
            leftMargin = dp(leftDp)
            topMargin = dp(topDp)
        }

    private fun space(height: Int): View = Space(context).apply {
        layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, height)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpF(v: Int): Float = v * resources.displayMetrics.density
}
