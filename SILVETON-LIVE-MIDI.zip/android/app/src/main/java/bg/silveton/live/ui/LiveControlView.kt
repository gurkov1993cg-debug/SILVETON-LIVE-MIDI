package bg.silveton.live.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import bg.silveton.live.controller.LiveMidiController
import bg.silveton.live.midi.*
import bg.silveton.live.model.KorgModels
import bg.silveton.live.model.PadConfig

/**
 * SILVETON LIVE MIDI main surface.
 *
 * Each live processor owns its own page.  This keeps SCALE, PORTAMENTO, TERCA and
 * RIBBON visually and functionally isolated while leaving the MIDI connection and
 * SETTINGS available at all times.
 */
class LiveControlView(context: Context) : LinearLayout(context) {
    interface Actions {
        fun onModel(id: String)
        fun onConnect()
        fun onDisconnect()
        fun onSettings()
        fun onPresets()
        fun onMonitor(enabled: Boolean)
        fun onPanic()
        fun onPortamentoEnabled(enabled: Boolean)
        fun onAppSidePortamento(enabled: Boolean)
        fun onPortamentoMode(mode: PortaMode)
        fun onPortamentoTime(ms: Double)
        fun onPortamentoCustomTime(ms: Double)
        fun onPortamentoDepth(depth: Double)
        fun onHarmonyEnabled(enabled: Boolean)
        fun onScaleEnabled(enabled: Boolean)
        fun onScaleMode(mode: ScaleTuningMode)
        fun onScaleNote(note: Int)
        fun onTurkishMakam(makam: TurkishMakam)
        fun onUserScaleCent(cents: Int)
        fun onTercaScan()
        fun onPadBank(bank: Int)
        fun onPadPress(index: Int)
        fun onPadRelease(index: Int)
        fun onPadEdit(index: Int, config: PadConfig)
        fun onRibbonConfig(output: RibbonOutput, release: RibbonRelease)
        fun onRibbon(position: Double)
        fun onRibbonRelease()
    }

    var actions: Actions? = null
    private var syncing = false
    private var currentPage = 0

    private val statusText = TextView(context)
    private val modelSpinner = Spinner(context)
    private val settingsButton = Button(context)

    private val pageHost = FrameLayout(context)
    private val pages = arrayOfNulls<View>(4)
    private val pageButtons = Array(4) { Button(context) }

    private val scaleKeyboard = ScaleKeyboardView(context)
    private val scaleOn = ToggleButton(context)
    private val scaleModeSpinner = Spinner(context)
    private val turkishMakamSpinner = Spinner(context)
    private val selectedNoteText = TextView(context)
    private val scaleTuning = SeekBar(context)
    private val scaleTuningText = TextView(context)
    private val scaleMinus = Button(context)
    private val scalePlus = Button(context)
    private var turkishMakamField: View? = null
    private var tuningField: View? = null
    private var scaleTuningValue = 0

    private val portaOn = ToggleButton(context)
    private val portaModeSpinner = Spinner(context)
    private val portaTime = SeekBar(context)
    private val portaTimeText = TextView(context)
    private val numericKeypad = NumericKeypadView(context)
    private val depthText = TextView(context)
    private val depthPlus = Button(context)
    private val depthMinus = Button(context)
    private var depth = 1.0

    private val harmonyOn = ToggleButton(context)
    private val tercaScanButton = Button(context)
    private val tercaStatusText = TextView(context)

    private val ribbon = RibbonView(context)
    private val ribbonOutputSpinner = Spinner(context)

    init {
        orientation = VERTICAL
        background = SilvetonTheme.carbonBackground()
        setPadding(dp(6), dp(4), dp(6), dp(5))

        addView(buildHeader(), LayoutParams(LayoutParams.MATCH_PARENT, dp(82)))
        addView(buildPageNavigation(), marginParams(LayoutParams.MATCH_PARENT, dp(48), 0, 5))

        pages[0] = buildScalePage()
        pages[1] = buildPortamentoPage()
        pages[2] = buildTercaPage()
        pages[3] = buildRibbonPage()
        pages.forEach { pageHost.addView(it, FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)) }
        addView(pageHost, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        selectPage(0)
    }

    private fun buildHeader(): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(5), dp(10), dp(5))
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.blue, dpF(15))
        }

        val brand = LinearLayout(context).apply { orientation = VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        brand.addView(TextView(context).apply {
            text = "SILVETON"
            setTextColor(SilvetonTheme.text)
            textSize = 27f
            typeface = SilvetonTheme.titleTypeface()
            letterSpacing = 0.08f
            includeFontPadding = false
        }, LayoutParams(LayoutParams.WRAP_CONTENT, dp(34)))
        brand.addView(TextView(context).apply {
            text = "L I V E   M I D I"
            setTextColor(SilvetonTheme.cyan)
            textSize = 11f
            typeface = SilvetonTheme.condensedBold()
            letterSpacing = 0.16f
            includeFontPadding = false
        }, LayoutParams(LayoutParams.WRAP_CONTENT, dp(20)))
        row.addView(brand, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        val connectionBox = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(3), dp(6), dp(3))
            background = SilvetonTheme.insetPanelDrawable(dpF(12))
        }

        styleSpinner(modelSpinner, KorgModels.supportedTargets.map { it.displayName }, SilvetonTheme.cyan)
        modelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onModel(KorgModels.supportedTargets[position].id)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        connectionBox.addView(modelSpinner, LayoutParams(dp(185), dp(42)))

        statusText.apply {
            text = "● MIDI Disconnected"
            setTextColor(SilvetonTheme.red)
            textSize = 11f
            typeface = SilvetonTheme.condensedBold()
            gravity = Gravity.CENTER
            includeFontPadding = false
            background = SilvetonTheme.selectableBackground(SilvetonTheme.red, dpF(11))
            setOnClickListener {
                val connected = tag as? Boolean ?: false
                if (connected) actions?.onDisconnect() else actions?.onConnect()
            }
        }
        connectionBox.addView(statusText, marginParams(dp(168), dp(42), 6, 0))

        settingsButton.apply {
            text = "⚙"
            contentDescription = "MIDI settings"
            SilvetonTheme.styleControl(this, SilvetonTheme.cyan, 19f, dpF(11))
            setOnClickListener { actions?.onSettings() }
        }
        connectionBox.addView(settingsButton, marginParams(dp(50), dp(42), 6, 0))
        row.addView(connectionBox, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT))
        return row
    }

    private fun buildPageNavigation(): View {
        val row = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
            background = SilvetonTheme.insetPanelDrawable(dpF(12))
            setPadding(dp(4), dp(3), dp(4), dp(3))
        }
        val specs = listOf(
            Triple("SCALE", SilvetonTheme.cyan, 0),
            Triple("PORTAMENTO", SilvetonTheme.purple, 1),
            Triple("TERCA", SilvetonTheme.amber, 2),
            Triple("RIBBON", SilvetonTheme.blue, 3)
        )
        specs.forEachIndexed { index, (label, accent, page) ->
            pageButtons[index].apply {
                text = label
                SilvetonTheme.styleControl(this, accent, 13f, dpF(10))
                setOnClickListener { selectPage(page) }
            }
            row.addView(pageButtons[index], marginParams(0, LayoutParams.MATCH_PARENT, if (index == 0) 0 else 4, 0, 1f))
        }
        return row
    }

    private fun buildScalePage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(8))
        }

        val keyboardPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.cyan, dpF(13))
            setPadding(dp(10), dp(7), dp(10), dp(8))
        }
        keyboardPanel.addView(sectionLabel("SCALE KEYBOARD · 1 OCTAVE", SilvetonTheme.text).apply {
            gravity = Gravity.CENTER_VERTICAL
            textSize = 18f
        }, LayoutParams(LayoutParams.MATCH_PARENT, dp(36)))
        scaleKeyboard.listener = object : ScaleKeyboardView.Listener {
            override fun onNoteSelected(note: Int) { actions?.onScaleNote(note) }
        }
        keyboardPanel.addView(scaleKeyboard, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(keyboardPanel, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1.4f))
        root.addView(space(dp(7)))

        val controlPanel = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.cyan, dpF(13))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

        val scaleTitle = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            addView(sectionLabel("SCALE", SilvetonTheme.cyan).apply { textSize = 19f }, LayoutParams(LayoutParams.MATCH_PARENT, dp(34)))
            scaleOn.apply {
                textOn = "ON"; textOff = "OFF"
                SilvetonTheme.styleControl(this, SilvetonTheme.cyan, 15f, dpF(16))
                setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onScaleEnabled(checked) }
            }
            addView(scaleOn, LayoutParams(LayoutParams.MATCH_PARENT, dp(52)))
        }
        controlPanel.addView(scaleTitle, LayoutParams(dp(145), LayoutParams.MATCH_PARENT))

        styleSpinner(scaleModeSpinner, listOf("ARABIC", "TURKISH", "USER"), SilvetonTheme.cyan)
        scaleModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onScaleMode(arrayOf(ScaleTuningMode.ARABIC, ScaleTuningMode.TURKISH, ScaleTuningMode.USER)[position.coerceIn(0, 2)])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        controlPanel.addView(field("MODE", scaleModeSpinner), LayoutParams(0, LayoutParams.MATCH_PARENT, .8f))

        styleSpinner(turkishMakamSpinner, TurkishMakam.values().map { it.displayName }, SilvetonTheme.cyan)
        turkishMakamSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onTurkishMakam(TurkishMakam.values()[position.coerceIn(0, TurkishMakam.values().lastIndex)])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        val makamField = field("MAKAM", turkishMakamSpinner)
        turkishMakamField = makamField
        controlPanel.addView(makamField, LayoutParams(0, LayoutParams.MATCH_PARENT, 1.1f))

        selectedNoteText.apply {
            text = "C"
            gravity = Gravity.CENTER
            textSize = 28f
            typeface = SilvetonTheme.monoBold()
            setTextColor(SilvetonTheme.text)
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
        }
        controlPanel.addView(field("NOTE / ROOT", selectedNoteText), LayoutParams(0, LayoutParams.MATCH_PARENT, .65f))

        val tuningBox = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            scaleMinus.apply {
                text = "−"
                SilvetonTheme.styleControl(this, SilvetonTheme.cyan, 20f, dpF(10))
                setOnClickListener { if (!syncing) actions?.onUserScaleCent((scaleTuningValue - 1).coerceIn(-99, 99)) }
            }
            addView(scaleMinus, LayoutParams(dp(46), LayoutParams.MATCH_PARENT))
            scaleTuning.max = 198
            scaleTuning.progress = 99
            scaleTuning.progressTintList = android.content.res.ColorStateList.valueOf(SilvetonTheme.cyan)
            scaleTuning.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            scaleTuning.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val cents = progress - 99
                    scaleTuningValue = cents
                    scaleTuningText.text = if (cents > 0) "+$cents" else cents.toString()
                    if (fromUser && !syncing) actions?.onUserScaleCent(cents)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
            addView(scaleTuning, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))
            scalePlus.apply {
                text = "+"
                SilvetonTheme.styleControl(this, SilvetonTheme.cyan, 20f, dpF(10))
                setOnClickListener { if (!syncing) actions?.onUserScaleCent((scaleTuningValue + 1).coerceIn(-99, 99)) }
            }
            addView(scalePlus, LayoutParams(dp(46), LayoutParams.MATCH_PARENT))
            scaleTuningText.apply {
                gravity = Gravity.CENTER
                setTextColor(SilvetonTheme.text)
                textSize = 18f
                typeface = SilvetonTheme.monoBold()
                background = SilvetonTheme.insetPanelDrawable(dpF(8))
            }
            addView(scaleTuningText, marginParams(dp(72), LayoutParams.MATCH_PARENT, 5, 0))
        }
        val userTuningField = field("TUNING (CENT)", tuningBox)
        tuningField = userTuningField
        controlPanel.addView(userTuningField, LayoutParams(0, LayoutParams.MATCH_PARENT, 1.7f))

        root.addView(controlPanel, LayoutParams(LayoutParams.MATCH_PARENT, 0, .8f))
        return root
    }

    private fun buildPortamentoPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(10))
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.purple, dpF(14))
        }

        val head = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(sectionLabel("GLOBAL PORTAMENTO · ALL UPPERS", SilvetonTheme.text).apply { textSize = 20f }, LayoutParams(0, dp(58), 1f))
        portaOn.apply {
            textOn = "ON"; textOff = "OFF"
            SilvetonTheme.styleControl(this, SilvetonTheme.purple, 16f, dpF(18))
            setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onPortamentoEnabled(checked) }
        }
        head.addView(portaOn, LayoutParams(dp(120), dp(54)))
        root.addView(head)

        val controls = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        styleSpinner(portaModeSpinner, listOf("FIXED", "LINEAR", "FIBONACCI", "REAL"), SilvetonTheme.purple)
        portaModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onPortamentoMode(arrayOf(PortaMode.FIX, PortaMode.LIN, PortaMode.FIB, PortaMode.REAL)[position.coerceIn(0, 3)])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        controls.addView(field("MODE / CURVE", portaModeSpinner), LayoutParams(0, LayoutParams.MATCH_PARENT, 1.05f))

        portaTime.max = 4999
        portaTime.progressTintList = android.content.res.ColorStateList.valueOf(SilvetonTheme.purple)
        portaTime.thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        portaTime.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val ms = progress + 1
                portaTimeText.text = "$ms ms"
                if (fromUser && !syncing) actions?.onPortamentoTime(ms.toDouble())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        controls.addView(field("TIME", portaTime), LayoutParams(0, LayoutParams.MATCH_PARENT, 1.55f))

        portaTimeText.apply {
            gravity = Gravity.CENTER
            setTextColor(SilvetonTheme.text)
            textSize = 22f
            typeface = SilvetonTheme.monoBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
        }
        controls.addView(field("VALUE", portaTimeText), LayoutParams(0, LayoutParams.MATCH_PARENT, .65f))
        root.addView(controls, LayoutParams(LayoutParams.MATCH_PARENT, dp(120)))
        root.addView(space(dp(10)))

        val lower = LinearLayout(context).apply { orientation = HORIZONTAL }
        val depthPanel = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            background = SilvetonTheme.insetPanelDrawable(dpF(14))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        depthPanel.addView(sectionLabel("FIX DEPTH", SilvetonTheme.muted), LayoutParams(LayoutParams.MATCH_PARENT, dp(32)))
        val depthRow = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        depthMinus.apply { text = "−"; SilvetonTheme.styleControl(this, SilvetonTheme.purple, 25f); setOnClickListener { actions?.onPortamentoDepth((depth - .05).coerceAtLeast(.05)) } }
        depthPlus.apply { text = "+"; SilvetonTheme.styleControl(this, SilvetonTheme.purple, 25f); setOnClickListener { actions?.onPortamentoDepth((depth + .05).coerceAtMost(8.0)) } }
        depthText.apply {
            gravity = Gravity.CENTER
            setTextColor(SilvetonTheme.text)
            textSize = 28f
            typeface = SilvetonTheme.monoBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(10))
            text = "1.00"
        }
        depthRow.addView(depthMinus, LayoutParams(dp(70), LayoutParams.MATCH_PARENT))
        depthRow.addView(depthText, marginParams(0, LayoutParams.MATCH_PARENT, 8, 0, 1f))
        depthRow.addView(depthPlus, marginParams(dp(70), LayoutParams.MATCH_PARENT, 8, 0))
        depthPanel.addView(depthRow, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        lower.addView(depthPanel, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        numericKeypad.listener = object : NumericKeypadView.Listener {
            override fun onAccepted(value: Double) { actions?.onPortamentoCustomTime(value) }
        }
        lower.addView(numericKeypad, marginParams(dp(270), LayoutParams.MATCH_PARENT, 10, 0))
        root.addView(lower, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    private fun buildTercaPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.amber, dpF(14))
        }
        root.addView(sectionLabel("TERCA · UPPER 3", SilvetonTheme.text).apply { textSize = 22f }, LayoutParams(LayoutParams.MATCH_PARENT, dp(60)))

        val row = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        harmonyOn.apply {
            textOn = "TERCA ON"; textOff = "TERCA OFF"
            SilvetonTheme.styleControl(this, SilvetonTheme.amber, 19f, dpF(18))
            setOnCheckedChangeListener { _, checked -> if (!syncing) actions?.onHarmonyEnabled(checked) }
        }
        row.addView(harmonyOn, LayoutParams(0, dp(100), 1f))
        tercaScanButton.apply {
            text = "SCAN TERCA"
            SilvetonTheme.styleControl(this, SilvetonTheme.amber, 19f, dpF(18))
            setOnClickListener { if (!syncing) actions?.onTercaScan() }
        }
        row.addView(tercaScanButton, marginParams(0, dp(100), 14, 0, 1f))
        root.addView(row, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        tercaStatusText.apply {
            gravity = Gravity.CENTER
            setTextColor(SilvetonTheme.text)
            textSize = 17f
            typeface = SilvetonTheme.condensedBold()
            background = SilvetonTheme.insetPanelDrawable(dpF(14))
            setPadding(dp(18), dp(18), dp(18), dp(18))
            maxLines = 4
        }
        root.addView(tercaStatusText, marginParams(LayoutParams.MATCH_PARENT, 0, 0, 16, 1f))
        return root
    }

    private fun buildRibbonPage(): View {
        val root = LinearLayout(context).apply {
            orientation = VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = SilvetonTheme.neonPanelDrawable(SilvetonTheme.blue, dpF(14))
        }
        val head = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(sectionLabel("RIBBON · GLOBAL · ALL UPPERS", SilvetonTheme.text).apply { textSize = 20f }, LayoutParams(0, dp(58), 1f))
        styleSpinner(ribbonOutputSpinner, listOf("PITCH BEND", "CC16"), SilvetonTheme.blue)
        ribbonOutputSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!syncing) actions?.onRibbonConfig(if (position == 0) RibbonOutput.PITCH_BEND else RibbonOutput.CONTROL_CHANGE, RibbonRelease.CENTER)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        head.addView(ribbonOutputSpinner, LayoutParams(dp(220), dp(48)))
        root.addView(head)

        ribbon.listener = object : RibbonView.Listener {
            override fun onPosition(position: Double) { actions?.onRibbon(position) }
            override fun onRelease() { actions?.onRibbonRelease() }
        }
        root.addView(ribbon, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
        return root
    }

    fun updateState(state: LiveMidiController.State) {
        syncing = true
        modelSpinner.setSelection(KorgModels.supportedTargets.indexOfFirst { it.id == state.selectedModelId }.coerceAtLeast(0))

        statusText.text = if (state.connected) "● MIDI Connected" else "● MIDI Disconnected"
        statusText.setTextColor(if (state.connected) SilvetonTheme.green else SilvetonTheme.red)
        statusText.tag = state.connected

        scaleOn.isChecked = state.scaleTuningEnabled
        scaleModeSpinner.setSelection(when (state.scaleTuningMode) {
            ScaleTuningMode.ARABIC -> 0
            ScaleTuningMode.TURKISH -> 1
            ScaleTuningMode.USER -> 2
        })
        turkishMakamSpinner.setSelection(TurkishMakam.values().indexOf(state.turkishMakam).coerceAtLeast(0))
        turkishMakamField?.visibility = if (state.scaleTuningMode == ScaleTuningMode.TURKISH) View.VISIBLE else View.GONE
        tuningField?.visibility = if (state.scaleTuningMode == ScaleTuningMode.USER) View.VISIBLE else View.GONE
        val note = if (state.scaleTuningMode == ScaleTuningMode.TURKISH) state.turkishScaleRoot else state.scaleSelectedNote
        val names = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","A#","B")
        selectedNoteText.text = names[note.coerceIn(0, 11)]
        scaleKeyboard.setTuningState(note, state.scaleCents.toIntArray())
        scaleTuningValue = state.scaleCents.getOrElse(state.scaleSelectedNote.coerceIn(0, 11)) { 0 }.coerceIn(-99, 99)
        scaleTuning.progress = scaleTuningValue + 99
        scaleTuningText.text = if (scaleTuningValue > 0) "+$scaleTuningValue" else scaleTuningValue.toString()

        portaOn.isChecked = state.portamentoEnabled
        portaModeSpinner.setSelection(when (state.portamentoMode) {
            PortaMode.FIX -> 0
            PortaMode.LIN -> 1
            PortaMode.FIB -> 2
            PortaMode.REAL -> 3
            PortaMode.CUSTOM -> 0
        })
        portaTime.progress = state.portamentoMs.toInt().coerceIn(1, 5000) - 1
        portaTimeText.text = "${state.portamentoMs.toInt()} ms"
        numericKeypad.setValue(state.portamentoMs)
        depth = state.portamentoDepth
        depthText.text = "%.2f".format(depth).trimEnd('0').trimEnd('.')
        val depthActive = state.portamentoMode == PortaMode.FIX || state.portamentoMode == PortaMode.CUSTOM
        depthPlus.isEnabled = depthActive
        depthMinus.isEnabled = depthActive
        depthPlus.alpha = if (depthActive) 1f else .4f
        depthMinus.alpha = if (depthActive) 1f else .4f
        depthText.alpha = if (depthActive) 1f else .4f

        harmonyOn.isChecked = state.harmonyEnabled
        tercaScanButton.isSelected = state.tercaScanActive
        tercaScanButton.text = if (state.tercaScanActive) "SCANNING… HOLD 3 NOTES" else "SCAN TERCA"
        val dir = if (state.tercaDegree == HarmonyDegree.THIRD_DOWN) "DOWN" else "UP"
        tercaStatusText.text = if (state.tercaScanActive) {
            "SCAN ARMED · hold 3 notes above C4"
        } else {
            "${if (state.harmonyEnabled) "TERCA ON" else "TERCA OFF"} · $dir · ${names[state.harmonyTonic.coerceIn(0, 11)]} · ${state.harmonyScale.name.replace('_', ' ')} · UPPER 3 = MIDI CH ${state.upper3Channel + 1}"
        }

        ribbonOutputSpinner.setSelection(if (state.ribbonOutput == RibbonOutput.PITCH_BEND) 0 else 1)
        syncing = false
    }

    fun appendMonitor(line: String) = Unit

    fun showError(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun selectPage(index: Int) {
        currentPage = index.coerceIn(0, 3)
        pages.forEachIndexed { i, v -> v?.visibility = if (i == currentPage) View.VISIBLE else View.GONE }
        pageButtons.forEachIndexed { i, b -> b.isSelected = i == currentPage }
    }

    private fun field(label: String, view: View): View = LinearLayout(context).apply {
        orientation = VERTICAL
        setPadding(dp(5), 0, dp(5), 0)
        addView(sectionLabel(label, SilvetonTheme.muted).apply {
            textSize = 10f
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }, LayoutParams(LayoutParams.MATCH_PARENT, dp(22)))
        addView(view, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))
    }

    private fun sectionLabel(text: String, accent: Int = SilvetonTheme.text) = TextView(context).apply {
        this.text = text
        setTextColor(accent)
        typeface = SilvetonTheme.condensedBold()
        gravity = Gravity.CENTER
        textSize = 14f
        letterSpacing = 0.08f
        includeFontPadding = false
    }

    private fun styleSpinner(spinner: Spinner, values: List<String>, accent: Int) {
        val adapter = object : ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, values) {
            private fun style(v: View, dropdown: Boolean): View {
                val tv = v as TextView
                tv.setTextColor(SilvetonTheme.text)
                tv.setBackgroundColor(if (dropdown) SilvetonTheme.panel2 else Color.TRANSPARENT)
                tv.typeface = SilvetonTheme.condensedBold()
                tv.textSize = if (dropdown) 15f else 14f
                tv.gravity = Gravity.CENTER_VERTICAL
                tv.setPadding(dp(12), 0, dp(10), 0)
                return tv
            }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View = style(super.getView(position, convertView, parent), false)
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View = style(super.getDropDownView(position, convertView, parent), true)
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.background = SilvetonTheme.selectableBackground(accent, dpF(13))
        spinner.setPadding(dp(4), 0, dp(4), 0)
        spinner.setPopupBackgroundDrawable(SilvetonTheme.panelDrawable(dpF(8), SilvetonTheme.border))
    }

    private fun marginParams(width: Int, height: Int, leftDp: Int, topDp: Int, weight: Float = 0f): LayoutParams =
        LayoutParams(width, height, weight).apply {
            leftMargin = dp(leftDp)
            topMargin = dp(topDp)
        }

    private fun space(height: Int): View = Space(context).apply { layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, height) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + .5f).toInt()
    private fun dpF(v: Int): Float = v * resources.displayMetrics.density
}
