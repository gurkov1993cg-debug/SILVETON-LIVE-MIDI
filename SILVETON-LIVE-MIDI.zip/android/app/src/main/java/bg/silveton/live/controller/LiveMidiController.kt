package bg.silveton.live.controller

import android.content.Context
import android.media.midi.MidiDeviceInfo
import android.os.SystemClock
import bg.silveton.live.midi.*
import bg.silveton.live.model.AppPreferences
import bg.silveton.live.model.KorgModels
import bg.silveton.live.model.PortamentoCalibrationStore
import bg.silveton.live.model.PadConfigurationStore
import bg.silveton.live.model.PadConfig
import bg.silveton.live.model.MidiRuntimeSettings
import bg.silveton.live.model.PerformancePreset
import bg.silveton.live.model.PerformancePresetStore
import java.io.Closeable
import java.util.ArrayDeque
import java.util.concurrent.CopyOnWriteArrayList

class LiveMidiController(context: Context) : Closeable, AndroidMidiTransport.Listener {
    private companion object {
        // Hard performance split requested for the live rig:
        // C4 (MIDI note 60) and every lower key belong exclusively to the
        // arranger chord/left-hand zone.  Silveton effects start at C#4 (61).
        const val CHORD_ZONE_MAX_NOTE = 60
    }

    data class State(
        val connected: Boolean = false,
        val connectionLabel: String? = null,
        val identityLabel: String? = null,
        val selectedModelId: String = "pa600",
        val portamentoEnabled: Boolean = false,
        val portamentoMode: PortaMode = PortaMode.FIX,
        val portamentoMs: Double = 20.0,
        val portamentoDepth: Double = 1.0,
        val appSidePortamento: Boolean = false,
        val targetUpperMask: Int = 1,
        val harmonyEnabled: Boolean = false,
        val intervalMode: IntervalMode = IntervalMode.SCALE,
        val harmonyTonic: Int = 0,
        val harmonyScale: ScaleType = ScaleType.MAJOR,
        val tercaDegree: HarmonyDegree = HarmonyDegree.THIRD,
        val tercaScanActive: Boolean = false,
        val harmonyVoiceMask: Int = 1,
        val ribbonOutput: RibbonOutput = RibbonOutput.PITCH_BEND,
        val ribbonRelease: RibbonRelease = RibbonRelease.CENTER,
        val padBank: Int = 0,
        val padConfigs: List<PadConfig> = emptyList(),
        val monitorEnabled: Boolean = false,
        val midiThru: Boolean = false,
        val performanceInputChannel: Int = 0,
        val performanceInputOmni: Boolean = false,
        val upper1Channel: Int = 0,
        val upper2Channel: Int = 1,
        val upper3Channel: Int = 2,
        val pitchBendRangeSemitones: Int = 12,
        val autoReconnect: Boolean = true,
        val activePresetName: String? = null
    )

    interface Listener {
        fun onStateChanged(state: State) {}
        fun onDevicesChanged(devices: List<AndroidMidiTransport.Device>) {}
        fun onMonitorLine(line: String) {}
        fun onError(message: String) {}
    }

    val preferences = AppPreferences(context)
    private val calibrationStore = PortamentoCalibrationStore(context)
    private val padStore = PadConfigurationStore(context)
    private val presetStore = PerformancePresetStore(context)
    val transport = AndroidMidiTransport(context)
    val core = NativeMidiCore()
    private val effectRouter = EffectIsolationRouter()
    private val pitchBendMixer = PitchBendMixer()
    private val dispatcher = MidiEventDispatcher(
        sendNow = { bytes ->
            transport.send(bytes, 0L)
            if (state.monitorEnabled) addMonitor("OUT ${MidiMessageFormatter.format(bytes)}")
        },
        transform = { bytes -> pitchBendMixer.applyPortamento(bytes) },
        onError = { publishError(it.message ?: "MIDI scheduled send failed") }
    )

    private val listeners = CopyOnWriteArrayList<Listener>()
    private val decoder = MidiStreamDecoder()
    private val monitor = ArrayDeque<String>(256)
    private val tercaScanNotes = LinkedHashSet<Int>()
    // TERCA SCAN learns the real note-source channel from the keyboard.  This avoids
    // a dead scan when a PA-series MIDI preset transmits Upper 1 on a different
    // channel than the app preference.  Once the first scan NoteOn arrives, the
    // scan is locked to that channel so Upper 2/3 duplicate streams cannot pollute it.
    private var tercaScanChannel: Int? = null
    private var ribbonChannel = preferences.upper1Channel
    private var ribbonChannels = listOf(preferences.upper1Channel, preferences.upper2Channel, preferences.upper3Channel).distinct()
    private var configuredRibbonOutput = preferences.ribbonOutput
    private var state = State(
        selectedModelId = preferences.selectedModelId,
        portamentoEnabled = preferences.portamentoEnabled,
        portamentoMode = preferences.portamentoMode,
        portamentoMs = preferences.portamentoDurationMs,
        portamentoDepth = preferences.portamentoDepth,
        appSidePortamento = preferences.appSidePortamento,
        targetUpperMask = preferences.targetUpperMask,
        harmonyEnabled = preferences.harmonyEnabled,
        intervalMode = preferences.intervalMode,
        harmonyTonic = preferences.harmonyTonic,
        harmonyScale = preferences.harmonyScale,
        tercaDegree = preferences.tercaDegree,
        harmonyVoiceMask = preferences.harmonyVoiceMask,
        ribbonOutput = preferences.ribbonOutput,
        ribbonRelease = RibbonRelease.CENTER,
        padBank = preferences.padBank,
        padConfigs = padStore.loadBank(preferences.padBank),
        midiThru = preferences.midiThru,
        performanceInputChannel = preferences.performanceInputChannel,
        performanceInputOmni = preferences.performanceInputOmni,
        upper1Channel = preferences.upper1Channel,
        upper2Channel = preferences.upper2Channel,
        upper3Channel = preferences.upper3Channel,
        pitchBendRangeSemitones = preferences.pitchBendRangeSemitones,
        autoReconnect = preferences.autoReconnect
    )

    init {
        // Ribbon is now permanently spring-centred; migrate any older saved release mode.
        preferences.ribbonRelease = RibbonRelease.CENTER

        // PA600 does not have a reliable documented CC16 ribbon path. Older builds
        // defaulted to CC16, which can make a freshly updated app look as if the
        // ribbon is dead. Migrate that old default once to Pitch Bend; the user can
        // still explicitly choose CC16 afterwards if their MIDI setup maps it.
        if (!preferences.pa600RibbonPitchBendMigrationDone) {
            if (state.selectedModelId == "pa600" && state.ribbonOutput == RibbonOutput.CONTROL_CHANGE) {
                preferences.ribbonOutput = RibbonOutput.PITCH_BEND
            }
            preferences.pa600RibbonPitchBendMigrationDone = true
            state = state.copy(ribbonOutput = preferences.ribbonOutput)
        }

        // Routing migration: older builds allowed TERCA SCAN/OMNI to change the
        // performance source. That could make app-side PORTA follow the arranger's
        // left-hand/chord stream. The live processor must listen to one explicit
        // RIGHT-HAND / UPPER source channel only. Reset affected installs once to
        // the documented PA-series live setup (CH1); the channel remains editable.
        if (!preferences.rightHandRoutingMigrationDone) {
            preferences.performanceInputChannel = 0
            preferences.performanceInputOmni = false
            preferences.rightHandRoutingMigrationDone = true
        } else {
            preferences.performanceInputOmni = false
        }
        state = state.copy(
            ribbonRelease = RibbonRelease.CENTER,
            performanceInputChannel = preferences.performanceInputChannel,
            performanceInputOmni = false
        )
        core.selectModel(state.selectedModelId)
        applyStoredCalibration(state.selectedModelId)
        core.configurePortamento(state.portamentoMode, state.portamentoMs, state.portamentoDepth)
        core.setPortamentoEngineEnabled(state.portamentoEnabled)
        core.configureHarmony(preferences.harmonyTonic, preferences.harmonyScale)
        // TERCA is the only harmony voice exposed by the live UI.  Migrate older
        // presets/preferences so no hidden 5th/6th/octave voice can remain active.
        val tercaMask = if (preferences.harmonyEnabled) 1 else 0
        preferences.harmonyVoiceMask = tercaMask
        preferences.intervalMode = IntervalMode.SCALE
        val startupTargetMask = preferences.targetUpperMask
        state = state.copy(
            harmonyVoiceMask = tercaMask,
            intervalMode = IntervalMode.SCALE,
            targetUpperMask = startupTargetMask
        )
        configureTercaOnly(preferences.harmonyEnabled, preferences.tercaDegree)
        ribbonChannel = preferences.upper1Channel
        core.configureRibbon(preferences.ribbonOutput, ribbonChannel, 16, 0.10, RibbonRelease.CENTER)
        initializePadBanks()
        transport.setAutoReconnect(preferences.autoReconnect)
        transport.addListener(this)
        if (preferences.autoReconnect) {
            preferences.lastDeviceKey?.let { transport.reconnect(it, preferences.lastInputPort, preferences.lastOutputPort) }
        }
    }

    fun addListener(listener: Listener) {
        listeners += listener
        listener.onStateChanged(state)
        listener.onDevicesChanged(transport.devices())
    }

    fun removeListener(listener: Listener) { listeners -= listener }
    fun state(): State = state
    fun monitorSnapshot(): List<String> = synchronized(monitor) { monitor.toList() }
    fun portamentoCalibration(): PortamentoCalibrationStore.Table? = calibrationStore.load(state.selectedModelId)

    fun selectModel(id: String) {
        if (KorgModels.supportedTargets.none { it.id == id }) return
        if (!core.selectModel(id)) return
        preferences.selectedModelId = id
        applyStoredCalibration(id)
        state = state.copy(selectedModelId = id, activePresetName = null)
        if (transport.isConnected()) {
            applyPortamentoToTargets(sendSwitch = true, sendTime = true)
            if (state.appSidePortamento) {
                targetChannels().forEach { ch -> safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones)) }
            }
        }
        publishState()
    }

    fun setPortamentoCalibration(cc: IntArray, milliseconds: DoubleArray): Boolean {
        val id = state.selectedModelId
        if (!calibrationStore.save(id, cc, milliseconds)) return false
        if (!core.setPortamentoCalibration(cc, milliseconds)) {
            calibrationStore.clear(id)
            return false
        }
        if (!state.appSidePortamento) applyPortamentoToTargets(sendSwitch = false, sendTime = true)
        return true
    }

    fun clearPortamentoCalibration() {
        calibrationStore.clear(state.selectedModelId)
        // Selecting the model resets native calibration to the built-in table (currently empty unless measured).
        core.selectModel(state.selectedModelId)
        if (!state.appSidePortamento) applyPortamentoToTargets(sendSwitch = false, sendTime = true)
    }

    fun connect(info: MidiDeviceInfo, inputPort: Int = 0, outputPort: Int = 0) {
        if (transport.isConnected()) panic()
        val d = AndroidMidiTransport.Device(info)
        KorgModels.guessFromDeviceText(d.manufacturer, d.product, d.label)?.let { selectModel(it.id) }
        preferences.lastDeviceKey = d.stableKey
        preferences.lastInputPort = inputPort
        preferences.lastOutputPort = outputPort
        transport.connect(info, inputPort, outputPort)
    }

    fun disconnect() {
        if (transport.isConnected()) panic()
        transport.disconnect(clearReconnectTarget = true)
    }

    fun setMonitorEnabled(enabled: Boolean) {
        state = state.copy(monitorEnabled = enabled)
        publishState()
    }

    fun setTargetUpper(index: Int, enabled: Boolean) {
        if (index !in 0..2) return
        val oldMask = state.targetUpperMask
        val oldChannels = targetChannelsForMask(oldMask)
        var mask = oldMask
        mask = if (enabled) mask or (1 shl index) else mask and (1 shl index).inv()
        if (mask == 0) mask = 1 shl index
        val newChannels = targetChannelsForMask(mask)

        // PORTA target changes are channel-local. They never reconfigure TERCA or RIBBON.
        val removed = oldChannels - newChannels.toSet()
        removed.forEach { ch ->
            dispatcher.invalidateChannel(ch)
            if (state.appSidePortamento && state.portamentoEnabled) {
                val u3 = effectRouter.tercaChannel(preferences.upper3Channel)
                resetPortaChannel(ch, state.harmonyEnabled && ch == u3)
            }
            safeSend(core.hardwarePortamentoSwitch(false, ch))
        }

        preferences.targetUpperMask = mask
        state = state.copy(targetUpperMask = mask, activePresetName = null)
        applyPortamentoToTargets(sendSwitch = true, sendTime = true)
        if (state.appSidePortamento && transport.isConnected()) {
            targetChannels().forEach { ch -> safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones)) }
        }
        publishState()
    }

    fun setAppSidePortamento(enabled: Boolean) {
        if (enabled == preferences.appSidePortamento) return
        if (enabled && transport.isConnected() && !transport.canReceiveMidi()) {
            publishError("TIMES needs MIDI from KORG → phone. Reconnect using a From KORG port.")
            publishState()
            return
        }
        dispatcher.invalidateAll()
        resetSelectedPortaChannels()
        preferences.appSidePortamento = enabled
        state = state.copy(appSidePortamento = enabled, activePresetName = null)
        // PORTA mode changes never touch RIBBON configuration.
        // Hardware portamento must be off while the app generates the pitch trajectory.
        targetChannels().forEach { ch ->
            safeSend(core.hardwarePortamentoSwitch(state.portamentoEnabled && !enabled, ch))
            if (enabled) safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones))
            else if (state.portamentoEnabled) safeSend(core.applyPortamentoTime(ch))
        }
        publishState()
    }

    fun setPortamentoEnabled(enabled: Boolean) {
        if (!enabled && state.portamentoEnabled && preferences.appSidePortamento) {
            dispatcher.invalidateAll()
            resetSelectedPortaChannels()
        }
        preferences.portamentoEnabled = enabled
        state = state.copy(portamentoEnabled = enabled, activePresetName = null)
        core.configurePortamento(state.portamentoMode, state.portamentoMs, state.portamentoDepth)
        core.setPortamentoEngineEnabled(enabled)
        targetChannels().forEach { ch ->
            safeSend(core.hardwarePortamentoSwitch(enabled && !state.appSidePortamento, ch))
            if (enabled && !state.appSidePortamento) safeSend(core.applyPortamentoTime(ch))
        }
        publishState()
    }

    fun setPortamentoMode(mode: PortaMode) {
        // FIX/LIN/FIB/REAL are real app-side glide laws. A mode press must not be
        // just a GUI selection: ensure TIMES owns the trajectory, replace any old
        // in-flight glide, then configure the native engine before the next note.
        if (transport.isConnected() && !transport.canReceiveMidi()) {
            publishError("${mode.name} needs MIDI from KORG → phone. Select a From KORG port; TIMES cannot work output-only.")
            publishState()
            return
        }

        if (!state.appSidePortamento) setAppSidePortamento(true)

        // Cancel/flush only PORTA channels. TERCA, RIBBON and PADS remain isolated.
        // This prevents a long trajectory from the previous mode continuing after
        // the player has already selected a different law.
        if (state.portamentoEnabled) {
            selectedPortamentoChannels().forEach { ch ->
                dispatcher.invalidateChannel(ch)
                val u3 = effectRouter.tercaChannel(preferences.upper3Channel)
                resetPortaChannel(ch, state.harmonyEnabled && ch == u3)
                safeSend(core.hardwarePortamentoSwitch(false, ch))
                safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones))
            }
        }

        preferences.portamentoMode = mode
        state = state.copy(portamentoMode = mode, activePresetName = null)
        core.configurePortamento(mode, state.portamentoMs, state.portamentoDepth)
        core.setPortamentoEngineEnabled(state.portamentoEnabled)
        if (state.monitorEnabled) addMonitor("PORTA MODE ${mode.name} · ${state.portamentoMs.toInt()} ms")
        publishState()
    }

    fun setPortamentoTime(ms: Double) {
        val v = ms.coerceIn(1.0, 5000.0)
        preferences.portamentoDurationMs = v
        state = state.copy(portamentoMs = v, activePresetName = null)
        core.configurePortamento(state.portamentoMode, v, state.portamentoDepth)
        if (!state.appSidePortamento) targetChannels().forEach { safeSend(core.applyPortamentoTime(it)) }
        publishState()
    }

    fun setCustomPortamentoTime(ms: Double) {
        val v = ms.coerceIn(1.0, 5000.0)

        // The keypad is an exact-millisecond control, not another hardware CC5 shortcut.
        // CUSTOM therefore always uses the app-side timing engine, where the entered value
        // is the total glide duration regardless of interval size.
        if (!state.appSidePortamento) {
            if (transport.isConnected() && !transport.canReceiveMidi()) {
                publishError("CUSTOM MS needs MIDI from KORG → phone. Reconnect using a From KORG port.")
                publishState()
                return
            }
            setAppSidePortamento(true)
        }

        preferences.portamentoMode = PortaMode.CUSTOM
        preferences.portamentoDurationMs = v
        state = state.copy(
            portamentoMode = PortaMode.CUSTOM,
            portamentoMs = v,
            activePresetName = null
        )
        core.configurePortamento(PortaMode.CUSTOM, v, state.portamentoDepth)
        publishState()
    }

    fun setPortamentoDepth(depth: Double) {
        val v = depth.coerceIn(0.05, 8.0)
        preferences.portamentoDepth = v
        state = state.copy(portamentoDepth = v, activePresetName = null)
        core.configurePortamento(state.portamentoMode, state.portamentoMs, v)
        publishState()
    }

    private fun configureTercaOnly(enabled: Boolean, degree: HarmonyDegree = state.tercaDegree) {
        // TERCA is a single generated harmony voice and is hard-routed only to UPPER 3.
        // No other harmony/interval voice is allowed to remain active.
        core.setHarmonyVoice(0, enabled, degree, outputChannel = preferences.upper3Channel)
        for (index in 1..3) {
            core.setHarmonyVoice(index, false, HarmonyDegree.UNISON, outputChannel = -1)
        }
        for (index in 0..3) core.setIntervalVoice(index, false, 0)
    }

    fun setHarmonyEnabled(enabled: Boolean) {
        val wasEnabled = state.harmonyEnabled
        if (!enabled && wasEnabled) {
            safeSendScheduled(core.flushHarmony(System.nanoTime()))
        }

        // TERCA changes only TERCA state. Shared MIDI-channel ownership is resolved
        // afterwards by the isolation router without changing PORTA or RIBBON settings.
        preferences.harmonyEnabled = enabled
        preferences.intervalMode = IntervalMode.SCALE
        preferences.harmonyVoiceMask = if (enabled) 1 else 0
        configureTercaOnly(enabled, state.tercaDegree)
        state = state.copy(
            harmonyEnabled = enabled,
            intervalMode = IntervalMode.SCALE,
            harmonyVoiceMask = if (enabled) 1 else 0,
            activePresetName = null
        )
        reconcileTercaPortamentoOwnership(wasEnabled, enabled)
        publishState()
    }

    fun setIntervalMode(mode: IntervalMode) {
        if (mode == state.intervalMode) return
        // Terminate notes generated by the previous algorithm before switching.
        safeSendScheduled(core.flushHarmony(System.nanoTime()))
        safeSendScheduled(core.flushIntervals(System.nanoTime()))
        preferences.intervalMode = mode
        state = state.copy(intervalMode = mode, activePresetName = null)
        publishState()
    }

    fun setHarmonyKey(tonic: Int, scale: ScaleType) {
        preferences.harmonyTonic = tonic.coerceIn(0, 11)
        preferences.harmonyScale = scale
        core.configureHarmony(preferences.harmonyTonic, scale)
        state = state.copy(harmonyTonic = preferences.harmonyTonic, harmonyScale = scale, activePresetName = null)
        publishState()
    }

    fun setHarmonyVoice(index: Int, enabled: Boolean, degree: HarmonyDegree, octaves: Int = 0) {
        // The live product exposes only TERCA. Reject hidden/legacy harmony voices so
        // nothing can ever generate harmony on UPPER 1/2 or another MIDI channel.
        if (index != 0) return
        val wasEnabled = state.harmonyEnabled
        val effectiveDegree = if (degree == HarmonyDegree.THIRD_DOWN) HarmonyDegree.THIRD_DOWN else HarmonyDegree.THIRD
        if (!enabled && wasEnabled) safeSendScheduled(core.flushHarmony(System.nanoTime()))
        preferences.tercaDegree = effectiveDegree
        preferences.harmonyEnabled = enabled
        preferences.harmonyVoiceMask = if (enabled) 1 else 0
        preferences.intervalMode = IntervalMode.SCALE
        configureTercaOnly(enabled, effectiveDegree)
        state = state.copy(
            harmonyEnabled = enabled,
            intervalMode = IntervalMode.SCALE,
            tercaDegree = effectiveDegree,
            harmonyVoiceMask = if (enabled) 1 else 0,
            activePresetName = null
        )
        reconcileTercaPortamentoOwnership(wasEnabled, enabled)
        publishState()
    }

    fun toggleTercaScan() {
        if (state.tercaScanActive) {
            tercaScanNotes.clear()
            tercaScanChannel = null
            state = state.copy(tercaScanActive = false)
            addMonitor("TERCA SCAN cancelled")
            publishState()
            return
        }
        if (!transport.isConnected()) {
            publishError("Connect the KORG before TERCA SCAN")
            return
        }
        if (!transport.canReceiveMidi()) {
            publishError("TERCA SCAN needs MIDI from KORG → phone. Reconnect using a From KORG port.")
            return
        }
        safeSendScheduled(core.flushHarmony(System.nanoTime()))
        tercaScanNotes.clear()
        tercaScanChannel = null
        state = state.copy(tercaScanActive = true, intervalMode = IntervalMode.SCALE, activePresetName = null)
        preferences.intervalMode = IntervalMode.SCALE
        addMonitor("TERCA SCAN: play 3 notes together")
        publishState()
    }

    private fun consumeTercaScanNote(note: Int, noteOn: Boolean) {
        if (!state.tercaScanActive) return
        if (!noteOn) {
            tercaScanNotes.remove(note.coerceIn(0, 127))
            return
        }
        tercaScanNotes.add(note.coerceIn(0, 127))
        if (tercaScanNotes.size < 3) {
            publishState()
            return
        }

        val notes = tercaScanNotes.take(3).toIntArray()
        tercaScanNotes.clear()
        val scan = core.scanTercaChord(notes)
        if (scan == null) {
            // Invalid scan never destroys the last valid terca setup and never
            // changes the user's ON/OFF choice.
            state = state.copy(tercaScanActive = false)
            tercaScanChannel = null
            addMonitor("TERCA SCAN rejected: ${notes.joinToString("-")}")
            publishError("TERCA SCAN: invalid 3-note combination")
            publishState()
            return
        }

        preferences.harmonyTonic = scan.tonic
        preferences.harmonyScale = scan.scale
        preferences.tercaDegree = scan.degree
        preferences.intervalMode = IntervalMode.SCALE
        // SCAN is only a command recognizer. It must never change the live
        // performance routing: the three scan notes may be played from the
        // arranger's left-hand/chord zone. PORTA and TERCA continue listening only
        // to the explicitly configured RIGHT-HAND / UPPER input channel.
        val mask = if (state.harmonyEnabled) 1 else 0
        preferences.harmonyVoiceMask = mask
        core.configureHarmony(scan.tonic, scan.scale)
        configureTercaOnly(state.harmonyEnabled, scan.degree)
        state = state.copy(
            intervalMode = IntervalMode.SCALE,
            harmonyTonic = scan.tonic,
            harmonyScale = scan.scale,
            tercaDegree = scan.degree,
            tercaScanActive = false,
            harmonyVoiceMask = mask,
            performanceInputChannel = preferences.performanceInputChannel,
            activePresetName = null
        )
        val learnedChannel = tercaScanChannel
        tercaScanChannel = null
        val direction = if (scan.degree == HarmonyDegree.THIRD_DOWN) "DOWN" else "UP"
        addMonitor("TERCA SCAN accepted: tonic=${scan.tonic} scale=${scan.scale.name} $direction CH${(learnedChannel ?: preferences.performanceInputChannel) + 1}")
        publishState()
    }

    fun setMidiThru(enabled: Boolean) {
        preferences.midiThru = enabled
        state = state.copy(midiThru = enabled, activePresetName = null)
        publishState()
    }

    fun runtimeSettings(): MidiRuntimeSettings = MidiRuntimeSettings(
        performanceInputChannel = preferences.performanceInputChannel,
        performanceInputOmni = preferences.performanceInputOmni,
        upper1Channel = preferences.upper1Channel,
        upper2Channel = preferences.upper2Channel,
        upper3Channel = preferences.upper3Channel,
        midiThru = preferences.midiThru,
        pitchBendRangeSemitones = preferences.pitchBendRangeSemitones,
        autoReconnect = preferences.autoReconnect
    )

    fun applyRuntimeSettings(settings: MidiRuntimeSettings) {
        val oldUpper3Channel = preferences.upper3Channel
        val normalized = settings.copy(
            performanceInputChannel = settings.performanceInputChannel.coerceIn(0, 15),
            upper1Channel = settings.upper1Channel.coerceIn(0, 15),
            upper2Channel = settings.upper2Channel.coerceIn(0, 15),
            upper3Channel = settings.upper3Channel.coerceIn(0, 15),
            pitchBendRangeSemitones = settings.pitchBendRangeSemitones.coerceIn(1, 96)
        )
        if (transport.isConnected()) panic()
        else if (state.harmonyEnabled && oldUpper3Channel != normalized.upper3Channel) {
            safeSendScheduled(core.flushHarmony(System.nanoTime()))
        }

        preferences.performanceInputChannel = normalized.performanceInputChannel
        preferences.performanceInputOmni = false
        preferences.upper1Channel = normalized.upper1Channel
        preferences.upper2Channel = normalized.upper2Channel
        preferences.upper3Channel = normalized.upper3Channel
        preferences.midiThru = normalized.midiThru
        preferences.pitchBendRangeSemitones = normalized.pitchBendRangeSemitones
        preferences.autoReconnect = normalized.autoReconnect
        transport.setAutoReconnect(normalized.autoReconnect)

        state = state.copy(
            midiThru = normalized.midiThru,
            performanceInputChannel = normalized.performanceInputChannel,
            performanceInputOmni = false,
            upper1Channel = normalized.upper1Channel,
            upper2Channel = normalized.upper2Channel,
            upper3Channel = normalized.upper3Channel,
            pitchBendRangeSemitones = normalized.pitchBendRangeSemitones,
            autoReconnect = normalized.autoReconnect,
            activePresetName = null
        )

        configureTercaOnly(state.harmonyVoiceMask and 1 != 0, state.tercaDegree)

        configureRibbonRoute(
            state.ribbonOutput,
            normalized.upper1Channel,
            16, 0.10
        )
        if (transport.isConnected()) {
            applyPortamentoToTargets(sendSwitch = true, sendTime = true)
            if (state.appSidePortamento) {
                targetChannels().forEach { ch -> safeSend(core.setPitchBendRange(ch, normalized.pitchBendRangeSemitones)) }
            }
        }
        publishState()
    }

    fun presetNames(): List<String?> = presetStore.names()

    fun savePreset(slot: Int, name: String): Boolean {
        val preset = PerformancePreset(
            name = name.trim().take(32).ifBlank { "Preset ${slot + 1}" },
            modelId = state.selectedModelId,
            portamentoEnabled = state.portamentoEnabled,
            portamentoMode = state.portamentoMode,
            portamentoMs = state.portamentoMs,
            portamentoDepth = state.portamentoDepth,
            appSidePortamento = state.appSidePortamento,
            targetUpperMask = state.targetUpperMask,
            harmonyEnabled = state.harmonyEnabled,
            intervalMode = state.intervalMode,
            harmonyTonic = state.harmonyTonic,
            harmonyScale = state.harmonyScale,
            tercaDegree = state.tercaDegree,
            harmonyVoiceMask = state.harmonyVoiceMask,
            ribbonOutput = state.ribbonOutput,
            ribbonRelease = state.ribbonRelease,
            padBank = state.padBank,
            midiThru = preferences.midiThru,
            performanceInputChannel = preferences.performanceInputChannel,
            performanceInputOmni = false,
            upper1Channel = preferences.upper1Channel,
            upper2Channel = preferences.upper2Channel,
            upper3Channel = preferences.upper3Channel,
            pitchBendRangeSemitones = preferences.pitchBendRangeSemitones,
            autoReconnect = preferences.autoReconnect,
            padBanks = (0..2).map { padStore.loadBank(it) }
        )
        val ok = presetStore.save(slot, preset)
        if (ok) {
            state = state.copy(activePresetName = preset.name)
            publishState()
        }
        return ok
    }

    fun clearPreset(slot: Int): Boolean {
        val cleared = presetStore.clear(slot)
        if (cleared) {
            state = state.copy(activePresetName = null)
            publishState()
        }
        return cleared
    }

    fun loadPreset(slot: Int): Boolean {
        val p = presetStore.load(slot) ?: return false
        if (KorgModels.supportedTargets.none { it.id == p.modelId }) return false
        if (transport.isConnected()) panic()

        // Preserve the full saved portamento target mask. UPPER 3 is only
        // temporarily withheld from portamento while TERCA is ON.
        val loadedTargetMask = p.targetUpperMask

        preferences.selectedModelId = p.modelId
        preferences.portamentoEnabled = p.portamentoEnabled
        preferences.portamentoMode = p.portamentoMode
        preferences.portamentoDurationMs = p.portamentoMs
        preferences.portamentoDepth = p.portamentoDepth
        preferences.appSidePortamento = p.appSidePortamento
        preferences.targetUpperMask = loadedTargetMask
        preferences.harmonyEnabled = p.harmonyEnabled
        preferences.intervalMode = IntervalMode.SCALE
        preferences.harmonyTonic = p.harmonyTonic
        preferences.harmonyScale = p.harmonyScale
        preferences.tercaDegree = p.tercaDegree
        preferences.harmonyVoiceMask = if (p.harmonyEnabled) 1 else 0
        preferences.ribbonOutput = p.ribbonOutput
        preferences.ribbonRelease = RibbonRelease.CENTER
        preferences.padBank = p.padBank
        preferences.midiThru = p.midiThru
        preferences.performanceInputChannel = p.performanceInputChannel
        preferences.performanceInputOmni = false
        preferences.upper1Channel = p.upper1Channel
        preferences.upper2Channel = p.upper2Channel
        preferences.upper3Channel = p.upper3Channel
        preferences.pitchBendRangeSemitones = p.pitchBendRangeSemitones
        preferences.autoReconnect = p.autoReconnect

        p.padBanks.take(3).forEachIndexed { bank, pads ->
            pads.take(16).forEachIndexed { index, cfg -> padStore.save(bank, index, cfg) }
        }

        core.selectModel(p.modelId)
        applyStoredCalibration(p.modelId)
        core.configurePortamento(p.portamentoMode, p.portamentoMs, p.portamentoDepth)
        core.setPortamentoEngineEnabled(p.portamentoEnabled)
        core.configureHarmony(p.harmonyTonic, p.harmonyScale)
        configureTercaOnly(p.harmonyEnabled, p.tercaDegree)
        initializePadBanks()
        core.setPadBank(p.padBank)
        ribbonChannel = p.upper1Channel
        core.configureRibbon(p.ribbonOutput, ribbonChannel, 16, 0.10, RibbonRelease.CENTER)
        transport.setAutoReconnect(p.autoReconnect)

        val loadedRibbonOutput = p.ribbonOutput

        state = state.copy(
            selectedModelId = p.modelId,
            portamentoEnabled = p.portamentoEnabled,
            portamentoMode = p.portamentoMode,
            portamentoMs = p.portamentoMs,
            portamentoDepth = p.portamentoDepth,
            appSidePortamento = p.appSidePortamento,
            targetUpperMask = loadedTargetMask,
            harmonyEnabled = p.harmonyEnabled,
            intervalMode = IntervalMode.SCALE,
            harmonyTonic = p.harmonyTonic,
            harmonyScale = p.harmonyScale,
            tercaDegree = p.tercaDegree,
            tercaScanActive = false,
            harmonyVoiceMask = if (p.harmonyEnabled) 1 else 0,
            ribbonOutput = loadedRibbonOutput,
            ribbonRelease = RibbonRelease.CENTER,
            padBank = p.padBank,
            padConfigs = padStore.loadBank(p.padBank),
            midiThru = p.midiThru,
            performanceInputChannel = p.performanceInputChannel,
            performanceInputOmni = false,
            upper1Channel = p.upper1Channel,
            upper2Channel = p.upper2Channel,
            upper3Channel = p.upper3Channel,
            pitchBendRangeSemitones = p.pitchBendRangeSemitones,
            autoReconnect = p.autoReconnect,
            activePresetName = p.name
        )

        configureRibbonRoute(
            state.ribbonOutput,
            preferences.upper1Channel,
            16, 0.10
        )

        if (transport.isConnected()) {
            applyPortamentoToTargets(sendSwitch = true, sendTime = true)
            if (p.appSidePortamento) targetChannels().forEach { safeSend(core.setPitchBendRange(it, p.pitchBendRangeSemitones)) }
        }
        publishState()
        return true
    }

    fun configureRibbon(output: RibbonOutput, release: RibbonRelease = RibbonRelease.CENTER, cc: Int = 16, smoothing: Double = 0.10) {
        // Pitch Bend Ribbon and app-side portamento are mixed by PitchBendMixer,
        // so both effects can stay active on the same channel without overwriting
        // one another.
        val centeredRelease = RibbonRelease.CENTER
        preferences.ribbonOutput = output
        preferences.ribbonRelease = centeredRelease
        configureRibbonRoute(output, preferences.upper1Channel, cc, smoothing)
        state = state.copy(ribbonOutput = output, ribbonRelease = centeredRelease, activePresetName = null)
        publishState()
    }

    fun ribbon(position: Double) {
        val raw = core.ribbon(position.coerceIn(0.0, 1.0), System.nanoTime())
        safeSend(fanOutRibbon(raw))
    }

    fun ribbonRelease() {
        val raw = core.ribbonRelease(System.nanoTime())
        safeSend(fanOutRibbon(raw))
    }

    fun selectPadBank(bank: Int) {
        val b = bank.coerceIn(0, 2)
        if (b == state.padBank) return
        safeSend(core.flushPads(System.nanoTime()))
        // Switching captures the current native bank before loading the destination bank.
        core.setPadBank(b)
        preferences.padBank = b
        state = state.copy(padBank = b, padConfigs = padStore.loadBank(b), activePresetName = null)
        publishState()
    }

    fun configurePad(index: Int, config: PadConfig) {
        if (index !in 0..15) return
        // Editing a latched/momentary pad must first terminate any active note/CC.
        safeSend(core.flushPads(System.nanoTime()))
        val normalized = config.copy(
            label = config.label.trim().take(24).ifBlank { "PAD ${index + 1}" },
            channel = config.channel.coerceIn(0, 15),
            number = config.number.coerceIn(0, 127),
            onValue = config.onValue.coerceIn(0, 127),
            offValue = config.offValue.coerceIn(0, 127)
        )
        padStore.save(state.padBank, index, normalized)
        core.setPad(index, normalized.type, normalized.channel, normalized.number,
            normalized.onValue, normalized.offValue, normalized.momentary)
        val configs = state.padConfigs.toMutableList().let { list ->
            while (list.size < 16) list += padStore.default(list.size)
            list[index] = normalized
            list
        }
        state = state.copy(padConfigs = configs, activePresetName = null)
        publishState()
    }

    fun resetCurrentPadBank() {
        safeSend(core.flushPads(System.nanoTime()))
        padStore.resetBank(state.padBank)
        val defaults = padStore.loadBank(state.padBank)
        defaults.forEachIndexed { index, c ->
            core.setPad(index, c.type, c.channel, c.number, c.onValue, c.offValue, c.momentary)
        }
        state = state.copy(padConfigs = defaults, activePresetName = null)
        publishState()
    }

    fun pressPad(index: Int) { safeSend(core.pressPad(index, System.nanoTime())) }
    fun releasePad(index: Int) { safeSend(core.releasePad(index, System.nanoTime())) }

    fun panic() {
        dispatcher.invalidateAll()
        pitchBendMixer.resetAll()
        safeSend(core.flushPads(System.nanoTime()))
        safeSendScheduled(core.flushHarmony(System.nanoTime()))
        safeSendScheduled(core.flushIntervals(System.nanoTime()))
        safeSendScheduled(core.resetPortaBridge(System.nanoTime()))
        safeSend(core.panic(true, preferences.midiChannel))
    }

    fun requestIdentity() {
        safeSend(arrayOf(core.identityRequest()))
    }

    /** Used by a calibrated/bridge workflow for exact app-side pitch trajectories. */
    fun sendAppSideGlide(startNote: Int, endNote: Int, bendRangeSemitones: Int = 12) {
        // Manual/test glide entry points obey the same hard keyboard split.
        if (startNote <= CHORD_ZONE_MAX_NOTE || endNote <= CHORD_ZONE_MAX_NOTE) return
        val ch = targetChannels().firstOrNull() ?: return
        safeSend(core.setPitchBendRange(ch, bendRangeSemitones))
        val start = System.nanoTime() + 2_000_000L
        dispatcher.replaceChannel(ch, core.buildGlide(startNote, endNote, start, ch, bendRangeSemitones))
    }

    private fun configureRibbonRoute(output: RibbonOutput, channel: Int, cc: Int, smoothing: Double) {
        // Ribbon is a right-hand/UPPER controller, not a PORTA target selector.
        // Keep it independent from the U1/U2/U3 portamento mask and fan it out to
        // all three Upper MIDI channels. This also lets PORTA + TERCA + RIBBON run
        // together: U3 can carry TERCA while still receiving the same ribbon bend.
        val newChannels = effectRouter.ribbonChannels(
            preferences.upper1Channel, preferences.upper2Channel, preferences.upper3Channel
        )

        val routeChanged = newChannels != ribbonChannels
        val leavingPitchBend = configuredRibbonOutput == RibbonOutput.PITCH_BEND && output != RibbonOutput.PITCH_BEND
        if ((routeChanged || leavingPitchBend) && configuredRibbonOutput == RibbonOutput.PITCH_BEND && transport.isConnected()) {
            ribbonChannels.forEach { ch -> safeSend(arrayOf(pitchBendMixer.centerRibbon(ch))) }
        }
        if (routeChanged) {
            ribbonChannels.forEach { pitchBendMixer.resetChannel(it) }
        }

        ribbonChannels = newChannels.ifEmpty { listOf(channel.coerceIn(0, 15)) }
        ribbonChannel = ribbonChannels.first()
        configuredRibbonOutput = output
        core.configureRibbon(output, ribbonChannel, cc, smoothing, RibbonRelease.CENTER)
    }

    private fun fanOutRibbon(raw: ByteArray): Array<ByteArray> {
        if (raw.size < 3) return arrayOf(raw)
        val status = raw[0].toInt() and 0xFF
        val command = status and 0xF0
        if (command != 0xE0 && command != 0xB0) return arrayOf(raw)

        return ribbonChannels.map { ch ->
            val routed = raw.copyOf()
            routed[0] = (command or ch.coerceIn(0, 15)).toByte()
            if (state.ribbonOutput == RibbonOutput.PITCH_BEND) {
                pitchBendMixer.applyRibbon(routed)
            } else {
                routed
            }
        }.toTypedArray()
    }

    private fun initializePadBanks() {
        // Populate all three native banks from persistent mappings, then return to the saved bank.
        for (bank in 0..2) {
            core.setPadBank(bank)
            padStore.loadBank(bank).forEachIndexed { index, c ->
                core.setPad(index, c.type, c.channel, c.number, c.onValue, c.offValue, c.momentary)
            }
        }
        core.setPadBank(preferences.padBank)
    }

    private fun applyStoredCalibration(modelId: String) {
        val table = calibrationStore.load(modelId) ?: return
        if (!core.setPortamentoCalibration(table.cc, table.milliseconds)) {
            calibrationStore.clear(modelId)
        }
    }

    private fun targetChannels(): List<Int> = targetChannelsForMask(state.targetUpperMask)

    private fun selectedPortamentoChannels(mask: Int = state.targetUpperMask): List<Int> =
        effectRouter.selectedPortamentoChannels(
            mask, preferences.upper1Channel, preferences.upper2Channel, preferences.upper3Channel
        )

    private fun targetChannelsForMask(mask: Int): List<Int> =
        effectRouter.selectedPortamentoChannels(
            mask, preferences.upper1Channel, preferences.upper2Channel, preferences.upper3Channel
        )

    /**
     * TERCA never disables or reconfigures PORTA/RIBBON.  The only runtime action
     * needed when TERCA toggles is to clear the app-side U3 note bridge so U3 can
     * change cleanly between the main note stream and the generated TERCA stream.
     * Hardware PORTA stays enabled on U3 when the user selected U3.
     */
    private fun reconcileTercaPortamentoOwnership(wasTercaEnabled: Boolean, isTercaEnabled: Boolean) {
        if (wasTercaEnabled == isTercaEnabled) return
        if (state.targetUpperMask and 4 == 0) return
        if (!state.appSidePortamento || !state.portamentoEnabled) return

        val u3 = effectRouter.tercaChannel(preferences.upper3Channel)
        dispatcher.invalidateChannel(u3)
        // If TERCA was active, U3 may own a synthetic generated note and needs a
        // real NoteOff. If we are merely entering TERCA from the local main voice,
        // reset only Pitch Bend so a locally sounding/muted Upper is not touched.
        resetPortaChannel(u3, syntheticNoteOwner = wasTercaEnabled)
        safeSend(core.setPitchBendRange(u3, preferences.pitchBendRangeSemitones))
    }

    private fun applyPortamentoToTargets(sendSwitch: Boolean, sendTime: Boolean) {
        targetChannels().forEach { ch ->
            if (sendSwitch) safeSend(core.hardwarePortamentoSwitch(state.portamentoEnabled && !state.appSidePortamento, ch))
            if (sendTime && !state.appSidePortamento) safeSend(core.applyPortamentoTime(ch))
        }
    }

    private fun safeSend(messages: Array<ByteArray>) {
        if (!transport.isConnected()) return
        messages.forEach { bytes ->
            runCatching {
                transport.send(bytes)
                if (state.monitorEnabled) addMonitor("OUT ${MidiMessageFormatter.format(bytes)}")
            }.onFailure { publishError(it.message ?: "MIDI send failed") }
        }
    }

    /**
     * TERCA is deliberately note-only and UPPER-3-only.  It must never send
     * Program Change, CC, track Play/Mute or any other message that could alter
     * the current KORG Keyboard Set/Performance.  Whether externally received
     * U3 notes are audible while U3 is muted is owned by the keyboard's
     * GLOBAL > MIDI > MIDI In Controls > Track Mute Active setting.
     */
    private fun safeSendTercaNotesOnly(messages: Array<ByteArray>, upper3Channel: Int) {
        val u3 = upper3Channel.coerceIn(0, 15)
        val noteOnly = messages.mapNotNull { bytes ->
            if (bytes.size < 3) return@mapNotNull null
            val status = bytes[0].toInt() and 0xFF
            val command = status and 0xF0
            if (command != 0x80 && command != 0x90) return@mapNotNull null
            bytes.copyOf().also { it[0] = (command or u3).toByte() }
        }.toTypedArray()
        if (noteOnly.isNotEmpty()) safeSend(noteOnly)
    }

    private fun safeSendScheduled(messages: List<ScheduledMidi>) {
        if (!transport.isConnected() || messages.isEmpty()) return
        dispatcher.dispatchUnscoped(messages)
    }

    private fun safeSendPortaScheduled(channel: Int, messages: List<ScheduledMidi>) {
        if (!transport.isConnected()) return
        // Replacing the generation is essential: old pitch-bend tails must never
        // continue after a new note changes the intended glide trajectory.
        dispatcher.replaceChannel(channel, messages)
    }

    /**
     * Main-melody PORTA is a control overlay, not a note router. The keyboard keeps
     * ownership of which Upper tracks are sounding/muted; Silveton only sends the
     * generated Pitch Bend trajectory. This prevents selecting U1/U2/U3 in PORTA
     * from resurrecting a KORG Upper that the current Sound/Performance has muted.
     */
    private fun safeSendPortaControlScheduled(channel: Int, messages: List<ScheduledMidi>) {
        if (!transport.isConnected()) return
        val pitchOnly = messages.filter { event ->
            val bytes = event.bytes
            bytes.isNotEmpty() && ((bytes[0].toInt() and 0xF0) == 0xE0)
        }
        dispatcher.replaceChannel(channel, pitchOnly)
    }

    private fun resetPortaChannel(channel: Int, syntheticNoteOwner: Boolean) {
        val messages = core.resetPortaBridgeChannel(channel, System.nanoTime())
        if (syntheticNoteOwner) safeSendPortaScheduled(channel, messages)
        else safeSendPortaControlScheduled(channel, messages)
    }

    private fun resetSelectedPortaChannels() {
        val u3 = effectRouter.tercaChannel(preferences.upper3Channel)
        selectedPortamentoChannels().forEach { ch ->
            resetPortaChannel(ch, state.harmonyEnabled && ch == u3)
        }
    }

    override fun onDevicesChanged(devices: List<AndroidMidiTransport.Device>) {
        listeners.forEach { it.onDevicesChanged(devices) }
    }

    override fun onConnectionChanged(connected: Boolean, label: String?) {
        state = state.copy(connected = connected, connectionLabel = label, identityLabel = if (connected) state.identityLabel else null)
        if (connected) {
            // Metadata hint is safe: it only selects a profile when the Android device name itself names a supported model.
            KorgModels.guessFromDeviceText(label)?.let { guessed ->
                if (guessed.id != state.selectedModelId) selectModel(guessed.id)
            }
            // Push current state so the keyboard and app cannot silently diverge.
            applyPortamentoToTargets(sendSwitch = true, sendTime = true)
            if (!transport.canReceiveMidi()) {
                publishError("Connected output-only: RIBBON/CC can work, but TERCA and TIMES need a From KORG MIDI port.")
            }
            if (preferences.appSidePortamento) {
                targetChannels().forEach { ch -> safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones)) }
            }
            requestIdentity()
        } else {
            // Clear queued and native note state after a cable/device loss so reconnect cannot inherit stale notes.
            dispatcher.invalidateAll()
            core.resetPortaBridge(0L)
            core.flushHarmony(0L)
            core.flushIntervals(0L)
            core.flushPads(0L)
            pitchBendMixer.resetAll()
            decoder.reset()
            tercaScanNotes.clear()
            tercaScanChannel = null
            state = state.copy(tercaScanActive = false)
        }
        publishState()
    }

    override fun onMidiReceived(bytes: ByteArray, timestampNanos: Long) {
        val eventTime = if (timestampNanos > 0L) timestampNanos else System.nanoTime()
        val complete = decoder.push(bytes)
        for (msg in complete) {
            if (state.monitorEnabled) addMonitor("IN  ${MidiMessageFormatter.format(msg)}")
            processPerformanceMessage(msg, eventTime)
        }
    }

    private fun processPerformanceMessage(msg: ByteArray, timestampNanos: Long) {
        if (msg.isEmpty()) return
        val status = msg[0].toInt() and 0xFF
        if (status >= 0xF0) {
            handleSystemMidi(msg, status)
            return
        }

        val command = status and 0xF0
        val channel = status and 0x0F
        val isNoteMessage = command == 0x80 || command == 0x90

        // Global input firewall, not an effect: C4 and below belong exclusively to
        // the arranger chord section and are never delivered to any live effect.
        if (isNoteMessage && msg.size >= 3) {
            val note = msg[1].toInt() and 0x7F
            if (note <= CHORD_ZONE_MAX_NOTE) {
                if (state.monitorEnabled) addMonitor("CHORD BYPASS note=$note (C4 and below)")
                return
            }
        }

        // SCAN is a TERCA configuration gesture. While armed, its three notes are
        // consumed only by the scanner and never leak into the performance engines.
        if (handleTercaScanMessage(msg, command, channel, isNoteMessage)) return

        val isPerformanceChannel = channel == preferences.performanceInputChannel
        val portaBridgeActive = preferences.appSidePortamento && state.portamentoEnabled && isPerformanceChannel
        val isRoutedExpression = command == 0xA0 || command == 0xB0 || command == 0xD0
        val portaConsumesMessage = portaBridgeActive && (isNoteMessage || isRoutedExpression)

        // MIDI THRU is transport policy. It does not change any effect state.
        if (preferences.midiThru && !portaConsumesMessage) safeSend(arrayOf(msg))
        if (!isPerformanceChannel) return

        handlePortamentoPerformance(msg, command, isNoteMessage, isRoutedExpression, portaBridgeActive, timestampNanos)
        handleTercaPerformance(msg, command, channel, isNoteMessage, timestampNanos)
    }

    private fun handleSystemMidi(msg: ByteArray, status: Int) {
        if (status != 0xF0 || msg.size < 6) return
        if (msg[1].toInt().and(0xFF) != 0x7E ||
            msg[3].toInt().and(0xFF) != 0x06 ||
            msg[4].toInt().and(0xFF) != 0x02) return

        val identity = core.parseIdentityReply(msg)
        if (identity != null) {
            val label = buildString {
                append(identity.manufacturerName)
                append(" F:").append(identity.familyCodeHex)
                append(" M:").append(identity.modelNumberHex)
                if (identity.versionHex.isNotBlank()) append(" V:").append(identity.versionHex)
            }
            state = state.copy(identityLabel = label)
            publishState()
            addMonitor("IDENTITY $label  ${MidiMessageFormatter.format(msg)}")
        } else {
            addMonitor("IDENTITY (unparsed)  ${MidiMessageFormatter.format(msg)}")
        }
    }

    private fun handleTercaScanMessage(
        msg: ByteArray,
        command: Int,
        channel: Int,
        isNoteMessage: Boolean
    ): Boolean {
        if (!state.tercaScanActive || !isNoteMessage || msg.size < 3) return false
        val note = msg[1].toInt() and 0x7F
        val velocity = msg[2].toInt() and 0x7F
        val noteOn = command == 0x90 && velocity > 0
        val noteOff = command == 0x80 || (command == 0x90 && velocity == 0)
        if (noteOn && tercaScanChannel == null) tercaScanChannel = channel
        if (tercaScanChannel != channel || (!noteOn && !noteOff)) return false
        consumeTercaScanNote(note, noteOn)
        return true
    }

    private fun handlePortamentoPerformance(
        msg: ByteArray,
        command: Int,
        isNoteMessage: Boolean,
        isRoutedExpression: Boolean,
        bridgeActive: Boolean,
        timestampNanos: Long
    ) {
        if (!bridgeActive) return

        if (isRoutedExpression) {
            // PORTA owns only its pitch trajectory. Expression/breath/aftertouch
            // routing remains the keyboard/Juzisound's job and is never duplicated
            // just because an Upper was selected for PORTA.
            return
        }

        if (!isNoteMessage || msg.size < 3) return
        val note = msg[1].toInt() and 0x7F
        val velocity = msg[2].toInt() and 0x7F
        val noteOn = command == 0x90 && velocity > 0
        val noteOff = command == 0x80 || (command == 0x90 && velocity == 0)
        if (!noteOn && !noteOff) return

        // Main PORTA never sends Note On/Off to KORG: it only derives a Pitch Bend
        // trajectory from the played note stream. Therefore KORG keeps ownership of
        // active/muted Uppers. When TERCA is ON, U3 is still excluded from the main
        // detector because its generated TERCA note has its own independent bridge.
        val u3 = effectRouter.tercaChannel(preferences.upper3Channel)
        val mainNoteChannels = if (state.harmonyEnabled) targetChannels().filterNot { it == u3 } else targetChannels()
        mainNoteChannels.forEach { outCh ->
            if (noteOn) {
                safeSendPortaControlScheduled(outCh, core.portaBridgeNoteOn(
                    outCh, note, velocity, timestampNanos, preferences.pitchBendRangeSemitones))
            } else {
                safeSendPortaControlScheduled(outCh, core.portaBridgeNoteOff(outCh, note, velocity, timestampNanos))
            }
        }
    }

    private fun handleTercaPerformance(
        msg: ByteArray,
        command: Int,
        inputChannel: Int,
        isNoteMessage: Boolean,
        timestampNanos: Long
    ) {
        if (!state.harmonyEnabled || !isNoteMessage || msg.size < 3) return
        val note = msg[1].toInt() and 0x7F
        val velocity = msg[2].toInt() and 0x7F
        val noteOn = command == 0x90 && velocity > 0
        val noteOff = command == 0x80 || (command == 0x90 && velocity == 0)
        val generated = when {
            noteOn -> core.harmonyNoteOn(inputChannel, note, velocity, timestampNanos)
            noteOff -> core.harmonyNoteOff(inputChannel, note, velocity, timestampNanos)
            else -> emptyArray()
        }
        if (generated.isEmpty()) return

        val u3 = effectRouter.tercaChannel(preferences.upper3Channel)
        val u3PortaSelected = state.targetUpperMask and 4 != 0
        val routeTercaThroughAppPorta = state.appSidePortamento && state.portamentoEnabled && u3PortaSelected

        if (!routeTercaThroughAppPorta) {
            // Hardware PORTA, PORTA-off, or U3 not selected: TERCA sends NOTE data
            // only to U3.  It never changes U3 Play/Mute or the Keyboard Set.
            // On KORG PA, enable GLOBAL > MIDI > MIDI In Controls > Track Mute Active
            // so a muted U3 stays silent until the player unmutes it on the keyboard.
            safeSendTercaNotesOnly(generated, u3)
            return
        }

        // App-side TIMES: TERCA remains its own note generator on U3, but its
        // generated note is fed to U3's independent portamento bridge.  RIBBON is
        // mixed later by PitchBendMixer, so all three effects remain fully active.
        generated.forEach { bytes ->
            if (bytes.size < 3) {
                safeSend(arrayOf(bytes))
                return@forEach
            }
            val st = bytes[0].toInt() and 0xFF
            val cmd = st and 0xF0
            val outCh = st and 0x0F
            if (outCh != u3 || (cmd != 0x80 && cmd != 0x90)) {
                safeSend(arrayOf(bytes))
                return@forEach
            }
            val generatedNote = bytes[1].toInt() and 0x7F
            val generatedVelocity = bytes[2].toInt() and 0x7F
            val generatedOn = cmd == 0x90 && generatedVelocity > 0
            if (generatedOn) {
                safeSendPortaScheduled(u3, core.portaBridgeNoteOn(
                    u3, generatedNote, generatedVelocity, timestampNanos, preferences.pitchBendRangeSemitones))
            } else {
                safeSendPortaScheduled(u3, core.portaBridgeNoteOff(
                    u3, generatedNote, generatedVelocity, timestampNanos))
            }
        }
    }

    override fun onError(message: String) = publishError(message)

    private fun addMonitor(line: String) {
        val stamped = "${SystemClock.elapsedRealtime()}  $line"
        synchronized(monitor) {
            while (monitor.size >= 256) monitor.removeFirst()
            monitor.addLast(stamped)
        }
        listeners.forEach { it.onMonitorLine(stamped) }
    }

    private fun publishState() { listeners.forEach { it.onStateChanged(state) } }
    private fun publishError(message: String) { listeners.forEach { it.onError(message) } }

    override fun close() {
        if (transport.isConnected()) runCatching { panic() }
        dispatcher.close()
        transport.removeListener(this)
        transport.close()
        core.close()
    }
}
