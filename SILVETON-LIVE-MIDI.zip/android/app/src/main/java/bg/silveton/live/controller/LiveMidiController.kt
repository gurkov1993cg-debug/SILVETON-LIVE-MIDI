package bg.silveton.live.controller

import android.content.Context
import android.media.midi.MidiDeviceInfo
import android.os.SystemClock
import bg.silveton.live.midi.*
import bg.silveton.live.model.AppPreferences
import bg.silveton.live.model.KorgModels
import bg.silveton.live.model.PortamentoCalibrationStore
import bg.silveton.live.model.PadConfigurationStore
import bg.silveton.live.model.PadConfig
import bg.silveton.live.model.MidiRuntimeSettings
import bg.silveton.live.model.PerformancePreset
import bg.silveton.live.model.PerformancePresetStore
import java.io.Closeable
import java.util.ArrayDeque
import java.util.concurrent.CopyOnWriteArrayList

class LiveMidiController(context: Context) : Closeable, AndroidMidiTransport.Listener {
    data class State(
        val connected: Boolean = false,
        val connectionLabel: String? = null,
        val identityLabel: String? = null,
        val selectedModelId: String = "pa600",
        val portamentoEnabled: Boolean = false,
        val portamentoMode: PortaMode = PortaMode.FIX,
        val portamentoMs: Double = 20.0,
        val portamentoDepth: Double = 1.0,
        val appSidePortamento: Boolean = false,
        val targetUpperMask: Int = 1,
        val harmonyEnabled: Boolean = false,
        val intervalMode: IntervalMode = IntervalMode.SCALE,
        val harmonyTonic: Int = 0,
        val harmonyScale: ScaleType = ScaleType.MAJOR,
        val tercaDegree: HarmonyDegree = HarmonyDegree.THIRD,
        val tercaScanActive: Boolean = false,
        val harmonyVoiceMask: Int = 1,
        val ribbonOutput: RibbonOutput = RibbonOutput.CONTROL_CHANGE,
        val ribbonRelease: RibbonRelease = RibbonRelease.CENTER,
        val padBank: Int = 0,
        val padConfigs: List<PadConfig> = emptyList(),
        val monitorEnabled: Boolean = false,
        val midiThru: Boolean = false,
        val performanceInputChannel: Int = 0,
        val performanceInputOmni: Boolean = false,
        val upper1Channel: Int = 0,
        val upper2Channel: Int = 1,
        val upper3Channel: Int = 2,
        val pitchBendRangeSemitones: Int = 12,
        val autoReconnect: Boolean = true,
        val activePresetName: String? = null
    )

    interface Listener {
        fun onStateChanged(state: State) {}
        fun onDevicesChanged(devices: List<AndroidMidiTransport.Device>) {}
        fun onMonitorLine(line: String) {}
        fun onError(message: String) {}
    }

    val preferences = AppPreferences(context)
    private val calibrationStore = PortamentoCalibrationStore(context)
    private val padStore = PadConfigurationStore(context)
    private val presetStore = PerformancePresetStore(context)
    val transport = AndroidMidiTransport(context)
    val core = NativeMidiCore()
    private val pitchBendMixer = PitchBendMixer()
    private val dispatcher = MidiEventDispatcher(
        sendNow = { bytes ->
            transport.send(bytes, 0L)
            if (state.monitorEnabled) addMonitor("OUT ${MidiMessageFormatter.format(bytes)}")
        },
        transform = { bytes -> pitchBendMixer.applyPortamento(bytes) },
        onError = { publishError(it.message ?: "MIDI scheduled send failed") }
    )

    private val listeners = CopyOnWriteArrayList<Listener>()
    private val decoder = MidiStreamDecoder()
    private val monitor = ArrayDeque<String>(256)
    private val tercaScanNotes = LinkedHashSet<Int>()
    private var ribbonChannel = preferences.upper1Channel
    private var state = State(
        selectedModelId = preferences.selectedModelId,
        portamentoEnabled = preferences.portamentoEnabled,
        portamentoMode = preferences.portamentoMode,
        portamentoMs = preferences.portamentoDurationMs,
        portamentoDepth = preferences.portamentoDepth,
        appSidePortamento = preferences.appSidePortamento,
        targetUpperMask = preferences.targetUpperMask,
        harmonyEnabled = preferences.harmonyEnabled,
        intervalMode = preferences.intervalMode,
        harmonyTonic = preferences.harmonyTonic,
        harmonyScale = preferences.harmonyScale,
        tercaDegree = preferences.tercaDegree,
        harmonyVoiceMask = preferences.harmonyVoiceMask,
        ribbonOutput = preferences.ribbonOutput,
        ribbonRelease = RibbonRelease.CENTER,
        padBank = preferences.padBank,
        padConfigs = padStore.loadBank(preferences.padBank),
        midiThru = preferences.midiThru,
        performanceInputChannel = preferences.performanceInputChannel,
        performanceInputOmni = preferences.performanceInputOmni,
        upper1Channel = preferences.upper1Channel,
        upper2Channel = preferences.upper2Channel,
        upper3Channel = preferences.upper3Channel,
        pitchBendRangeSemitones = preferences.pitchBendRangeSemitones,
        autoReconnect = preferences.autoReconnect
    )

    init {
        // Ribbon is now permanently spring-centred; migrate any older saved release mode.
        preferences.ribbonRelease = RibbonRelease.CENTER
        state = state.copy(ribbonRelease = RibbonRelease.CENTER)
        core.selectModel(state.selectedModelId)
        applyStoredCalibration(state.selectedModelId)
        core.configurePortamento(state.portamentoMode, state.portamentoMs, state.portamentoDepth)
        core.setPortamentoEngineEnabled(state.portamentoEnabled)
        core.configureHarmony(preferences.harmonyTonic, preferences.harmonyScale)
        // TERCA is the only harmony voice exposed by the live UI.  Migrate older
        // presets/preferences so no hidden 5th/6th/octave voice can remain active.
        val tercaMask = if (preferences.harmonyEnabled) 1 else 0
        preferences.harmonyVoiceMask = tercaMask
        preferences.intervalMode = IntervalMode.SCALE
        var startupTargetMask = preferences.targetUpperMask
        if (preferences.harmonyEnabled && (startupTargetMask and 0x4) != 0) {
            startupTargetMask = startupTargetMask and 0x4.inv()
            if (startupTargetMask == 0) startupTargetMask = 0x1
            preferences.targetUpperMask = startupTargetMask
        }
        state = state.copy(
            harmonyVoiceMask = tercaMask,
            intervalMode = IntervalMode.SCALE,
            targetUpperMask = startupTargetMask
        )
        core.setHarmonyVoice(
            0, preferences.harmonyEnabled, preferences.tercaDegree,
            outputChannel = preferences.upper3Channel
        )
        for (index in 1..3) {
            core.setHarmonyVoice(index, false, HarmonyDegree.UNISON, outputChannel = -1)
            core.setIntervalVoice(index, false, 0)
        }
        core.setIntervalVoice(0, false, 0)
        ribbonChannel = preferences.upper1Channel
        core.configureRibbon(preferences.ribbonOutput, ribbonChannel, 16, 0.10, RibbonRelease.CENTER)
        initializePadBanks()
        transport.setAutoReconnect(preferences.autoReconnect)
        transport.addListener(this)
        if (preferences.autoReconnect) {
            preferences.lastDeviceKey?.let { transport.reconnect(it, preferences.lastInputPort, preferences.lastOutputPort) }
        }
    }

    fun addListener(listener: Listener) {
        listeners += listener
        listener.onStateChanged(state)
        listener.onDevicesChanged(transport.devices())
    }

    fun removeListener(listener: Listener) { listeners -= listener }
    fun state(): State = state
    fun monitorSnapshot(): List<String> = synchronized(monitor) { monitor.toList() }
    fun portamentoCalibration(): PortamentoCalibrationStore.Table? = calibrationStore.load(state.selectedModelId)

    fun selectModel(id: String) {
        if (KorgModels.supportedTargets.none { it.id == id }) return
        if (!core.selectModel(id)) return
        preferences.selectedModelId = id
        applyStoredCalibration(id)
        state = state.copy(selectedModelId = id, activePresetName = null)
        if (transport.isConnected()) {
            applyPortamentoToTargets(sendSwitch = true, sendTime = true)
            if (state.appSidePortamento) {
                targetChannels().forEach { ch -> safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones)) }
            }
        }
        publishState()
    }

    fun setPortamentoCalibration(cc: IntArray, milliseconds: DoubleArray): Boolean {
        val id = state.selectedModelId
        if (!calibrationStore.save(id, cc, milliseconds)) return false
        if (!core.setPortamentoCalibration(cc, milliseconds)) {
            calibrationStore.clear(id)
            return false
        }
        if (!state.appSidePortamento) applyPortamentoToTargets(sendSwitch = false, sendTime = true)
        return true
    }

    fun clearPortamentoCalibration() {
        calibrationStore.clear(state.selectedModelId)
        // Selecting the model resets native calibration to the built-in table (currently empty unless measured).
        core.selectModel(state.selectedModelId)
        if (!state.appSidePortamento) applyPortamentoToTargets(sendSwitch = false, sendTime = true)
    }

    fun connect(info: MidiDeviceInfo, inputPort: Int = 0, outputPort: Int = 0) {
        if (transport.isConnected()) panic()
        val d = AndroidMidiTransport.Device(info)
        KorgModels.guessFromDeviceText(d.manufacturer, d.product, d.label)?.let { selectModel(it.id) }
        preferences.lastDeviceKey = d.stableKey
        preferences.lastInputPort = inputPort
        preferences.lastOutputPort = outputPort
        transport.connect(info, inputPort, outputPort)
    }

    fun disconnect() {
        if (transport.isConnected()) panic()
        transport.disconnect(clearReconnectTarget = true)
    }

    fun setMonitorEnabled(enabled: Boolean) {
        state = state.copy(monitorEnabled = enabled)
        publishState()
    }

    fun setTargetUpper(index: Int, enabled: Boolean) {
        if (index !in 0..2) return
        if (index == 2 && enabled && state.harmonyEnabled) {
            publishError("UPPER 3 is reserved for TERCA while TERCA is ON")
            publishState()
            return
        }
        val oldMask = state.targetUpperMask
        val oldChannels = targetChannelsForMask(oldMask)
        if (preferences.appSidePortamento && state.portamentoEnabled) {
            dispatcher.invalidateAll()
            safeSendScheduled(core.resetPortaBridge(System.nanoTime()))
        }
        var mask = oldMask
        mask = if (enabled) mask or (1 shl index) else mask and (1 shl index).inv()
        if (mask == 0) mask = 1 shl index
        val newChannels = targetChannelsForMask(mask)

        // A channel removed from the target set must never keep a stale hardware
        // portamento switch from the previous selection. Explicitly release it
        // before committing the new mask.
        (oldChannels - newChannels.toSet()).forEach { ch ->
            safeSend(core.hardwarePortamentoSwitch(false, ch))
        }

        preferences.targetUpperMask = mask
        state = state.copy(targetUpperMask = mask, activePresetName = null)
        // Ribbon follows the first selected Upper target. Refresh its channel whenever
        // the target mask changes so U1/U2/U3 selection cannot leave a stale route.
        configureRibbonRoute(
            state.ribbonOutput,
            targetChannels().firstOrNull() ?: preferences.upper1Channel,
            16, 0.10
        )
        applyPortamentoToTargets(sendSwitch = true, sendTime = true)
        if (state.appSidePortamento && transport.isConnected()) {
            targetChannels().forEach { ch -> safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones)) }
        }
        publishState()
    }

    fun setAppSidePortamento(enabled: Boolean) {
        if (enabled == preferences.appSidePortamento) return
        dispatcher.invalidateAll()
        safeSendScheduled(core.resetPortaBridge(System.nanoTime()))
        preferences.appSidePortamento = enabled
        state = state.copy(appSidePortamento = enabled, activePresetName = null)
        configureRibbonRoute(state.ribbonOutput, targetChannels().firstOrNull() ?: preferences.upper1Channel, 16, 0.10)
        // Hardware portamento must be off while the app generates the pitch trajectory.
        targetChannels().forEach { ch ->
            safeSend(core.hardwarePortamentoSwitch(state.portamentoEnabled && !enabled, ch))
            if (enabled) safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones))
            else if (state.portamentoEnabled) safeSend(core.applyPortamentoTime(ch))
        }
        publishState()
    }

    fun setPortamentoEnabled(enabled: Boolean) {
        if (!enabled && state.portamentoEnabled && preferences.appSidePortamento) {
            dispatcher.invalidateAll()
            safeSendScheduled(core.resetPortaBridge(System.nanoTime()))
        }
        preferences.portamentoEnabled = enabled
        state = state.copy(portamentoEnabled = enabled, activePresetName = null)
        core.configurePortamento(state.portamentoMode, state.portamentoMs, state.portamentoDepth)
        core.setPortamentoEngineEnabled(enabled)
        targetChannels().forEach { ch ->
            safeSend(core.hardwarePortamentoSwitch(enabled && !state.appSidePortamento, ch))
            if (enabled && !state.appSidePortamento) safeSend(core.applyPortamentoTime(ch))
        }
        publishState()
    }

    fun setPortamentoMode(mode: PortaMode) {
        preferences.portamentoMode = mode
        state = state.copy(portamentoMode = mode, activePresetName = null)
        core.configurePortamento(mode, state.portamentoMs, state.portamentoDepth)
        // In hardware mode CC5 is updated; in TIMES/app mode the native curve is authoritative.
        if (!state.appSidePortamento) targetChannels().forEach { safeSend(core.applyPortamentoTime(it)) }
        publishState()
    }

    fun setPortamentoTime(ms: Double) {
        val v = ms.coerceIn(1.0, 5000.0)
        preferences.portamentoDurationMs = v
        state = state.copy(portamentoMs = v, activePresetName = null)
        core.configurePortamento(state.portamentoMode, v, state.portamentoDepth)
        if (!state.appSidePortamento) targetChannels().forEach { safeSend(core.applyPortamentoTime(it)) }
        publishState()
    }

    fun setPortamentoDepth(depth: Double) {
        val v = depth.coerceIn(0.05, 8.0)
        preferences.portamentoDepth = v
        state = state.copy(portamentoDepth = v, activePresetName = null)
        core.configurePortamento(state.portamentoMode, state.portamentoMs, v)
        publishState()
    }

    fun setHarmonyEnabled(enabled: Boolean) {
        if (!enabled && state.harmonyEnabled) {
            safeSendScheduled(core.flushHarmony(System.nanoTime()))
        }

        // Upper 3 is reserved for TERCA while it is enabled.  If an older setup
        // had U3 selected as a main portamento target, move the main voice to U1
        // instead of doubling the melody and the generated third on one track.
        var targetMask = state.targetUpperMask
        if (enabled && (targetMask and 0x4) != 0) {
            val oldChannels = targetChannelsForMask(targetMask)
            targetMask = targetMask and 0x4.inv()
            if (targetMask == 0) targetMask = 0x1
            preferences.targetUpperMask = targetMask
            state = state.copy(targetUpperMask = targetMask)
            val newChannels = targetChannelsForMask(targetMask)
            (oldChannels - newChannels.toSet()).forEach { ch ->
                safeSend(core.hardwarePortamentoSwitch(false, ch))
                dispatcher.invalidateChannel(ch)
            }
        }

        preferences.harmonyEnabled = enabled
        preferences.intervalMode = IntervalMode.SCALE
        preferences.harmonyVoiceMask = if (enabled) 1 else 0
        core.setHarmonyVoice(
            0, enabled, state.tercaDegree,
            outputChannel = preferences.upper3Channel
        )
        for (index in 1..3) core.setHarmonyVoice(index, false, HarmonyDegree.UNISON, outputChannel = -1)
        state = state.copy(
            harmonyEnabled = enabled,
            intervalMode = IntervalMode.SCALE,
            harmonyVoiceMask = if (enabled) 1 else 0,
            activePresetName = null
        )
        applyPortamentoToTargets(sendSwitch = true, sendTime = true)
        configureRibbonRoute(state.ribbonOutput, targetChannels().firstOrNull() ?: preferences.upper1Channel, 16, 0.10)
        publishState()
    }

    fun setIntervalMode(mode: IntervalMode) {
        if (mode == state.intervalMode) return
        // Terminate notes generated by the previous algorithm before switching.
        safeSendScheduled(core.flushHarmony(System.nanoTime()))
        safeSendScheduled(core.flushIntervals(System.nanoTime()))
        preferences.intervalMode = mode
        state = state.copy(intervalMode = mode, activePresetName = null)
        publishState()
    }

    fun setHarmonyKey(tonic: Int, scale: ScaleType) {
        preferences.harmonyTonic = tonic.coerceIn(0, 11)
        preferences.harmonyScale = scale
        core.configureHarmony(preferences.harmonyTonic, scale)
        state = state.copy(harmonyTonic = preferences.harmonyTonic, harmonyScale = scale, activePresetName = null)
        publishState()
    }

    fun setHarmonyVoice(index: Int, enabled: Boolean, degree: HarmonyDegree, octaves: Int = 0) {
        if (index !in 0..3) return
        val effectiveDegree = if (index == 0) state.tercaDegree else degree
        core.setHarmonyVoice(
            index, enabled, effectiveDegree, octaves,
            outputChannel = if (index == 0) preferences.upper3Channel else -1
        )
        val fixedSemitones = intArrayOf(4, 7, 9, 12)
        core.setIntervalVoice(index, enabled, fixedSemitones[index] + 12 * octaves)
        var mask = preferences.harmonyVoiceMask
        mask = if (enabled) mask or (1 shl index) else mask and (1 shl index).inv()
        preferences.harmonyVoiceMask = mask
        state = state.copy(harmonyVoiceMask = mask, activePresetName = null)
        publishState()
    }

    fun toggleTercaScan() {
        if (state.tercaScanActive) {
            tercaScanNotes.clear()
            state = state.copy(tercaScanActive = false)
            addMonitor("TERCA SCAN cancelled")
            publishState()
            return
        }
        safeSendScheduled(core.flushHarmony(System.nanoTime()))
        tercaScanNotes.clear()
        state = state.copy(tercaScanActive = true, intervalMode = IntervalMode.SCALE, activePresetName = null)
        preferences.intervalMode = IntervalMode.SCALE
        addMonitor("TERCA SCAN: play 3 notes together")
        publishState()
    }

    private fun consumeTercaScanNote(note: Int, noteOn: Boolean) {
        if (!state.tercaScanActive) return
        if (!noteOn) {
            tercaScanNotes.remove(note.coerceIn(0, 127))
            return
        }
        tercaScanNotes.add(note.coerceIn(0, 127))
        if (tercaScanNotes.size < 3) {
            publishState()
            return
        }

        val notes = tercaScanNotes.take(3).toIntArray()
        tercaScanNotes.clear()
        val scan = core.scanTercaChord(notes)
        if (scan == null) {
            // Invalid scan never destroys the last valid terca setup and never
            // changes the user's ON/OFF choice.
            state = state.copy(tercaScanActive = false)
            addMonitor("TERCA SCAN rejected: ${notes.joinToString("-")}")
            publishError("TERCA SCAN: invalid 3-note combination")
            publishState()
            return
        }

        preferences.harmonyTonic = scan.tonic
        preferences.harmonyScale = scan.scale
        preferences.tercaDegree = scan.degree
        preferences.intervalMode = IntervalMode.SCALE
        val mask = if (state.harmonyEnabled) 1 else 0
        preferences.harmonyVoiceMask = mask
        core.configureHarmony(scan.tonic, scan.scale)
        core.setHarmonyVoice(0, state.harmonyEnabled, scan.degree, outputChannel = preferences.upper3Channel)
        state = state.copy(
            intervalMode = IntervalMode.SCALE,
            harmonyTonic = scan.tonic,
            harmonyScale = scan.scale,
            tercaDegree = scan.degree,
            tercaScanActive = false,
            harmonyVoiceMask = mask,
            activePresetName = null
        )
        val direction = if (scan.degree == HarmonyDegree.THIRD_DOWN) "DOWN" else "UP"
        addMonitor("TERCA SCAN accepted: tonic=${scan.tonic} scale=${scan.scale.name} $direction")
        publishState()
    }

    fun setMidiThru(enabled: Boolean) {
        preferences.midiThru = enabled
        state = state.copy(midiThru = enabled, activePresetName = null)
        publishState()
    }

    fun runtimeSettings(): MidiRuntimeSettings = MidiRuntimeSettings(
        performanceInputChannel = preferences.performanceInputChannel,
        performanceInputOmni = preferences.performanceInputOmni,
        upper1Channel = preferences.upper1Channel,
        upper2Channel = preferences.upper2Channel,
        upper3Channel = preferences.upper3Channel,
        midiThru = preferences.midiThru,
        pitchBendRangeSemitones = preferences.pitchBendRangeSemitones,
        autoReconnect = preferences.autoReconnect
    )

    fun applyRuntimeSettings(settings: MidiRuntimeSettings) {
        val normalized = settings.copy(
            performanceInputChannel = settings.performanceInputChannel.coerceIn(0, 15),
            upper1Channel = settings.upper1Channel.coerceIn(0, 15),
            upper2Channel = settings.upper2Channel.coerceIn(0, 15),
            upper3Channel = settings.upper3Channel.coerceIn(0, 15),
            pitchBendRangeSemitones = settings.pitchBendRangeSemitones.coerceIn(1, 96)
        )
        if (transport.isConnected()) panic()

        preferences.performanceInputChannel = normalized.performanceInputChannel
        preferences.performanceInputOmni = normalized.performanceInputOmni
        preferences.upper1Channel = normalized.upper1Channel
        preferences.upper2Channel = normalized.upper2Channel
        preferences.upper3Channel = normalized.upper3Channel
        preferences.midiThru = normalized.midiThru
        preferences.pitchBendRangeSemitones = normalized.pitchBendRangeSemitones
        preferences.autoReconnect = normalized.autoReconnect
        transport.setAutoReconnect(normalized.autoReconnect)

        state = state.copy(
            midiThru = normalized.midiThru,
            performanceInputChannel = normalized.performanceInputChannel,
            performanceInputOmni = normalized.performanceInputOmni,
            upper1Channel = normalized.upper1Channel,
            upper2Channel = normalized.upper2Channel,
            upper3Channel = normalized.upper3Channel,
            pitchBendRangeSemitones = normalized.pitchBendRangeSemitones,
            autoReconnect = normalized.autoReconnect,
            activePresetName = null
        )

        core.setHarmonyVoice(
            0, state.harmonyVoiceMask and 1 != 0, state.tercaDegree,
            outputChannel = normalized.upper3Channel
        )

        configureRibbonRoute(
            state.ribbonOutput,
            targetChannels().firstOrNull() ?: normalized.upper1Channel,
            16, 0.10
        )
        if (transport.isConnected()) {
            applyPortamentoToTargets(sendSwitch = true, sendTime = true)
            if (state.appSidePortamento) {
                targetChannels().forEach { ch -> safeSend(core.setPitchBendRange(ch, normalized.pitchBendRangeSemitones)) }
            }
        }
        publishState()
    }

    fun presetNames(): List<String?> = presetStore.names()

    fun savePreset(slot: Int, name: String): Boolean {
        val preset = PerformancePreset(
            name = name.trim().take(32).ifBlank { "Preset ${slot + 1}" },
            modelId = state.selectedModelId,
            portamentoEnabled = state.portamentoEnabled,
            portamentoMode = state.portamentoMode,
            portamentoMs = state.portamentoMs,
            portamentoDepth = state.portamentoDepth,
            appSidePortamento = state.appSidePortamento,
            targetUpperMask = state.targetUpperMask,
            harmonyEnabled = state.harmonyEnabled,
            intervalMode = state.intervalMode,
            harmonyTonic = state.harmonyTonic,
            harmonyScale = state.harmonyScale,
            tercaDegree = state.tercaDegree,
            harmonyVoiceMask = state.harmonyVoiceMask,
            ribbonOutput = state.ribbonOutput,
            ribbonRelease = state.ribbonRelease,
            padBank = state.padBank,
            midiThru = preferences.midiThru,
            performanceInputChannel = preferences.performanceInputChannel,
            performanceInputOmni = preferences.performanceInputOmni,
            upper1Channel = preferences.upper1Channel,
            upper2Channel = preferences.upper2Channel,
            upper3Channel = preferences.upper3Channel,
            pitchBendRangeSemitones = preferences.pitchBendRangeSemitones,
            autoReconnect = preferences.autoReconnect,
            padBanks = (0..2).map { padStore.loadBank(it) }
        )
        val ok = presetStore.save(slot, preset)
        if (ok) {
            state = state.copy(activePresetName = preset.name)
            publishState()
        }
        return ok
    }

    fun clearPreset(slot: Int): Boolean {
        val cleared = presetStore.clear(slot)
        if (cleared) {
            state = state.copy(activePresetName = null)
            publishState()
        }
        return cleared
    }

    fun loadPreset(slot: Int): Boolean {
        val p = presetStore.load(slot) ?: return false
        if (KorgModels.supportedTargets.none { it.id == p.modelId }) return false
        if (transport.isConnected()) panic()

        var loadedTargetMask = p.targetUpperMask
        if (p.harmonyEnabled && (loadedTargetMask and 0x4) != 0) {
            loadedTargetMask = loadedTargetMask and 0x4.inv()
            if (loadedTargetMask == 0) loadedTargetMask = 0x1
        }

        preferences.selectedModelId = p.modelId
        preferences.portamentoEnabled = p.portamentoEnabled
        preferences.portamentoMode = p.portamentoMode
        preferences.portamentoDurationMs = p.portamentoMs
        preferences.portamentoDepth = p.portamentoDepth
        preferences.appSidePortamento = p.appSidePortamento
        preferences.targetUpperMask = loadedTargetMask
        preferences.harmonyEnabled = p.harmonyEnabled
        preferences.intervalMode = IntervalMode.SCALE
        preferences.harmonyTonic = p.harmonyTonic
        preferences.harmonyScale = p.harmonyScale
        preferences.tercaDegree = p.tercaDegree
        preferences.harmonyVoiceMask = if (p.harmonyEnabled) 1 else 0
        preferences.ribbonOutput = p.ribbonOutput
        preferences.ribbonRelease = RibbonRelease.CENTER
        preferences.padBank = p.padBank
        preferences.midiThru = p.midiThru
        preferences.performanceInputChannel = p.performanceInputChannel
        preferences.performanceInputOmni = p.performanceInputOmni
        preferences.upper1Channel = p.upper1Channel
        preferences.upper2Channel = p.upper2Channel
        preferences.upper3Channel = p.upper3Channel
        preferences.pitchBendRangeSemitones = p.pitchBendRangeSemitones
        preferences.autoReconnect = p.autoReconnect

        p.padBanks.take(3).forEachIndexed { bank, pads ->
            pads.take(16).forEachIndexed { index, cfg -> padStore.save(bank, index, cfg) }
        }

        core.selectModel(p.modelId)
        applyStoredCalibration(p.modelId)
        core.configurePortamento(p.portamentoMode, p.portamentoMs, p.portamentoDepth)
        core.setPortamentoEngineEnabled(p.portamentoEnabled)
        core.configureHarmony(p.harmonyTonic, p.harmonyScale)
        core.setHarmonyVoice(0, p.harmonyEnabled, p.tercaDegree, outputChannel = p.upper3Channel)
        for (i in 1..3) core.setHarmonyVoice(i, false, HarmonyDegree.UNISON, outputChannel = -1)
        for (i in 0..3) core.setIntervalVoice(i, false, 0)
        initializePadBanks()
        core.setPadBank(p.padBank)
        ribbonChannel = p.upper1Channel
        core.configureRibbon(p.ribbonOutput, ribbonChannel, 16, 0.10, RibbonRelease.CENTER)
        transport.setAutoReconnect(p.autoReconnect)

        val loadedRibbonOutput = p.ribbonOutput

        state = state.copy(
            selectedModelId = p.modelId,
            portamentoEnabled = p.portamentoEnabled,
            portamentoMode = p.portamentoMode,
            portamentoMs = p.portamentoMs,
            portamentoDepth = p.portamentoDepth,
            appSidePortamento = p.appSidePortamento,
            targetUpperMask = loadedTargetMask,
            harmonyEnabled = p.harmonyEnabled,
            intervalMode = IntervalMode.SCALE,
            harmonyTonic = p.harmonyTonic,
            harmonyScale = p.harmonyScale,
            tercaDegree = p.tercaDegree,
            tercaScanActive = false,
            harmonyVoiceMask = if (p.harmonyEnabled) 1 else 0,
            ribbonOutput = loadedRibbonOutput,
            ribbonRelease = RibbonRelease.CENTER,
            padBank = p.padBank,
            padConfigs = padStore.loadBank(p.padBank),
            midiThru = p.midiThru,
            performanceInputChannel = p.performanceInputChannel,
            performanceInputOmni = p.performanceInputOmni,
            upper1Channel = p.upper1Channel,
            upper2Channel = p.upper2Channel,
            upper3Channel = p.upper3Channel,
            pitchBendRangeSemitones = p.pitchBendRangeSemitones,
            autoReconnect = p.autoReconnect,
            activePresetName = p.name
        )

        configureRibbonRoute(
            state.ribbonOutput,
            targetChannels().firstOrNull() ?: preferences.upper1Channel,
            16, 0.10
        )

        if (transport.isConnected()) {
            applyPortamentoToTargets(sendSwitch = true, sendTime = true)
            if (p.appSidePortamento) targetChannels().forEach { safeSend(core.setPitchBendRange(it, p.pitchBendRangeSemitones)) }
        }
        publishState()
        return true
    }

    fun configureRibbon(output: RibbonOutput, release: RibbonRelease = RibbonRelease.CENTER, cc: Int = 16, smoothing: Double = 0.10) {
        // Pitch Bend Ribbon and app-side portamento are mixed by PitchBendMixer,
        // so both effects can stay active on the same channel without overwriting
        // one another.
        val centeredRelease = RibbonRelease.CENTER
        preferences.ribbonOutput = output
        preferences.ribbonRelease = centeredRelease
        configureRibbonRoute(output, targetChannels().firstOrNull() ?: preferences.upper1Channel, cc, smoothing)
        state = state.copy(ribbonOutput = output, ribbonRelease = centeredRelease, activePresetName = null)
        publishState()
    }

    fun ribbon(position: Double) {
        val raw = core.ribbon(position.coerceIn(0.0, 1.0), System.nanoTime())
        val message = if (state.ribbonOutput == RibbonOutput.PITCH_BEND) pitchBendMixer.applyRibbon(raw) else raw
        safeSend(arrayOf(message))
    }

    fun ribbonRelease() {
        val raw = core.ribbonRelease(System.nanoTime())
        val message = if (state.ribbonOutput == RibbonOutput.PITCH_BEND) pitchBendMixer.applyRibbon(raw) else raw
        safeSend(arrayOf(message))
    }

    fun selectPadBank(bank: Int) {
        val b = bank.coerceIn(0, 2)
        if (b == state.padBank) return
        safeSend(core.flushPads(System.nanoTime()))
        // Switching captures the current native bank before loading the destination bank.
        core.setPadBank(b)
        preferences.padBank = b
        state = state.copy(padBank = b, padConfigs = padStore.loadBank(b), activePresetName = null)
        publishState()
    }

    fun configurePad(index: Int, config: PadConfig) {
        if (index !in 0..15) return
        // Editing a latched/momentary pad must first terminate any active note/CC.
        safeSend(core.flushPads(System.nanoTime()))
        val normalized = config.copy(
            label = config.label.trim().take(24).ifBlank { "PAD ${index + 1}" },
            channel = config.channel.coerceIn(0, 15),
            number = config.number.coerceIn(0, 127),
            onValue = config.onValue.coerceIn(0, 127),
            offValue = config.offValue.coerceIn(0, 127)
        )
        padStore.save(state.padBank, index, normalized)
        core.setPad(index, normalized.type, normalized.channel, normalized.number,
            normalized.onValue, normalized.offValue, normalized.momentary)
        val configs = state.padConfigs.toMutableList().let { list ->
            while (list.size < 16) list += padStore.default(list.size)
            list[index] = normalized
            list
        }
        state = state.copy(padConfigs = configs, activePresetName = null)
        publishState()
    }

    fun resetCurrentPadBank() {
        safeSend(core.flushPads(System.nanoTime()))
        padStore.resetBank(state.padBank)
        val defaults = padStore.loadBank(state.padBank)
        defaults.forEachIndexed { index, c ->
            core.setPad(index, c.type, c.channel, c.number, c.onValue, c.offValue, c.momentary)
        }
        state = state.copy(padConfigs = defaults, activePresetName = null)
        publishState()
    }

    fun pressPad(index: Int) { safeSend(core.pressPad(index, System.nanoTime())) }
    fun releasePad(index: Int) { safeSend(core.releasePad(index, System.nanoTime())) }

    fun panic() {
        dispatcher.invalidateAll()
        pitchBendMixer.resetAll()
        safeSend(core.flushPads(System.nanoTime()))
        safeSendScheduled(core.flushHarmony(System.nanoTime()))
        safeSendScheduled(core.flushIntervals(System.nanoTime()))
        safeSendScheduled(core.resetPortaBridge(System.nanoTime()))
        safeSend(core.panic(true, preferences.midiChannel))
    }

    fun requestIdentity() {
        safeSend(arrayOf(core.identityRequest()))
    }

    /** Used by a calibrated/bridge workflow for exact app-side pitch trajectories. */
    fun sendAppSideGlide(startNote: Int, endNote: Int, bendRangeSemitones: Int = 12) {
        val ch = targetChannels().firstOrNull() ?: preferences.midiChannel
        safeSend(core.setPitchBendRange(ch, bendRangeSemitones))
        val start = System.nanoTime() + 2_000_000L
        dispatcher.replaceChannel(ch, core.buildGlide(startNote, endNote, start, ch, bendRangeSemitones))
    }

    private fun configureRibbonRoute(output: RibbonOutput, channel: Int, cc: Int, smoothing: Double) {
        val newChannel = channel.coerceIn(0, 15)
        if (newChannel != ribbonChannel) {
            if (state.ribbonOutput == RibbonOutput.PITCH_BEND && transport.isConnected()) {
                safeSend(arrayOf(pitchBendMixer.centerRibbon(ribbonChannel)))
            }
            pitchBendMixer.resetChannel(ribbonChannel)
            ribbonChannel = newChannel
        }
        core.configureRibbon(output, ribbonChannel, cc, smoothing, RibbonRelease.CENTER)
    }

    private fun initializePadBanks() {
        // Populate all three native banks from persistent mappings, then return to the saved bank.
        for (bank in 0..2) {
            core.setPadBank(bank)
            padStore.loadBank(bank).forEachIndexed { index, c ->
                core.setPad(index, c.type, c.channel, c.number, c.onValue, c.offValue, c.momentary)
            }
        }
        core.setPadBank(preferences.padBank)
    }

    private fun applyStoredCalibration(modelId: String) {
        val table = calibrationStore.load(modelId) ?: return
        if (!core.setPortamentoCalibration(table.cc, table.milliseconds)) {
            calibrationStore.clear(modelId)
        }
    }

    private fun targetChannels(): List<Int> = targetChannelsForMask(state.targetUpperMask)

    private fun targetChannelsForMask(mask: Int): List<Int> {
        val result = ArrayList<Int>(3)
        if (mask and 1 != 0) result += preferences.upper1Channel
        if (mask and 2 != 0) result += preferences.upper2Channel
        if (mask and 4 != 0) result += preferences.upper3Channel
        return result.distinct()
    }

    private fun applyPortamentoToTargets(sendSwitch: Boolean, sendTime: Boolean) {
        targetChannels().forEach { ch ->
            if (sendSwitch) safeSend(core.hardwarePortamentoSwitch(state.portamentoEnabled && !state.appSidePortamento, ch))
            if (sendTime && !state.appSidePortamento) safeSend(core.applyPortamentoTime(ch))
        }
    }

    private fun safeSend(messages: Array<ByteArray>) {
        if (!transport.isConnected()) return
        messages.forEach { bytes ->
            runCatching {
                transport.send(bytes)
                if (state.monitorEnabled) addMonitor("OUT ${MidiMessageFormatter.format(bytes)}")
            }.onFailure { publishError(it.message ?: "MIDI send failed") }
        }
    }

    private fun safeSendScheduled(messages: List<ScheduledMidi>) {
        if (!transport.isConnected() || messages.isEmpty()) return
        dispatcher.dispatchUnscoped(messages)
    }

    private fun safeSendPortaScheduled(channel: Int, messages: List<ScheduledMidi>) {
        if (!transport.isConnected()) return
        // Replacing the generation is essential: old pitch-bend tails must never
        // continue after a new note changes the intended glide trajectory.
        dispatcher.replaceChannel(channel, messages)
    }

    override fun onDevicesChanged(devices: List<AndroidMidiTransport.Device>) {
        listeners.forEach { it.onDevicesChanged(devices) }
    }

    override fun onConnectionChanged(connected: Boolean, label: String?) {
        state = state.copy(connected = connected, connectionLabel = label, identityLabel = if (connected) state.identityLabel else null)
        if (connected) {
            // Metadata hint is safe: it only selects a profile when the Android device name itself names a supported model.
            KorgModels.guessFromDeviceText(label)?.let { guessed ->
                if (guessed.id != state.selectedModelId) selectModel(guessed.id)
            }
            // Push current state so the keyboard and app cannot silently diverge.
            applyPortamentoToTargets(sendSwitch = true, sendTime = true)
            if (preferences.appSidePortamento) {
                targetChannels().forEach { ch -> safeSend(core.setPitchBendRange(ch, preferences.pitchBendRangeSemitones)) }
            }
            requestIdentity()
        } else {
            // Clear queued and native note state after a cable/device loss so reconnect cannot inherit stale notes.
            dispatcher.invalidateAll()
            core.resetPortaBridge(0L)
            core.flushHarmony(0L)
            core.flushIntervals(0L)
            core.flushPads(0L)
            pitchBendMixer.resetAll()
            decoder.reset()
            tercaScanNotes.clear()
            state = state.copy(tercaScanActive = false)
        }
        publishState()
    }

    override fun onMidiReceived(bytes: ByteArray, timestampNanos: Long) {
        val eventTime = if (timestampNanos > 0L) timestampNanos else System.nanoTime()
        val complete = decoder.push(bytes)
        for (msg in complete) {
            if (state.monitorEnabled) addMonitor("IN  ${MidiMessageFormatter.format(msg)}")
            processPerformanceMessage(msg, eventTime)
        }
    }

    private fun processPerformanceMessage(msg: ByteArray, timestampNanos: Long) {
        if (msg.isEmpty()) return
        val status = msg[0].toInt() and 0xFF
        if (status >= 0xF0) {
            if (status == 0xF0 && msg.size >= 6 && msg[1].toInt().and(0xFF) == 0x7E && msg[3].toInt().and(0xFF) == 0x06 && msg[4].toInt().and(0xFF) == 0x02) {
                val identity = core.parseIdentityReply(msg)
                if (identity != null) {
                    val label = buildString {
                        append(identity.manufacturerName)
                        append(" F:").append(identity.familyCodeHex)
                        append(" M:").append(identity.modelNumberHex)
                        if (identity.versionHex.isNotBlank()) append(" V:").append(identity.versionHex)
                    }
                    state = state.copy(identityLabel = label)
                    publishState()
                    addMonitor("IDENTITY $label  ${MidiMessageFormatter.format(msg)}")
                } else {
                    addMonitor("IDENTITY (unparsed)  ${MidiMessageFormatter.format(msg)}")
                }
            }
            return
        }

        val command = status and 0xF0
        val isNoteMessage = command == 0x80 || command == 0x90
        val ch = status and 0x0F
        val isPerformanceChannel = preferences.performanceInputOmni || ch == preferences.performanceInputChannel

        // Juzisound-style terca scan: while armed, the three scan notes are control input only.
        // They are consumed before MIDI THRU, portamento routing and harmony generation.
        if (state.tercaScanActive && isPerformanceChannel && isNoteMessage && msg.size >= 3) {
            val note = msg[1].toInt() and 0x7F
            val velocity = msg[2].toInt() and 0x7F
            val noteOn = command == 0x90 && velocity > 0
            val noteOff = command == 0x80 || (command == 0x90 && velocity == 0)
            if (noteOn || noteOff) consumeTercaScanNote(note, noteOn)
            return
        }

        val bridgeActive = preferences.appSidePortamento && state.portamentoEnabled && isPerformanceChannel
        // App-side note routing also owns expressive channel messages needed by the
        // bridged performance (sustain, breath, expression, modulation, aftertouch).
        // Pitch Bend is deliberately excluded while the glide engine owns bend state.
        val isRoutedExpression = command == 0xA0 || command == 0xB0 || command == 0xD0
        val bridgeConsumesMessage = bridgeActive && (isNoteMessage || isRoutedExpression)
        if (preferences.midiThru && !bridgeConsumesMessage) {
            safeSend(arrayOf(msg))
        }

        if (!isPerformanceChannel) return

        if (bridgeActive && isRoutedExpression) {
            val routed = targetChannels().map { outCh ->
                msg.copyOf().also { bytes ->
                    bytes[0] = ((command or outCh.coerceIn(0, 15)) and 0xFF).toByte()
                }
            }.toTypedArray()
            safeSend(routed)
        }

        if (msg.size < 3) return
        val note = msg[1].toInt() and 0x7F
        val velocity = msg[2].toInt() and 0x7F
        val noteOn = command == 0x90 && velocity > 0
        val noteOff = command == 0x80 || (command == 0x90 && velocity == 0)

        if (bridgeActive && (noteOn || noteOff)) {
            targetChannels().forEach { outCh ->
                if (noteOn) {
                    safeSendPortaScheduled(outCh, core.portaBridgeNoteOn(
                        outCh, note, velocity, timestampNanos, preferences.pitchBendRangeSemitones))
                } else {
                    safeSendPortaScheduled(outCh, core.portaBridgeNoteOff(outCh, note, velocity, timestampNanos))
                }
            }
        }

        if (!state.harmonyEnabled) return
        when (state.intervalMode) {
            IntervalMode.SCALE -> when {
                noteOn -> safeSend(core.harmonyNoteOn(ch, note, velocity, timestampNanos))
                noteOff -> safeSend(core.harmonyNoteOff(ch, note, velocity, timestampNanos))
            }
            IntervalMode.CHROMATIC -> when {
                noteOn -> safeSend(core.intervalNoteOn(ch, note, velocity, timestampNanos))
                noteOff -> safeSend(core.intervalNoteOff(ch, note, velocity, timestampNanos))
            }
        }
    }

    override fun onError(message: String) = publishError(message)

    private fun addMonitor(line: String) {
        val stamped = "${SystemClock.elapsedRealtime()}  $line"
        synchronized(monitor) {
            while (monitor.size >= 256) monitor.removeFirst()
            monitor.addLast(stamped)
        }
        listeners.forEach { it.onMonitorLine(stamped) }
    }

    private fun publishState() { listeners.forEach { it.onStateChanged(state) } }
    private fun publishError(message: String) { listeners.forEach { it.onError(message) } }

    override fun close() {
        if (transport.isConnected()) runCatching { panic() }
        dispatcher.close()
        transport.removeListener(this)
        transport.close()
        core.close()
    }
}
