package bg.silveton.live.controller

import android.content.Context
import android.media.midi.MidiDeviceInfo
import android.os.SystemClock
import bg.silveton.live.midi.*
import bg.silveton.live.model.AppPreferences
import bg.silveton.live.model.KorgModels
import bg.silveton.live.model.PadConfigurationStore
import bg.silveton.live.model.PadConfig
import bg.silveton.live.model.MidiRuntimeSettings
import bg.silveton.live.model.PerformancePreset
import bg.silveton.live.model.PerformancePresetStore
import java.io.Closeable
import java.util.ArrayDeque
import java.util.concurrent.CopyOnWriteArrayList

class LiveMidiController(context: Context) : Closeable, AndroidMidiTransport.Listener {
    private companion object {
        // Hard performance split requested for the live rig:
        // B3 (MIDI note 59) and every lower key belong exclusively to the
        // arranger chord/left-hand zone. Silveton PORTAMENTO + TERCA start at C4 (60).
        const val CHORD_ZONE_MAX_NOTE = 59
    }

    data class State(
        val connected: Boolean = false,
        val connectionLabel: String? = null,
        val identityLabel: String? = null,
        val selectedModelId: String = "pa600",
        val portamentoEnabled: Boolean = false,
        val portamentoMs: Double = 20.0,
        val portamentoBendRangeReference: Int = 12,
        val targetUpperMask: Int = 7,
        val harmonyEnabled: Boolean = false,
        val harmonyTonic: Int = 0,
        val harmonyScale: ScaleType = ScaleType.MAJOR,
        val tercaDegree: HarmonyDegree = HarmonyDegree.THIRD,
        val tercaScanActive: Boolean = false,
        val ribbonOutput: RibbonOutput = RibbonOutput.PITCH_BEND,
        val ribbonRelease: RibbonRelease = RibbonRelease.CENTER,
        val padBank: Int = 0,
        val padConfigs: List<PadConfig> = emptyList(),
        val monitorEnabled: Boolean = false,
        val midiThru: Boolean = false,
        val performanceInputChannel: Int = 0,
        val performanceInputOmni: Boolean = false,
        val upper1Channel: Int = 0,
        val upper2Channel: Int = 1,
        val upper3Channel: Int = 2,
        val autoReconnect: Boolean = true,
        val activePresetName: String? = null
    )

    interface Listener {
        fun onStateChanged(state: State) {}
        fun onDevicesChanged(devices: List<AndroidMidiTransport.Device>) {}
        fun onMonitorLine(line: String) {}
        fun onError(message: String) {}
    }

    val preferences = AppPreferences(context)
    private val padStore = PadConfigurationStore(context)
    private val presetStore = PerformancePresetStore(context)
    val transport = AndroidMidiTransport(context)
    val core = NativeMidiCore()
    private val effectRouter = EffectIsolationRouter()
    private val masterKeyPorta = MasterKeyPortamento { msg -> runCatching { if (transport.isConnected()) transport.send(msg) } }
    private val tercaEngine = TercaEngine()

    private val listeners = CopyOnWriteArrayList<Listener>()
    private val decoder = MidiStreamDecoder()
    private val monitor = ArrayDeque<String>(256)
    private val tercaScanNotes = LinkedHashSet<Int>()
    // TERCA SCAN learns the real note-source channel from the keyboard.  This avoids
    // a dead scan when a PA-series MIDI preset transmits Upper 1 on a different
    // channel than the app preference.  Once the first scan NoteOn arrives, the
    // scan is locked to that channel so Upper 2/3 duplicate streams cannot pollute it.
    private var tercaScanChannel: Int? = null
    private var ribbonChannel = preferences.upper1Channel
    private var ribbonChannels = listOf(preferences.upper1Channel, preferences.upper2Channel, preferences.upper3Channel).distinct()
    private var state = State(
        selectedModelId = preferences.selectedModelId,
        portamentoEnabled = preferences.portamentoEnabled,
        portamentoMs = preferences.portamentoDurationMs,
        portamentoBendRangeReference = preferences.portamentoBendRangeReference,
        targetUpperMask = preferences.targetUpperMask,
        harmonyEnabled = preferences.harmonyEnabled,
        harmonyTonic = preferences.harmonyTonic,
        harmonyScale = preferences.harmonyScale,
        tercaDegree = preferences.tercaDegree,
        ribbonOutput = preferences.ribbonOutput,
        ribbonRelease = RibbonRelease.CENTER,
        padBank = preferences.padBank,
        padConfigs = padStore.loadBank(preferences.padBank),
        midiThru = preferences.midiThru,
        performanceInputChannel = preferences.performanceInputChannel,
        performanceInputOmni = preferences.performanceInputOmni,
        upper1Channel = preferences.upper1Channel,
        upper2Channel = preferences.upper2Channel,
        upper3Channel = preferences.upper3Channel,
        autoReconnect = preferences.autoReconnect
    )

    init {
        // SAFE START: connecting/opening the app must not change the current PA600 state.
        state = state.copy(portamentoEnabled = false, harmonyEnabled = false, tercaScanActive = false)
        // One-time app-local migration: GLOBAL PORTA targets U1/U2/U3 by default.
        // This changes only the app routing mask; it sends no MIDI to the keyboard.
        if (!preferences.portamentoAllUppersMigrationDone) {
            preferences.targetUpperMask = 7
            preferences.portamentoAllUppersMigrationDone = true
            state = state.copy(targetUpperMask = 7)
        }
        preferences.ribbonRelease = RibbonRelease.CENTER
        preferences.performanceInputOmni = false
        if (!preferences.rightHandRoutingMigrationDone) {
            preferences.performanceInputChannel = 0
            preferences.rightHandRoutingMigrationDone = true
        }
        if (!preferences.pa600RibbonPitchBendMigrationDone) {
            if (state.selectedModelId == "pa600" && state.ribbonOutput == RibbonOutput.CONTROL_CHANGE) {
                preferences.ribbonOutput = RibbonOutput.PITCH_BEND
            }
            preferences.pa600RibbonPitchBendMigrationDone = true
            state = state.copy(ribbonOutput = preferences.ribbonOutput)
        }
        state = state.copy(performanceInputChannel = preferences.performanceInputChannel, performanceInputOmni = false)
        core.selectModel(state.selectedModelId)
        tercaEngine.configure(preferences.harmonyTonic, preferences.harmonyScale, preferences.tercaDegree)
        masterKeyPorta.durationMs = state.portamentoMs
        masterKeyPorta.bendRangeSemitones = state.portamentoBendRangeReference
        masterKeyPorta.enabled = false
        ribbonChannel = preferences.upper1Channel
        core.configureRibbon(preferences.ribbonOutput, ribbonChannel, 16, 0.10, RibbonRelease.CENTER)
        initializePadBanks()
        transport.setAutoReconnect(preferences.autoReconnect)
        transport.addListener(this)
        if (preferences.autoReconnect) {
            preferences.lastDeviceKey?.let { transport.reconnect(it, preferences.lastInputPort, preferences.lastOutputPort) }
        }
    }

    fun addListener(listener: Listener) {
        listeners += listener
        listener.onStateChanged(state)
        listener.onDevicesChanged(transport.devices())
    }

    fun removeListener(listener: Listener) { listeners -= listener }
    fun state(): State = state
    fun monitorSnapshot(): List<String> = synchronized(monitor) { monitor.toList() }
    fun selectModel(id: String) {
        if (KorgModels.supportedTargets.none { it.id == id }) return
        if (!core.selectModel(id)) return
        preferences.selectedModelId = id
        state = state.copy(selectedModelId = id, activePresetName = null)
        publishState()
    }

    fun connect(info: MidiDeviceInfo, inputPort: Int = 0, outputPort: Int = 0) {
        if (transport.isConnected()) panic()
        val d = AndroidMidiTransport.Device(info)
        KorgModels.guessFromDeviceText(d.manufacturer, d.product, d.label)?.let { selectModel(it.id) }
        preferences.lastDeviceKey = d.stableKey
        preferences.lastInputPort = inputPort
        preferences.lastOutputPort = outputPort
        transport.connect(info, inputPort, outputPort)
    }

    fun disconnect() {
        if (transport.isConnected()) panic()
        transport.disconnect(clearReconnectTarget = true)
    }

    fun setMonitorEnabled(enabled: Boolean) {
        state = state.copy(monitorEnabled = enabled)
        publishState()
    }

    fun setTargetUpper(index: Int, enabled: Boolean) {
        if (index !in 0..2) return
        var mask = state.targetUpperMask
        mask = if (enabled) mask or (1 shl index) else mask and (1 shl index).inv()
        if (mask == 0) mask = 1 shl index
        preferences.targetUpperMask = mask
        state = state.copy(targetUpperMask = mask, activePresetName = null)
        publishState()
    }

    fun setPortamentoEnabled(enabled: Boolean) {
        preferences.portamentoEnabled = enabled
        masterKeyPorta.enabled = enabled
        if (!enabled) {
            targetChannels().forEach { masterKeyPorta.resetChannel(it, emitCenter = transport.isConnected()) }
            masterKeyPorta.reset(emitCurrentPhysicalBend = false)
        }
        state = state.copy(portamentoEnabled = enabled, activePresetName = null)
        if (state.monitorEnabled) addMonitor("MASTERKEY PORTA ${if (enabled) "ON" else "OFF"} · ${state.portamentoMs.toInt()} ms")
        publishState()
    }

    fun setPortamentoTime(ms: Double) {
        val v = ms.coerceIn(1.0, 5000.0)
        preferences.portamentoDurationMs = v
        masterKeyPorta.durationMs = v
        state = state.copy(portamentoMs = v, activePresetName = null)
        if (state.monitorEnabled) addMonitor("MASTERKEY PORTA TIME ${v.toInt()} ms")
        publishState()
    }

    fun setCustomPortamentoTime(ms: Double) = setPortamentoTime(ms)

    fun setHarmonyEnabled(enabled: Boolean) {
        if (!enabled && state.harmonyEnabled) safeSend(tercaEngine.flush(preferences.upper3Channel))
        preferences.harmonyEnabled = enabled
        state = state.copy(harmonyEnabled = enabled, activePresetName = null)
        if (state.portamentoEnabled && targetChannels().contains(preferences.upper3Channel)) {
            masterKeyPorta.resetChannel(preferences.upper3Channel, emitCenter = transport.isConnected())
        }
        publishState()
    }

    fun toggleTercaScan() {
        if (state.tercaScanActive) {
            silenceUpperNotesForScan()
            tercaScanNotes.clear(); tercaScanChannel = null
            state = state.copy(tercaScanActive = false)
            addMonitor("TERCA SCAN cancelled")
            publishState(); return
        }
        if (!transport.isConnected()) { publishError("Connect the KORG before TERCA SCAN"); return }
        if (!transport.canReceiveMidi()) { publishError("TERCA SCAN needs MIDI from KORG → phone."); return }
        safeSend(tercaEngine.flush(preferences.upper3Channel))
        silenceUpperNotesForScan()
        tercaScanNotes.clear(); tercaScanChannel = null
        state = state.copy(tercaScanActive = true, activePresetName = null)
        addMonitor("TERCA SCAN: play 3 notes together")
        publishState()
    }

    private fun consumeTercaScanNote(note: Int, noteOn: Boolean) {
        if (!state.tercaScanActive) return
        if (!noteOn) return
        tercaScanNotes.add(note.coerceIn(0, 127))
        if (tercaScanNotes.size < 3) { publishState(); return }
        val notes = tercaScanNotes.take(3).toIntArray()
        tercaScanNotes.clear()
        val scan = tercaEngine.scan(notes)
        if (scan == null) {
            state = state.copy(tercaScanActive = false); tercaScanChannel = null
            publishError("TERCA SCAN: invalid 3-note combination"); publishState(); return
        }
        preferences.harmonyTonic = scan.tonic
        preferences.harmonyScale = scan.scale
        preferences.tercaDegree = scan.degree
        // scan() already installed the exact packed MasterKey root/mode. Do NOT
        // translate it back through generic ScaleType and configure() again.
        state = state.copy(harmonyTonic = scan.tonic, harmonyScale = scan.scale, tercaDegree = scan.degree, tercaScanActive = false, activePresetName = null)
        val learned = tercaScanChannel; tercaScanChannel = null
        addMonitor("TERCA SCAN accepted · ${scan.scale.name} · ${scan.degree.name} · CH${(learned ?: preferences.performanceInputChannel)+1}")
        publishState()
    }

    fun setMidiThru(enabled: Boolean) {
        preferences.midiThru = enabled
        state = state.copy(midiThru = enabled, activePresetName = null)
        publishState()
    }

    fun runtimeSettings(): MidiRuntimeSettings = MidiRuntimeSettings(
        performanceInputChannel = preferences.performanceInputChannel,
        performanceInputOmni = preferences.performanceInputOmni,
        upper1Channel = preferences.upper1Channel,
        upper2Channel = preferences.upper2Channel,
        upper3Channel = preferences.upper3Channel,
        portamentoBendRangeReference = preferences.portamentoBendRangeReference,
        midiThru = preferences.midiThru,
        autoReconnect = preferences.autoReconnect
    )

    fun applyRuntimeSettings(settings: MidiRuntimeSettings) {
        val oldU3 = preferences.upper3Channel
        val normalized = settings.copy(
            performanceInputChannel = settings.performanceInputChannel.coerceIn(0,15),
            performanceInputOmni = false,
            upper1Channel = settings.upper1Channel.coerceIn(0,15),
            upper2Channel = settings.upper2Channel.coerceIn(0,15),
            upper3Channel = settings.upper3Channel.coerceIn(0,15),
            portamentoBendRangeReference = settings.portamentoBendRangeReference.coerceIn(1,12)
        )
        if (state.harmonyEnabled && oldU3 != normalized.upper3Channel) safeSend(tercaEngine.flush(oldU3))
        preferences.performanceInputChannel = normalized.performanceInputChannel
        preferences.performanceInputOmni = false
        preferences.upper1Channel = normalized.upper1Channel; preferences.upper2Channel = normalized.upper2Channel; preferences.upper3Channel = normalized.upper3Channel
        preferences.portamentoBendRangeReference = normalized.portamentoBendRangeReference
        masterKeyPorta.bendRangeSemitones = normalized.portamentoBendRangeReference
        preferences.midiThru = normalized.midiThru; preferences.autoReconnect = normalized.autoReconnect
        transport.setAutoReconnect(normalized.autoReconnect)
        state = state.copy(midiThru=normalized.midiThru, performanceInputChannel=normalized.performanceInputChannel, performanceInputOmni=false,
            upper1Channel=normalized.upper1Channel, upper2Channel=normalized.upper2Channel, upper3Channel=normalized.upper3Channel,
            portamentoBendRangeReference=normalized.portamentoBendRangeReference, autoReconnect=normalized.autoReconnect, activePresetName=null)
        configureRibbonRoute(state.ribbonOutput, normalized.upper1Channel, 16, 0.10)
        publishState()
    }

    fun presetNames(): List<String?> = presetStore.names()

    fun savePreset(slot: Int, name: String): Boolean {
        val preset = PerformancePreset(
            name=name.trim().take(32).ifBlank { "Preset ${slot+1}" }, modelId=state.selectedModelId,
            portamentoEnabled=state.portamentoEnabled, portamentoMs=state.portamentoMs, targetUpperMask=state.targetUpperMask,
            harmonyEnabled=state.harmonyEnabled, harmonyTonic=state.harmonyTonic, harmonyScale=state.harmonyScale, tercaDegree=state.tercaDegree,
            ribbonOutput=state.ribbonOutput, ribbonRelease=RibbonRelease.CENTER, padBank=state.padBank, midiThru=preferences.midiThru,
            performanceInputChannel=preferences.performanceInputChannel, performanceInputOmni=false, upper1Channel=preferences.upper1Channel,
            upper2Channel=preferences.upper2Channel, upper3Channel=preferences.upper3Channel, autoReconnect=preferences.autoReconnect,
            padBanks=(0..2).map { padStore.loadBank(it) })
        val ok=presetStore.save(slot,preset)
        if(ok){ state=state.copy(activePresetName=preset.name); publishState() }
        return ok
    }

    fun clearPreset(slot: Int): Boolean {
        val cleared = presetStore.clear(slot)
        if (cleared) {
            state = state.copy(activePresetName = null)
            publishState()
        }
        return cleared
    }

    fun loadPreset(slot: Int): Boolean {
        val p=presetStore.load(slot) ?: return false
        if(KorgModels.supportedTargets.none{it.id==p.modelId}) return false
        if(transport.isConnected()) panic()
        preferences.selectedModelId=p.modelId; preferences.portamentoEnabled=p.portamentoEnabled; preferences.portamentoDurationMs=p.portamentoMs; preferences.targetUpperMask=p.targetUpperMask
        preferences.harmonyEnabled=p.harmonyEnabled; preferences.harmonyTonic=p.harmonyTonic; preferences.harmonyScale=p.harmonyScale; preferences.tercaDegree=p.tercaDegree
        preferences.ribbonOutput=p.ribbonOutput; preferences.ribbonRelease=RibbonRelease.CENTER; preferences.padBank=p.padBank; preferences.midiThru=p.midiThru
        preferences.performanceInputChannel=p.performanceInputChannel; preferences.performanceInputOmni=false; preferences.upper1Channel=p.upper1Channel; preferences.upper2Channel=p.upper2Channel; preferences.upper3Channel=p.upper3Channel; preferences.autoReconnect=p.autoReconnect
        p.padBanks.take(3).forEachIndexed{bank,pads->pads.take(16).forEachIndexed{index,cfg->padStore.save(bank,index,cfg)}}
        core.selectModel(p.modelId); tercaEngine.configure(p.harmonyTonic,p.harmonyScale,p.tercaDegree); initializePadBanks(); core.setPadBank(p.padBank)
        ribbonChannel=p.upper1Channel; core.configureRibbon(p.ribbonOutput,ribbonChannel,16,0.10,RibbonRelease.CENTER); transport.setAutoReconnect(p.autoReconnect)
        masterKeyPorta.durationMs = p.portamentoMs
        masterKeyPorta.bendRangeSemitones = preferences.portamentoBendRangeReference
        masterKeyPorta.enabled = p.portamentoEnabled
        state=state.copy(selectedModelId=p.modelId,portamentoEnabled=p.portamentoEnabled,portamentoMs=p.portamentoMs,targetUpperMask=p.targetUpperMask,
            harmonyEnabled=p.harmonyEnabled,harmonyTonic=p.harmonyTonic,harmonyScale=p.harmonyScale,tercaDegree=p.tercaDegree,tercaScanActive=false,
            ribbonOutput=p.ribbonOutput,ribbonRelease=RibbonRelease.CENTER,padBank=p.padBank,padConfigs=padStore.loadBank(p.padBank),midiThru=p.midiThru,
            performanceInputChannel=p.performanceInputChannel,performanceInputOmni=false,upper1Channel=p.upper1Channel,upper2Channel=p.upper2Channel,upper3Channel=p.upper3Channel,
            portamentoBendRangeReference=preferences.portamentoBendRangeReference, autoReconnect=p.autoReconnect,activePresetName=p.name)
        configureRibbonRoute(state.ribbonOutput,preferences.upper1Channel,16,0.10)
        publishState(); return true
    }

    fun configureRibbon(output: RibbonOutput, release: RibbonRelease = RibbonRelease.CENTER, cc: Int = 16, smoothing: Double = 0.10) {
        // RIBBON remains a separate user control. MASTERKEY PORTA never changes the
        // keyboard's configured PB range/RPN/transpose/octave.
        val centeredRelease = RibbonRelease.CENTER
        preferences.ribbonOutput = output
        preferences.ribbonRelease = centeredRelease
        configureRibbonRoute(output, preferences.upper1Channel, cc, smoothing)
        state = state.copy(ribbonOutput = output, ribbonRelease = centeredRelease, activePresetName = null)
        publishState()
    }

    fun ribbon(position: Double) {
        val raw = core.ribbon(position.coerceIn(0.0, 1.0), System.nanoTime())
        sendRibbonWithoutFightingPortamento(raw)
    }

    fun ribbonRelease() {
        val raw = core.ribbonRelease(System.nanoTime())
        sendRibbonWithoutFightingPortamento(raw)
    }

    private fun sendRibbonWithoutFightingPortamento(raw: ByteArray) {
        if (state.portamentoEnabled && state.ribbonOutput == RibbonOutput.PITCH_BEND && raw.size >= 3 && ((raw[0].toInt() and 0xF0) == 0xE0)) {
            val bend = (raw[1].toInt() and 0x7F) or ((raw[2].toInt() and 0x7F) shl 7)
            ribbonChannels.forEach { masterKeyPorta.physicalPitchBend(it, bend) }
        } else {
            safeSend(fanOutRibbon(raw))
        }
    }

    fun selectPadBank(bank: Int) {
        val b = bank.coerceIn(0, 2)
        if (b == state.padBank) return
        safeSend(core.flushPads(System.nanoTime()))
        // Switching captures the current native bank before loading the destination bank.
        core.setPadBank(b)
        preferences.padBank = b
        state = state.copy(padBank = b, padConfigs = padStore.loadBank(b), activePresetName = null)
        publishState()
    }

    fun configurePad(index: Int, config: PadConfig) {
        if (index !in 0..15) return
        // Editing a latched/momentary pad must first terminate any active note/CC.
        safeSend(core.flushPads(System.nanoTime()))
        val normalized = config.copy(
            label = config.label.trim().take(24).ifBlank { "PAD ${index + 1}" },
            channel = config.channel.coerceIn(0, 15),
            number = config.number.coerceIn(0, 127),
            onValue = config.onValue.coerceIn(0, 127),
            offValue = config.offValue.coerceIn(0, 127)
        )
        padStore.save(state.padBank, index, normalized)
        core.setPad(index, normalized.type, normalized.channel, normalized.number,
            normalized.onValue, normalized.offValue, normalized.momentary)
        val configs = state.padConfigs.toMutableList().let { list ->
            while (list.size < 16) list += padStore.default(list.size)
            list[index] = normalized
            list
        }
        state = state.copy(padConfigs = configs, activePresetName = null)
        publishState()
    }

    fun resetCurrentPadBank() {
        safeSend(core.flushPads(System.nanoTime()))
        padStore.resetBank(state.padBank)
        val defaults = padStore.loadBank(state.padBank)
        defaults.forEachIndexed { index, c ->
            core.setPad(index, c.type, c.channel, c.number, c.onValue, c.offValue, c.momentary)
        }
        state = state.copy(padConfigs = defaults, activePresetName = null)
        publishState()
    }

    fun pressPad(index: Int) { safeSend(core.pressPad(index, System.nanoTime())) }
    fun releasePad(index: Int) { safeSend(core.releasePad(index, System.nanoTime())) }

    fun panic() {
        safeSend(tercaEngine.flush(preferences.upper3Channel))
        safeSend(core.flushPads(System.nanoTime()))
        safeSend(core.panic(true, preferences.midiChannel))
    }

    fun requestIdentity() {
        safeSend(arrayOf(core.identityRequest()))
    }

    private fun configureRibbonRoute(output: RibbonOutput, channel: Int, cc: Int, smoothing: Double) {
        ribbonChannels = effectRouter.ribbonChannels(preferences.upper1Channel, preferences.upper2Channel, preferences.upper3Channel)
            .ifEmpty { listOf(channel.coerceIn(0,15)) }
        ribbonChannel = ribbonChannels.first()
        core.configureRibbon(output, ribbonChannel, cc, smoothing, RibbonRelease.CENTER)
    }

    private fun fanOutRibbon(raw: ByteArray): Array<ByteArray> {
        if(raw.size<3) return arrayOf(raw)
        val status=raw[0].toInt() and 0xFF; val command=status and 0xF0
        if(command!=0xE0 && command!=0xB0) return arrayOf(raw)
        return ribbonChannels.map{ch->raw.copyOf().also{it[0]=(command or ch.coerceIn(0,15)).toByte()}}.toTypedArray()
    }

    private fun initializePadBanks() {
        // Populate all three native banks from persistent mappings, then return to the saved bank.
        for (bank in 0..2) {
            core.setPadBank(bank)
            padStore.loadBank(bank).forEachIndexed { index, c ->
                core.setPad(index, c.type, c.channel, c.number, c.onValue, c.offValue, c.momentary)
            }
        }
        core.setPadBank(preferences.padBank)
    }



    private fun targetChannels(): List<Int> = targetChannelsForMask(state.targetUpperMask)

    private fun targetChannelsForMask(mask: Int): List<Int> =
        effectRouter.selectedPortamentoChannels(
            mask, preferences.upper1Channel, preferences.upper2Channel, preferences.upper3Channel
        )

    private fun silenceUpperNotesForScan() {
        if (!transport.isConnected()) return
        // CC123 is transient: it stops current notes without touching Program,
        // transpose, octave, volume or any persistent Keyboard Set state.
        effectRouter.ribbonChannels(preferences.upper1Channel, preferences.upper2Channel, preferences.upper3Channel)
            .forEach { ch ->
                safeSend(arrayOf(byteArrayOf((0xB0 or ch.coerceIn(0, 15)).toByte(), 123.toByte(), 0)))
            }
    }

    private fun safeSend(messages: Array<ByteArray>) {
        if (!transport.isConnected()) return
        messages.forEach { bytes ->
            runCatching {
                transport.send(bytes)
                if (state.monitorEnabled) addMonitor("OUT ${MidiMessageFormatter.format(bytes)}")
            }.onFailure { publishError(it.message ?: "MIDI send failed") }
        }
    }

    override fun onDevicesChanged(devices: List<AndroidMidiTransport.Device>) {
        listeners.forEach { it.onDevicesChanged(devices) }
    }

    override fun onConnectionChanged(connected: Boolean, label: String?) {
        state = state.copy(connected = connected, connectionLabel = label, identityLabel = if (connected) state.identityLabel else null)
        if (connected) {
            KorgModels.guessFromDeviceText(label)?.let { guessed ->
                if (guessed.id != state.selectedModelId) selectModel(guessed.id)
            }
            if (!transport.canReceiveMidi()) {
                publishError("Connected output-only: TERCA SCAN needs MIDI from KORG → phone.")
            }
            requestIdentity()
        } else {
            // Local app state only. Never send reset/transpose/bend/porta messages on disconnect.
            tercaEngine.flush(preferences.upper3Channel)
            decoder.reset()
            tercaScanNotes.clear()
            tercaScanChannel = null
            state = state.copy(tercaScanActive = false)
        }
        publishState()
    }

    override fun onMidiReceived(bytes: ByteArray, timestampNanos: Long) {
        val eventTime = if (timestampNanos > 0L) timestampNanos else System.nanoTime()
        val complete = decoder.push(bytes)
        for (msg in complete) {
            if (state.monitorEnabled) addMonitor("IN  ${MidiMessageFormatter.format(msg)}")
            processPerformanceMessage(msg, eventTime)
        }
    }

    private fun processPerformanceMessage(msg: ByteArray, timestampNanos: Long) {
        if (msg.isEmpty()) return
        val status = msg[0].toInt() and 0xFF
        if (status >= 0xF0) {
            handleSystemMidi(msg, status)
            return
        }

        val command = status and 0xF0
        val channel = status and 0x0F
        val isNoteMessage = command == 0x80 || command == 0x90

        // Global input firewall, not an effect: notes below C4 belong exclusively to
        // the arranger chord section. C4 (60) and above reach PORTAMENTO + TERCA.
        if (isNoteMessage && msg.size >= 3) {
            val note = msg[1].toInt() and 0x7F
            if (note <= CHORD_ZONE_MAX_NOTE) {
                // LEFT HAND / arranger zone: pass the original note unchanged when MIDI THRU
                // is enabled, but NEVER feed it to TERCA scan, TERCA generation or PORTAMENTO.
                if (state.monitorEnabled) addMonitor("LEFT HAND BYPASS note=$note (B3/59 or below)")
                if (preferences.midiThru) safeSend(arrayOf(msg))
                return
            }
        }

        // SCAN is a TERCA configuration gesture. While armed, its three notes are
        // consumed only by the scanner and never leak into the performance engines.
        if (handleTercaScanMessage(msg, command, channel, isNoteMessage)) return

        val isPerformanceChannel = channel == preferences.performanceInputChannel

        // MasterKey-style PORTAMENTO is a separate state machine. It never changes
        // PA600 bend range/RPN/transpose/octave on connect. While active, physical
        // joystick Pitch Bend becomes the base value and the glide is added to it.
        if (state.portamentoEnabled && isPerformanceChannel) {
            if (command == 0xE0 && msg.size >= 3) {
                val bend = (msg[1].toInt() and 0x7F) or ((msg[2].toInt() and 0x7F) shl 7)
                targetChannels().forEach { masterKeyPorta.physicalPitchBend(it, bend) }
                return
            }
            if (isNoteMessage && msg.size >= 3) {
                val note = msg[1].toInt() and 0x7F
                val vel = msg[2].toInt() and 0x7F
                val on = command == 0x90 && vel > 0
                val off = command == 0x80 || (command == 0x90 && vel == 0)
                val u3 = effectRouter.tercaChannel(preferences.upper3Channel)
                // When TERCA is ON, U3 PORTA must follow the GENERATED third, not
                // the original input note. U1/U2 remain completely independent.
                targetChannels().filterNot { state.harmonyEnabled && it == u3 }.forEach { ch ->
                    if (on) masterKeyPorta.noteOn(ch, note) else if (off) masterKeyPorta.noteOff(ch, note)
                }
            }
        }
        if (preferences.midiThru) safeSend(arrayOf(msg))
        if (!isPerformanceChannel) return
        handleTercaPerformance(msg, command, channel, isNoteMessage, timestampNanos)
    }

    private fun handleSystemMidi(msg: ByteArray, status: Int) {
        if (status != 0xF0 || msg.size < 6) return
        if (msg[1].toInt().and(0xFF) != 0x7E ||
            msg[3].toInt().and(0xFF) != 0x06 ||
            msg[4].toInt().and(0xFF) != 0x02) return

        val identity = core.parseIdentityReply(msg)
        if (identity != null) {
            val label = buildString {
                append(identity.manufacturerName)
                append(" F:").append(identity.familyCodeHex)
                append(" M:").append(identity.modelNumberHex)
                if (identity.versionHex.isNotBlank()) append(" V:").append(identity.versionHex)
            }
            state = state.copy(identityLabel = label)
            publishState()
            addMonitor("IDENTITY $label  ${MidiMessageFormatter.format(msg)}")
        } else {
            addMonitor("IDENTITY (unparsed)  ${MidiMessageFormatter.format(msg)}")
        }
    }

    private fun handleTercaScanMessage(
        msg: ByteArray,
        command: Int,
        channel: Int,
        isNoteMessage: Boolean
    ): Boolean {
        if (!state.tercaScanActive || !isNoteMessage || msg.size < 3) return false
        val note = msg[1].toInt() and 0x7F
        val velocity = msg[2].toInt() and 0x7F
        val noteOn = command == 0x90 && velocity > 0
        val noteOff = command == 0x80 || (command == 0x90 && velocity == 0)
        if (noteOn && tercaScanChannel == null) tercaScanChannel = channel
        if (tercaScanChannel != channel || (!noteOn && !noteOff)) return false
        if (noteOn) silenceUpperNotesForScan()
        consumeTercaScanNote(note, noteOn)
        return true
    }

    // MASTERKEY-style PORTA and TERCA are separate state machines. PORTA never sends
    // RPN/CC5/CC65/transpose/octave; its PB-range value is a local math reference only.

    private fun handleTercaPerformance(
        msg: ByteArray,
        command: Int,
        inputChannel: Int,
        isNoteMessage: Boolean,
        @Suppress("UNUSED_PARAMETER") timestampNanos: Long
    ) {
        if (!state.harmonyEnabled || !isNoteMessage || msg.size < 3) return
        val note = msg[1].toInt() and 0x7F
        val velocity = msg[2].toInt() and 0x7F
        val noteOn = command == 0x90 && velocity > 0
        val noteOff = command == 0x80 || (command == 0x90 && velocity == 0)
        val u3 = effectRouter.tercaChannel(preferences.upper3Channel)
        val generated = when {
            noteOn -> tercaEngine.noteOn(inputChannel, note, velocity, u3)
            noteOff -> tercaEngine.noteOff(inputChannel, note, velocity, u3)
            else -> emptyArray()
        }
        if (generated.isNotEmpty()) {
            val u3PortaActive = state.portamentoEnabled && targetChannels().contains(u3)
            // PORTA sees exactly the generated TERCA note.  This prevents the old
            // U3 conflict where its glide was calculated from the original note.
            if (u3PortaActive) {
                generated.forEach { bytes ->
                    if (bytes.size < 3) return@forEach
                    val st = bytes[0].toInt() and 0xF0
                    val g = bytes[1].toInt() and 0x7F
                    val v = bytes[2].toInt() and 0x7F
                    if (st == 0x90 && v > 0) masterKeyPorta.noteOn(u3, g)
                    else if (st == 0x80 || (st == 0x90 && v == 0)) masterKeyPorta.noteOff(u3, g)
                }
            }
            safeSend(generated)
        }
    }

    override fun onError(message: String) = publishError(message)

    private fun addMonitor(line: String) {
        val stamped = "${SystemClock.elapsedRealtime()}  $line"
        synchronized(monitor) {
            while (monitor.size >= 256) monitor.removeFirst()
            monitor.addLast(stamped)
        }
        listeners.forEach { it.onMonitorLine(stamped) }
    }

    private fun publishState() { listeners.forEach { it.onStateChanged(state) } }
    private fun publishError(message: String) { listeners.forEach { it.onError(message) } }

    override fun close() {
        if (transport.isConnected()) runCatching { panic() }
        masterKeyPorta.close()
        transport.removeListener(this)
        transport.close()
        core.close()
    }
}
