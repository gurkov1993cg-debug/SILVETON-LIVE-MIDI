package bg.silveton.live.ui

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.sin

/** Neon ribbon surface matching the approved HOME reference while retaining real MIDI control. */
class RibbonView(context: Context) : View(context) {
    interface Listener { fun onPosition(position: Double); fun onRelease() }
    var listener: Listener? = null
    private var position = 0.5f
    private var touched = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = RectF()
    private val path = Path()

    init {
        minimumHeight = 0
        isClickable = true
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        setPadding(0,0,0,0)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return
        val hInset = dpF(42)
        val vInset = dpF(8)
        track.set(hInset, vInset, width-hInset, height-vInset)

        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(track.left,0f,track.right,0f,
            intArrayOf(Color.rgb(2,34,92), Color.rgb(0,92,246), Color.rgb(92,21,220), Color.rgb(0,203,255)),
            floatArrayOf(0f,.36f,.72f,1f), Shader.TileMode.CLAMP)
        paint.setShadowLayer(dpF(12),0f,0f,SilvetonTheme.blue)
        canvas.drawRoundRect(track, dpF(24), dpF(24), paint)
        paint.clearShadowLayer(); paint.shader = null

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dpF(1)
        paint.color = Color.argb(90, 70, 183, 255)
        for (i in 1 until 20) {
            val x = track.left + track.width()*i/20f
            canvas.drawLine(x, track.top, x, track.bottom, paint)
        }
        for (i in 1 until 4) {
            val y = track.top + track.height()*i/4f
            canvas.drawLine(track.left, y, track.right, y, paint)
        }

        path.reset()
        val steps = 120
        for (i in 0..steps) {
            val t = i/steps.toFloat()
            val x = track.left + track.width()*t
            val wave = sin((t*6.0*Math.PI)).toFloat()*track.height()*0.18f
            val y = track.centerY()+wave
            if (i==0) path.moveTo(x,y) else path.lineTo(x,y)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dpF(2.2f)
        paint.shader = LinearGradient(track.left,0f,track.right,0f,
            intArrayOf(SilvetonTheme.cyan, Color.WHITE, SilvetonTheme.purple, SilvetonTheme.cyan), null, Shader.TileMode.CLAMP)
        paint.setShadowLayer(dpF(8),0f,0f,SilvetonTheme.cyan)
        canvas.drawPath(path,paint)
        paint.clearShadowLayer(); paint.shader=null

        val x = track.left + track.width()*position
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dpF(2)
        paint.color = Color.WHITE
        paint.setShadowLayer(dpF(10),0f,0f,SilvetonTheme.cyan)
        canvas.drawLine(x, track.top+dpF(4), x, track.bottom-dpF(4), paint)
        paint.clearShadowLayer()
        paint.style = Paint.Style.FILL
        paint.color = if(touched) SilvetonTheme.cyan else Color.rgb(52,211,238)
        canvas.drawCircle(x,track.centerY(),dpF(13),paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth=dpF(2); paint.color=Color.WHITE
        canvas.drawCircle(x,track.centerY(),dpF(13),paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                touched=true
                position=((event.x-track.left)/max(1f,track.width())).coerceIn(0f,1f)
                listener?.onPosition(position.toDouble()); invalidate(); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touched=false; position=.5f; listener?.onRelease(); invalidate(); performClick(); return true
            }
        }
        return super.onTouchEvent(event)
    }
    override fun performClick():Boolean { super.performClick(); return true }
    private fun dpF(v:Int)=v*resources.displayMetrics.density
    private fun dpF(v:Float)=v*resources.displayMetrics.density
}
