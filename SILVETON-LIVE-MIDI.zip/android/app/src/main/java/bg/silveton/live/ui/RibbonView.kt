package bg.silveton.live.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/**
 * Large stage-friendly ribbon controller.
 *
 * The control is intentionally spring-centred: when the finger leaves the ribbon,
 * both the visual thumb and the MIDI value return to the exact centre (0.5).
 */
class RibbonView(context: Context) : View(context) {
    interface Listener {
        fun onPosition(position: Double)
        fun onRelease()
    }

    var listener: Listener? = null
    private var position = 0.5f
    private var touched = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val track = RectF()

    init {
        minimumHeight = dp(220)
        isClickable = true
        background = SilvetonTheme.panelDrawable(dpF(18), SilvetonTheme.border)
        setPadding(dp(18), dp(18), dp(18), dp(18))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val horizontalInset = dp(26).toFloat()
        val trackHalfHeight = dpF(46)
        track.set(
            horizontalInset,
            height * 0.5f - trackHalfHeight,
            width - horizontalInset,
            height * 0.5f + trackHalfHeight
        )

        // Large physical-ribbon style touch surface instead of a thin line.
        paint.style = Paint.Style.FILL
        paint.color = SilvetonTheme.bg
        canvas.drawRoundRect(track, dpF(22), dpF(22), paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dpF(2)
        paint.color = SilvetonTheme.border
        canvas.drawRoundRect(track, dpF(22), dpF(22), paint)

        // Reference ticks and a stronger centre detent.
        paint.strokeWidth = dpF(1)
        paint.color = SilvetonTheme.borderSoft
        for (i in 1 until 10) {
            val x = track.left + track.width() * i / 10f
            val h = if (i == 5) dpF(28) else dpF(13)
            canvas.drawLine(x, track.centerY() - h, x, track.centerY() + h, paint)
        }

        val x = track.left + track.width() * position
        val fillLeft = if (position >= 0.5f) track.centerX() else x
        val fillRight = if (position >= 0.5f) x else track.centerX()
        paint.style = Paint.Style.FILL
        paint.color = SilvetonTheme.blend(SilvetonTheme.blue, SilvetonTheme.cyan, 0.45f)
        canvas.drawRoundRect(
            RectF(fillLeft, track.top + dpF(9), fillRight, track.bottom - dpF(9)),
            dpF(16), dpF(16), paint
        )

        // Big stage-visible thumb: outer halo + solid centre.
        paint.style = Paint.Style.FILL
        paint.color = if (touched) SilvetonTheme.cyan else SilvetonTheme.blue
        paint.alpha = 70
        canvas.drawCircle(x, track.centerY(), dpF(38), paint)
        paint.alpha = 255
        canvas.drawCircle(x, track.centerY(), dpF(29), paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dpF(3)
        paint.color = SilvetonTheme.text
        canvas.drawCircle(x, track.centerY(), dpF(29), paint)

        // Small centre mark inside the thumb helps precise return/zero recognition.
        paint.strokeWidth = dpF(2)
        paint.color = SilvetonTheme.bg
        canvas.drawLine(x, track.centerY() - dpF(11), x, track.centerY() + dpF(11), paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                touched = true
                position = ((event.x - track.left) / max(1f, track.width())).coerceIn(0f, 1f)
                listener?.onPosition(position.toDouble())
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touched = false
                // Spring return: the UI returns to the exact centre immediately and
                // the controller sends the matching centred MIDI value.
                position = 0.5f
                listener?.onRelease()
                invalidate()
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpF(v: Int): Float = v * resources.displayMetrics.density
}
