package bg.silveton.live.controller

/**
 * Pure routing policy for the live effects.
 *
 * PORTA, TERCA and RIBBON keep independent routing/state.  UPPER 3 is not removed
 * from PORTA when TERCA is active: TERCA owns which note is generated on U3, while
 * PORTA may still shape that generated note and RIBBON may still control U3.
 */
internal class EffectIsolationRouter {
    /**
     * PORTA is permanently armed for all three Upper tracks. There is deliberately
     * no per-Upper enable mask: the KORG remains the authority for Play/Mute, while
     * PORTA control data is always ready on U1/U2/U3.
     */
    fun portamentoChannels(upper1: Int, upper2: Int, upper3: Int): List<Int> =
        listOf(upper1, upper2, upper3).map { it.coerceIn(0, 15) }.distinct()

    fun tercaChannel(upper3: Int): Int = upper3.coerceIn(0, 15)

    fun ribbonChannels(upper1: Int, upper2: Int, upper3: Int): List<Int> =
        listOf(upper1, upper2, upper3).map { it.coerceIn(0, 15) }.distinct()
}
