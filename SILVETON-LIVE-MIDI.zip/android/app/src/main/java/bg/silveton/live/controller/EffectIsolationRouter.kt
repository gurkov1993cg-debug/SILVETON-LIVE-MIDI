package bg.silveton.live.controller

/**
 * Pure routing policy for the live effects.
 *
 * PORTA, TERCA and RIBBON keep independent routing/state.  UPPER 3 is not removed
 * from PORTA when TERCA is active: TERCA owns which note is generated on U3, while
 * PORTA may still shape that generated note and RIBBON may still control U3.
 */
internal class EffectIsolationRouter {
    fun selectedPortamentoChannels(mask: Int, upper1: Int, upper2: Int, upper3: Int): List<Int> {
        val result = ArrayList<Int>(3)
        if (mask and 1 != 0) result += upper1.coerceIn(0, 15)
        if (mask and 2 != 0) result += upper2.coerceIn(0, 15)
        if (mask and 4 != 0) result += upper3.coerceIn(0, 15)
        return result.distinct()
    }

    fun tercaChannel(upper3: Int): Int = upper3.coerceIn(0, 15)

    fun ribbonChannels(upper1: Int, upper2: Int, upper3: Int): List<Int> =
        listOf(upper1, upper2, upper3).map { it.coerceIn(0, 15) }.distinct()
}
