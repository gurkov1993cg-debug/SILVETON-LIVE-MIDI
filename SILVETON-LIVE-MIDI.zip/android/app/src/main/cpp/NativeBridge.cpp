#include <jni.h>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "silvetonlive/GlideScheduler.h"
#include "silvetonlive/LiveMidiEngine.h"
#include "silvetonlive/MidiIdentity.h"
#include "silvetonlive/TercaScanner.h"
#include <iomanip>
#include <sstream>

using silvetonlive::GlideScheduleConfig;
using silvetonlive::GlideScheduler;
using silvetonlive::HarmonyConfig;
using silvetonlive::HarmonyDegree;
using silvetonlive::HarmonyVoice;
using silvetonlive::IntervalVoice;
using silvetonlive::LiveMidiEngine;
using silvetonlive::MidiPacket;
using silvetonlive::MidiIdentityCodec;
using silvetonlive::PadAction;
using silvetonlive::PadActionType;
using silvetonlive::PortaMode;
using silvetonlive::RibbonConfig;
using silvetonlive::RibbonOutput;
using silvetonlive::RibbonRelease;
using silvetonlive::ScaleType;
using silvetonlive::TercaScanner;

static LiveMidiEngine* fromHandle(jlong handle) {
    return reinterpret_cast<LiveMidiEngine*>(handle);
}

static std::string hexBytes(const std::vector<std::uint8_t>& bytes) {
    std::ostringstream ss;
    ss << std::uppercase << std::hex << std::setfill('0');
    for (auto b : bytes) ss << std::setw(2) << static_cast<int>(b);
    return ss.str();
}

static jobjectArray packetsToJava(JNIEnv* env, const std::vector<MidiPacket>& packets) {
    jclass byteArrayClass = env->FindClass("[B");
    jobjectArray outer = env->NewObjectArray(static_cast<jsize>(packets.size()), byteArrayClass, nullptr);
    for (jsize i = 0; i < static_cast<jsize>(packets.size()); ++i) {
        const auto& b = packets[static_cast<std::size_t>(i)].bytes;
        jbyteArray arr = env->NewByteArray(static_cast<jsize>(b.size()));
        if (!b.empty()) {
            env->SetByteArrayRegion(arr, 0, static_cast<jsize>(b.size()), reinterpret_cast<const jbyte*>(b.data()));
        }
        env->SetObjectArrayElement(outer, i, arr);
        env->DeleteLocalRef(arr);
    }
    return outer;
}

static jbyteArray packetToJava(JNIEnv* env, const MidiPacket& packet) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(packet.bytes.size()));
    if (!packet.bytes.empty()) {
        env->SetByteArrayRegion(arr, 0, static_cast<jsize>(packet.bytes.size()),
                                reinterpret_cast<const jbyte*>(packet.bytes.data()));
    }
    return arr;
}

// Scheduled frame wire format: 8-byte signed timestamp, big-endian, followed by MIDI bytes.
static jobjectArray scheduledPacketsToJava(JNIEnv* env, const std::vector<MidiPacket>& packets) {
    jclass byteArrayClass = env->FindClass("[B");
    jobjectArray outer = env->NewObjectArray(static_cast<jsize>(packets.size()), byteArrayClass, nullptr);
    for (jsize i = 0; i < static_cast<jsize>(packets.size()); ++i) {
        const auto& p = packets[static_cast<std::size_t>(i)];
        std::vector<jbyte> frame(8 + p.bytes.size());
        const std::uint64_t t = static_cast<std::uint64_t>(p.timestampNanos);
        for (int j = 0; j < 8; ++j) frame[static_cast<std::size_t>(j)] = static_cast<jbyte>((t >> (56 - 8 * j)) & 0xFF);
        for (std::size_t j = 0; j < p.bytes.size(); ++j) frame[8 + j] = static_cast<jbyte>(p.bytes[j]);
        jbyteArray arr = env->NewByteArray(static_cast<jsize>(frame.size()));
        env->SetByteArrayRegion(arr, 0, static_cast<jsize>(frame.size()), frame.data());
        env->SetObjectArrayElement(outer, i, arr);
        env->DeleteLocalRef(arr);
    }
    return outer;
}

extern "C" JNIEXPORT jlong JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeCreate(JNIEnv*, jobject) {
    return reinterpret_cast<jlong>(new LiveMidiEngine());
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeDestroy(JNIEnv*, jobject, jlong handle) {
    delete fromHandle(handle);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSelectModel(JNIEnv* env, jobject, jlong handle, jstring modelId) {
    const char* chars = env->GetStringUTFChars(modelId, nullptr);
    const bool ok = fromHandle(handle)->selectModel(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(modelId, chars);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeConfigurePortamento(
    JNIEnv*, jobject, jlong handle, jint mode, jdouble durationMs, jdouble depth, jint steps) {
    auto* e = fromHandle(handle);
    auto cfg = e->portamento().config();
    cfg.mode = static_cast<PortaMode>(mode < 0 ? 0 : (mode > 4 ? 4 : mode));
    cfg.durationMs = durationMs;
    cfg.depth = depth;
    cfg.steps = steps;
    e->portamento().setConfig(cfg);
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetPortamentoEngineEnabled(JNIEnv*, jobject, jlong handle, jboolean enabled) {
    fromHandle(handle)->setPortamentoEngineEnabled(enabled == JNI_TRUE);
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeHardwarePortamentoSwitch(JNIEnv* env, jobject, jlong handle, jboolean enabled, jint channel) {
    return packetsToJava(env, fromHandle(handle)->hardwarePortamentoSwitch(enabled == JNI_TRUE, channel));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetPortamentoEnabled(JNIEnv* env, jobject, jlong handle, jboolean enabled, jint channel) {
    return packetsToJava(env, fromHandle(handle)->setPortamentoEnabled(enabled == JNI_TRUE, channel));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeApplyPortamentoTime(JNIEnv* env, jobject, jlong handle, jint channel) {
    return packetsToJava(env, fromHandle(handle)->applyPortamentoTime(channel));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetPortamentoCalibration(JNIEnv* env, jobject, jlong handle,
    jintArray ccValues, jdoubleArray milliseconds) {
    if (!ccValues || !milliseconds) return JNI_FALSE;
    const jsize n = env->GetArrayLength(ccValues);
    if (n != env->GetArrayLength(milliseconds)) return JNI_FALSE;
    std::vector<jint> cc(static_cast<std::size_t>(n));
    std::vector<jdouble> ms(static_cast<std::size_t>(n));
    if (n > 0) {
        env->GetIntArrayRegion(ccValues, 0, n, cc.data());
        env->GetDoubleArrayRegion(milliseconds, 0, n, ms.data());
    }
    std::vector<silvetonlive::PortamentoCalibrationPoint> points;
    points.reserve(static_cast<std::size_t>(n));
    for (jsize i = 0; i < n; ++i) points.push_back({cc[static_cast<std::size_t>(i)], ms[static_cast<std::size_t>(i)]});
    try {
        fromHandle(handle)->setPortamentoCalibration(std::move(points));
        return JNI_TRUE;
    } catch (...) {
        return JNI_FALSE;
    }
}


extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeBuildGlide(JNIEnv* env, jobject, jlong handle,
    jint startNote, jint endNote, jlong startTimeNanos, jint channel, jint bendRangeSemitones) {
    auto packets = GlideScheduler::build(fromHandle(handle)->portamento(), startNote, endNote,
        startTimeNanos, {channel, bendRangeSemitones, true});
    return scheduledPacketsToJava(env, packets);
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetPitchBendRange(JNIEnv* env, jobject, jlong,
    jint channel, jint semitones) {
    return packetsToJava(env, silvetonlive::rpnPitchBendRange(channel, semitones));
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeConfigureRibbon(JNIEnv*, jobject, jlong handle,
    jint output, jint channel, jint cc, jdouble smoothing, jint releaseMode) {
    RibbonConfig cfg;
    cfg.output = output == 0 ? RibbonOutput::PitchBend : RibbonOutput::ControlChange;
    cfg.channel = channel;
    cfg.cc = cc;
    cfg.smoothing = smoothing;
    cfg.release = static_cast<RibbonRelease>(releaseMode < 0 ? 0 : (releaseMode > 3 ? 3 : releaseMode));
    fromHandle(handle)->ribbon().setConfig(cfg);
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeRibbon(JNIEnv* env, jobject, jlong handle,
    jdouble position, jlong timestampNanos) {
    return packetToJava(env, fromHandle(handle)->ribbon().process(position, timestampNanos));
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeRibbonRelease(JNIEnv* env, jobject, jlong handle,
    jlong timestampNanos) {
    return packetToJava(env, fromHandle(handle)->ribbon().release(timestampNanos));
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetPadBank(JNIEnv*, jobject, jlong handle, jint bank) {
    auto* e = fromHandle(handle);
    e->padBanks().captureFrom(e->pads());
    e->padBanks().setActiveBank(bank);
    e->padBanks().loadInto(e->pads());
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetPad(JNIEnv*, jobject, jlong handle,
    jint index, jint type, jint channel, jint number, jint onValue, jint offValue, jboolean momentary) {
    PadAction action;
    action.type = static_cast<PadActionType>(type < 0 ? 0 : (type > 2 ? 2 : type));
    action.channel = channel;
    action.number = number;
    action.onValue = onValue;
    action.offValue = offValue;
    action.momentary = momentary == JNI_TRUE;
    fromHandle(handle)->pads().setPad(index, action);
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativePressPad(JNIEnv* env, jobject, jlong handle, jint index, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->pads().press(index, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeReleasePad(JNIEnv* env, jobject, jlong handle, jint index, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->pads().release(index, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeFlushPads(JNIEnv* env, jobject, jlong handle, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->flushPads(ts));
}


extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetIntervalVoice(JNIEnv*, jobject, jlong handle,
    jint index, jboolean enabled, jint semitones, jint velocityOffset, jint outputChannel) {
    IntervalVoice v;
    v.enabled = enabled == JNI_TRUE;
    v.semitones = semitones;
    v.velocityOffset = velocityOffset;
    v.outputChannel = outputChannel;
    fromHandle(handle)->intervals().setVoice(index, v);
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeIntervalNoteOn(JNIEnv* env, jobject, jlong handle,
    jint channel, jint note, jint velocity, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->intervals().processNoteOn(channel, note, velocity, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeIntervalNoteOff(JNIEnv* env, jobject, jlong handle,
    jint channel, jint note, jint velocity, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->intervals().processNoteOff(channel, note, velocity, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeFlushIntervals(JNIEnv* env, jobject, jlong handle, jlong ts) {
    return scheduledPacketsToJava(env, fromHandle(handle)->flushIntervals(ts));
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeConfigureHarmony(JNIEnv*, jobject, jlong handle,
    jint tonic, jint scale, jboolean quantize) {
    HarmonyConfig cfg;
    cfg.tonic = tonic;
    cfg.scale = static_cast<ScaleType>(scale < 0 ? 0 : (scale > 7 ? 7 : scale));
    cfg.quantizeNonScaleNotes = quantize == JNI_TRUE;
    fromHandle(handle)->harmony().setConfig(cfg);
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetHarmonyVoice(JNIEnv*, jobject, jlong handle,
    jint index, jboolean enabled, jint degree, jint octaves, jint velocityOffset, jint outputChannel) {
    HarmonyVoice v;
    v.enabled = enabled == JNI_TRUE;
    v.degree = static_cast<HarmonyDegree>(degree < -2 ? -2 : (degree > 7 ? 7 : degree));
    v.octaves = octaves;
    v.velocityOffset = velocityOffset;
    v.outputChannel = outputChannel;
    fromHandle(handle)->harmony().setVoice(index, v);
}

extern "C" JNIEXPORT jint JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeScanTercaChord(JNIEnv* env, jobject, jlong, jintArray notesArray) {
    if (!notesArray || env->GetArrayLength(notesArray) != 3) return -1;
    jint raw[3]{};
    env->GetIntArrayRegion(notesArray, 0, 3, raw);
    const std::array<int, 3> notes{{raw[0], raw[1], raw[2]}};
    const auto r = TercaScanner::scan(notes);
    if (!r.valid) return -1;
    const int degreeCode = r.degree == HarmonyDegree::ThirdDown ? 1 : 0;
    return (r.tonic & 0x0F) | ((static_cast<int>(r.scale) & 0x0F) << 4) | (degreeCode << 8);
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeHarmonyNoteOn(JNIEnv* env, jobject, jlong handle,
    jint channel, jint note, jint velocity, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->harmony().processNoteOn(channel, note, velocity, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeHarmonyNoteOff(JNIEnv* env, jobject, jlong handle,
    jint channel, jint note, jint velocity, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->harmony().processNoteOff(channel, note, velocity, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeFlushHarmony(JNIEnv* env, jobject, jlong handle, jlong ts) {
    return scheduledPacketsToJava(env, fromHandle(handle)->flushHarmony(ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativePortaBridgeNoteOn(JNIEnv* env, jobject, jlong handle,
    jint outputChannel, jint note, jint velocity, jlong ts, jint bendRangeSemitones) {
    return scheduledPacketsToJava(env, fromHandle(handle)->portaBridgeNoteOn(
        outputChannel, note, velocity, ts, bendRangeSemitones));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativePortaBridgeNoteOff(JNIEnv* env, jobject, jlong handle,
    jint outputChannel, jint note, jint velocity, jlong ts) {
    return scheduledPacketsToJava(env, fromHandle(handle)->portaBridgeNoteOff(
        outputChannel, note, velocity, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeResetPortaBridge(JNIEnv* env, jobject, jlong handle, jlong ts) {
    return scheduledPacketsToJava(env, fromHandle(handle)->resetPortaBridge(ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeResetPortaBridgeChannel(JNIEnv* env, jobject, jlong handle,
    jint outputChannel, jlong ts) {
    return scheduledPacketsToJava(env, fromHandle(handle)->resetPortaBridgeChannel(outputChannel, ts));
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeIdentityRequest(JNIEnv* env, jobject, jlong handle) {
    return packetToJava(env, fromHandle(handle)->identityRequest());
}

extern "C" JNIEXPORT jstring JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeParseIdentityReply(JNIEnv* env, jobject, jlong, jbyteArray bytes) {
    if (!bytes) return nullptr;
    const jsize n = env->GetArrayLength(bytes);
    if (n <= 0) return nullptr;
    std::vector<jbyte> temp(static_cast<std::size_t>(n));
    env->GetByteArrayRegion(bytes, 0, n, temp.data());
    std::vector<std::uint8_t> data;
    data.reserve(static_cast<std::size_t>(n));
    for (jbyte b : temp) data.push_back(static_cast<std::uint8_t>(b));
    const auto id = MidiIdentityCodec::parseReply(data);
    if (!id.valid) return nullptr;
    const std::string name = id.manufacturerName.empty() ? "UNKNOWN" : id.manufacturerName;
    const std::string packed = name + "|" + hexBytes(id.manufacturerId) + "|" +
        hexBytes(id.familyCode) + "|" + hexBytes(id.modelNumber) + "|" + hexBytes(id.version);
    return env->NewStringUTF(packed.c_str());
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativePanic(JNIEnv* env, jobject, jlong handle, jboolean allChannels, jint channel) {
    return packetsToJava(env, fromHandle(handle)->panic(allChannels == JNI_TRUE, channel));
}
