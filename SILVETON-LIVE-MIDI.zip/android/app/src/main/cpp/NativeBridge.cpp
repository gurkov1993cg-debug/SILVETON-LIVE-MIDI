#include <jni.h>
#include <cstdint>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
#include "silvetonlive/LiveMidiEngine.h"
#include "silvetonlive/MidiIdentity.h"

using silvetonlive::LiveMidiEngine;
using silvetonlive::MidiIdentityCodec;
using silvetonlive::MidiPacket;
using silvetonlive::PadAction;
using silvetonlive::PadActionType;
using silvetonlive::RibbonConfig;
using silvetonlive::RibbonOutput;
using silvetonlive::RibbonRelease;

static LiveMidiEngine* fromHandle(jlong handle) {
    return reinterpret_cast<LiveMidiEngine*>(handle);
}

static std::string hexBytes(const std::vector<std::uint8_t>& bytes) {
    std::ostringstream ss;
    ss << std::uppercase << std::hex << std::setfill('0');
    for (auto b : bytes) ss << std::setw(2) << static_cast<int>(b);
    return ss.str();
}

static jobjectArray packetsToJava(JNIEnv* env, const std::vector<MidiPacket>& packets) {
    jclass byteArrayClass = env->FindClass("[B");
    jobjectArray outer = env->NewObjectArray(static_cast<jsize>(packets.size()), byteArrayClass, nullptr);
    for (jsize i = 0; i < static_cast<jsize>(packets.size()); ++i) {
        const auto& b = packets[static_cast<std::size_t>(i)].bytes;
        jbyteArray arr = env->NewByteArray(static_cast<jsize>(b.size()));
        if (!b.empty()) {
            env->SetByteArrayRegion(arr, 0, static_cast<jsize>(b.size()), reinterpret_cast<const jbyte*>(b.data()));
        }
        env->SetObjectArrayElement(outer, i, arr);
        env->DeleteLocalRef(arr);
    }
    return outer;
}

static jbyteArray packetToJava(JNIEnv* env, const MidiPacket& packet) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(packet.bytes.size()));
    if (!packet.bytes.empty()) {
        env->SetByteArrayRegion(arr, 0, static_cast<jsize>(packet.bytes.size()), reinterpret_cast<const jbyte*>(packet.bytes.data()));
    }
    return arr;
}

extern "C" JNIEXPORT jlong JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeCreate(JNIEnv*, jobject) {
    return reinterpret_cast<jlong>(new LiveMidiEngine());
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeDestroy(JNIEnv*, jobject, jlong handle) {
    delete fromHandle(handle);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSelectModel(JNIEnv* env, jobject, jlong handle, jstring modelId) {
    const char* chars = env->GetStringUTFChars(modelId, nullptr);
    const bool ok = fromHandle(handle)->selectModel(chars ? chars : "");
    if (chars) env->ReleaseStringUTFChars(modelId, chars);
    return ok ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeConfigureRibbon(JNIEnv*, jobject, jlong handle,
    jint output, jint channel, jint cc, jdouble smoothing, jint releaseMode) {
    RibbonConfig cfg;
    cfg.output = output == 0 ? RibbonOutput::PitchBend : RibbonOutput::ControlChange;
    cfg.channel = channel;
    cfg.cc = cc;
    cfg.smoothing = smoothing;
    cfg.release = static_cast<RibbonRelease>(releaseMode < 0 ? 0 : (releaseMode > 3 ? 3 : releaseMode));
    fromHandle(handle)->ribbon().setConfig(cfg);
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeRibbon(JNIEnv* env, jobject, jlong handle,
    jdouble position, jlong timestampNanos) {
    return packetToJava(env, fromHandle(handle)->ribbon().process(position, timestampNanos));
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeRibbonRelease(JNIEnv* env, jobject, jlong handle,
    jlong timestampNanos) {
    return packetToJava(env, fromHandle(handle)->ribbon().release(timestampNanos));
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetPadBank(JNIEnv*, jobject, jlong handle, jint bank) {
    auto* e = fromHandle(handle);
    e->padBanks().captureFrom(e->pads());
    e->padBanks().setActiveBank(bank);
    e->padBanks().loadInto(e->pads());
}

extern "C" JNIEXPORT void JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeSetPad(JNIEnv*, jobject, jlong handle,
    jint index, jint type, jint channel, jint number, jint onValue, jint offValue, jboolean momentary) {
    PadAction action;
    action.type = static_cast<PadActionType>(type < 0 ? 0 : (type > 2 ? 2 : type));
    action.channel = channel;
    action.number = number;
    action.onValue = onValue;
    action.offValue = offValue;
    action.momentary = momentary == JNI_TRUE;
    fromHandle(handle)->pads().setPad(index, action);
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativePressPad(JNIEnv* env, jobject, jlong handle, jint index, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->pads().press(index, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeReleasePad(JNIEnv* env, jobject, jlong handle, jint index, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->pads().release(index, ts));
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeFlushPads(JNIEnv* env, jobject, jlong handle, jlong ts) {
    return packetsToJava(env, fromHandle(handle)->flushPads(ts));
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeIdentityRequest(JNIEnv* env, jobject, jlong handle) {
    return packetToJava(env, fromHandle(handle)->identityRequest());
}

extern "C" JNIEXPORT jstring JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativeParseIdentityReply(JNIEnv* env, jobject, jlong, jbyteArray bytes) {
    if (!bytes) return nullptr;
    const jsize n = env->GetArrayLength(bytes);
    if (n <= 0) return nullptr;
    std::vector<jbyte> temp(static_cast<std::size_t>(n));
    env->GetByteArrayRegion(bytes, 0, n, temp.data());
    std::vector<std::uint8_t> data;
    data.reserve(static_cast<std::size_t>(n));
    for (jbyte b : temp) data.push_back(static_cast<std::uint8_t>(b));
    const auto id = MidiIdentityCodec::parseReply(data);
    if (!id.valid) return nullptr;
    const std::string name = id.manufacturerName.empty() ? "UNKNOWN" : id.manufacturerName;
    const std::string packed = name + "|" + hexBytes(id.manufacturerId) + "|" +
        hexBytes(id.familyCode) + "|" + hexBytes(id.modelNumber) + "|" + hexBytes(id.version);
    return env->NewStringUTF(packed.c_str());
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_bg_silveton_live_midi_NativeMidiCore_nativePanic(JNIEnv* env, jobject, jlong handle, jboolean allChannels, jint channel) {
    return packetsToJava(env, fromHandle(handle)->panic(allChannels == JNI_TRUE, channel));
}
