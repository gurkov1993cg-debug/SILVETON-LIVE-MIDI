import bg.silveton.live.midi.*
import kotlin.math.abs

private fun assertTrue(value: Boolean, message: String) {
    if (!value) error(message)
}

private fun assertEq(expected: Any?, actual: Any?, message: String) {
    if (expected != actual) error("$message expected=$expected actual=$actual")
}

fun main() {
    val t = TercaEngine()

    val cMaj = t.scan(intArrayOf(60, 64, 67)) ?: error("C major scan failed")
    assertEq(0, cMaj.tonic, "C major tonic")
    assertEq(ScaleType.MAJOR, cMaj.scale, "C major scale")
    assertEq(HarmonyDegree.THIRD, cMaj.degree, "C major direction")

    val cMajDown = t.scan(intArrayOf(64, 67, 72)) ?: error("C major inversion scan failed")
    assertEq(0, cMajDown.tonic, "C major inversion tonic")
    assertEq(HarmonyDegree.THIRD_DOWN, cMajDown.degree, "root-on-top must select down")

    val cMin = t.scan(intArrayOf(60, 63, 67)) ?: error("C minor scan failed")
    assertEq(ScaleType.HARMONIC_MINOR, cMin.scale, "minor triad scale")

    val cHijaz = t.scan(intArrayOf(60, 61, 64)) ?: error("C Hijaz scan failed")
    assertEq(ScaleType.HIJAZ, cHijaz.scale, "Hijaz scan")

    assertTrue(t.scan(intArrayOf(60, 62, 67)) == null, "invalid scan must reject")

    for (scale in ScaleType.entries) {
        for (tonic in 0..11) {
            for (note in 60..83) {
                val up = TercaEngine.thirdInterval(note, tonic, scale, HarmonyDegree.THIRD)
                val down = TercaEngine.thirdInterval(note, tonic, scale, HarmonyDegree.THIRD_DOWN)
                assertTrue(up == 3 || up == 4, "up third escaped 3/4: $scale tonic=$tonic note=$note interval=$up")
                assertTrue(down == -3 || down == -4, "down third escaped -3/-4: $scale tonic=$tonic note=$note interval=$down")
            }
        }
    }

    for (duration in listOf(10.0, 20.0, 35.0, 60.0, 100.0, 500.0)) {
        val half1 = SmoothPortamento.glideSemitonesAt(1.0, duration / 2.0, duration)
        val half12 = SmoothPortamento.glideSemitonesAt(12.0, duration / 2.0, duration)
        assertTrue(abs(half1 / 1.0 - half12 / 12.0) < 1e-12, "normalized glide differs by interval")
        assertEq(0.0, SmoothPortamento.glideSemitonesAt(1.0, duration, duration), "1-semitone finish")
        assertEq(0.0, SmoothPortamento.glideSemitonesAt(12.0, duration, duration), "12-semitone finish")
    }

    assertEq(0, SmoothPortamento.semitonesToBendOffset(0.0, 12.0), "PB center offset")
    assertEq(8191, SmoothPortamento.semitonesToBendOffset(12.0, 12.0), "+12 PB max")
    assertEq(-8192, SmoothPortamento.semitonesToBendOffset(-12.0, 12.0), "-12 PB min")

    val rpn = SmoothPortamento.pitchBendSensitivityMessages(0, 12)
    assertEq(6, rpn.size, "RPN message count")
    assertEq(101, rpn[0][1].toInt() and 0xFF, "RPN MSB CC")
    assertEq(100, rpn[1][1].toInt() and 0xFF, "RPN LSB CC")
    assertEq(6, rpn[2][1].toInt() and 0xFF, "Data Entry MSB CC")
    assertEq(12, rpn[2][2].toInt() and 0xFF, "PB range value")

    println("LOGIC_SELF_TEST_OK")
}
