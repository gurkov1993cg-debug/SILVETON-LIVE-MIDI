#include "../app/src/main/cpp/NativeMidiEngine.h"
#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    silveton::NativeMidiEngine e;

    auto m = e.handleMidiIn(0x90, 60, 100);
    assert(m.status == 0x90 && m.data1 == 60 && m.data2 == 100);
    assert(e.isActive(0, 60));
    assert(e.lastNote(0) == 60);

    // Critical regression: Note On velocity 0 is Note Off.
    m = e.handleMidiIn(0x90, 60, 0);
    assert(m.status == 0x90 && m.data1 == 60 && m.data2 == 0);
    assert(!e.isActive(0, 60));
    assert(e.lastNote(0) == -1);

    e.handleMidiIn(0x91, 64, 100);
    assert(e.isActive(1, 64));
    e.handleMidiIn(0xB1, 123, 0);
    assert(!e.isActive(1, 64));
    assert(e.lastNote(1) == -1);


    e.handleMidiIn(0x92, 64, 100);
    assert(e.isActive(2, 64));
    e.handleMidiIn(0x92, 64, 0);
    assert(!e.isActive(2, 64));
    assert(e.lastNote(2) == -1);

    std::cout << "NativeMidiEngine tests PASS\n";
}
