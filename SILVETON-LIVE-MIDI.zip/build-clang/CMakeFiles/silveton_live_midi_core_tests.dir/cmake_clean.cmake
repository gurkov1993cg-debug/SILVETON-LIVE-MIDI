file(REMOVE_RECURSE
  "CMakeFiles/silveton_live_midi_core_tests.dir/link.d"
  "CMakeFiles/silveton_live_midi_core_tests.dir/tests/CoreTests.cpp.o"
  "CMakeFiles/silveton_live_midi_core_tests.dir/tests/CoreTests.cpp.o.d"
  "silveton_live_midi_core_tests"
  "silveton_live_midi_core_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/silveton_live_midi_core_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
