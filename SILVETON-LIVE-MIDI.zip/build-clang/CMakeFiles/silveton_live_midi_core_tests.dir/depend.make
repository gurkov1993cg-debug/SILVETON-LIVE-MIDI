# Empty dependencies file for silveton_live_midi_core_tests.
# This may be replaced when dependencies are built.
