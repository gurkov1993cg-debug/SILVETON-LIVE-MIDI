file(REMOVE_RECURSE
  "libsilveton_live_midi_core.a"
)
