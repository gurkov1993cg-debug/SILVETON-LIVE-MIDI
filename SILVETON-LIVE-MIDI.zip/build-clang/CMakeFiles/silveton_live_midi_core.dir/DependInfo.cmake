
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/data/SilvetonLiveMIDI/core/src/GlideScheduler.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/GlideScheduler.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/GlideScheduler.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/HarmonyEngine.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/HarmonyEngine.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/HarmonyEngine.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/IntervalEngine.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/IntervalEngine.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/IntervalEngine.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/LatencyTracker.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/LatencyTracker.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/LatencyTracker.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/LiveMidiEngine.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/LiveMidiEngine.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/LiveMidiEngine.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/MidiIdentity.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/MidiIdentity.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/MidiIdentity.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/MidiParser.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/MidiParser.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/MidiParser.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/ModelProfile.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/ModelProfile.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/ModelProfile.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/MonophonicPortaProcessor.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/MonophonicPortaProcessor.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/MonophonicPortaProcessor.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/PadBank.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/PadBank.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/PadBank.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/PadEngine.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/PadEngine.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/PadEngine.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/PanicEngine.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/PanicEngine.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/PanicEngine.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/PortamentoCalibration.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/PortamentoCalibration.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/PortamentoCalibration.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/PortamentoEngine.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/PortamentoEngine.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/PortamentoEngine.cpp.o.d"
  "/mnt/data/SilvetonLiveMIDI/core/src/RibbonEngine.cpp" "CMakeFiles/silveton_live_midi_core.dir/src/RibbonEngine.cpp.o" "gcc" "CMakeFiles/silveton_live_midi_core.dir/src/RibbonEngine.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
