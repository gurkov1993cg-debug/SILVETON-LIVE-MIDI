# Empty compiler generated dependencies file for silveton_live_midi_core.
# This may be replaced when dependencies are built.
